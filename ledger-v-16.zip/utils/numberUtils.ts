
/**
 * Converts English digits in a string or number to Bengali digits, preserving dots and spaces.
 */
export const toBengaliDigits = (input: string | number | undefined | null): string => {
  if (input === undefined || input === null) return '';
  const bengaliDigits: { [key: string]: string } = {
    '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪',
    '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯'
  };
  return input.toString().replace(/[0-9]/g, (digit) => bengaliDigits[digit]);
};

/**
 * Converts Bengali digits in a string back to English digits.
 */
export const toEnglishDigits = (input: string | number | undefined | null): string => {
  if (input === undefined || input === null) return '';
  const str = input.toString();
  const englishDigits: { [key: string]: string } = {
    '০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4',
    '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9'
  };
  return str.replace(/[০-৯]/g, (digit) => englishDigits[digit]);
};

/**
 * Parses a string that may contain Bengali or English digits into a number.
 */
export const parseBengaliNumber = (input: string | number | undefined | null): number => {
  if (input === undefined || input === null || input === '') return 0;
  let eng = toEnglishDigits(input).trim();
  if (eng.includes(',') && eng.includes('.')) {
    eng = eng.replace(/,/g, '');
  } else if (eng.includes(',')) {
    eng = eng.replace(/,/g, '.');
  }
  const englishString = eng.replace(/[^0-9.]/g, '');
  const parsed = parseFloat(englishString);
  return isNaN(parsed) ? 0 : parsed;
};

/**
 * Formats a number with commas and converts to Bengali digits for display only.
 * By default formats as a round integer (no .০০), or optional decimals if specified.
 */
export const formatBengaliAmount = (num: number, includeDecimals: boolean = false): string => {
  if (num === 0) return '০';
  const formatted = includeDecimals
    ? num.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
    : Math.round(num).toLocaleString('en-IN', { maximumFractionDigits: 0 });
  return toBengaliDigits(formatted);
};

/**
 * Formats an ISO date string (YYYY-MM-DD or YYYY/MM/DD) to Bengali DD/MM/YYYY format.
 */
export const formatDateBN = (iso: string | undefined | null): string => {
  if (!iso || iso === '0000-00-00' || iso.startsWith('0000')) return '';
  const eng = toEnglishDigits(iso).trim();
  
  // If it's a full ISO string or contains time info
  if (eng.includes('T') || eng.includes(':')) {
    try {
      const date = new Date(eng);
      if (!isNaN(date.getTime())) {
        const d = date.getDate().toString().padStart(2, '0');
        const m = (date.getMonth() + 1).toString().padStart(2, '0');
        const y = date.getFullYear().toString();
        return toBengaliDigits(`${d}/${m}/${y}`);
      }
    } catch (e) {}
  }

  // If match YYYY-MM-DD or YYYY/MM/DD
  const ymdMatch = eng.match(/^(\d{4})[-\/\.](0?[1-9]|1[0-2])[-\/\.](0?[1-9]|[12]\d|3[01])$/);
  if (ymdMatch) {
    const [, y, m, d] = ymdMatch;
    return toBengaliDigits(`${d.padStart(2, '0')}/${m.padStart(2, '0')}/${y}`);
  }

  // If match DD-MM-YYYY or DD/MM/YYYY
  const dmyMatch = eng.match(/^(0?[1-9]|[12]\d|3[01])[-\/\.](0?[1-9]|1[0-2])[-\/\.](\d{2,4})$/);
  if (dmyMatch) {
    let [, d, m, y] = dmyMatch;
    if (y.length === 2) y = '20' + y;
    return toBengaliDigits(`${d.padStart(2, '0')}/${m.padStart(2, '0')}/${y}`);
  }
  
  // If it's ISO YYYY-MM-DD with extra text
  const parts = eng.split('-');
  if (parts.length === 3 && parts[0].length === 4) {
    const day = parts[2].split('T')[0].split(' ')[0].padStart(2, '0');
    const month = parts[1].padStart(2, '0');
    return toBengaliDigits(`${day}/${month}/${parts[0]}`);
  }
  return toBengaliDigits(iso);
};