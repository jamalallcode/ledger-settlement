import { useMemo, useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { ChevronLeft, ChevronRight, Printer, Mail, Calendar, RotateCcw, Search, X, User, ChevronDown, Check, Sparkles, BarChart3, FileSpreadsheet, FileText } from 'lucide-react';
import React from 'react';
import { toBengaliDigits, toEnglishDigits, formatDateBN } from '../utils/numberUtils';
import { OFFICE_HEADER } from '../constants';
import { format, startOfMonth, endOfMonth, addDays, isBefore, subMonths, parseISO } from 'date-fns';
import { parseManualDate } from '../utils/dateValidation';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import LetterDetailsModal from './LetterDetailsModal';
import { getReceivers } from './ReceiverManagement';
import { normalizeName as normNameUtils, resolveCanonicalName, KNOWN_ALIASES } from '../utils/nameUtils';
import { getCleanLetterTypeDisplay } from '../utils/branchUtils';

interface DDSirCorrespondenceReturnProps {
  entries: any[];
  activeCycle: { start: Date; end: Date; label: string };
  onBack: () => void;
  isLayoutEditable?: boolean;
  IDBadge: React.FC<{ id: string }>;
  showFilters: boolean;
}

const BENGALI_MONTHS = [
  'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
  'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
];

const BENGALI_WEEKDAYS = ['শনি', 'রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র'];

const DDSirCorrespondenceReturn: React.FC<DDSirCorrespondenceReturnProps> = ({ 
  entries, 
  activeCycle, 
  onBack, 
  isLayoutEditable,
  IDBadge,
  showFilters
}) => {
  const [filterBranch, setFilterBranch] = useState('সকল');
  const [filterAuditor, setFilterAuditor] = useState('সকল');
  const [showStats, setShowStats] = useState(false);
  const [isAuditorDropdownOpen, setIsAuditorDropdownOpen] = useState(false);
  const [isBranchDropdownOpen, setIsBranchDropdownOpen] = useState(false);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [isStatsOpen, setIsStatsOpen] = useState(false);
  const auditorDropdownRef = useRef<HTMLDivElement>(null);
  const branchDropdownRef = useRef<HTMLDivElement>(null);
  const calendarRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);

  const downloadExcel = () => {
    const tables = document.querySelectorAll('table');
    if (tables.length === 0) return;

    let tablesHtml = '';
    tables.forEach((table, tableIdx) => {
      const clonedTable = table.cloneNode(true) as HTMLTableElement;
      const interactiveElements = clonedTable.querySelectorAll('.no-print, button, svg, input, select');
      interactiveElements.forEach(el => el.remove());
      
      tablesHtml += `
        <div style="margin-bottom: 40px;">
          ${tableIdx > 0 ? '<br><hr><br>' : ''}
          ${clonedTable.outerHTML}
        </div>
      `;
    });

    const filename = `চিঠিপত্র_সংক্রান্ত_মাসিক_রিটার্ন_ডিডি_স্যার_${format(new Date(), 'yyyy-MM-dd')}.xls`;

    const template = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
      <head>
        <meta http-equiv="content-type" content="application/vnd.ms-excel; charset=UTF-8">
        <!--[if gte mso 9]>
        <xml>
          <x:ExcelWorkbook>
            <x:ExcelWorksheets>
              <x:ExcelWorksheet>
                <x:Name>রিপোর্ট</x:Name>
                <x:WorksheetOptions>
                  <x:DisplayGridlines/>
                </x:WorksheetOptions>
              </x:ExcelWorksheet>
            </x:ExcelWorksheets>
          </x:ExcelWorkbook>
        </xml>
        <![endif]-->
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif, 'Hind Siliguri', sans-serif; }
          table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }
          th, td { border: 1px solid #cbd5e1 !important; padding: 8px 12px !important; text-align: center; font-size: 11px; vertical-align: middle; }
          th { background-color: #f1f5f9 !important; color: #0f172a !important; font-weight: bold !important; }
          .bg-slate-200, thead, tfoot { background-color: #e2e8f0 !important; font-weight: bold !important; }
          .bg-sky-100 { background-color: #e0f2fe !important; }
          .bg-amber-50 { background-color: #fef3c7 !important; }
          .bg-black { background-color: #090d16 !important; color: #ffffff !important; }
          tfoot td { background-color: #0f172a !important; color: #ffffff !important; font-weight: bold !important; }
        </style>
      </head>
      <body>
        <h2 style="text-align: center; margin-bottom: 20px; color: #1e3a8a;">চিঠিপত্র সংক্রান্ত মাসিক রিটার্ন (ডিডি স্যার)</h2>
        ${tablesHtml}
      </body>
      </html>
    `;

    const blob = new Blob([template], { type: 'application/vnd.ms-excel;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const [receiverImages, setReceiverImages] = useState<Record<string, string>>({});
  const [receiverDesignations, setReceiverDesignations] = useState<Record<string, string>>({});
  const [receiversList, setReceiversList] = useState<any[]>([]);

  const normalizeName = (name: string | null | undefined): string => {
    return normNameUtils(name) || 'অনির্ধারিত';
  };

  const getDisplayName = (name: string | null | undefined, fallbackRawName?: string): string => {
    if (!name && !fallbackRawName) return 'অনির্ধারিত';
    const raw = (name || fallbackRawName || '').trim();
    if (!raw) return 'অনির্ধারিত';

    const resolved = resolveCanonicalName(raw, receiversList);
    if (resolved && resolved !== 'অনির্ধারিত') {
      return resolved.replace(/শাহ্রিন/g, 'শাহরিন').replace(/শাম্মীমা/g, 'শামীমা');
    }

    try {
      const recs = getReceivers();
      const resolvedRec = resolveCanonicalName(raw, recs);
      if (resolvedRec && resolvedRec !== 'অনির্ধারিত') {
        return resolvedRec.replace(/শাহ্রিন/g, 'শাহরিন').replace(/শাম্মীমা/g, 'শামীমা');
      }
    } catch (e) {}

    const directResolved = resolveCanonicalName(raw);
    if (directResolved && directResolved !== 'অনির্ধারিত') {
      return directResolved.replace(/শাহ্রিন/g, 'শাহরিন').replace(/শাম্মীমা/g, 'শামীমা');
    }

    const norm = normalizeName(raw);
    if (norm === 'অনির্ধারিত' || !norm) return 'অনির্ধারিত';

    let match = receiversList.find(r => normalizeName(r.name) === norm);
    if (!match) {
      match = receiversList.find(r => {
        const rNorm = normalizeName(r.name);
        return rNorm && (rNorm.includes(norm) || norm.includes(rNorm));
      });
    }
    let finalName = match && match.name ? match.name : (fallbackRawName || name || 'অনির্ধারিত');
    return finalName.replace(/শাহ্রিন/g, 'শাহরিন').replace(/শাম্মীমা/g, 'শামীমা');
  };

  const getDisplayDesignation = (name: string | null | undefined, fallbackRawName?: string): string => {
    if (!name && !fallbackRawName) return 'অডিটর';
    const norm = normalizeName(name || fallbackRawName);
    const match = receiversList.find(r => normalizeName(r.name) === norm);
    if (match && match.designation) return match.designation;
    const key = fallbackRawName || name || '';
    return receiverDesignations[key] || receiverDesignations[norm] || "অডিটর";
  };

  const getDisplayImage = (name: string | null | undefined, fallbackRawName?: string): string | null => {
    if (!name && !fallbackRawName) return null;
    const norm = normalizeName(name || fallbackRawName);
    const match = receiversList.find(r => normalizeName(r.name) === norm);
    if (match) return match.image || null;
    const key = fallbackRawName || name || '';
    return receiverImages[key] || receiverImages[norm] || null;
  };

  useEffect(() => {
    const fetchReceiverProfiles = async () => {
      const imagesMap: Record<string, string> = {};
      const designationsMap: Record<string, string> = {};
      let finalReceivers: any[] = [];

      const addProfile = (name: string, img: string | null, desig: string | null) => {
        if (!name) return;
        const nameTrim = name.trim();
        const norm = normalizeName(nameTrim);
        if (img) {
          imagesMap[nameTrim] = img;
          imagesMap[norm] = img;
        }
        if (desig) {
          designationsMap[nameTrim] = desig;
          designationsMap[norm] = desig;
        }
      };

      const getCleanBranch = (type: string | null | undefined): string => {
        if (!type) return 'এসএফআই';
        if (type.includes('প্রশাসন') || type === 'ADMIN' || type === 'admin') return 'প্রশাসন';
        if (type.includes('নন') || type.toUpperCase().includes('NON')) return 'নন এসএফআই';
        return 'এসএফআই';
      };

      const getInactiveList = (): string[] => {
        try {
          const saved = localStorage.getItem('ledger_inactive_receivers_v1');
          return saved ? JSON.parse(saved) : [];
        } catch {
          return [];
        }
      };

      // 1. Fetch from local storage keys FIRST (instant synchronous populating)
      const localKeys = [
        { key: 'ledger_correspondence_receivers_admin', branch: 'প্রশাসন' },
        { key: 'ledger_correspondence_receivers_sfi', branch: 'এসএফআই' },
        { key: 'ledger_correspondence_receivers_nonsfi', branch: 'নন এসএফআই' }
      ];
      localKeys.forEach(({ key, branch }) => {
        try {
          const saved = localStorage.getItem(key);
          if (saved) {
            const items = JSON.parse(saved);
            if (Array.isArray(items)) {
              items.forEach((item: any) => {
                addProfile(item.name, item.image, item.designation);
                const b = getCleanBranch(item.para_type || branch);
                const compositeKey = normalizeName(item.name) + '_' + b;
                finalReceivers.push({
                  ...item,
                  para_type: b,
                  source: 'local'
                });
              });
            }
          }
        } catch (e) {
          console.error("Error parsing local receivers in DD Sir Return:", e);
        }
      });

      // 2. Fetch from database (Supabase) if configured and merge
      if (isSupabaseConfigured) {
        try {
          const { data: dbReceivers } = await supabase
            .from('receivers')
            .select('*');
          if (dbReceivers) {
            dbReceivers.forEach(r => {
              addProfile(r.name, r.image, r.designation);
              const b = getCleanBranch(r.para_type);
              const compositeKey = normalizeName(r.name) + '_' + b;
              const hasSameIdInBranch = r.id && finalReceivers.some(existing => existing.id === r.id && getCleanBranch(existing.para_type) === b);
              if (!hasSameIdInBranch) {
                finalReceivers.push({
                  ...r,
                  name: r.name ? r.name.trim() : '',
                  source: 'database'
                });
              }
            });
          }
        } catch (err) {
          console.error("Error fetching db receivers in DD Sir Return:", err);
        }
      }

      const inactiveListRaw = getInactiveList();
      const inactiveKeysSet = new Set(inactiveListRaw.map(item => normalizeName(item)));

      const receiversWithCounts = finalReceivers.map(r => {
        const b = getCleanBranch(r.para_type);
        const norm = normalizeName(r.name);
        const compKey = `${norm}_${b}`;
        
        let is_active = r.is_active;
        if (is_active === undefined || is_active === null) {
          if (inactiveKeysSet.has(compKey)) {
            is_active = false;
          } else if (inactiveKeysSet.has(norm)) {
            const hasBranchSpecificKey = Array.from(inactiveKeysSet).some(k => k.startsWith(`${norm}_`));
            is_active = !hasBranchSpecificKey;
          } else {
            is_active = true;
          }
        }

        return {
          ...r,
          para_type: b,
          is_active
        };
      });

      setReceiverImages(imagesMap);
      setReceiverDesignations(designationsMap);
      setReceiversList(receiversWithCounts);
    };

    fetchReceiverProfiles();
  }, [entries]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (auditorDropdownRef.current && !auditorDropdownRef.current.contains(e.target as Node)) {
        setIsAuditorDropdownOpen(false);
      }
      if (branchDropdownRef.current && !branchDropdownRef.current.contains(e.target as Node)) {
        setIsBranchDropdownOpen(false);
      }
      if (calendarRef.current && !calendarRef.current.contains(e.target as Node)) {
        setIsCalendarOpen(false);
      }
      if (statsRef.current && !statsRef.current.contains(e.target as Node)) {
        setIsStatsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const auditorOptions = useMemo(() => {
    // 1. Get active auditors of selected branch
    let activeInBranch = receiversList.filter(r => r.is_active !== false);
    if (filterBranch !== 'সকল') {
      activeInBranch = activeInBranch.filter(r => r.para_type === filterBranch);
    }

    let extraRecs: any[] = [];
    try {
      extraRecs = getReceivers().filter(r => r.is_active !== false);
      if (filterBranch !== 'সকল') {
        extraRecs = extraRecs.filter(r => r.para_type === filterBranch);
      }
    } catch (e) {}

    const combinedRecs = [...activeInBranch, ...extraRecs];
    const activeNames = combinedRecs.map(r => getDisplayName(r.name)).filter(name => name !== 'অনির্ধারিত' && name !== '');

    let finalDisplayNames: string[];

    if (filterBranch === 'সকল') {
      const entriesAuditors = (entries || []).map(e => getDisplayName(e.receiverName || e.presentedToName)).filter(name => name !== 'অনির্ধারিত' && name !== '');
      finalDisplayNames = Array.from(new Set([...activeNames, ...entriesAuditors]));
    } else {
      const branchEntries = (entries || []).filter(e => e.paraType === filterBranch);
      const entriesAuditors = branchEntries.map(e => getDisplayName(e.receiverName || e.presentedToName)).filter(name => name !== 'অনির্ধারিত' && name !== '');
      finalDisplayNames = Array.from(new Set([...activeNames, ...entriesAuditors]));
    }

    const displayUnique = finalDisplayNames.sort((a, b) => a.localeCompare(b));

    return ['সকল', ...displayUnique];
  }, [entries, filterBranch, receiversList]);

  useEffect(() => {
    if (filterAuditor !== 'সকল' && !auditorOptions.includes(filterAuditor)) {
      setFilterAuditor('সকল');
    }
  }, [filterBranch, auditorOptions, filterAuditor]);

  const reportingLimitDate = useMemo(() => {
    const today = new Date();
    const currentMonthStart = new Date(today.getFullYear(), today.getMonth(), 1);
    const selectedMonthStart = new Date(activeCycle.end.getFullYear(), activeCycle.end.getMonth(), 1);
    
    if (selectedMonthStart.getTime() > currentMonthStart.getTime()) {
      // Next month selected: show up to today (Current Status)
      return today;
    } else if (selectedMonthStart.getTime() === currentMonthStart.getTime()) {
      // Current month selected: show up to today
      return today;
    } else {
      // Past month selected: show up to the end of that month
      return new Date(activeCycle.end.getFullYear(), activeCycle.end.getMonth() + 1, 0, 23, 59, 59);
    }
  }, [activeCycle.start]);

  const [startDate, setStartDate] = useState<Date>(() => new Date(2025, 5, 16));
  const [endDate, setEndDate] = useState<Date>(() => new Date());
  const [selectingDateType, setSelectingDateType] = useState<'start' | 'end'>('start');
  const [selectedReportingDate, setSelectedReportingDate] = useState<string>(format(new Date(), 'yyyy-MM-dd'));
  const [currentViewDate, setCurrentViewDate] = useState<Date>(new Date());
  const [manualStartDate, setManualStartDate] = useState<string>(() => toBengaliDigits(format(new Date(2025, 5, 16), 'dd/MM/yyyy')));
  const [manualEndDate, setManualEndDate] = useState<string>(() => toBengaliDigits(format(new Date(), 'dd/MM/yyyy')));

  useEffect(() => {
    setManualStartDate(toBengaliDigits(format(startDate, 'dd/MM/yyyy')));
  }, [startDate]);

  useEffect(() => {
    setManualEndDate(toBengaliDigits(format(endDate, 'dd/MM/yyyy')));
  }, [endDate]);

  useEffect(() => {
    const now = new Date();
    setEndDate(now);
    setSelectedReportingDate(format(now, 'yyyy-MM-dd'));
    setCurrentViewDate(now);
  }, [reportingLimitDate]);

  const parseDate = (dateStr: string | null | undefined) => {
    if (!dateStr) return null;
    const cleanStr = toEnglishDigits(dateStr).trim();
    // Support DD/MM/YYYY, DD-MM-YYYY, DD.MM.YYYY AND YYYY-MM-DD
    const parts = cleanStr.split(/[-/.]/);
    if (parts.length === 3) {
      let d, m, y;
      if (parts[0].length === 4) {
        // YYYY-MM-DD
        y = parseInt(parts[0]);
        m = parseInt(parts[1]) - 1;
        d = parseInt(parts[2]);
      } else {
        // DD/MM/YYYY
        d = parseInt(parts[0]);
        m = parseInt(parts[1]) - 1;
        y = parseInt(parts[2]);
      }
      const fullY = y < 100 ? 2000 + y : y;
      const date = new Date(fullY, m, d);
      if (!isNaN(date.getTime())) {
        // Return date normalized to midnight
        return new Date(date.getFullYear(), date.getMonth(), date.getDate());
      }
    }
    const fallback = new Date(cleanStr);
    if (!isNaN(fallback.getTime())) {
      return new Date(fallback.getFullYear(), fallback.getMonth(), fallback.getDate());
    }
    return null;
  };

  const getHistoricalPresentation = (entry: any, repDateStr: string) => {
    if (!entry.presentationDate || !String(entry.presentationDate).trim()) {
      return {
        isPresented: false,
        presentationDateFormatted: '-',
        position: 'অডিটর'
      };
    }

    const pDate = parseDate(entry.presentationDate);
    if (!pDate) {
      return {
        isPresented: false,
        presentationDateFormatted: '-',
        position: 'অডিটর'
      };
    }

    const reportingDateObj = parseDate(repDateStr);
    if (reportingDateObj) {
      if (pDate.getTime() > reportingDateObj.getTime()) {
        return {
          isPresented: false,
          presentationDateFormatted: '-',
          position: 'অডিটর'
        };
      }
    }

    return {
      isPresented: true,
      presentationDateFormatted: formatDateBN(entry.presentationDate) || '-',
      position: entry.presentedToName || 'অডিটর'
    };
  };

  const filteredEntries = useMemo(() => {
    let data = entries || [];
    
    const startMidnight = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate()).getTime();
    const endMidnight = new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate(), 23, 59, 59, 999).getTime();

    data = data.filter(e => {
      // 1. Check if it's settled (has valid issue no AND date)
      const issueNo = (e.issueLetterNo || '').trim();
      const hasValidIssueNo = issueNo !== '' && 
                              issueNo !== '০' && 
                              issueNo !== '0' && 
                              issueNo !== 'নং' && 
                              issueNo !== 'নং-' && 
                              issueNo !== 'নং -' &&
                              !/^নং\s*$/.test(issueNo);

      const hasValidIssueDate = e.issueLetterDate && 
                                e.issueLetterDate.trim() !== '' && 
                                e.issueLetterDate !== '০' && 
                                e.issueLetterDate !== '0';

      if (hasValidIssueNo && hasValidIssueDate) {
        const iDate = parseDate(e.issueLetterDate);
        if (iDate) {
          // If issued on or before end date, it's SETTLED (not pending)
          if (iDate.getTime() <= endMidnight) {
            return false; 
          }
        }
      }

      // 2. If not settled, it must have a diary date to be considered
      const dDate = parseDate(e.diaryDate);
      if (!dDate) return false;
      
      // 3. Must be received within startDate and endDate
      const dTime = dDate.getTime();
      if (dTime < startMidnight || dTime > endMidnight) return false;
      
      return true; // Still Pending
    });

    if (filterAuditor !== 'সকল') {
      data = data.filter(e => {
        const rawAud = e.receiverName || e.presentedToName;
        return getDisplayName(rawAud) === filterAuditor || normalizeName(rawAud) === normalizeName(filterAuditor);
      });
    }

    if (filterBranch !== 'সকল') {
      data = data.filter(e => e.paraType === filterBranch);
    }

    const endStr = format(endDate, 'yyyy-MM-dd');
    return [...data]
      .sort((a, b) => {
        const dateA = parseDate(a.diaryDate)?.getTime() ?? 0;
        const dateB = parseDate(b.diaryDate)?.getTime() ?? 0;
        if (dateA !== dateB) return dateA - dateB;
        const noA = parseInt(toEnglishDigits(String(a.diaryNo || '')).replace(/\D/g, ''), 10) || 0;
        const noB = parseInt(toEnglishDigits(String(b.diaryNo || '')).replace(/\D/g, ''), 10) || 0;
        return noA - noB;
      })
      .map(e => {
        const hist = getHistoricalPresentation(e, endStr);
        return {
          ...e,
          presentationDate: hist.isPresented ? e.presentationDate : null,
          presentationDateFormatted: hist.presentationDateFormatted,
          presentedToName: hist.position
        };
      });
  }, [entries, filterAuditor, filterBranch, startDate, endDate]);

  const [showAuditorStatsModal, setShowAuditorStatsModal] = useState(false);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [detailsModalTitle, setDetailsModalTitle] = useState('');
  const [detailsModalLetters, setDetailsModalLetters] = useState<any[]>([]);
  const [highlightedKey, setHighlightedKey] = useState<string | null>(null);

  const handleCountClick = (title: string, letters: any[]) => {
    if (letters.length === 0) return;
    setDetailsModalTitle(title);
    setDetailsModalLetters(letters);
    setIsDetailsModalOpen(true);
    setHighlightedKey(title);
  };

  const getHighlightClass = (key: string) => {
    return highlightedKey === key ? 'clicked-cell-highlight' : '';
  };

  const auditorWiseStats = useMemo(() => {
    const stats: Record<string, { 
      rawName: string;
      total: number; auditor: number; aao: number; dd: number; others: number;
      auditorLetters: any[]; aaoLetters: any[]; ddLetters: any[]; othersLetters: any[]; totalLetters: any[]
    }> = {};
    
    filteredEntries.forEach(entry => {
      const rawAud = (entry.receiverName || entry.presentedToName || '').trim();
      const officialDisplay = getDisplayName(rawAud);
      const auditorKey = normalizeName(officialDisplay) || 'অনির্ধারিত';

      if (!stats[auditorKey]) {
        stats[auditorKey] = { 
          rawName: officialDisplay,
          total: 0, auditor: 0, aao: 0, dd: 0, others: 0,
          auditorLetters: [], aaoLetters: [], ddLetters: [], othersLetters: [], totalLetters: []
        };
      }
      
      stats[auditorKey].total++;
      stats[auditorKey].totalLetters.push(entry);
      const pos = (entry.presentedToName || 'অডিটর');
      
      if (pos.includes('অডিটর')) {
        stats[auditorKey].auditor++;
        stats[auditorKey].auditorLetters.push(entry);
      } else if (pos.includes('এএন্ডএও')) {
        stats[auditorKey].aao++;
        stats[auditorKey].aaoLetters.push(entry);
      } else if (pos.includes('উপপরিচালক')) {
        stats[auditorKey].dd++;
        stats[auditorKey].ddLetters.push(entry);
      } else {
        stats[auditorKey].others++;
        stats[auditorKey].othersLetters.push(entry);
      }
    });
    
    return Object.entries(stats).map(([key, data]) => ({ name: data.rawName, ...data }));
  }, [filteredEntries]);

  const reportingDate = endDate;

  const isSameDate = startDate.getFullYear() === endDate.getFullYear() &&
                     startDate.getMonth() === endDate.getMonth() &&
                     startDate.getDate() === endDate.getDate();

  const reportingDateBN = isSameDate
    ? toBengaliDigits(format(endDate, 'dd/MM/yyyy'))
    : `${toBengaliDigits(format(startDate, 'dd/MM/yyyy'))} হতে ${toBengaliDigits(format(endDate, 'dd/MM/yyyy'))}`;

  const reportingMonthBN = toBengaliDigits(format(reportingDate, 'MMMM/yy'))
    .replace('January', 'জানুয়ারি').replace('February', 'ফেব্রুয়ারি').replace('March', 'মার্চ')
    .replace('April', 'এপ্রিল').replace('May', 'মে').replace('June', 'জুন')
    .replace('July', 'জুলাই').replace('August', 'আগস্ট').replace('September', 'সেপ্টেম্বর')
    .replace('October', 'অক্টোবর').replace('November', 'নভেম্বর').replace('December', 'ডিসেম্বর');

  const customDropdownCls = (isOpen: boolean) => `relative flex items-center gap-2.5 px-3 h-[38px] bg-slate-50 border rounded-xl cursor-pointer transition-all duration-300 ${isOpen ? 'border-blue-600 ring-4 ring-blue-50 shadow-md z-[1010]' : 'border-slate-300 shadow-sm hover:border-slate-300'}`;

  // --- Grouping & Calculation Logic for Table 1 (Summary) ---
  const reportTableData = useMemo(() => {
    const grouped: Record<string, any> = {};
    const thresholdDate = subMonths(reportingDate, 1);

    filteredEntries.forEach(entry => {
      const rawAud = (entry.receiverName || entry.presentedToName || '').trim();
      const officialDisplay = getDisplayName(rawAud);
      const auditorKey = normalizeName(officialDisplay) || 'অনির্ধারিত';

      if (!grouped[auditorKey]) {
        grouped[auditorKey] = {
          name: officialDisplay,
          rawName: officialDisplay,
          karyapatra: { less: 0, more: 0, lessLetters: [], moreLetters: [] },
          karyabibarani: { less: 0, more: 0, lessLetters: [], moreLetters: [] },
          broadsheet: { less: 0, more: 0, lessLetters: [], moreLetters: [] },
          reconciliation: { less: 0, more: 0, lessLetters: [], moreLetters: [] },
          others: { less: 0, more: 0, lessLetters: [], moreLetters: [] }
        };
      }

      const diaryDate = parseDate(entry.diaryDate) || new Date(entry.diaryDate);
      const isMoreThanMonth = isBefore(diaryDate, thresholdDate);
      const durationKey = isMoreThanMonth ? 'more' : 'less';
      const lettersKey = isMoreThanMonth ? 'moreLetters' : 'lessLetters';

      const lType = (entry.letterType || '').normalize('NFC');
      const desc = (entry.description || '').toLowerCase();

      // UPDATED LOGIC: Categorize based on Workpaper (কার্যপত্র) or Minutes (কার্যবিবরণী)
      if (lType.includes('কার্যপত্র')) {
        grouped[auditorKey].karyapatra[durationKey]++;
        grouped[auditorKey].karyapatra[lettersKey].push(entry);
      } else if (
        lType.includes('কার্যবিবরণী') ||
        lType.includes('কার্যবিবরনী') ||
        lType === 'দ্বিপক্ষীয় সভা' ||
        lType === 'ত্রিপক্ষীয় সভা' ||
        lType.includes('দ্বি-সভা') ||
        lType.includes('ত্রি-সভা') ||
        lType.includes('দ্বিপক্ষ') ||
        lType.includes('ত্রিপক্ষ')
      ) {
        grouped[auditorKey].karyabibarani[durationKey]++;
        grouped[auditorKey].karyabibarani[lettersKey].push(entry);
      } else if (lType === 'বিএসআর') {
        grouped[auditorKey].broadsheet[durationKey]++;
        grouped[auditorKey].broadsheet[lettersKey].push(entry);
      } else if (lType === 'মিলিকরণ' || desc.includes('মিলিকরণ') || desc.includes('সমন্বয়')) {
        grouped[auditorKey].reconciliation[durationKey]++;
        grouped[auditorKey].reconciliation[lettersKey].push(entry);
      } else {
        grouped[auditorKey].others[durationKey]++;
        grouped[auditorKey].others[lettersKey].push(entry);
      }
    });

    return Object.values(grouped);
  }, [filteredEntries, reportingDate]);

  // --- Grouping & Logic for Table 2 (Detailed List) ---
  const detailedListData = useMemo(() => {
    const sorted = [...filteredEntries].sort((a, b) => {
      const audA = getDisplayName(a.receiverName || a.presentedToName);
      const audB = getDisplayName(b.receiverName || b.presentedToName);
      const audCompare = audA.localeCompare(audB);
      if (audCompare !== 0) return audCompare;
      const dateA = parseDate(a.diaryDate)?.getTime() ?? 0;
      const dateB = parseDate(b.diaryDate)?.getTime() ?? 0;
      if (dateA !== dateB) return dateA - dateB;
      const noA = parseInt(toEnglishDigits(String(a.diaryNo || '')).replace(/\D/g, ''), 10) || 0;
      const noB = parseInt(toEnglishDigits(String(b.diaryNo || '')).replace(/\D/g, ''), 10) || 0;
      return noA - noB;
    });

    const groups: { auditor: string; rawAuditor: string; rows: any[] }[] = [];
    sorted.forEach(row => {
      const rawAud = (row.receiverName || row.presentedToName || '').trim();
      const officialDisplay = getDisplayName(rawAud);
      const audKey = normalizeName(officialDisplay) || 'অনির্ধারিত';
      const lastGroup = groups[groups.length - 1];
      if (lastGroup && lastGroup.auditor === audKey) {
        lastGroup.rows.push(row);
      } else {
        groups.push({ auditor: audKey, rawAuditor: officialDisplay, rows: [row] });
      }
    });
    return groups;
  }, [filteredEntries]);

  const totals = useMemo(() => {
    return reportTableData.reduce((acc, row) => {
      acc.kpL += row.karyapatra.less; acc.kpM += row.karyapatra.more;
      acc.kbL += row.karyabibarani.less; acc.kbM += row.karyabibarani.more;
      acc.bsL += row.broadsheet.less; acc.bsM += row.broadsheet.more;
      acc.rcL += row.reconciliation.less; acc.rcM += row.reconciliation.more;
      acc.otL += row.others.less; acc.otM += row.others.more;
      return acc;
    }, { kpL: 0, kpM: 0, kbL: 0, kbM: 0, bsL: 0, bsM: 0, rcL: 0, rcM: 0, otL: 0, otM: 0 });
  }, [reportTableData]);

  const grandTotalLess = totals.kpL + totals.kbL + totals.bsL + totals.rcL + totals.otL;
  const grandTotalMore = totals.kpM + totals.kbM + totals.bsM + totals.rcM + totals.otM;

  const columnTotalLetters = useMemo(() => {
    const kpL: any[] = []; const kpM: any[] = [];
    const kbL: any[] = []; const kbM: any[] = [];
    const bsL: any[] = []; const bsM: any[] = [];
    const rcL: any[] = []; const rcM: any[] = [];
    const otL: any[] = []; const otM: any[] = [];

    reportTableData.forEach(row => {
      kpL.push(...row.karyapatra.lessLetters);
      kpM.push(...row.karyapatra.moreLetters);
      kbL.push(...row.karyabibarani.lessLetters);
      kbM.push(...row.karyabibarani.moreLetters);
      bsL.push(...row.broadsheet.lessLetters);
      bsM.push(...row.broadsheet.moreLetters);
      rcL.push(...row.reconciliation.lessLetters);
      rcM.push(...row.reconciliation.moreLetters);
      otL.push(...row.others.lessLetters);
      otM.push(...row.others.moreLetters);
    });

    const totL = [...kpL, ...kbL, ...bsL, ...rcL, ...otL];
    const totM = [...kpM, ...kbM, ...bsM, ...rcM, ...otM];

    return { kpL, kpM, kbL, kbM, bsL, bsM, rcL, rcM, otL, otM, totL, totM };
  }, [reportTableData]);

  const summaryStats = useMemo(() => {
    const stats = {
      total: entries.length,
      totalParas: 0,
      sfi: { total: 0, bsr: 0, kp: 0, kb: 0, reconciliation: 0, paras: 0 },
      nonSfi: { total: 0, bsr: 0, kp: 0, kb: 0, reconciliation: 0, paras: 0 }
    };
    entries.forEach(e => {
      const paras = parseInt(toEnglishDigits(e.totalParas || '0')) || 0;
      stats.totalParas += paras;

      if (e.paraType === 'এসএফআই') {
        stats.sfi.total++;
        stats.sfi.paras += paras;
        if (e.letterType === 'বিএসআর') stats.sfi.bsr++;
        if (e.letterType?.includes('কার্যপত্র')) stats.sfi.kp++;
        else if (e.letterType?.includes('কার্যবিবরণী') || e.letterType?.includes('কার্যবিবরনী') || e.letterType === 'দ্বিপক্ষীয় সভা' || e.letterType === 'ত্রিপক্ষীয় সভা' || e.letterType?.includes('দ্বি-সভা') || e.letterType?.includes('ত্রি-সভা') || e.letterType?.includes('দ্বিপক্ষ') || e.letterType?.includes('ত্রিপক্ষ')) stats.sfi.kb++;
        if (e.letterType === 'মিলিকরণ') stats.sfi.reconciliation++;
      } else if (e.paraType === 'নন এসএফআই') {
        stats.nonSfi.total++;
        stats.nonSfi.paras += paras;
        if (e.letterType === 'বিএসআর') stats.nonSfi.bsr++;
        if (e.letterType?.includes('কার্যপত্র')) stats.nonSfi.kp++;
        else if (e.letterType?.includes('কার্যবিবরণী') || e.letterType?.includes('কার্যবিবরনী') || e.letterType === 'দ্বিপক্ষীয় সভা' || e.letterType === 'ত্রিপক্ষীয় সভা' || e.letterType?.includes('দ্বি-সভা') || e.letterType?.includes('ত্রি-সভা') || e.letterType?.includes('দ্বিপক্ষ') || e.letterType?.includes('ত্রিপক্ষ')) stats.nonSfi.kb++;
        if (e.letterType === 'মিলিকরণ') stats.nonSfi.reconciliation++;
      }
    });
    return stats;
  }, [entries]);

  // Header font is font-bold with solid background
  const thStyle = "px-1.5 py-1 font-bold text-center text-[11px] leading-tight align-middle bg-slate-200 whitespace-nowrap";
  // Data cells reverted to font-bold (700 weight as per instruction)
  const tdStyle = "px-2 py-2 text-[12px] text-center font-bold leading-tight align-middle transition-colors whitespace-nowrap bg-white";
  
  // Reverted sticky header with solid background and precise padding
  const stickyThStyle = "px-1.5 py-1 font-bold text-center text-[10.5px] leading-tight align-middle bg-slate-200";
  // Reverted sticky data from medium to bold
  const stickyTdStyle = "px-1.5 py-1.5 text-[11px] text-center font-bold leading-tight align-middle transition-colors bg-white";

  const getPositionColor = (name: string) => {
    const pos = name || 'অডিটর';
    if (pos.includes('অডিটর')) return 'bg-red-500 text-white';
    if (pos.includes('সুপার')) return 'bg-yellow-400 text-black';
    if (pos.includes('এএন্ডএও')) return 'bg-blue-600 text-white';
    if (pos.includes('উপপরিচালক')) return 'bg-green-600 text-white';
    return 'bg-slate-100 text-slate-700';
  };

  return (
    <div id="dd-sir-report-container" className="space-y-6 py-2 px-[4px] w-full animate-report-reveal relative font-['Hind_Siliguri'] bg-white multi-table-view">
      <IDBadge id="dd-sir-report-container" />

      {/* Summary Stats Panel (Removed as it's now in hover) */}

      <div className="w-full bg-white px-0 py-6 relative z-[1000]">
        {/* Header container for Title, Reporting Date, Filters and Statistics on a single line */}
        <div className="bg-white flex flex-col xl:flex-row items-center justify-between gap-4 mb-8 pt-4 pb-6 border-b border-slate-200/80 w-full px-4 sm:px-6 transition-all duration-300">
          
          {/* Left: Title Header styled as split-block button */}
          <div className="flex items-stretch h-[38px] w-fit max-w-[95%] shadow-[0_4px_12px_rgba(0,0,0,0.1)] select-none rounded-lg overflow-hidden border border-slate-200/50 shrink-0">
            {/* Left Icon Area: Off-white bg & gray bottom border */}
            <div className="flex flex-col w-9 sm:w-10 shrink-0 h-full">
              <div className="flex-1 flex items-center justify-center bg-[#f8fafc]">
                <Mail className="text-red-700 w-4 h-4 stroke-[2.5]" />
              </div>
              <div className="h-[3px] bg-[#94a3b8]" />
            </div>
            
            {/* Right Text Area: Solid Deep Blue/Indigo with dark blue bottom bar */}
            <div className="flex-1 flex flex-col h-full min-w-[160px] sm:min-w-[200px]">
              <div className="flex-1 bg-[#1e40af] flex items-center justify-center px-2.5 sm:px-4">
                <span className="text-white font-bold text-[11px] sm:text-[12px] tracking-wide text-center">
                  চিঠিপত্র সংক্রান্ত মাসিক রিটার্ন (ডিডি স্যার)
                </span>
              </div>
              <div className="h-[3px] bg-[#1e3a8a]" />
            </div>
          </div>

          {/* Right Group: Date Picker, Filters & Statistics on a single row */}
          <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap xl:flex-nowrap justify-center xl:justify-end shrink-0 select-none no-print">
            
            {/* Reporting Date Range with Elegant Custom Calendar picker (হতে - থেকে) */}
            <div className="flex items-center justify-center gap-2">
              <div className="relative shrink-0 select-none z-[400]" ref={calendarRef}>
                <button
                  type="button"
                  onClick={() => setIsCalendarOpen(!isCalendarOpen)}
                  className={`flex items-center gap-2 px-3 h-[38px] bg-slate-50 border rounded-xl font-bold text-xs transition-all cursor-pointer shadow-sm ${
                    isCalendarOpen ? 'border-blue-600 ring-2 ring-blue-100 bg-white' : 'border-slate-300 hover:border-blue-400'
                  }`}
                  title={`${toBengaliDigits(format(startDate, 'dd/MM/yyyy'))} হতে ${toBengaliDigits(format(endDate, 'dd/MM/yyyy'))}`}
                >
                  <Calendar size={14} className="text-blue-600 shrink-0" />
                  <span className="text-slate-600 font-semibold shrink-0">সময়কাল:</span>
                  <span className="text-slate-900 font-black truncate max-w-[200px] sm:max-w-none">
                    {toBengaliDigits(format(startDate, 'dd/MM/yyyy'))} হতে {toBengaliDigits(format(endDate, 'dd/MM/yyyy'))}
                  </span>
                  <ChevronDown size={13} className={`text-slate-400 shrink-0 transition-transform duration-200 ${isCalendarOpen ? 'rotate-180 text-blue-600' : ''}`} />
                </button>

                {isCalendarOpen && (
                  <div className="absolute top-full left-0 mt-2 w-[320px] sm:w-[350px] max-w-[calc(100vw-24px)] bg-white border border-slate-200 shadow-2xl rounded-2xl p-4 z-[9999] animate-in fade-in slide-in-from-top-2 duration-200 select-none">
                    {/* Calendar Top Header with Title & Close */}
                    <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-100">
                      <div className="flex items-center gap-1.5 text-xs font-black text-slate-800">
                        <Calendar size={13} className="text-blue-600" />
                        <span>রিপোর্টিং সময়কাল নির্বাচন (হতে - থেকে)</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setIsCalendarOpen(false)}
                        className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
                        title="বন্ধ করুন"
                      >
                        <X size={14} />
                      </button>
                    </div>

                    {/* Start & End Date Selection Cards */}
                    <div className="grid grid-cols-2 gap-2 mb-3">
                      {/* Start Date Card */}
                      <div
                        onClick={() => {
                          setSelectingDateType('start');
                        setSelectingDateType('start');
                        setCurrentViewDate(new Date(startDate.getFullYear(), startDate.getMonth(), 1));
                      }}
                      className={`relative p-2 rounded-xl border text-left transition-all ${
                        selectingDateType === 'start'
                          ? 'border-blue-600 bg-blue-50/70 ring-2 ring-blue-200 shadow-xs'
                          : 'border-slate-200 bg-slate-50 hover:bg-slate-100/70'
                      }`}
                    >
                      <span className="block text-[10px] font-bold text-slate-500">শুরুর তারিখ (হতে)</span>
                      <div className="flex items-center justify-between mt-0.5 gap-1">
                        <input
                          type="text"
                          value={manualStartDate}
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectingDateType('start');
                            setCurrentViewDate(new Date(startDate.getFullYear(), startDate.getMonth(), 1));
                          }}
                          onFocus={() => {
                            setSelectingDateType('start');
                          }}
                          onChange={(e) => {
                            const val = e.target.value;
                            setManualStartDate(val);
                            const parsed = parseManualDate(val);
                            if (parsed) {
                              setStartDate(parsed);
                              if (parsed > endDate) setEndDate(parsed);
                              setCurrentViewDate(new Date(parsed.getFullYear(), parsed.getMonth(), 1));
                            }
                          }}
                          onBlur={() => {
                            const parsed = parseManualDate(manualStartDate);
                            if (parsed) {
                              setStartDate(parsed);
                              setManualStartDate(toBengaliDigits(format(parsed, 'dd/MM/yyyy')));
                            } else {
                              setManualStartDate(toBengaliDigits(format(startDate, 'dd/MM/yyyy')));
                            }
                          }}
                          placeholder="০১/০১/২০২৬"
                          className="w-full bg-transparent font-extrabold text-xs text-slate-800 outline-none p-0 border-none focus:ring-0 cursor-text"
                          title="ক্যালেন্ডার বা ম্যানুয়ালি তারিখ লিখুন (যেমন: ০১/১০/২০২৬ বা 01/10/2026)"
                        />
                        <div className="relative shrink-0">
                          <input
                            type="date"
                            value={format(startDate, 'yyyy-MM-dd')}
                            onChange={(e) => {
                              const val = e.target.value;
                              if (val) {
                                const [y, m, d] = val.split('-').map(Number);
                                const newD = new Date(y, m - 1, d);
                                setStartDate(newD);
                                if (newD > endDate) setEndDate(newD);
                                setCurrentViewDate(new Date(y, m - 1, 1));
                              }
                            }}
                            className="opacity-0 absolute inset-0 w-full h-full cursor-pointer z-10"
                            title="ক্যালেন্ডার থেকে নির্বাচন করুন"
                          />
                          <Calendar size={13} className="text-blue-600" />
                        </div>
                      </div>
                    </div>

                    {/* End Date Card */}
                    <div
                      onClick={() => {
                        setSelectingDateType('end');
                        setCurrentViewDate(new Date(endDate.getFullYear(), endDate.getMonth(), 1));
                      }}
                      className={`relative p-2 rounded-xl border text-left transition-all ${
                        selectingDateType === 'end'
                          ? 'border-blue-600 bg-blue-50/70 ring-2 ring-blue-200 shadow-xs'
                          : 'border-slate-200 bg-slate-50 hover:bg-slate-100/70'
                      }`}
                    >
                      <span className="block text-[10px] font-bold text-slate-500">শেষের তারিখ (পর্যন্ত)</span>
                      <div className="flex items-center justify-between mt-0.5 gap-1">
                        <input
                          type="text"
                          value={manualEndDate}
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectingDateType('end');
                            setCurrentViewDate(new Date(endDate.getFullYear(), endDate.getMonth(), 1));
                          }}
                          onFocus={() => {
                            setSelectingDateType('end');
                          }}
                          onChange={(e) => {
                            const val = e.target.value;
                            setManualEndDate(val);
                            const parsed = parseManualDate(val);
                            if (parsed) {
                              setEndDate(parsed);
                              if (parsed < startDate) setStartDate(parsed);
                              setCurrentViewDate(new Date(parsed.getFullYear(), parsed.getMonth(), 1));
                            }
                          }}
                          onBlur={() => {
                            const parsed = parseManualDate(manualEndDate);
                            if (parsed) {
                              setEndDate(parsed);
                              setManualEndDate(toBengaliDigits(format(parsed, 'dd/MM/yyyy')));
                            } else {
                              setManualEndDate(toBengaliDigits(format(endDate, 'dd/MM/yyyy')));
                            }
                          }}
                          placeholder="৩১/০১/২০২৬"
                          className="w-full bg-transparent font-extrabold text-xs text-slate-800 outline-none p-0 border-none focus:ring-0 cursor-text"
                          title="ক্যালেন্ডার বা ম্যানুয়ালি তারিখ লিখুন (যেমন: ৩১/১০/২০২৬ বা 31/10/2026)"
                        />
                        <div className="relative shrink-0">
                          <input
                            type="date"
                            value={format(endDate, 'yyyy-MM-dd')}
                            onChange={(e) => {
                              const val = e.target.value;
                              if (val) {
                                const [y, m, d] = val.split('-').map(Number);
                                const newD = new Date(y, m - 1, d);
                                setEndDate(newD);
                                if (newD < startDate) setStartDate(newD);
                                setCurrentViewDate(new Date(y, m - 1, 1));
                              }
                            }}
                            className="opacity-0 absolute inset-0 w-full h-full cursor-pointer z-10"
                            title="ক্যালেন্ডার থেকে নির্বাচন করুন"
                          />
                          <Calendar size={13} className="text-blue-600" />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Quick Presets: [ < ] [বিগত মাস] [চলতি মাস] [ > ] [চলতি বছর] [গত ৩০ দিন] */}
                  <div className="flex flex-wrap items-center gap-1 mb-3 pb-2.5 border-b border-slate-100">
                    {/* পূর্ববর্তী মাস নেভিগেশন বোতাম */}
                    <button
                      type="button"
                      onClick={() => {
                        const base = startDate || new Date();
                        const prevM = subMonths(base, 1);
                        const s = startOfMonth(prevM);
                        const e = endOfMonth(prevM);
                        setStartDate(s);
                        setEndDate(e);
                        setCurrentViewDate(new Date(s.getFullYear(), s.getMonth(), 1));
                      }}
                      className="p-1 px-1.5 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-300 border border-slate-200 rounded-lg text-slate-700 transition-colors cursor-pointer flex items-center justify-center shrink-0"
                      title="পূর্ববর্তী মাস (পেছনে যান - যতবার চাপবেন এক মাস করে পেছনে যাবে)"
                    >
                      <ChevronLeft size={13} />
                    </button>

                    {/* বিগত মাস */}
                    <button
                      type="button"
                      onClick={() => {
                        const now = new Date();
                        const s = startOfMonth(subMonths(now, 1));
                        const e = endOfMonth(subMonths(now, 1));
                        setStartDate(s);
                        setEndDate(e);
                        setCurrentViewDate(new Date(s.getFullYear(), s.getMonth(), 1));
                      }}
                      className="px-2 py-0.5 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-300 border border-slate-200 rounded-lg text-[10px] font-bold text-slate-700 transition-colors cursor-pointer"
                      title="বিগত মাস"
                    >
                      বিগত মাস
                    </button>

                    {/* চলতি মাস (বিগত মাসের ডান পাশে) */}
                    <button
                      type="button"
                      onClick={() => {
                        const now = new Date();
                        const s = startOfMonth(now);
                        const e = endOfMonth(now);
                        setStartDate(s);
                        setEndDate(e);
                        setCurrentViewDate(new Date(now.getFullYear(), now.getMonth(), 1));
                      }}
                      className="px-2 py-0.5 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-300 border border-slate-200 rounded-lg text-[10px] font-bold text-slate-700 transition-colors cursor-pointer"
                      title="চলতি মাস"
                    >
                      চলতি মাস
                    </button>

                    {/* পরবর্তী মাস নেভিগেশন বোতাম */}
                    <button
                      type="button"
                      onClick={() => {
                        const base = startDate || new Date();
                        const nextM = new Date(base.getFullYear(), base.getMonth() + 1, 1);
                        const s = startOfMonth(nextM);
                        const e = endOfMonth(nextM);
                        setStartDate(s);
                        setEndDate(e);
                        setCurrentViewDate(new Date(s.getFullYear(), s.getMonth(), 1));
                      }}
                      className="p-1 px-1.5 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-300 border border-slate-200 rounded-lg text-slate-700 transition-colors cursor-pointer flex items-center justify-center shrink-0"
                      title="পরবর্তী মাস (সামনে যান)"
                    >
                      <ChevronRight size={13} />
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const now = new Date();
                        const s = new Date(now.getFullYear(), 0, 1);
                        const e = new Date(now.getFullYear(), 11, 31);
                        setStartDate(s);
                        setEndDate(e);
                        setCurrentViewDate(new Date(now.getFullYear(), now.getMonth(), 1));
                      }}
                      className="px-2 py-0.5 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-300 border border-slate-200 rounded-lg text-[10px] font-bold text-slate-700 transition-colors cursor-pointer"
                    >
                      চলতি বছর
                    </button>
                      <button
                        type="button"
                        onClick={() => {
                          const now = new Date();
                          const s = new Date(now.getTime() - 29 * 24 * 60 * 60 * 1000);
                          setStartDate(s);
                          setEndDate(now);
                          setCurrentViewDate(new Date(s.getFullYear(), s.getMonth(), 1));
                        }}
                        className="px-2 py-0.5 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-300 border border-slate-200 rounded-lg text-[10px] font-bold text-slate-700 transition-colors cursor-pointer"
                      >
                        গত ৩০ দিন
                      </button>
                    </div>

                    {/* Calendar Header with Navigation */}
                    <div className="flex items-center justify-between mb-2">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setCurrentViewDate(prev => new Date(prev.getFullYear(), prev.getMonth() - 1, 1));
                        }}
                        className="p-1 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-blue-700 transition-colors cursor-pointer"
                        title="পূর্ববর্তী মাস"
                      >
                        <ChevronLeft size={16} />
                      </button>

                      <div className="flex items-center gap-1.5">
                        <select
                          value={currentViewDate.getMonth()}
                          onChange={(e) => {
                            const m = parseInt(e.target.value, 10);
                            setCurrentViewDate(new Date(currentViewDate.getFullYear(), m, 1));
                          }}
                          className="font-black text-xs text-slate-800 bg-slate-50 border border-slate-200 rounded-lg px-2 py-0.5 cursor-pointer outline-none focus:border-blue-500"
                        >
                          {BENGALI_MONTHS.map((mName, mIdx) => (
                            <option key={mIdx} value={mIdx}>{mName}</option>
                          ))}
                        </select>
                        <select
                          value={currentViewDate.getFullYear()}
                          onChange={(e) => {
                            const y = parseInt(e.target.value, 10);
                            setCurrentViewDate(new Date(y, currentViewDate.getMonth(), 1));
                          }}
                          className="font-black text-xs text-slate-800 bg-slate-50 border border-slate-200 rounded-lg px-2 py-0.5 cursor-pointer outline-none focus:border-blue-500"
                        >
                          {[2024, 2025, 2026, 2027, 2028].map(y => (
                            <option key={y} value={y}>{toBengaliDigits(y.toString())}</option>
                          ))}
                        </select>
                      </div>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setCurrentViewDate(prev => new Date(prev.getFullYear(), prev.getMonth() + 1, 1));
                        }}
                        className="p-1 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-blue-700 transition-colors cursor-pointer"
                        title="পরবর্তী মাস"
                      >
                        <ChevronRight size={16} />
                      </button>
                    </div>

                    {/* Calendar Week Days */}
                    <div className="grid grid-cols-7 gap-1 text-center mb-1">
                      {BENGALI_WEEKDAYS.map((wd, i) => (
                        <span key={i} className="text-[10px] font-black text-slate-400 py-0.5">
                          {wd}
                        </span>
                      ))}
                    </div>

                    {/* Calendar Days Grid with Range Highlight */}
                    <div className="grid grid-cols-7 gap-1">
                      {(() => {
                        const Y = currentViewDate.getFullYear();
                        const M = currentViewDate.getMonth();
                        const firstDay = new Date(Y, M, 1);
                        
                        let startOffset = (firstDay.getDay() + 1) % 7; 
                        
                        const daysInMonth = new Date(Y, M + 1, 0).getDate();
                        const prevMonthDays = new Date(Y, M, 0).getDate();
                        
                        const cells = [];
                        
                        // Trailing days
                        for (let i = startOffset - 1; i >= 0; i--) {
                          const d = prevMonthDays - i;
                          const dateObj = new Date(Y, M - 1, d);
                          cells.push({ day: d, isCurrentMonth: false, dateObj });
                        }
                        
                        // Current month days
                        for (let d = 1; d <= daysInMonth; d++) {
                          const dateObj = new Date(Y, M, d);
                          cells.push({ day: d, isCurrentMonth: true, dateObj });
                        }
                        
                        // Lead days
                        const totalCells = cells.length > 35 ? 42 : 35;
                        const remaining = totalCells - cells.length;
                        for (let d = 1; d <= remaining; d++) {
                          const dateObj = new Date(Y, M + 1, d);
                          cells.push({ day: d, isCurrentMonth: false, dateObj });
                        }

                        const startStr = format(startDate, 'yyyy-MM-dd');
                        const endStr = format(endDate, 'yyyy-MM-dd');

                        return cells.map((cell, idx) => {
                          const dateStr = format(cell.dateObj, 'yyyy-MM-dd');
                          const isStart = dateStr === startStr;
                          const isEnd = dateStr === endStr;
                          const isInRange = dateStr > startStr && dateStr < endStr;

                          let cellCls = "text-[11.5px] font-bold h-7 flex items-center justify-center transition-all cursor-pointer relative ";
                          if (isStart && isEnd) {
                            cellCls += "bg-blue-600 text-white font-black rounded-lg shadow-sm z-10";
                          } else if (isStart) {
                            cellCls += "bg-blue-600 text-white font-black rounded-l-lg shadow-sm z-10";
                          } else if (isEnd) {
                            cellCls += "bg-blue-600 text-white font-black rounded-r-lg shadow-sm z-10";
                          } else if (isInRange) {
                            cellCls += "bg-blue-100/70 text-blue-950 font-extrabold rounded-none";
                          } else if (cell.isCurrentMonth) {
                            cellCls += "text-slate-800 hover:bg-blue-50 hover:text-blue-700 rounded-lg";
                          } else {
                            cellCls += "text-slate-300 hover:bg-slate-50 hover:text-slate-400 rounded-lg";
                          }

                          return (
                            <div
                              key={idx}
                              onClick={(e) => {
                                e.stopPropagation();
                                const clickedDate = cell.dateObj;
                                if (selectingDateType === 'start') {
                                  if (clickedDate > endDate) {
                                    setStartDate(clickedDate);
                                    setEndDate(clickedDate);
                                    setSelectingDateType('end');
                                  } else {
                                    setStartDate(clickedDate);
                                    setSelectingDateType('end');
                                  }
                                } else {
                                  if (clickedDate < startDate) {
                                    setStartDate(clickedDate);
                                    setSelectingDateType('end');
                                  } else {
                                    setEndDate(clickedDate);
                                  }
                                }
                              }}
                              className={cellCls}
                            >
                              <span>{toBengaliDigits(cell.day.toString())}</span>
                            </div>
                          );
                        });
                      })()}
                    </div>
                  </div>
                )}
              </div>

              {(format(startDate, 'yyyy-MM-dd') !== '2025-06-16' ||
                format(endDate, 'yyyy-MM-dd') !== format(new Date(), 'yyyy-MM-dd')) && (
                <button 
                  onClick={() => {
                    const now = new Date();
                    setStartDate(new Date(2025, 5, 16));
                    setEndDate(now);
                    setCurrentViewDate(now);
                  }}
                  className="p-2 bg-slate-50 border border-slate-300 hover:bg-red-50 hover:border-red-200 hover:text-red-500 rounded-xl transition-all shadow-sm h-[38px] flex items-center justify-center cursor-pointer"
                  title="ডিফল্ট সময়সীমায় ফিরুন"
                >
                  <RotateCcw size={14} />
                </button>
              )}
            </div>

            {/* Branch Filter */}
            <div className="relative shrink-0" ref={branchDropdownRef}>
              <div 
                onClick={() => {
                  setIsBranchDropdownOpen(!isBranchDropdownOpen);
                  setIsAuditorDropdownOpen(false);
                  setIsCalendarOpen(false);
                  setIsStatsOpen(false);
                }}
                className={customDropdownCls(isBranchDropdownOpen) + " min-w-[115px] sm:min-w-[125px]"}
              >
                <Mail size={14} className="text-blue-600 shrink-0" />
                <span className="font-bold text-[11.5px] text-slate-900 truncate">
                  {filterBranch === 'সকল' ? 'সকল শাখা' : filterBranch}
                </span>
                <ChevronDown size={13} className={`text-slate-400 ml-auto transition-transform duration-300 shrink-0 ${isBranchDropdownOpen ? 'rotate-180 text-blue-600' : ''}`} />
              </div>
              
              {isBranchDropdownOpen && (
                <div className="absolute top-full right-0 w-[180px] max-w-[calc(100vw-24px)] pt-1 transition-all duration-200 z-[9999]">
                  <div className="w-full bg-white border-2 border-slate-200 rounded-2xl shadow-2xl overflow-hidden">
                    <div className="max-h-[250px] overflow-y-auto no-scrollbar">
                      {['সকল', 'এসএফআই', 'নন এসএফআই'].map((opt, idx) => (
                        <div 
                          key={idx} 
                          onClick={() => {
                            setFilterBranch(opt);
                            setIsBranchDropdownOpen(false);
                          }} 
                          className={`flex items-center justify-between px-4 py-2.5 cursor-pointer transition-all ${filterBranch === opt ? 'bg-blue-600 text-white' : 'hover:bg-blue-50 text-slate-700 font-bold text-[12px]'}`}
                        >
                          <span>{opt === 'সকল' ? 'সকল শাখা' : opt}</span>
                          {filterBranch === opt && <Check size={14} strokeWidth={3} />}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Auditor Filter */}
            <div className="relative shrink-0" ref={auditorDropdownRef}>
              <div 
                onClick={() => {
                  setIsAuditorDropdownOpen(!isAuditorDropdownOpen);
                  setIsBranchDropdownOpen(false);
                  setIsCalendarOpen(false);
                  setIsStatsOpen(false);
                }}
                className={customDropdownCls(isAuditorDropdownOpen) + " min-w-[135px] sm:min-w-[145px]"}
              >
                <User size={14} className="text-blue-600 shrink-0" />
                <span className="font-bold text-[11.5px] text-slate-900 truncate">
                  {filterAuditor === 'সকল' ? 'সকল অডিটর' : filterAuditor}
                </span>
                <ChevronDown size={13} className={`text-slate-400 ml-auto transition-transform duration-300 shrink-0 ${isAuditorDropdownOpen ? 'rotate-180 text-blue-600' : ''}`} />
              </div>
              
              {isAuditorDropdownOpen && (
                <div className="absolute top-full left-0 sm:left-auto sm:right-0 lg:left-0 w-[220px] max-w-[calc(100vw-24px)] pt-1 transition-all duration-200 z-[9999]">
                  <div className="w-full bg-white border-2 border-slate-200 rounded-2xl shadow-2xl overflow-hidden font-sans">
                    <div className="max-h-[250px] overflow-y-auto no-scrollbar">
                      {auditorOptions.map((opt, idx) => (
                        <div 
                          key={idx} 
                          onClick={() => {
                            setFilterAuditor(opt);
                            setIsAuditorDropdownOpen(false);
                          }} 
                          className={`flex items-center justify-between px-4 py-2.5 cursor-pointer transition-all ${filterAuditor === opt ? 'bg-blue-600 text-white' : 'hover:bg-blue-50 text-slate-700 font-bold text-[12px]'}`}
                        >
                          <span>{opt === 'সকল' ? 'সকল অডিটর' : opt}</span>
                          {filterAuditor === opt && <Check size={14} strokeWidth={3} />}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Download Button */}
            <button
              type="button"
              onClick={downloadExcel}
              className="flex items-center justify-center w-10 h-[38px] bg-emerald-50 text-emerald-700 hover:text-emerald-800 border border-emerald-100 hover:border-emerald-300 hover:bg-white hover:shadow-md transition-all duration-300 rounded-xl cursor-pointer shrink-0"
              title="এক্সেল ফাইল ডাউনলোড করুন"
            >
              <FileSpreadsheet size={15} className="stroke-[2.5]" />
            </button>

            {/* Right: Statistics button and its modal */}
            <div 
              className="relative z-[1050]" 
              ref={statsRef}
            >
              <button 
                type="button"
                onClick={() => setIsStatsOpen(prev => !prev)}
                className="flex items-center gap-2 px-4 h-[38px] bg-sky-50 text-sky-800 rounded-xl font-black text-[12px] border border-sky-100 hover:border-sky-300 transition-all duration-300 hover:bg-white hover:shadow-md cursor-pointer"
              >
                <Sparkles size={14} className="text-sky-600 animate-pulse shrink-0" />
                পরিসংখ্যান
                <ChevronDown size={13} className={`text-sky-500 transition-transform duration-300 shrink-0 ${isStatsOpen ? 'rotate-180' : ''}`} />
              </button>
              
              {isStatsOpen && (
                <div 
                  className="fixed inset-0 z-[10000] bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4"
                  onClick={() => setIsStatsOpen(false)}
                >
                  <div 
                    className="bg-white rounded-3xl shadow-2xl border border-slate-100 w-full max-w-md max-h-[85vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200 text-left"
                    onClick={(e) => e.stopPropagation()}
                  >
                    {/* Modal Header */}
                    <div className="flex items-center justify-between px-5 py-3.5 bg-slate-50 border-b border-slate-100 shrink-0">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center">
                          <BarChart3 size={18} />
                        </div>
                        <div>
                          <h3 className="text-slate-900 font-black text-sm">রিপোর্ট পরিসংখ্যান</h3>
                          <p className="text-slate-500 text-[10.5px] font-bold">ডিডি স্যার মাসিক রিটার্ন সারসংক্ষেপ</p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setIsStatsOpen(false)}
                        className="w-8 h-8 rounded-full bg-slate-200/80 hover:bg-slate-300 text-slate-700 flex items-center justify-center transition-colors cursor-pointer"
                      >
                        <X size={16} />
                      </button>
                    </div>

                    {/* Modal Body */}
                    <div 
                      className="p-4 sm:p-6 overflow-y-auto overscroll-contain flex-1 space-y-4"
                      style={{
                        WebkitOverflowScrolling: 'touch',
                        touchAction: 'pan-y'
                      }}
                    >
                      <div className="flex items-center gap-3 bg-blue-50/60 p-4 rounded-2xl border border-blue-100/60">
                        <div className="w-10 h-10 bg-blue-600 text-white rounded-xl flex items-center justify-center shrink-0 shadow-md shadow-blue-500/20">
                          <BarChart3 size={20} />
                        </div>
                        <div className="flex flex-col text-left">
                          <span className="text-blue-950 font-black text-base">মোট চিঠি: {toBengaliDigits(summaryStats.total)} টি</span>
                          <span className="text-emerald-700 font-black text-xs sm:text-[13px]">মোট অনুচ্ছেদ: {toBengaliDigits(summaryStats.totalParas)} টি</span>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div className="flex flex-col gap-1.5 bg-blue-50/40 p-3.5 rounded-2xl border border-blue-100/40">
                          <div className="flex items-center justify-between">
                            <span className="text-blue-900 font-black text-xs sm:text-sm">এসএফআই:</span>
                            <span className="text-blue-950 font-black text-xs sm:text-sm">{toBengaliDigits(summaryStats.sfi.total)} টি <span className="text-emerald-700 font-bold text-[11px]">({toBengaliDigits(summaryStats.sfi.paras)} টি অনুচ্ছেদ)</span></span>
                          </div>
                          <div className="text-slate-600 font-bold text-[11px] leading-relaxed">
                            (বিএসআর: {toBengaliDigits(summaryStats.sfi.bsr)} টি, ত্রিপক্ষীয় সভা (কার্যপত্র): {toBengaliDigits(summaryStats.sfi.kp)} টি, ত্রিপক্ষীয় সভা (কার্যবিবরণী): {toBengaliDigits(summaryStats.sfi.kb)} টি, মিলিকরণ: {toBengaliDigits(summaryStats.sfi.reconciliation)} টি)
                          </div>
                        </div>

                        <div className="flex flex-col gap-1.5 bg-slate-50 p-3.5 rounded-2xl border border-slate-100">
                          <div className="flex items-center justify-between">
                            <span className="text-slate-800 font-black text-xs sm:text-sm">নন এসএফআই:</span>
                            <span className="text-slate-900 font-black text-xs sm:text-sm">{toBengaliDigits(summaryStats.nonSfi.total)} টি <span className="text-emerald-700 font-bold text-[11px]">({toBengaliDigits(summaryStats.nonSfi.paras)} টি অনুচ্ছেদ)</span></span>
                          </div>
                          <div className="text-slate-600 font-bold text-[11px] leading-relaxed">
                            (বিএসআর: {toBengaliDigits(summaryStats.nonSfi.bsr)} টি, দ্বিপক্ষীয় সভা (কার্যপত্র): {toBengaliDigits(summaryStats.nonSfi.kp)} টি, দ্বিপক্ষীয় সভা (কার্যবিবরণী): {toBengaliDigits(summaryStats.nonSfi.kb)} টি, মিলিকরণ: {toBengaliDigits(summaryStats.nonSfi.reconciliation)} টি)
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Print Only Header (invisible on screen, but visible when printing) */}
        <div className="hidden print:block text-center mb-8 pt-4">
          <div className="inline-block relative">
            <h1 className="text-3xl font-black text-slate-900 tracking-tight mb-2">
              চিঠিপত্র সংক্রান্ত মাসিক রিটার্ন (ডিডি স্যার)
            </h1>
            <div className="flex items-center justify-center gap-4">
              <div className="h-[2px] w-12 bg-gradient-to-r from-transparent to-slate-400"></div>
              <div className="w-2 h-2 rounded-full bg-blue-600"></div>
              <div className="h-[2px] w-12 bg-gradient-to-l from-transparent to-slate-400"></div>
            </div>
          </div>
        </div>

        {/* SECTION 1: সারসংক্ষেপ টেবিল */}
        <div className="mb-10 flex flex-col items-stretch overflow-visible">
          <div className="summary-table-container max-w-full w-full overflow-visible bg-white">
            <table className="w-full border-separate border-spacing-0 table-fixed min-w-[1070px] xl:min-w-full">
              <colgroup>
                <col className="w-[60px]" />
                <col className="w-[160px]" />
                <col className="w-[70px]" />
                <col className="w-[70px]" />
                <col className="w-[70px]" />
                <col className="w-[70px]" />
                <col className="w-[70px]" />
                <col className="w-[70px]" />
                <col className="w-[70px]" />
                <col className="w-[70px]" />
                <col className="w-[70px]" />
                <col className="w-[70px]" />
                <col className="w-[75px]" />
                <col className="w-[75px]" />
              </colgroup>
              <thead>
                <tr className="h-[32px]">
                  <th colSpan={2} className="px-2 py-1 text-center font-bold text-[12px] bg-slate-200 whitespace-nowrap border border-slate-300">অনিষ্পন্ন কাজের তালিকা</th>
                  <th colSpan={4} className="px-2 py-1 text-center font-bold text-[12px] bg-slate-200 whitespace-nowrap border border-slate-300">শাখা: {filterBranch === 'সকল' ? 'সকল' : filterBranch}</th>
                  <th colSpan={4} className="px-2 py-1 text-center font-bold text-[12px] bg-slate-200 whitespace-nowrap border border-slate-300">মাস: {reportingMonthBN}</th>
                  <th colSpan={4} className="px-2 py-1 text-center font-bold text-[12px] bg-slate-200 whitespace-nowrap border border-slate-300">তারিখ: {reportingDateBN} খ্রি:</th>
                </tr>
                <tr className="h-[42px]">
                  <th rowSpan={2} className={`${thStyle} whitespace-nowrap min-w-[60px] border border-slate-300`}>ক্রমিক নং</th>
                  <th rowSpan={2} className={`${thStyle} border border-slate-300`}>দায়িত্বপ্রাপ্ত অডিটর</th>
                  <th colSpan={2} className={`${thStyle} border border-slate-300`}>
                    {filterBranch === 'এসএফআই' ? 'ত্রিপক্ষীয় সভার কার্যপত্র' : 
                     filterBranch === 'নন এসএফআই' ? 'দ্বিপক্ষীয় সভার কার্যপত্র' : 
                     'দ্বি/ত্রিপক্ষীয় সভার কার্যপত্র'}
                  </th>
                  <th colSpan={2} className={`${thStyle} border border-slate-300`}>
                    {filterBranch === 'এসএফআই' ? 'ত্রিপক্ষীয় সভার কার্যবিবরণী' : 
                     filterBranch === 'নন এসএফআই' ? 'দ্বিপক্ষীয় সভার কার্যবিবরণী' : 
                     'দ্বি/ত্রিপক্ষীয় সভার কার্যবিবরণী'}
                  </th>
                  <th colSpan={2} className={`${thStyle} border border-slate-300`}>ব্রডশীট জবাব</th>
                  <th colSpan={2} className={`${thStyle} border border-slate-300`}>মিলিকরণ</th>
                  <th colSpan={2} className={`${thStyle} border border-slate-300`}>অন্যান্য</th>
                  <th colSpan={2} className={`${thStyle} bg-slate-300 text-slate-900 font-black border border-slate-300`}>মোট</th>
                </tr>
                <tr className="h-[30px]">
                  <th className={`${thStyle} border border-slate-300`}>১ মাসের কম</th>
                  <th className={`${thStyle} border border-slate-300`}>১ মাসের বেশি</th>
                  <th className={`${thStyle} border border-slate-300`}>১ মাসের কম</th>
                  <th className={`${thStyle} border border-slate-300`}>১ মাসের বেশি</th>
                  <th className={`${thStyle} border border-slate-300`}>১ মাসের কম</th>
                  <th className={`${thStyle} border border-slate-300`}>১ মাসের বেশি</th>
                  <th className={`${thStyle} border border-slate-300`}>১ মাসের কম</th>
                  <th className={`${thStyle} border border-slate-300`}>১ মাসের বেশি</th>
                  <th className={`${thStyle} border border-slate-300`}>১ মাসের কম</th>
                  <th className={`${thStyle} border border-slate-300`}>১ মাসের বেশি</th>
                  <th className={`${thStyle} bg-slate-300 font-black border border-slate-300`}>১ মাসের কম</th>
                  <th className={`${thStyle} bg-slate-300 font-black border border-slate-300`}>১ মাসের বেশি</th>
                </tr>
              </thead>
              <tbody>
                {reportTableData.length > 0 ? reportTableData.map((row, idx) => {
                  const rowLess = row.karyapatra.less + row.karyabibarani.less + row.broadsheet.less + row.reconciliation.less + row.others.less;
                  const rowMore = row.karyapatra.more + row.karyabibarani.more + row.broadsheet.more + row.reconciliation.more + row.others.more;
                  const rowLessLetters = [
                    ...row.karyapatra.lessLetters,
                    ...row.karyabibarani.lessLetters,
                    ...row.broadsheet.lessLetters,
                    ...row.reconciliation.lessLetters,
                    ...row.others.lessLetters
                  ];
                  const rowMoreLetters = [
                    ...row.karyapatra.moreLetters,
                    ...row.karyabibarani.moreLetters,
                    ...row.broadsheet.moreLetters,
                    ...row.reconciliation.moreLetters,
                    ...row.others.moreLetters
                  ];

                  return (
                    <tr key={idx} className="no-hover-row group bg-white hover:bg-blue-100/50 transition-all duration-200">
                      <td className={tdStyle}>{toBengaliDigits(idx + 1)}</td>
                      <td className={tdStyle + " text-left text-[11px] font-bold group-hover:bg-blue-50/30"}>{getDisplayName(row.name, row.rawName)}</td>
                      <td 
                        className={`${tdStyle} ${row.karyapatra.less > 0 ? 'cursor-pointer hover:bg-blue-200/80 text-blue-700 font-black' : ''} ${getHighlightClass(`${row.name} - কার্যপত্র (১ মাসের কম)`)}`}
                        onClick={() => handleCountClick(`${row.name} - কার্যপত্র (১ মাসের কম)`, row.karyapatra.lessLetters)}
                      >
                        {row.karyapatra.less > 0 ? `${toBengaliDigits(row.karyapatra.less)} টি` : '-'}
                      </td>
                      <td 
                        className={`${tdStyle} ${row.karyapatra.more > 0 ? 'cursor-pointer hover:bg-blue-200/80 text-blue-700 font-black' : ''} ${getHighlightClass(`${row.name} - কার্যপত্র (১ মাসের বেশি)`)}`}
                        onClick={() => handleCountClick(`${row.name} - কার্যপত্র (১ মাসের বেশি)`, row.karyapatra.moreLetters)}
                      >
                        {row.karyapatra.more > 0 ? `${toBengaliDigits(row.karyapatra.more)} টি` : '-'}
                      </td>
                      <td 
                        className={`${tdStyle} ${row.karyabibarani.less > 0 ? 'cursor-pointer hover:bg-blue-200/80 text-blue-700 font-black' : ''} ${getHighlightClass(`${row.name} - কার্যবিবরণী (১ মাসের কম)`)}`}
                        onClick={() => handleCountClick(`${row.name} - কার্যবিবরণী (১ মাসের কম)`, row.karyabibarani.lessLetters)}
                      >
                        {row.karyabibarani.less > 0 ? `${toBengaliDigits(row.karyabibarani.less)} টি` : '-'}
                      </td>
                      <td 
                        className={`${tdStyle} ${row.karyabibarani.more > 0 ? 'cursor-pointer hover:bg-blue-200/80 text-blue-700 font-black' : ''} ${getHighlightClass(`${row.name} - কার্যবিবরণী (১ মাসের বেশি)`)}`}
                        onClick={() => handleCountClick(`${row.name} - কার্যবিবরণী (১ মাসের বেশি)`, row.karyabibarani.moreLetters)}
                      >
                        {row.karyabibarani.more > 0 ? `${toBengaliDigits(row.karyabibarani.more)} টি` : '-'}
                      </td>
                      <td 
                        className={`${tdStyle} ${row.broadsheet.less > 0 ? 'cursor-pointer hover:bg-blue-200/80 text-blue-700 font-black' : ''} ${getHighlightClass(`${row.name} - ব্রডশীট (১ মাসের কম)`)}`}
                        onClick={() => handleCountClick(`${row.name} - ব্রডশীট (১ মাসের কম)`, row.broadsheet.lessLetters)}
                      >
                        {row.broadsheet.less > 0 ? `${toBengaliDigits(row.broadsheet.less)} টি` : '-'}
                      </td>
                      <td 
                        className={`${tdStyle} ${row.broadsheet.more > 0 ? 'cursor-pointer hover:bg-blue-200/80 text-blue-700 font-black' : ''} ${getHighlightClass(`${row.name} - ব্রডশীট (১ মাসের বেশি)`)}`}
                        onClick={() => handleCountClick(`${row.name} - ব্রডশীট (১ মাসের বেশি)`, row.broadsheet.moreLetters)}
                      >
                        {row.broadsheet.more > 0 ? `${toBengaliDigits(row.broadsheet.more)} টি` : '-'}
                      </td>
                      <td 
                        className={`${tdStyle} ${row.reconciliation.less > 0 ? 'cursor-pointer hover:bg-blue-200/80 text-blue-700 font-black' : ''} ${getHighlightClass(`${row.name} - মিলিকরণ (১ মাসের কম)`)}`}
                        onClick={() => handleCountClick(`${row.name} - মিলিকরণ (১ মাসের কম)`, row.reconciliation.lessLetters)}
                      >
                        {row.reconciliation.less > 0 ? `${toBengaliDigits(row.reconciliation.less)} টি` : '-'}
                      </td>
                      <td 
                        className={`${tdStyle} ${row.reconciliation.more > 0 ? 'cursor-pointer hover:bg-blue-200/80 text-blue-700 font-black' : ''} ${getHighlightClass(`${row.name} - মিলিকরণ (১ মাসের বেশি)`)}`}
                        onClick={() => handleCountClick(`${row.name} - মিলিকরণ (১ মাসের বেশি)`, row.reconciliation.moreLetters)}
                      >
                        {row.reconciliation.more > 0 ? `${toBengaliDigits(row.reconciliation.more)} টি` : '-'}
                      </td>
                      <td 
                        className={`${tdStyle} ${row.others.less > 0 ? 'cursor-pointer hover:bg-blue-200/80 text-blue-700 font-black' : ''} ${getHighlightClass(`${row.name} - অন্যান্য (১ মাসের কম)`)}`}
                        onClick={() => handleCountClick(`${row.name} - অন্যান্য (১ মাসের কম)`, row.others.lessLetters)}
                      >
                        {row.others.less > 0 ? `${toBengaliDigits(row.others.less)} টি` : '-'}
                      </td>
                      <td 
                        className={`${tdStyle} ${row.others.more > 0 ? 'cursor-pointer hover:bg-blue-200/80 text-blue-700 font-black' : ''} ${getHighlightClass(`${row.name} - অন্যান্য (১ মাসের বেশি)`)}`}
                        onClick={() => handleCountClick(`${row.name} - অন্যান্য (১ মাসের বেশি)`, row.others.moreLetters)}
                      >
                        {row.others.more > 0 ? `${toBengaliDigits(row.others.more)} টি` : '-'}
                      </td>
                      <td 
                        className={`${tdStyle} bg-slate-100/80 ${rowLess > 0 ? 'cursor-pointer hover:bg-blue-200/80 text-blue-800 font-black' : ''} ${getHighlightClass(`${getDisplayName(row.name, row.rawName)} - মোট (১ মাসের কম)`)}`}
                        onClick={() => handleCountClick(`${getDisplayName(row.name, row.rawName)} - মোট (১ মাসের কম)`, rowLessLetters)}
                      >
                        {rowLess > 0 ? `${toBengaliDigits(rowLess)} টি` : '-'}
                      </td>
                      <td 
                        className={`${tdStyle} bg-slate-100/80 ${rowMore > 0 ? 'cursor-pointer hover:bg-blue-200/80 text-blue-800 font-black' : ''} ${getHighlightClass(`${getDisplayName(row.name, row.rawName)} - মোট (১ মাসের বেশি)`)}`}
                        onClick={() => handleCountClick(`${getDisplayName(row.name, row.rawName)} - মোট (১ মাসের বেশি)`, rowMoreLetters)}
                      >
                        {rowMore > 0 ? `${toBengaliDigits(rowMore)} টি` : '-'}
                      </td>
                    </tr>
                  );
                }) : (
                  <tr>
                    <td colSpan={14} className="py-12 text-center italic border border-slate-300 font-bold text-slate-400">কোনো তথ্য পাওয়া যায়নি</td>
                  </tr>
                )}
              </tbody>
              <tfoot className="no-print">
                <tr className="bg-slate-900 text-white font-black">
                  <td colSpan={2} className="p-2 text-center text-[12px] bg-slate-900 text-white border border-slate-700 align-middle">
                    সর্বমোট
                  </td>
                  <td 
                    className={`p-1.5 text-center text-[12px] bg-slate-900 border border-slate-700 align-middle ${totals.kpL > 0 ? 'text-sky-300 cursor-pointer hover:bg-slate-800' : 'text-slate-400'}`}
                    onClick={() => totals.kpL > 0 && handleCountClick('সর্বমোট - কার্যপত্র (১ মাসের কম)', columnTotalLetters.kpL)}
                  >
                    {totals.kpL > 0 ? `${toBengaliDigits(totals.kpL)} টি` : '-'}
                  </td>
                  <td 
                    className={`p-1.5 text-center text-[12px] bg-slate-900 border border-slate-700 align-middle ${totals.kpM > 0 ? 'text-sky-300 cursor-pointer hover:bg-slate-800' : 'text-slate-400'}`}
                    onClick={() => totals.kpM > 0 && handleCountClick('সর্বমোট - কার্যপত্র (১ মাসের বেশি)', columnTotalLetters.kpM)}
                  >
                    {totals.kpM > 0 ? `${toBengaliDigits(totals.kpM)} টি` : '-'}
                  </td>
                  <td 
                    className={`p-1.5 text-center text-[12px] bg-slate-900 border border-slate-700 align-middle ${totals.kbL > 0 ? 'text-sky-300 cursor-pointer hover:bg-slate-800' : 'text-slate-400'}`}
                    onClick={() => totals.kbL > 0 && handleCountClick('সর্বমোট - কার্যবিবরণী (১ মাসের কম)', columnTotalLetters.kbL)}
                  >
                    {totals.kbL > 0 ? `${toBengaliDigits(totals.kbL)} টি` : '-'}
                  </td>
                  <td 
                    className={`p-1.5 text-center text-[12px] bg-slate-900 border border-slate-700 align-middle ${totals.kbM > 0 ? 'text-sky-300 cursor-pointer hover:bg-slate-800' : 'text-slate-400'}`}
                    onClick={() => totals.kbM > 0 && handleCountClick('সর্বমোট - কার্যবিবরণী (১ মাসের বেশি)', columnTotalLetters.kbM)}
                  >
                    {totals.kbM > 0 ? `${toBengaliDigits(totals.kbM)} টি` : '-'}
                  </td>
                  <td 
                    className={`p-1.5 text-center text-[12px] bg-slate-900 border border-slate-700 align-middle ${totals.bsL > 0 ? 'text-sky-300 cursor-pointer hover:bg-slate-800' : 'text-slate-400'}`}
                    onClick={() => totals.bsL > 0 && handleCountClick('সর্বমোট - ব্রডশীট (১ মাসের কম)', columnTotalLetters.bsL)}
                  >
                    {totals.bsL > 0 ? `${toBengaliDigits(totals.bsL)} টি` : '-'}
                  </td>
                  <td 
                    className={`p-1.5 text-center text-[12px] bg-slate-900 border border-slate-700 align-middle ${totals.bsM > 0 ? 'text-sky-300 cursor-pointer hover:bg-slate-800' : 'text-slate-400'}`}
                    onClick={() => totals.bsM > 0 && handleCountClick('সর্বমোট - ব্রডশীট (১ মাসের বেশি)', columnTotalLetters.bsM)}
                  >
                    {totals.bsM > 0 ? `${toBengaliDigits(totals.bsM)} টি` : '-'}
                  </td>
                  <td 
                    className={`p-1.5 text-center text-[12px] bg-slate-900 border border-slate-700 align-middle ${totals.rcL > 0 ? 'text-sky-300 cursor-pointer hover:bg-slate-800' : 'text-slate-400'}`}
                    onClick={() => totals.rcL > 0 && handleCountClick('সর্বমোট - মিলিকরণ (১ মাসের কম)', columnTotalLetters.rcL)}
                  >
                    {totals.rcL > 0 ? `${toBengaliDigits(totals.rcL)} টি` : '-'}
                  </td>
                  <td 
                    className={`p-1.5 text-center text-[12px] bg-slate-900 border border-slate-700 align-middle ${totals.rcM > 0 ? 'text-sky-300 cursor-pointer hover:bg-slate-800' : 'text-slate-400'}`}
                    onClick={() => totals.rcM > 0 && handleCountClick('সর্বমোট - মিলিকরণ (১ মাসের বেশি)', columnTotalLetters.rcM)}
                  >
                    {totals.rcM > 0 ? `${toBengaliDigits(totals.rcM)} টি` : '-'}
                  </td>
                  <td 
                    className={`p-1.5 text-center text-[12px] bg-slate-900 border border-slate-700 align-middle ${totals.otL > 0 ? 'text-sky-300 cursor-pointer hover:bg-slate-800' : 'text-slate-400'}`}
                    onClick={() => totals.otL > 0 && handleCountClick('সর্বমোট - অন্যান্য (১ মাসের কম)', columnTotalLetters.otL)}
                  >
                    {totals.otL > 0 ? `${toBengaliDigits(totals.otL)} টি` : '-'}
                  </td>
                  <td 
                    className={`p-1.5 text-center text-[12px] bg-slate-900 border border-slate-700 align-middle ${totals.otM > 0 ? 'text-sky-300 cursor-pointer hover:bg-slate-800' : 'text-slate-400'}`}
                    onClick={() => totals.otM > 0 && handleCountClick('সর্বমোট - অন্যান্য (১ মাসের বেশি)', columnTotalLetters.otM)}
                  >
                    {totals.otM > 0 ? `${toBengaliDigits(totals.otM)} টি` : '-'}
                  </td>
                  <td 
                    className={`p-1.5 text-center text-[12px] bg-slate-950 border border-slate-700 align-middle ${grandTotalLess > 0 ? 'text-amber-300 cursor-pointer hover:bg-slate-800' : 'text-slate-400'}`}
                    onClick={() => grandTotalLess > 0 && handleCountClick('সর্বমোট - মোট (১ মাসের কম)', columnTotalLetters.totL)}
                  >
                    {grandTotalLess > 0 ? `${toBengaliDigits(grandTotalLess)} টি` : '-'}
                  </td>
                  <td 
                    className={`p-1.5 text-center text-[12px] bg-slate-950 border border-slate-700 align-middle ${grandTotalMore > 0 ? 'text-amber-300 cursor-pointer hover:bg-slate-800' : 'text-slate-400'}`}
                    onClick={() => grandTotalMore > 0 && handleCountClick('সর্বমোট - মোট (১ মাসের বেশি)', columnTotalLetters.totM)}
                  >
                    {grandTotalMore > 0 ? `${toBengaliDigits(grandTotalMore)} টি` : '-'}
                  </td>
                </tr>
              </tfoot>
            </table>

            {/* নিচের সারসংক্ষেপ রো (১ম ছবির অনুরূপ) */}
            <table className="w-full border-separate border-spacing-0 table-fixed min-w-[1070px] xl:min-w-full mt-4">
              <colgroup>
                <col className="w-[22%]" />
                <col className="w-[13%]" />
                <col className="w-[22%]" />
                <col className="w-[13%]" />
                <col className="w-[17%]" />
                <col className="w-[13%]" />
              </colgroup>
              <tbody>
                <tr className="no-hover-row bg-white">
                  <td className={`${tdStyle} bg-slate-100 !border-t !border-t-[#94a3b8] font-black text-slate-900`}>
                    এক মাসের কম অনিষ্পন্ন কাজ
                  </td>
                  <td
                    className={`${tdStyle} !border-t !border-t-[#94a3b8] font-black ${grandTotalLess > 0 ? 'cursor-pointer hover:bg-blue-100 text-blue-700' : 'text-slate-800'} ${getHighlightClass('এক মাসের কম অনিষ্পন্ন কাজ')}`}
                    onClick={() => grandTotalLess > 0 && handleCountClick('এক মাসের কম অনিষ্পন্ন কাজ', columnTotalLetters.totL)}
                  >
                    {toBengaliDigits(grandTotalLess)} টি
                  </td>
                  <td className={`${tdStyle} bg-slate-100 !border-t !border-t-[#94a3b8] font-black text-slate-900`}>
                    এক মাসের বেশি অনিষ্পন্ন কাজ
                  </td>
                  <td
                    className={`${tdStyle} !border-t !border-t-[#94a3b8] font-black ${grandTotalMore > 0 ? 'cursor-pointer hover:bg-blue-100 text-blue-700' : 'text-slate-800'} ${getHighlightClass('এক মাসের বেশি অনিষ্পন্ন কাজ')}`}
                    onClick={() => grandTotalMore > 0 && handleCountClick('এক মাসের বেশি অনিষ্পন্ন কাজ', columnTotalLetters.totM)}
                  >
                    {toBengaliDigits(grandTotalMore)} টি
                  </td>
                  <td className={`${tdStyle} bg-slate-100 !border-t !border-t-[#94a3b8] font-black text-slate-900`}>
                    মোট কাজ
                  </td>
                  <td
                    className={`${tdStyle} !border-t !border-t-[#94a3b8] font-black ${(grandTotalLess + grandTotalMore) > 0 ? 'cursor-pointer hover:bg-blue-100 text-blue-800' : 'text-slate-800'} ${getHighlightClass('মোট কাজ')}`}
                    onClick={() => (grandTotalLess + grandTotalMore) > 0 && handleCountClick('মোট কাজ', [...columnTotalLetters.totL, ...columnTotalLetters.totM])}
                  >
                    {toBengaliDigits(grandTotalLess + grandTotalMore)} টি
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* SECTION 2: বিস্তারিত তালিকা টেবিল (Sticky by tableSticky.css logic) */}
        <div className="pt-8 border-t-4 border-double border-slate-200 flex flex-col items-center overflow-visible w-full max-w-full">
          <div className="w-full mb-4 space-y-3">
             {/* "ছক" ব্যাজ */}
             <div className="text-center">
               <span className="inline-flex items-center gap-1.5 px-6 py-1 bg-slate-900 text-amber-300 text-[13px] sm:text-[14px] font-black tracking-widest uppercase rounded-md shadow-xs border border-slate-800">
                 ছক
               </span>
             </div>

             {/* হেডার ও তারিখ সংক্রান্ত প্রিমিয়াম ইনফো বার */}
             <div className="flex flex-col sm:flex-row items-center justify-between gap-2.5 sm:gap-4 p-2.5 sm:p-3.5 bg-gradient-to-r from-slate-50 via-white to-slate-50 border border-slate-200/90 rounded-xl shadow-xs">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-700 shrink-0">
                    <FileText size={16} strokeWidth={2.5} />
                  </div>
                  <div className="flex items-center flex-wrap gap-2">
                    <span className="font-black text-sm sm:text-base text-slate-800 tracking-tight">
                      বকেয়া চিঠিপত্রের তালিকা
                    </span>
                    <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-black bg-blue-600/10 text-blue-700 border border-blue-200/80">
                      {filterBranch === 'সকল' ? 'সকল শাখা' : `${filterBranch} শাখা`}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 text-emerald-800 border border-emerald-200/80 rounded-lg shadow-2xs text-xs sm:text-[13px] font-black shrink-0">
                  <Calendar size={14} className="text-emerald-600 shrink-0 stroke-[2.5]" />
                  <span>তারিখ: {reportingDateBN} খ্রি:</span>
                </div>
             </div>
          </div>

          <div className="table-container dd-sir-detailed-table-container relative overflow-visible w-full rounded-none bg-white">
            <table className="w-full border-separate border-spacing-0 table-fixed min-w-[1085px] xl:min-w-full">
              <colgroup>
                <col className="w-[50px]" />
                <col className="w-[65px]" />
                <col className="w-[325px]" />
                <col className="w-[100px]" />
                <col className="w-[100px]" />
                <col className="w-[165px]" />
                <col className="w-[90px]" />
                <col className="w-[100px]" />
                <col className="w-[90px]" />
              </colgroup>
              <thead>
                <tr className="h-[42px]">
                  <th className={`${stickyThStyle} whitespace-nowrap min-w-[50px]`}>ক্রমিক নং</th>
                  <th className={stickyThStyle}>অডিটর</th>
                  <th className={stickyThStyle}>এনটিটি/প্রতিষ্ঠানের নাম</th>
                  <th className={stickyThStyle}>স্মারক নং ও তারিখ</th>
                  <th className={stickyThStyle}>ডায়েরি নং ও তারিখ</th>
                  <th className={stickyThStyle}>চিঠির ধরণ ও অনুচ্ছেদ</th>
                  <th className={stickyThStyle}>উপস্থাপনের তারিখ</th>
                  <th className={stickyThStyle}>বর্তমান অবস্থান</th>
                  <th className={stickyThStyle}>মন্তব্য</th>
                </tr>
                <tr className="h-[26px]">
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => (
                    <th key={n} className={`${stickyThStyle} text-[10.5px] font-bold text-slate-800 py-0.5`}>
                      {toBengaliDigits(n.toString())}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {detailedListData.length > 0 ? (() => {
                  let globalIdx = 0;
                  const formatSpacing = (text: string | null | undefined): string => {
                    if (!text) return '';
                    return String(text)
                      .replace(/,(\S)/g, ', $1')
                      .replace(/\)([^\s,।)])/g, ') $1')
                      .replace(/([^\s(])\(/g, '$1 (')
                      .replace(/\s+/g, ' ')
                      .trim();
                  };
                  return detailedListData.map((group) => group.rows.map((row, rowIdx) => {
                    globalIdx++;
                    return (
                      <tr key={row.id} className="no-hover-row group bg-white hover:bg-blue-100/70 transition-all duration-200 cursor-default">
                        <td className={stickyTdStyle}>{toBengaliDigits(globalIdx)}</td>
                        {rowIdx === 0 && (
                          <td
                            rowSpan={group.rows.length}
                            style={{ writingMode: 'vertical-rl' }}
                            className={stickyTdStyle + " [writing-mode:vertical-rl] bg-slate-50/50 group-hover:bg-blue-200/40 transition-colors"}
                          >
                            <span className="inline-block font-bold text-slate-900 text-[11px] leading-tight rotate-180 whitespace-nowrap py-2 mx-auto">
                              {getDisplayName(group.auditor, group.rawAuditor)}
                            </span>
                          </td>
                        )}
                        <td
                          align="justify"
                          style={{ textAlign: 'justify', textJustify: 'inter-word' }}
                          className={stickyTdStyle + " !text-justify text-justify px-2 font-bold text-[10.5px] group-hover:bg-blue-50/30"}
                        >
                          {formatSpacing(row.description)}
                        </td>
                        <td className={stickyTdStyle}>
                          <div className="flex flex-col gap-0.5">
                            <span>{formatSpacing(row.letterNo)}{row.letterNo && formatDateBN(row.letterDate) ? ', ' : ''}</span>
                            <span className="text-[9px] text-slate-500 font-bold">{formatDateBN(row.letterDate)}</span>
                          </div>
                        </td>
                        <td className={stickyTdStyle}>
                          <div className="flex flex-col gap-0.5">
                            <span>{formatSpacing(row.diaryNo)}{row.diaryNo && formatDateBN(row.diaryDate) ? ', ' : ''}</span>
                            <span className="text-[9px] text-slate-500 font-bold">{formatDateBN(row.diaryDate)}</span>
                          </div>
                        </td>
                        <td className={stickyTdStyle}>
                          <div className="flex flex-col gap-0.5">
                             <span className="text-blue-700 text-[10.5px] font-bold">
                               {formatSpacing((() => {
                                 const cleanType = getCleanLetterTypeDisplay(row.letterType);
                                 if (cleanType === 'কার্যপত্র' || cleanType === 'কার্যবিবরণী') {
                                   return row.paraType === 'এসএফআই'
                                     ? (cleanType === 'কার্যপত্র' ? 'কার্যপত্র (ত্রি-সভা)' : 'ত্রিপক্ষীয় সভা')
                                     : (cleanType === 'কার্যপত্র' ? 'দ্বি-সভা (কার্যপত্র)' : 'দ্বি-সভা (কার্যবিবরনী)');
                                 }
                                 return cleanType || row.letterType;
                               })())}{' '}
                             </span>
                             <span className="text-[9.5px] font-bold">(অনু: {toBengaliDigits(row.totalParas)}টি)</span>
                          </div>
                        </td>
                        <td className={stickyTdStyle}>{row.presentationDateFormatted || formatDateBN(row.presentationDate) || '-'}</td>
                        <td className={`${stickyTdStyle} py-1 px-1 text-center align-middle`}>
                          <div className="flex items-center justify-center w-full">
                            <span className={`inline-flex items-center justify-center px-2.5 py-0.5 text-[9.5px] font-black rounded-full shadow-xs whitespace-nowrap leading-tight tracking-tight ${getPositionColor(row.presentedToName)}`}>
                              {row.presentedToName || 'অডিটর'}
                            </span>
                          </div>
                        </td>
                        <td className={stickyTdStyle + " italic text-slate-400 text-[9px]"}>{row.remarks || '-'}</td>
                      </tr>
                    );
                  }));
                })() : (
                  <tr>
                    <td colSpan={9} className="py-20 text-center font-bold text-slate-400 bg-slate-50 italic border border-slate-300">
                      বর্তমানে বিস্তারিত তালিকায় কোনো তথ্য নেই।
                    </td>
                  </tr>
                )}
              </tbody>
              <tfoot>
                <tr className="bg-slate-200 text-slate-900 font-bold text-[12px] h-11 shadow-[0_-2px_10px_rgba(0,0,0,0.05)] border-t border-slate-300">
                  <td colSpan={3} className="px-6 text-left border-t border-slate-300 bg-slate-200">
                    <span className="mr-4 text-slate-700 font-extrabold">সর্বমোট চিঠিপত্র:</span>
                    <span className="text-blue-700 font-black ml-4">{toBengaliDigits(filteredEntries.length)} টি</span>
                  </td>
                  <td colSpan={6} className="border-t border-slate-300 bg-slate-200"></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
        
      </div>
      {/* Auditor Statistics Modal */}
      {showAuditorStatsModal && createPortal(
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[99999] flex items-center justify-center p-2 sm:p-4 lg:p-6 animate-in fade-in duration-200">
          <div className={`w-full ${isDetailsModalOpen ? 'max-w-[98vw] h-[92vh]' : 'max-w-2xl max-h-[90vh]'} flex flex-col lg:flex-row items-stretch gap-4 transition-all duration-300`}>
            
            {/* Auditor Stats Card */}
            <div className={`bg-white rounded-3xl shadow-2xl overflow-hidden flex flex-col transition-all duration-300 ${isDetailsModalOpen ? 'w-full lg:w-[35%] shrink-0 h-full' : 'w-full max-h-full'}`}>
              <div className="bg-slate-900 px-6 py-3.5 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-600/20 rounded-xl flex items-center justify-center">
                    <BarChart3 size={20} className="text-blue-400" />
                  </div>
                  <div>
                    <h3 className="text-white font-bold text-[16px]">অডিটর ভিত্তিক পরিসংখ্যান</h3>
                    <p className="text-slate-400 text-[11px] font-bold">কার কাছে কয়টি চিঠি আছে তার বিস্তারিত হিসাব</p>
                  </div>
                </div>
                <button 
                  onClick={() => {
                    setShowAuditorStatsModal(false);
                    setIsDetailsModalOpen(false);
                  }}
                  className="w-10 h-10 flex items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20 transition-all"
                >
                  <X size={20} />
                </button>
              </div>
              
              <div className={`overflow-y-auto no-scrollbar flex-1 min-h-0 ${isDetailsModalOpen ? 'p-2 sm:p-3' : 'p-3 sm:p-6'}`}>
                <table className="w-full border-collapse table-fixed">
                  <colgroup>
                    <col className={isDetailsModalOpen ? "w-[28%]" : "w-[36%]"} />
                    <col className={isDetailsModalOpen ? "w-[18%]" : "w-[16%]"} />
                    <col className={isDetailsModalOpen ? "w-[18%]" : "w-[16%]"} />
                    <col className={isDetailsModalOpen ? "w-[18%]" : "w-[16%]"} />
                    <col className={isDetailsModalOpen ? "w-[18%]" : "w-[16%]"} />
                  </colgroup>
                  <thead>
                    <tr className="bg-slate-100">
                      <th className={`border border-slate-200 ${isDetailsModalOpen ? 'px-0.5 py-1 text-[8.5px] sm:text-[9.5px]' : 'px-1 py-1.5 text-[10px] sm:text-[11px]'} text-center font-black text-slate-700 leading-tight`}>অডিটর</th>
                      <th className={`border border-slate-200 ${isDetailsModalOpen ? 'px-0.5 py-1 text-[8.5px] sm:text-[9.5px]' : 'px-1 py-1.5 text-[10px] sm:text-[11px]'} text-center font-black text-slate-700 leading-tight`}>অডিটরের</th>
                      <th className={`border border-slate-200 ${isDetailsModalOpen ? 'px-0.5 py-1 text-[8.5px] sm:text-[9.5px]' : 'px-1 py-1.5 text-[10px] sm:text-[11px]'} text-center font-black text-slate-700 leading-tight`}>এএন্ডএও</th>
                      <th className={`border border-slate-200 ${isDetailsModalOpen ? 'px-0.5 py-1 text-[8.5px] sm:text-[9.5px]' : 'px-1 py-1.5 text-[10px] sm:text-[11px]'} text-center font-black text-slate-700 leading-tight`}>উপপরিচালক</th>
                      <th className={`border border-slate-200 ${isDetailsModalOpen ? 'px-0.5 py-1 text-[8.5px] sm:text-[9.5px]' : 'px-1 py-1.5 text-[10px] sm:text-[11px]'} text-center font-black text-slate-700 leading-tight`}>মোট</th>
                    </tr>
                  </thead>
                  <tbody>
                    {auditorWiseStats.map((stat, idx) => (
                      <tr key={idx} className="hover:bg-blue-50/50 transition-colors">
                        <td className={`border border-slate-200 ${isDetailsModalOpen ? 'p-0.5' : 'px-1 py-2'} text-center align-middle overflow-hidden`}>
                          <div className="flex flex-col items-center justify-center gap-0.5 sm:gap-1 w-full mx-auto px-0.5 overflow-hidden">
                            {getDisplayImage(stat.name, stat.rawName) ? (
                              <img 
                                src={getDisplayImage(stat.name, stat.rawName)!} 
                                alt={getDisplayName(stat.name, stat.rawName)} 
                                className={`${isDetailsModalOpen ? 'w-6 h-6 sm:w-7 sm:h-7 rounded-lg' : 'w-8 h-8 sm:w-10 sm:h-10 rounded-xl'} object-cover border border-slate-100 shrink-0 shadow-sm`} 
                                referrerPolicy="no-referrer"
                              />
                            ) : (
                              <div className={`${isDetailsModalOpen ? 'w-6 h-6 sm:w-7 sm:h-7 text-[8px] rounded-lg' : 'w-8 h-8 sm:w-10 sm:h-10 text-xs rounded-xl'} bg-blue-50 text-blue-600 flex items-center justify-center font-black shrink-0 uppercase shadow-sm`}>
                                {getDisplayName(stat.name, stat.rawName).slice(0, 2)}
                              </div>
                            )}
                            <div className="flex flex-col items-center w-full min-w-0 overflow-hidden">
                              <span className={`${isDetailsModalOpen ? 'text-[7.5px] sm:text-[8px] tracking-tight' : 'text-[9.5px] sm:text-[11px]'} font-extrabold text-slate-800 leading-tight text-center break-words whitespace-normal w-full`}>{getDisplayName(stat.name, stat.rawName)}</span>
                              <span className={`${isDetailsModalOpen ? 'text-[6.5px] sm:text-[7px]' : 'text-[7.5px] sm:text-[9px]'} font-bold text-slate-400 leading-none mt-0.5 text-center break-words whitespace-normal w-full`}>
                                {getDisplayDesignation(stat.name, stat.rawName)}
                              </span>
                            </div>
                          </div>
                        </td>
                        <td 
                          className={`border border-slate-200 ${isDetailsModalOpen ? 'px-0.5 py-1 text-[8.5px] sm:text-[10px]' : 'px-1 py-1.5 text-[10px] sm:text-[11.5px]'} text-center font-black text-red-600 bg-red-50/30 cursor-pointer hover:bg-red-100/50 transition-all ${getHighlightClass(`${getDisplayName(stat.name, stat.rawName)} - অডিটরের কাছে`)}`}
                          onClick={() => handleCountClick(`${getDisplayName(stat.name, stat.rawName)} - অডিটরের কাছে`, stat.auditorLetters)}
                        >
                          {toBengaliDigits(stat.auditor)} টি
                        </td>
                        <td 
                          className={`border border-slate-200 ${isDetailsModalOpen ? 'px-0.5 py-1 text-[8.5px] sm:text-[10px]' : 'px-1 py-1.5 text-[10px] sm:text-[11.5px]'} text-center font-black text-blue-600 bg-blue-50/30 cursor-pointer hover:bg-blue-100/50 transition-all ${getHighlightClass(`${getDisplayName(stat.name, stat.rawName)} - এএন্ডএও`)}`}
                          onClick={() => handleCountClick(`${getDisplayName(stat.name, stat.rawName)} - এএন্ডএও`, stat.aaoLetters)}
                        >
                          {toBengaliDigits(stat.aao)} টি
                        </td>
                        <td 
                          className={`border border-slate-200 ${isDetailsModalOpen ? 'px-0.5 py-1 text-[8.5px] sm:text-[10px]' : 'px-1 py-1.5 text-[10px] sm:text-[11.5px]'} text-center font-black text-green-600 bg-green-50/30 cursor-pointer hover:bg-green-100/50 transition-all ${getHighlightClass(`${getDisplayName(stat.name, stat.rawName)} - উপপরিচালক`)}`}
                          onClick={() => handleCountClick(`${getDisplayName(stat.name, stat.rawName)} - উপপরিচালক`, stat.ddLetters)}
                        >
                          {toBengaliDigits(stat.dd)} টি
                        </td>
                        <td 
                          className={`border border-slate-200 ${isDetailsModalOpen ? 'px-0.5 py-1 text-[8.5px] sm:text-[10px]' : 'px-1 py-1.5 text-[10px] sm:text-[11.5px]'} text-center font-black text-slate-900 bg-slate-50 cursor-pointer hover:bg-slate-200/50 transition-all ${getHighlightClass(`${getDisplayName(stat.name, stat.rawName)} - মোট`)}`}
                          onClick={() => handleCountClick(`${getDisplayName(stat.name, stat.rawName)} - মোট`, stat.totalLetters)}
                        >
                          {toBengaliDigits(stat.total)} টি
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                
                {auditorWiseStats.length === 0 && (
                  <div className="py-10 text-center text-slate-400 font-bold italic">
                    কোনো তথ্য পাওয়া যায়নি।
                  </div>
                )}
              </div>
              
              <div className="bg-slate-50 px-6 py-3.5 flex justify-end border-t border-slate-100 shrink-0">
                <button 
                  onClick={() => {
                    setShowAuditorStatsModal(false);
                    setIsDetailsModalOpen(false);
                  }}
                  className="px-6 py-2 bg-slate-900 text-white rounded-xl font-bold text-[12px] hover:bg-slate-800 transition-all shadow-md"
                >
                  বন্ধ করুন
                </button>
              </div>
            </div>

            {/* Embedded letters detail card */}
            {isDetailsModalOpen && (
              <div className="w-full lg:flex-1 h-full flex flex-col overflow-hidden animate-in slide-in-from-right-8 duration-300">
                <LetterDetailsModal 
                  isOpen={isDetailsModalOpen}
                  onClose={() => setIsDetailsModalOpen(false)}
                  title={detailsModalTitle}
                  letters={detailsModalLetters}
                  isEmbedded={true}
                />
              </div>
            )}

          </div>
        </div>,
        document.body
      )}
      {/* Letter Details Modal (fallback only) */}
      {!showAuditorStatsModal && (
        <LetterDetailsModal 
          isOpen={isDetailsModalOpen}
          onClose={() => setIsDetailsModalOpen(false)}
          title={detailsModalTitle}
          letters={detailsModalLetters}
        />
      )}
    </div>
  );
};

export default DDSirCorrespondenceReturn;