import React, { useState, useMemo, useEffect, useRef, useLayoutEffect } from 'react';
import { Sparkles, ChevronDown, BarChart3, FileSpreadsheet, Building2, Landmark, Check, CalendarDays, X } from 'lucide-react';
import { toBengaliDigits, parseBengaliNumber } from '../utils/numberUtils';
import { format, addMonths } from 'date-fns';
import HighlightText from './HighlightText';
import { SettlementEntry } from '../types';
import { getQuarterlyCycleForDate } from '../utils/cycleHelper';

interface QRProps {
  entries: SettlementEntry[];
  prevStats?: any;
  activeCycle: any;
  IDBadge: React.FC<{ id: string }>;
  onBack?: () => void;
  searchTerm?: string;
  filterMinistry?: string;
  monthPickerElement?: React.ReactNode;
  periodOpeningBalances?: any[];
}

const robustNormalize = (str: string = '') => {
  return str.normalize('NFC').replace(/[\u200B-\u200D\uFEFF]/g, '').replace(/\s+/g, ' ').trim();
};

const isEntityMatch = (entryEntity: string = '', targetEntity: string = ''): boolean => {
  const normEntry = robustNormalize(entryEntity);
  const normTarget = robustNormalize(targetEntity);
  if (!normEntry || !normTarget) return false;
  if (normEntry === normTarget) return true;

  // Cottage / Handicraft / Small Industries / BSCIC
  if ((normTarget.includes("কুটির") || normTarget.includes("হস্ত") || normTarget.includes("বিসিক")) && 
      (normEntry.includes("কুটির") || normEntry.includes("হস্ত") || normEntry.includes("বিসিক"))) return true;

  // Sugar & Food Industries (বিএসএফআইসি / চিনি ও খাদ্য)
  if ((normTarget.includes("চিনি") || normTarget.includes("খাদ্য") || normTarget.includes("বিএসএফআইসি")) && 
      (normEntry.includes("চিনি") || normEntry.includes("খাদ্য") || normEntry.includes("বিএসএফআইসি"))) return true;

  // Chemical Industries (BCIC / বিসিআইসি / রসায়ন)
  if ((normTarget.includes("রসায়ন") || normTarget.includes("রসায়ন") || normTarget.includes("বিসিআইসি")) && 
      (normEntry.includes("রসায়ন") || normEntry.includes("রসায়ন") || normEntry.includes("বিসিআইসি"))) return true;

  // Banks & Financial Institutions
  if (normTarget.includes("সোনালী") && normEntry.includes("সোনালী")) return true;
  if (normTarget.includes("জনতা") && normEntry.includes("জনতা")) return true;
  if (normTarget.includes("অগ্রণী") && normEntry.includes("অগ্রণী")) return true;
  if (normTarget.includes("রূপালী") && normEntry.includes("রূপালী")) return true;
  if (normTarget.includes("কৃষি") && normEntry.includes("কৃষি")) return true;
  if (normTarget.includes("বাংলাদেশ ব্যাংক") && normEntry.includes("বাংলাদেশ ব্যাংক")) return true;
  if (normTarget.includes("ডেভেলপমেন্ট") && normEntry.includes("ডেভেলপমেন্ট")) return true;
  if (normTarget.includes("গৃহনির্মাণ") && normEntry.includes("গৃহনির্মাণ")) return true;
  if (normTarget.includes("কর্মসংস্থান") && normEntry.includes("কর্মসংস্থান")) return true;
  if (normTarget.includes("বেসিক") && normEntry.includes("বেসিক")) return true;
  if (normTarget.includes("আনসার") && normEntry.includes("আনসার")) return true;
  if (normTarget.includes("ইনভেস্ট") && normEntry.includes("ইনভেস্ট")) return true;
  if (normTarget.includes("সাধারণ বীমা") && normEntry.includes("সাধারণ বীমা")) return true;
  if (normTarget.includes("জীবন বীমা") && normEntry.includes("জীবন বীমা")) return true;
  if (normTarget.includes("প্রবাসী কল্যাণ") && normEntry.includes("প্রবাসী কল্যাণ")) return true;

  // Jute & Textiles (Patkol vs Pat)
  const isPatkolTarget = normTarget.includes("পাটকল") || normTarget.includes("বিজেএমসি") || normTarget.includes("জুট");
  const isPatkolEntry = normEntry.includes("পাটকল") || normEntry.includes("বিজেএমসি") || normEntry.includes("জুট");
  if (isPatkolTarget || isPatkolEntry) return isPatkolTarget && isPatkolEntry;

  const isPatTarget = normTarget.includes("পাট") && !normTarget.includes("পাটকল") && !normTarget.includes("বিজেএমসি");
  const isPatEntry = normEntry.includes("পাট") && !normEntry.includes("পাটকল") && !normEntry.includes("বিজেএমসি");
  if (isPatTarget || isPatEntry) return isPatTarget && isPatEntry;

  // Commerce / Aviation / Tourism
  if (normTarget.includes("টিসিবি") && normEntry.includes("টিসিবি")) return true;
  if ((normTarget.includes("আমদানি") || normTarget.includes("রপ্তানি")) && 
      (normEntry.includes("আমদানি") || normEntry.includes("রপ্তানি"))) return true;
  if (normTarget.includes("বিমান") && normEntry.includes("বিমান")) return true;
  if (normTarget.includes("পর্যটন") && normEntry.includes("পর্যটন")) return true;

  return normEntry.includes(normTarget) || normTarget.includes(normEntry);
};

interface EntityPriorValues {
  col4: number;  // প্রারম্ভিক অমিমাংসিত উত্থাপিত আপত্তির সংখ্যা
  col7: number;  // প্রারম্ভিক নিষ্পত্তিকৃত আপত্তির সংখ্যা
  col11: number; // অমিমাংসিত আপত্তিতে জড়িত টাকা
}

const table1Data = [
  {
    ministry: "শিল্প মন্ত্রণালয়",
    entities: ["চিনি ও খাদ্য সংস্থা", "ক্ষুদ্র ও কুটির শিল্প", "বিটাক", "রসায়ন শিল্প"]
  },
  {
    ministry: "বস্ত্র ও পাট মন্ত্রণালয়",
    entities: ["পাটকল সংস্থা", "পাট সংস্থা", "বস্ত্রকল সংস্থা", "রেশম বোর্ড"]
  },
  {
    ministry: "বাণিজ্য মন্ত্রণালয়",
    entities: ["টিসিবি", "আমদানি ও রপ্তানি"]
  },
  {
    ministry: "বেসামরিক বিমান পরিবহন ও পর্যটন",
    entities: ["বাংলাদেশ বিমান", "পর্যটন কর্পোরেশন"]
  }
];

const table2Data = [
  {
    ministry: "আর্থিক প্রতিষ্ঠান বিভাগ",
    entities: [
      "সোনালী ব্যাংক পিএলসি",
      "জনতা ব্যাংক পিএলসি",
      "অগ্রণী ব্যাংক পিএলসি",
      "বাংলাদেশ কৃষি ব্যাংক",
      "রূপালী ব্যাংক পিএলসি",
      "বাংলাদেশ ব্যাংক",
      "বাংলাদেশ ডেভেলপমেন্ট ব্যাংক লি.",
      "গৃহনির্মাণ ঋণদান সংস্থা",
      "কর্মসংস্থান ব্যাংক",
      "বেসিক ব্যাংক লি.",
      "আনসার ভিডিপি উন্নয়ন ব্যাংক লি.",
      "ইনভেস্টমেন্ট কর্পোরেশন অব বাংলাদেশ",
      "সাধারণ বীমা কর্পোরেশন",
      "জীবন বীমা কর্পোরেশন",
      "প্রবাসী কল্যাণ ব্যাংক"
    ]
  }
];

const allMinistryGroups = [...table1Data, ...table2Data];

const QR_Detailed_1: React.FC<QRProps> = ({
  entries,
  prevStats,
  activeCycle,
  IDBadge,
  searchTerm = '',
  filterMinistry = '',
  monthPickerElement,
  periodOpeningBalances
}) => {
  const getQuarterInfo = (date: Date) => {
    const cycleEndMonth = date.getMonth(); // 0 to 11
    const year = date.getFullYear();
    let quarterStartMonth = 0;
    let quarterEndMonth = 2;
    let quarterYear = year;

    if (cycleEndMonth >= 0 && cycleEndMonth <= 2) {
      quarterStartMonth = 0; // Jan
      quarterEndMonth = 2;   // Mar
    } else if (cycleEndMonth >= 3 && cycleEndMonth <= 5) {
      quarterStartMonth = 3; // Apr
      quarterEndMonth = 5;   // Jun
    } else if (cycleEndMonth >= 6 && cycleEndMonth <= 8) {
      quarterStartMonth = 6; // Jul
      quarterEndMonth = 8;   // Sep
    } else {
      quarterStartMonth = 9; // Oct
      quarterEndMonth = 11;  // Dec
    }

    const months = ["জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"];
    const startMonthName = months[quarterStartMonth];
    const endMonthName = months[quarterEndMonth];
    
    let priorMonthIdx = quarterStartMonth - 1;
    let priorYear = quarterYear;
    if (priorMonthIdx < 0) {
      priorMonthIdx = 11;
      priorYear -= 1;
    }
    const priorMonthName = months[priorMonthIdx];

    const formattedRange = `${startMonthName}/${toBengaliDigits(quarterYear.toString())} হতে ${endMonthName}/${toBengaliDigits(quarterYear.toString())}`;
    const priorPeriodEnd = `${priorMonthName}/${toBengaliDigits(priorYear.toString())}`;
    const cumPeriodEnd = `${endMonthName}/${toBengaliDigits(quarterYear.toString())}`;

    return {
      formattedRange,
      priorPeriodEnd,
      cumPeriodEnd
    };
  };

  const { formattedRange, priorPeriodEnd, cumPeriodEnd } = getQuarterInfo(activeCycle?.end || new Date());

  // Multi-select filters state (Cycle, Ministry, Entity)
  const [selectedCycles, setSelectedCycles] = useState<string[]>([]);
  const [selectedMinistries, setSelectedMinistries] = useState<string[]>([]);
  const [selectedEntities, setSelectedEntities] = useState<string[]>([]);

  const [isCycleOpen, setIsCycleOpen] = useState(false);
  const [isMinOpen, setIsMinOpen] = useState(false);
  const [isEntOpen, setIsEntOpen] = useState(false);

  const cycleDropdownRef = useRef<HTMLDivElement>(null);
  const minDropdownRef = useRef<HTMLDivElement>(null);
  const entDropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (cycleDropdownRef.current && !cycleDropdownRef.current.contains(e.target as Node)) {
        setIsCycleOpen(false);
      }
      if (minDropdownRef.current && !minDropdownRef.current.contains(e.target as Node)) {
        setIsMinOpen(false);
      }
      if (entDropdownRef.current && !entDropdownRef.current.contains(e.target as Node)) {
        setIsEntOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const cycleOptions = useMemo(() => {
    const list: { label: string; start: Date; end: Date; startStr: string; endStr: string }[] = [];
    const baseDate = activeCycle?.end ? new Date(activeCycle.end) : new Date();
    for (let i = -3; i <= 3; i++) {
      const targetDate = addMonths(baseDate, i * 3);
      const c = getQuarterlyCycleForDate(targetDate);
      if (!list.some(item => item.label === c.label)) {
        list.push({
          label: c.label,
          start: c.start,
          end: c.end,
          startStr: format(c.start, 'yyyy-MM-dd'),
          endStr: format(c.end, 'yyyy-MM-dd'),
        });
      }
    }
    return list;
  }, [activeCycle]);

  const ministryOptions = useMemo(() => {
    const set = new Set<string>();
    allMinistryGroups.forEach(g => set.add(g.ministry));
    return Array.from(set);
  }, []);

  const entityOptions = useMemo(() => {
    const set = new Set<string>();
    const groups = selectedMinistries.length > 0 
      ? allMinistryGroups.filter(g => selectedMinistries.includes(g.ministry))
      : allMinistryGroups;
    groups.forEach(g => g.entities.forEach(ent => set.add(ent)));
    return Array.from(set);
  }, [selectedMinistries]);

  // Filter Table 1 & Table 2 data based on selected ministries/entities
  const filteredTable1Data = useMemo(() => {
    return table1Data.map(group => {
      if (selectedMinistries.length > 0 && !selectedMinistries.includes(group.ministry)) {
        return null;
      }
      const filteredEntities = group.entities.filter(ent => {
        if (selectedEntities.length > 0 && !selectedEntities.some(se => isEntityMatch(ent, se))) {
          return false;
        }
        return true;
      });
      if (filteredEntities.length === 0) return null;
      return { ...group, entities: filteredEntities };
    }).filter(Boolean) as typeof table1Data;
  }, [selectedMinistries, selectedEntities]);

  const filteredTable2Data = useMemo(() => {
    return table2Data.map(group => {
      if (selectedMinistries.length > 0 && !selectedMinistries.includes(group.ministry)) {
        return null;
      }
      const filteredEntities = group.entities.filter(ent => {
        if (selectedEntities.length > 0 && !selectedEntities.some(se => isEntityMatch(ent, se))) {
          return false;
        }
        return true;
      });
      if (filteredEntities.length === 0) return null;
      return { ...group, entities: filteredEntities };
    }).filter(Boolean) as typeof table2Data;
  }, [selectedMinistries, selectedEntities]);

  const downloadExcel = () => {
    const tables = document.querySelectorAll('table');
    if (tables.length === 0) return;

    let tablesHtml = '';
    tables.forEach((table, tableIdx) => {
      const clonedTable = table.cloneNode(true) as HTMLTableElement;
      const interactiveElements = clonedTable.querySelectorAll('.no-print, button, svg, input, select');
      interactiveElements.forEach(el => el.remove());
      
      tablesHtml += `
        <div style="margin-bottom: 40px;">
          ${tableIdx > 0 ? '<br><hr><br>' : ''}
          ${clonedTable.outerHTML}
        </div>
      `;
    });

    const filename = `ত্রৈমাসিক_রিটার্ন_বিস্তারিত_১_${format(new Date(), 'yyyy-MM-dd')}.xls`;

    const template = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
      <head>
        <meta http-equiv="content-type" content="application/vnd.ms-excel; charset=UTF-8">
        <style>
          body { font-family: 'Segoe UI', 'Hind Siliguri', sans-serif; }
          table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }
          th, td { border: 1px solid #cbd5e1 !important; padding: 6px 10px !important; text-align: center; font-size: 11px; vertical-align: middle; }
          th { background-color: #f1f5f9 !important; color: #0f172a !important; font-weight: bold !important; }
          .bg-yellow-header { background-color: #facc15 !important; color: #000000 !important; font-weight: bold !important; }
          .bg-black { background-color: #000000 !important; color: #ffffff !important; }
        </style>
      </head>
      <body>
        <h2 style="text-align: center; margin-bottom: 20px; color: #1e3a8a;">বিস্তারিত - ১</h2>
        ${tablesHtml}
      </body>
      </html>
    `;

    const blob = new Blob([template], { type: 'application/vnd.ms-excel;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Compute metrics for each entity
  const getEntityData = (entityName: string) => {
    let priorRaisedCount = 0;
    let priorRaisedAmount = 0;
    let priorSettledCount = 0;
    let priorSettledAmount = 0;

    let currentRaisedCount = 0;
    let currentSettledCount = 0;
    let currentSettledAmount = 0;

    const cycleStartStr = activeCycle?.start ? format(activeCycle.start, 'yyyy-MM-dd') : '';
    const cycleEndStr = activeCycle?.end ? format(activeCycle.end, 'yyyy-MM-dd') : '';

    (entries || []).forEach(e => {
      if (isEntityMatch(e.entityName || '', entityName)) {
        // Extract raised count
        let rCount = 0;
        const rCountRaw = e.manualRaisedCount?.toString().trim() || "";
        if (rCountRaw !== "" && rCountRaw !== "0" && rCountRaw !== "০") {
          rCount = parseBengaliNumber(rCountRaw);
        }

        // Extract raised amount
        let rAmount = 0;
        if (e.manualRaisedAmount) {
          rAmount = parseBengaliNumber(String(e.manualRaisedAmount));
        }

        // Extract settled amount
        let settledAmt = 0;
        if (e.paragraphs && e.paragraphs.length > 0) {
          e.paragraphs.forEach(p => {
            settledAmt += parseBengaliNumber(String(p.recoveredAmount || '0')) + parseBengaliNumber(String(p.adjustedAmount || '0'));
          });
        } else {
          if (e.settledAmount) {
            settledAmt += parseBengaliNumber(String(e.settledAmount));
          } else if (e.manualSettledAmount) {
            settledAmt += parseBengaliNumber(String(e.manualSettledAmount));
          } else {
            const rec = (e.totalRec || 0) + (e.totalAdj || 0);
            if (rec > 0) settledAmt += rec;
          }
        }

        // Extract settled count (only full settlements count towards settled paragraph count)
        let sCount = 0;
        if (e.paragraphs && e.paragraphs.length > 0) {
          sCount = e.paragraphs.filter(p => robustNormalize(p.status || '') === robustNormalize('পূর্ণাঙ্গ')).length;
        } else {
          const rawFc = parseBengaliNumber(String(e.fullCount || e.meetingFullSettledParaCount || e.meetingSettledParaCount || 0));
          if (settledAmt > 0 && (rawFc === settledAmt || rawFc > 500)) {
            sCount = 1;
          } else {
            sCount = rawFc;
          }
        }

        // Categorize by date relative to active cycle using string comparison (yyyy-MM-dd)
        const entryDateRaw = e.issueDateISO || (e.createdAt ? e.createdAt.split('T')[0] : '');
        const entryDate = entryDateRaw ? entryDateRaw.split('T')[0] : '';

        if (selectedCycles.length > 0) {
          const matchedCycle = cycleOptions.find(c => selectedCycles.includes(c.label) && entryDate >= c.startStr && entryDate <= c.endStr);
          if (matchedCycle) {
            currentRaisedCount += rCount;
            currentSettledCount += sCount;
            currentSettledAmount += settledAmt;
          }
        } else if (cycleStartStr && cycleEndStr && entryDate) {
          if (entryDate < cycleStartStr) {
            // Prior quarter entry -> carry forward to opening balance of current quarter
            priorRaisedCount += rCount;
            priorRaisedAmount += rAmount;
            priorSettledCount += sCount;
            priorSettledAmount += settledAmt;
          } else if (entryDate >= cycleStartStr && entryDate <= cycleEndStr) {
            // Current active quarter entry
            currentRaisedCount += rCount;
            currentSettledCount += sCount;
            currentSettledAmount += settledAmt;
          }
        } else {
          currentRaisedCount += rCount;
          currentSettledCount += sCount;
          currentSettledAmount += settledAmt;
        }
      }
    });

    // Helper to get stats from a map with robust key matching
    const getStatsFromMap = (map: Record<string, any> | undefined) => {
      if (!map) return { unsettledCount: 0, unsettledAmount: 0, settledCount: 0, settledAmount: 0 };
      let matchKey = entityName;
      if (robustNormalize(entityName) === robustNormalize("হস্ত ও কুটির শিল্প সংস্থা")) {
        matchKey = "ক্ষুদ্র ও কুটির শিল্প";
      } else if (robustNormalize(entityName) === robustNormalize("রসায়ন শিল্প সংস্থা")) {
        matchKey = "রসায়ন শিল্প";
      }
      let res = map[matchKey] || map[entityName];
      if (!res) {
        const keys = Object.keys(map);
        const foundKey = keys.find(k => isEntityMatch(k, entityName));
        if (foundKey) res = map[foundKey];
      }
      return res || { unsettledCount: 0, unsettledAmount: 0, settledCount: 0, settledAmount: 0 };
    };

    // পূর্ব জের টেবিল হতে প্রারম্ভিক জের প্রাপ্তি এবং ত্রৈমাসিক রিটার্নে ম্যাপিং:
    // - পূর্ব জের কলাম (২) [অমীমাংসিত অনুচ্ছেদ সংখ্যা] -> কলাম ৪ (প্রারম্ভিক অমীমাংসিত অনুচ্ছেদ সংখ্যা)
    // - পূর্ব জের কলাম (৪) [অমীমাংসিত টাকা (ত্রৈমাসিক)] -> কলাম ১১ (প্রারম্ভিক অমীমাংসিত টাকা)
    // - পূর্ব জের কলাম (৫) [মীমাংসিত অনুচ্ছেদ সংখ্যা] -> কলাম ৭ (প্রারম্ভিক নিষ্পত্তিকৃত অনুচ্ছেদ সংখ্যা)
    let baseUnsettledCount = 0;
    let baseUnsettledAmount = 0;
    let baseSettledCount = 0;

    const exactMatch = periodOpeningBalances?.find(pb => pb.startDate === cycleStartStr);
    let sfiObj: any = null;
    let nonSfiObj: any = null;

    if (exactMatch && exactMatch.stats) {
      sfiObj = getStatsFromMap(exactMatch.stats.entitiesSFI);
      nonSfiObj = getStatsFromMap(exactMatch.stats.entitiesNonSFI);
    } else if (prevStats) {
      sfiObj = getStatsFromMap(prevStats.entitiesSFI);
      nonSfiObj = getStatsFromMap(prevStats.entitiesNonSFI);
    }

    if (sfiObj || nonSfiObj) {
      const sC = sfiObj?.unsettledCount || 0;
      const nsC = nonSfiObj?.unsettledCount || 0;
      const sA = sfiObj?.unsettledAmount || 0;
      const nsA = nonSfiObj?.unsettledAmount || 0;
      const sQA = (sfiObj && sfiObj.unsettledQuarterlyAmount !== undefined && sfiObj.unsettledQuarterlyAmount !== null)
        ? sfiObj.unsettledQuarterlyAmount 
        : sA;
      const nsQA = (nonSfiObj && nonSfiObj.unsettledQuarterlyAmount !== undefined && nonSfiObj.unsettledQuarterlyAmount !== null)
        ? nonSfiObj.unsettledQuarterlyAmount 
        : nsA;
      const sS = sfiObj?.settledCount || 0;
      const nsS = nonSfiObj?.settledCount || 0;

      // Opening Balance Setup uses a unified master row per entity.
      // Column 4 (unsettledQuarterlyAmount) represents the total initial quarterly unsettled amount.
      if (sQA === nsQA || nsQA === 0 || sfiObj === nonSfiObj) {
        baseUnsettledAmount = sQA;
      } else if (sQA === 0) {
        baseUnsettledAmount = nsQA;
      } else {
        baseUnsettledAmount = sQA + nsQA;
      }

      if (sC === nsC || nsC === 0 || sfiObj === nonSfiObj) {
        baseUnsettledCount = sC;
      } else if (sC === 0) {
        baseUnsettledCount = nsC;
      } else {
        baseUnsettledCount = sC + nsC;
      }

      if (sS === nsS || nsS === 0 || sfiObj === nonSfiObj) {
        baseSettledCount = sS;
      } else if (sS === 0) {
        baseSettledCount = nsS;
      } else {
        baseSettledCount = sS + nsS;
      }
    }

    const col4 = baseUnsettledCount + priorRaisedCount;
    const col5 = currentRaisedCount;
    const col6 = col4 + col5;

    const col7 = baseSettledCount + priorSettledCount;
    const col8 = currentSettledCount;
    const col9 = col7 + col8;

    const col10 = col6 - col9;

    const col11 = baseUnsettledAmount + priorRaisedAmount - priorSettledAmount;
    const col12 = currentSettledAmount;
    const col13 = col11 - col12;

    return { col4, col5, col6, col7, col8, col9, col10, col11, col12, col13 };
  };

  // Header styles (solid opaque ice-slate with embossed borders and sticky positioning)
  const reportThStyle1 = "sticky top-0 z-[140] p-2 font-black text-center text-slate-900 text-[10px] leading-tight align-middle bg-[#e2e8f0] border-r border-b border-slate-300 bg-clip-border whitespace-nowrap";
  const reportThStyle2 = "sticky z-[135] p-2 font-black text-center text-slate-900 text-[9.5px] leading-tight align-middle bg-[#e2e8f0] border-r border-b border-slate-300 bg-clip-border whitespace-normal";
  const reportThStyle3 = "sticky z-[130] p-1 font-black text-center text-slate-700 text-[9px] leading-tight align-middle bg-[#e2e8f0] border-r border-b border-slate-300 bg-clip-border whitespace-nowrap";

  const thCls = reportThStyle1;
  const thRow2Cls = reportThStyle2;
  const thRow3Cls = reportThStyle3;

  const yellowThCls = reportThStyle1;
  const yellowThRow2Cls = reportThStyle2;
  const yellowThRow3Cls = reportThStyle3;

  const tdCls = "p-2 text-[10px] text-slate-800 align-middle bg-white border-b border-r border-slate-200/90";
  const numTdCls = "p-2 text-[10px] text-slate-900 text-center align-middle font-bold bg-white border-b border-r border-slate-200/90 whitespace-nowrap";
  const footerTdCls = "p-2.5 text-[10px] text-white align-middle bg-slate-950 font-black text-center border-r border-slate-800 shadow-[inset_0_2px_0_rgba(255,255,255,0.15)] whitespace-nowrap";

  // Refs for Table 1 and Table 2 to dynamically compute sticky header row offsets
  const table1Ref = useRef<HTMLTableElement>(null);
  const table2Ref = useRef<HTMLTableElement>(null);

  useLayoutEffect(() => {
    const updateHeaderStickyOffsets = () => {
      [table1Ref.current, table2Ref.current].forEach((table) => {
        if (!table) return;
        const tr1 = table.querySelector('thead tr:nth-child(1)') as HTMLElement | null;
        if (tr1) {
          const nonRowSpanCell = (tr1.querySelector('th:not([rowspan]):not([rowSpan])') || tr1.children[3]) as HTMLElement | null;
          const rowSpanCell = (tr1.querySelector('th[rowspan], th[rowSpan]') || tr1.children[0]) as HTMLElement | null;

          const r2Top = nonRowSpanCell ? Math.floor(nonRowSpanCell.getBoundingClientRect().height) : 34;
          const r3Top = rowSpanCell ? Math.floor(rowSpanCell.getBoundingClientRect().height) : (r2Top + 76);

          table.style.setProperty('--th-r2-top', `${r2Top}px`);
          table.style.setProperty('--th-r3-top', `${r3Top}px`);
        }
      });
    };

    updateHeaderStickyOffsets();
    const t1 = setTimeout(updateHeaderStickyOffsets, 50);
    const t2 = setTimeout(updateHeaderStickyOffsets, 150);
    const t3 = setTimeout(updateHeaderStickyOffsets, 400);

    window.addEventListener('resize', updateHeaderStickyOffsets);
    if (document.fonts) {
      document.fonts.ready.then(updateHeaderStickyOffsets);
    }

    const observers: ResizeObserver[] = [];
    if (window.ResizeObserver) {
      [table1Ref.current, table2Ref.current].forEach((table) => {
        if (table) {
          const ro = new ResizeObserver(updateHeaderStickyOffsets);
          ro.observe(table);
          observers.push(ro);
        }
      });
    }

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      window.removeEventListener('resize', updateHeaderStickyOffsets);
      observers.forEach((ro) => ro.disconnect());
    };
  }, [filteredTable1Data, filteredTable2Data, priorPeriodEnd, formattedRange, cumPeriodEnd, searchTerm, filterMinistry]);

  // Calculate Table 1 Totals
  const t1Totals = { col4: 0, col5: 0, col6: 0, col7: 0, col8: 0, col9: 0, col10: 0, col11: 0, col12: 0, col13: 0 };
  filteredTable1Data.forEach(g => {
    g.entities.forEach(ent => {
      const d = getEntityData(ent);
      t1Totals.col4 += d.col4; t1Totals.col5 += d.col5; t1Totals.col6 += d.col6;
      t1Totals.col7 += d.col7; t1Totals.col8 += d.col8; t1Totals.col9 += d.col9;
      t1Totals.col10 += d.col10; t1Totals.col11 += d.col11; t1Totals.col12 += d.col12;
      t1Totals.col13 += d.col13;
    });
  });

  // Calculate Table 2 Totals
  const t2Totals = { col4: 0, col5: 0, col6: 0, col7: 0, col8: 0, col9: 0, col10: 0, col11: 0, col12: 0, col13: 0 };
  filteredTable2Data.forEach(g => {
    g.entities.forEach(ent => {
      const d = getEntityData(ent);
      t2Totals.col4 += d.col4; t2Totals.col5 += d.col5; t2Totals.col6 += d.col6;
      t2Totals.col7 += d.col7; t2Totals.col8 += d.col8; t2Totals.col9 += d.col9;
      t2Totals.col10 += d.col10; t2Totals.col11 += d.col11; t2Totals.col12 += d.col12;
      t2Totals.col13 += d.col13;
    });
  });

  // Grand Totals
  const grandTotals = {
    col4: t1Totals.col4 + t2Totals.col4,
    col5: t1Totals.col5 + t2Totals.col5,
    col6: t1Totals.col6 + t2Totals.col6,
    col7: t1Totals.col7 + t2Totals.col7,
    col8: t1Totals.col8 + t2Totals.col8,
    col9: t1Totals.col9 + t2Totals.col9,
    col10: t1Totals.col10 + t2Totals.col10,
    col11: t1Totals.col11 + t2Totals.col11,
    col12: t1Totals.col12 + t2Totals.col12,
    col13: t1Totals.col13 + t2Totals.col13,
  };

  return (
    <div id="qr-detailed-1-container" className="w-full mx-auto py-4 px-[4px] bg-white rounded-xl relative animate-in fade-in duration-500 font-sans">
      <IDBadge id="qr-detailed-1-container" />

      {/* Action Bar (No Print) */}
      <div className="flex flex-wrap justify-end items-center gap-3 mb-4 no-print">
        <div className="flex items-center gap-2 flex-wrap">
          {monthPickerElement && (
            <div className="select-none relative z-[300]">
              {monthPickerElement}
            </div>
          )}

          {/* Cycle Multi-Select Filter */}
          <div className="relative select-none z-[300]" ref={cycleDropdownRef}>
            <div
              onClick={() => setIsCycleOpen(!isCycleOpen)}
              className={`flex items-center gap-1.5 px-3 py-1.5 border transition-all rounded-lg cursor-pointer text-[11px] font-bold shadow-xs ${
                selectedCycles.length > 0
                  ? 'bg-blue-50 text-blue-800 border-blue-300'
                  : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border-slate-200'
              }`}
            >
              <CalendarDays size={13} className="text-blue-600 shrink-0" />
              <span className="truncate max-w-[130px]">
                {selectedCycles.length === 0
                  ? 'সকল সাইকেল'
                  : selectedCycles.length === 1
                  ? selectedCycles[0]
                  : `${toBengaliDigits(selectedCycles.length.toString())}টি সাইকেল`}
              </span>
              {selectedCycles.length > 0 && (
                <span className="ml-0.5 px-1.5 py-0.2 bg-blue-600 text-white rounded-full text-[9px]">
                  {toBengaliDigits(selectedCycles.length.toString())}
                </span>
              )}
              <ChevronDown
                size={12}
                className={`text-slate-400 transition-transform duration-200 ${isCycleOpen ? 'rotate-180 text-blue-600' : ''}`}
              />
            </div>

            {isCycleOpen && (
              <div className="absolute top-[calc(100%+4px)] right-0 w-[270px] bg-white border border-slate-200 rounded-xl shadow-xl z-[9999] p-2 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="px-2 py-1.5 border-b border-slate-100 flex items-center justify-between mb-1">
                  <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest flex items-center gap-1.5">
                    <CalendarDays size={11} /> সাইকেল নির্বাচন
                  </span>
                </div>
                <div className="max-h-[220px] overflow-y-auto space-y-0.5">
                  <div
                    onClick={() => setSelectedCycles([])}
                    className={`flex items-center justify-between px-2.5 py-1.5 rounded-lg cursor-pointer text-[11px] font-bold transition-colors ${
                      selectedCycles.length === 0
                        ? 'bg-blue-600 text-white'
                        : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <span>সকল সাইকেল</span>
                    {selectedCycles.length === 0 && <Check size={13} />}
                  </div>
                  {cycleOptions.map((opt, idx) => {
                    const isSelected = selectedCycles.includes(opt.label);
                    return (
                      <div
                        key={idx}
                        onClick={() => {
                          if (isSelected) {
                            setSelectedCycles(selectedCycles.filter(c => c !== opt.label));
                          } else {
                            setSelectedCycles([...selectedCycles, opt.label]);
                          }
                        }}
                        className={`flex items-center justify-between px-2.5 py-1.5 rounded-lg cursor-pointer text-[11px] font-bold transition-colors ${
                          isSelected
                            ? 'bg-blue-50 text-blue-800'
                            : 'hover:bg-slate-50 text-slate-700'
                        }`}
                      >
                        <span className="truncate">{opt.label}</span>
                        <input
                          type="checkbox"
                          checked={isSelected}
                          readOnly
                          className="w-3.5 h-3.5 text-blue-600 rounded border-slate-300 pointer-events-none"
                        />
                      </div>
                    );
                  })}
                </div>
                <div className="mt-2 pt-1.5 border-t border-slate-100 flex justify-end">
                  <button
                    type="button"
                    onClick={() => setIsCycleOpen(false)}
                    className="px-3 py-1 bg-blue-600 text-white text-[10px] font-bold rounded-md hover:bg-blue-700 cursor-pointer shadow-xs"
                  >
                    সম্পন্ন
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Ministry Multi-Select Filter */}
          <div className="relative select-none z-[290]" ref={minDropdownRef}>
            <div
              onClick={() => setIsMinOpen(!isMinOpen)}
              className={`flex items-center gap-1.5 px-3 py-1.5 border transition-all rounded-lg cursor-pointer text-[11px] font-bold shadow-xs ${
                selectedMinistries.length > 0
                  ? 'bg-blue-50 text-blue-800 border-blue-300'
                  : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border-slate-200'
              }`}
            >
              <Building2 size={13} className="text-blue-600 shrink-0" />
              <span className="truncate max-w-[130px]">
                {selectedMinistries.length === 0
                  ? 'সকল মন্ত্রণালয়'
                  : selectedMinistries.length === 1
                  ? selectedMinistries[0]
                  : `${toBengaliDigits(selectedMinistries.length.toString())}টি মন্ত্রণালয়`}
              </span>
              {selectedMinistries.length > 0 && (
                <span className="ml-0.5 px-1.5 py-0.2 bg-blue-600 text-white rounded-full text-[9px]">
                  {toBengaliDigits(selectedMinistries.length.toString())}
                </span>
              )}
              <ChevronDown
                size={12}
                className={`text-slate-400 transition-transform duration-200 ${isMinOpen ? 'rotate-180 text-blue-600' : ''}`}
              />
            </div>

            {isMinOpen && (
              <div className="absolute top-[calc(100%+4px)] right-0 w-[260px] bg-white border border-slate-200 rounded-xl shadow-xl z-[9999] p-2 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="px-2 py-1.5 border-b border-slate-100 flex items-center justify-between mb-1">
                  <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest flex items-center gap-1.5">
                    <Building2 size={11} /> মন্ত্রণালয় নির্বাচন
                  </span>
                  {selectedMinistries.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setSelectedMinistries([])}
                      className="text-[10px] text-red-600 hover:underline cursor-pointer"
                    >
                      ক্লিয়ার
                    </button>
                  )}
                </div>
                <div className="max-h-[220px] overflow-y-auto space-y-0.5">
                  <div
                    onClick={() => {
                      setSelectedMinistries([]);
                    }}
                    className={`flex items-center justify-between px-2.5 py-1.5 rounded-lg cursor-pointer text-[11px] font-bold transition-colors ${
                      selectedMinistries.length === 0
                        ? 'bg-blue-600 text-white'
                        : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <span>সকল মন্ত্রণালয়</span>
                    {selectedMinistries.length === 0 && <Check size={13} />}
                  </div>
                  {ministryOptions.map((m, idx) => {
                    const isSelected = selectedMinistries.includes(m);
                    return (
                      <div
                        key={idx}
                        onClick={() => {
                          if (isSelected) {
                            setSelectedMinistries(selectedMinistries.filter(item => item !== m));
                          } else {
                            setSelectedMinistries([...selectedMinistries, m]);
                          }
                        }}
                        className={`flex items-center justify-between px-2.5 py-1.5 rounded-lg cursor-pointer text-[11px] font-bold transition-colors ${
                          isSelected
                            ? 'bg-blue-50 text-blue-800'
                            : 'hover:bg-slate-50 text-slate-700'
                        }`}
                      >
                        <span className="truncate">{m}</span>
                        <input
                          type="checkbox"
                          checked={isSelected}
                          readOnly
                          className="w-3.5 h-3.5 text-blue-600 rounded border-slate-300 pointer-events-none"
                        />
                      </div>
                    );
                  })}
                </div>
                <div className="mt-2 pt-1.5 border-t border-slate-100 flex justify-end">
                  <button
                    type="button"
                    onClick={() => setIsMinOpen(false)}
                    className="px-3 py-1 bg-blue-600 text-white text-[10px] font-bold rounded-md hover:bg-blue-700 cursor-pointer shadow-xs"
                  >
                    সম্পন্ন
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Entity Multi-Select Filter */}
          <div className="relative select-none z-[280]" ref={entDropdownRef}>
            <div
              onClick={() => setIsEntOpen(!isEntOpen)}
              className={`flex items-center gap-1.5 px-3 py-1.5 border transition-all rounded-lg cursor-pointer text-[11px] font-bold shadow-xs ${
                selectedEntities.length > 0
                  ? 'bg-blue-50 text-blue-800 border-blue-300'
                  : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border-slate-200'
              }`}
            >
              <Landmark size={13} className="text-blue-600 shrink-0" />
              <span className="truncate max-w-[130px]">
                {selectedEntities.length === 0
                  ? 'সকল সংস্থা'
                  : selectedEntities.length === 1
                  ? selectedEntities[0]
                  : `${toBengaliDigits(selectedEntities.length.toString())}টি সংস্থা`}
              </span>
              {selectedEntities.length > 0 && (
                <span className="ml-0.5 px-1.5 py-0.2 bg-blue-600 text-white rounded-full text-[9px]">
                  {toBengaliDigits(selectedEntities.length.toString())}
                </span>
              )}
              <ChevronDown
                size={12}
                className={`text-slate-400 transition-transform duration-200 ${isEntOpen ? 'rotate-180 text-blue-600' : ''}`}
              />
            </div>

            {isEntOpen && (
              <div className="absolute top-[calc(100%+4px)] right-0 w-[260px] bg-white border border-slate-200 rounded-xl shadow-xl z-[9999] p-2 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="px-2 py-1.5 border-b border-slate-100 flex items-center justify-between mb-1">
                  <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest flex items-center gap-1.5">
                    <Landmark size={11} /> সংস্থা নির্বাচন
                  </span>
                  {selectedEntities.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setSelectedEntities([])}
                      className="text-[10px] text-red-600 hover:underline cursor-pointer"
                    >
                      ক্লিয়ার
                    </button>
                  )}
                </div>
                <div className="max-h-[220px] overflow-y-auto space-y-0.5">
                  <div
                    onClick={() => {
                      setSelectedEntities([]);
                    }}
                    className={`flex items-center justify-between px-2.5 py-1.5 rounded-lg cursor-pointer text-[11px] font-bold transition-colors ${
                      selectedEntities.length === 0
                        ? 'bg-blue-600 text-white'
                        : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <span>সকল সংস্থা</span>
                    {selectedEntities.length === 0 && <Check size={13} />}
                  </div>
                  {entityOptions.map((ent, idx) => {
                    const isSelected = selectedEntities.includes(ent);
                    return (
                      <div
                        key={idx}
                        onClick={() => {
                          if (isSelected) {
                            setSelectedEntities(selectedEntities.filter(item => item !== ent));
                          } else {
                            setSelectedEntities([...selectedEntities, ent]);
                          }
                        }}
                        className={`flex items-center justify-between px-2.5 py-1.5 rounded-lg cursor-pointer text-[11px] font-bold transition-colors ${
                          isSelected
                            ? 'bg-blue-50 text-blue-800'
                            : 'hover:bg-slate-50 text-slate-700'
                        }`}
                      >
                        <span className="truncate">{ent}</span>
                        <input
                          type="checkbox"
                          checked={isSelected}
                          readOnly
                          className="w-3.5 h-3.5 text-blue-600 rounded border-slate-300 pointer-events-none"
                        />
                      </div>
                    );
                  })}
                </div>
                <div className="mt-2 pt-1.5 border-t border-slate-100 flex justify-end">
                  <button
                    type="button"
                    onClick={() => setIsEntOpen(false)}
                    className="px-3 py-1 bg-blue-600 text-white text-[10px] font-bold rounded-md hover:bg-blue-700 cursor-pointer shadow-xs"
                  >
                    সম্পন্ন
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Reset Filters button if any active */}


          <button
            type="button"
            onClick={downloadExcel}
            className="flex items-center justify-center w-9 h-9 bg-emerald-50 text-emerald-700 hover:text-emerald-800 border border-emerald-200 hover:border-emerald-300 hover:bg-emerald-100 transition-all rounded-lg cursor-pointer shrink-0 shadow-xs"
            title="এক্সেল ফাইল ডাউনলোড করুন"
          >
            <FileSpreadsheet size={16} className="stroke-[2.5]" />
          </button>
        </div>
      </div>

      {/* Header Title Section */}
      <div className="text-center mb-3 pt-1 relative z-[260]">
        <div className="inline-block relative">
          <h1 className="text-2xl font-black text-slate-900 tracking-tight mb-2">
            বিস্তারিত - ১
          </h1>

          <div className="flex items-center justify-center gap-4 mb-2">
            <div className="h-[1px] w-12 bg-gradient-to-r from-transparent to-slate-400"></div>
            <div className="w-1.5 h-1.5 rounded-full bg-blue-600"></div>
            <div className="h-[1px] w-12 bg-gradient-to-l from-transparent to-slate-400"></div>
          </div>
        </div>
      </div>

      {/* Subject Bar */}
      <div className="mb-3 text-[11px] font-bold text-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-x-4 gap-y-2 border-b border-t border-slate-200 py-2 px-3 bg-slate-50/50 rounded-lg">
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
          <p><span className="text-slate-500">বিষয়ঃ</span> মন্ত্রণালয়/সংস্থা ভিত্তিক অমিমাংসিত অডিট আপত্তির ত্রৈমাসিক বিবরণ</p>
          <span className="text-slate-300 hidden md:inline font-normal">|</span>
          <p><span className="text-slate-500">শাখাঃ</span> এসএফআই + নন-এসএফআই শাখা</p>
          <span className="text-slate-300 hidden md:inline font-normal">|</span>
          <p><span className="text-slate-500">মাসের নামঃ</span> {formattedRange}</p>
        </div>
      </div>

      {/* Main Table Container (Exclusively for QR Detailed 1 with dynamic sticky offsets) */}
      <div id="qr-detailed-1-container" className="w-full">
        <style>{`
          #qr-detailed-1-table-1, #qr-detailed-1-table-2 {
            --th-r2-top: 34px;
            --th-r3-top: 110px;
          }
          #qr-detailed-1-table-1 thead,
          #qr-detailed-1-table-2 thead {
            background-color: #e2e8f0 !important;
          }
          #qr-detailed-1-table-1 thead th,
          #qr-detailed-1-table-2 thead th {
            position: -webkit-sticky !important;
            position: sticky !important;
            background-color: #e2e8f0 !important;
            background-clip: padding-box !important;
            vertical-align: middle !important;
            opacity: 1 !important;
          }
          #qr-detailed-1-table-1 thead tr:first-child,
          #qr-detailed-1-table-1 thead tr:nth-child(1),
          #qr-detailed-1-table-2 thead tr:first-child,
          #qr-detailed-1-table-2 thead tr:nth-child(1) {
            height: 34px !important;
          }
          #qr-detailed-1-table-1 thead tr:nth-child(2),
          #qr-detailed-1-table-2 thead tr:nth-child(2) {
            min-height: 62px !important;
          }
          #qr-detailed-1-table-1 thead tr:nth-child(3),
          #qr-detailed-1-table-2 thead tr:nth-child(3) {
            height: 28px !important;
            background-color: #e2e8f0 !important;
          }
          #qr-detailed-1-table-1 thead tr:first-child th,
          #qr-detailed-1-table-1 thead tr:nth-child(1) th,
          #qr-detailed-1-table-2 thead tr:first-child th,
          #qr-detailed-1-table-2 thead tr:nth-child(1) th {
            top: 0px !important;
            z-index: 140 !important;
          }
          #qr-detailed-1-table-1 thead tr:first-child th:not([rowspan]):not([rowSpan]),
          #qr-detailed-1-table-2 thead tr:first-child th:not([rowspan]):not([rowSpan]) {
            height: 34px !important;
          }
          #qr-detailed-1-table-1 thead tr:first-child th[rowspan],
          #qr-detailed-1-table-1 thead tr:first-child th[rowSpan],
          #qr-detailed-1-table-2 thead tr:first-child th[rowspan],
          #qr-detailed-1-table-2 thead tr:first-child th[rowSpan] {
            top: 0px !important;
            z-index: 145 !important;
          }
          #qr-detailed-1-table-1 thead tr:nth-child(2) th,
          #qr-detailed-1-table-2 thead tr:nth-child(2) th {
            top: var(--th-r2-top, 34px) !important;
            z-index: 135 !important;
          }
          #qr-detailed-1-table-1 thead tr:nth-child(3) th,
          #qr-detailed-1-table-2 thead tr:nth-child(3) th {
            top: var(--th-r3-top, 110px) !important;
            z-index: 130 !important;
            background-color: #e2e8f0 !important;
            background-clip: padding-box !important;
            border-bottom: 1px solid #cbd5e1 !important;
            box-shadow: none !important;
            box-sizing: border-box !important;
          }
          #qr-detailed-1-table-1 tfoot,
          #qr-detailed-1-table-1 tfoot tr,
          #qr-detailed-1-table-1 tfoot td,
          #qr-detailed-1-table-1 tfoot th,
          #qr-detailed-1-table-2 tfoot,
          #qr-detailed-1-table-2 tfoot tr,
          #qr-detailed-1-table-2 tfoot td,
          #qr-detailed-1-table-2 tfoot th {
            position: -webkit-sticky !important;
            position: sticky !important;
            bottom: 0px !important;
            z-index: 150 !important;
            background-color: #020617 !important;
            color: #ffffff !important;
            background-clip: padding-box !important;
          }
        `}</style>
        
        {/* TABLE 1 */}
        <div className="table-container qr-table-container overflow-visible shadow-sm rounded-lg mb-8 bg-white border border-slate-300">
          <table ref={table1Ref} id="qr-detailed-1-table-1" className="w-full border-separate border-spacing-0 min-w-[1050px] border border-slate-300">
          <thead>
            <tr className="h-[34px]">
              <th rowSpan={2} className={`${thCls} w-[40px]`}>ক্রঃ নং</th>
              <th rowSpan={2} className={`${thCls} w-[68px]`}>মন্ত্রণালয়ের নাম</th>
              <th rowSpan={2} className={`${thCls} w-[78px]`}>প্রতিষ্ঠানের নাম</th>
              <th colSpan={3} className={`${thCls} h-[34px]`}>প্রারম্ভিক অমিমাংসিত</th>
              <th colSpan={3} className={`${thCls} h-[34px]`}>প্রারম্ভিক মীমাংসিত</th>
              <th rowSpan={2} className={`${thCls} w-[100px]`}>{cumPeriodEnd} পর্যন্ত অনিষ্পন্ন আপত্তির সংখ্যা</th>
              <th colSpan={3} className={`${thCls} h-[34px]`}>অমিমাংসিত আপত্তিতে জড়িত টাকা</th>
            </tr>
            <tr className="h-[62px]">
              {/* Columns 4, 5, 6 under প্রারম্ভিক অমিমাংসিত - Item 2.5 Header Text Fix */}
              <th className={thRow2Cls}>১৯৭১-৭২ হতে {priorPeriodEnd} পর্যন্ত উত্থাপিত আপত্তির সংখ্যা</th>
              <th className={thRow2Cls}>{formattedRange} পর্যন্ত উত্থাপিত আপত্তির সংখ্যা</th>
              <th className={thRow2Cls}>{cumPeriodEnd} পর্যন্ত উত্থাপিত মোট আপত্তির সংখ্যা</th>
              
              {/* Columns 7, 8, 9 under প্রারম্ভিক মীমাংসিত - Item 2.5 Header Text Fix */}
              <th className={thRow2Cls}>১৯৭১-৭২ হতে {priorPeriodEnd} পর্যন্ত মোট নিষ্পত্তিকৃত আপত্তির সংখ্যা</th>
              <th className={thRow2Cls}>{formattedRange} পর্যন্ত নিষ্পত্তিকৃত আপত্তির সংখ্যা</th>
              <th className={thRow2Cls}>{cumPeriodEnd} পর্যন্ত মোট নিষ্পত্তিকৃত আপত্তির সংখ্যা</th>
              
              {/* Columns 11, 12, 13 under অমিমাংসিত আপত্তিতে জড়িত টাকা - Item 2.5 Header Text Fix */}
              <th className={thRow2Cls}>১৯৭১-৭২ হতে {priorPeriodEnd} পর্যন্ত অনিষ্পন্ন আপত্তিতে জড়িত টাকা</th>
              <th className={thRow2Cls}>{formattedRange} পর্যন্ত নিষ্পত্তিকৃত আপত্তিতে জড়িত টাকা</th>
              <th className={thRow2Cls}>১৯৭১-৭২ হতে {cumPeriodEnd} পর্যন্ত অনিষ্পন্ন আপত্তিতে জড়িত টাকা</th>
            </tr>
            {/* Column Numbers Row */}
            <tr className="h-[28px] bg-[#e2e8f0]">
              <th className={thRow3Cls}>১</th>
              <th className={thRow3Cls}>২</th>
              <th className={thRow3Cls}>৩</th>
              <th className={thRow3Cls}>৪</th>
              <th className={thRow3Cls}>৫</th>
              <th className={thRow3Cls}>৬ = ৪+৫</th>
              <th className={thRow3Cls}>৭</th>
              <th className={thRow3Cls}>৮</th>
              <th className={thRow3Cls}>৯ = (৭+৮)</th>
              <th className={thRow3Cls}>১০ = ৬-৯</th>
              <th className={thRow3Cls}>১১</th>
              <th className={thRow3Cls}>১২</th>
              <th className={thRow3Cls}>১৩ = ১১-১২</th>
            </tr>
          </thead>
          <tbody>
            {(() => {
              let serialCount = 0;
              return filteredTable1Data.map((group, gIdx) => {
                const groupSums = { col4: 0, col5: 0, col6: 0, col7: 0, col8: 0, col9: 0, col10: 0, col11: 0, col12: 0, col13: 0 };
                group.entities.forEach(ent => {
                  const d = getEntityData(ent);
                  groupSums.col4 += d.col4; groupSums.col5 += d.col5; groupSums.col6 += d.col6;
                  groupSums.col7 += d.col7; groupSums.col8 += d.col8; groupSums.col9 += d.col9;
                  groupSums.col10 += d.col10; groupSums.col11 += d.col11; groupSums.col12 += d.col12;
                  groupSums.col13 += d.col13;
                });

                const groupRows = group.entities.map((entity, eIdx) => {
                  serialCount++;
                  const isFirstOfGroup = eIdx === 0;

                  const matchSearch = searchTerm === '' ||
                    group.ministry.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    entity.toLowerCase().includes(searchTerm.toLowerCase());

                  const matchFilter = filterMinistry === '' || group.ministry.includes(filterMinistry);

                  if (!matchSearch || !matchFilter) return null;

                  const d = getEntityData(entity);

                  return (
                    <tr key={`${gIdx}-${eIdx}`} className="hover:bg-slate-50 transition-colors">
                      <td className={numTdCls}>{toBengaliDigits(serialCount.toString())}</td>
                      {isFirstOfGroup && (
                        <td rowSpan={group.entities.length} className={`${tdCls} font-bold text-center align-middle p-0 bg-white`}>
                          <div
                            className="flex items-center justify-center w-full h-full py-2 px-1"
                            style={{ minHeight: `${Math.max(70, Math.ceil((group.ministry || '').length * 6.5) + 24)}px` }}
                          >
                            <span
                              className="inline-block whitespace-nowrap font-bold text-[10.5px] tracking-normal text-slate-900 select-none"
                              style={{ transform: 'rotate(-90deg)', transformOrigin: 'center center' }}
                            >
                              <HighlightText text={group.ministry} searchTerm={searchTerm} />
                            </span>
                          </div>
                        </td>
                      )}
                      <td className={tdCls}>
                        <HighlightText text={entity} searchTerm={searchTerm} />
                      </td>
                      <td className={numTdCls}>{toBengaliDigits(d.col4.toString())}</td>
                      <td className={numTdCls}>{toBengaliDigits(d.col5.toString())}</td>
                      <td className={numTdCls}>{toBengaliDigits(d.col6.toString())}</td>
                      <td className={numTdCls}>{toBengaliDigits(d.col7.toString())}</td>
                      <td className={numTdCls}>{toBengaliDigits(d.col8.toString())}</td>
                      <td className={numTdCls}>{toBengaliDigits(d.col9.toString())}</td>
                      <td className={numTdCls}>{toBengaliDigits(d.col10.toString())}</td>
                      <td className={numTdCls}>{toBengaliDigits(d.col11.toString())}</td>
                      <td className={numTdCls}>{toBengaliDigits(d.col12.toString())}</td>
                      <td className={numTdCls}>{toBengaliDigits(d.col13.toString())}</td>
                    </tr>
                  );
                });

                const hasMatchingEntities = groupRows.some(row => row !== null);
                if (!hasMatchingEntities) return null;

                return (
                  <React.Fragment key={`t1-group-${gIdx}`}>
                    {groupRows}
                    <tr className="bg-slate-100 font-black">
                      <td colSpan={3} className={`${tdCls} font-black text-center !bg-slate-200 text-slate-900 shadow-[inset_0_1px_0_rgba(255,255,255,0.6)]`}>
                        মোট ({group.ministry})
                      </td>
                      <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupSums.col4.toString())}</td>
                      <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupSums.col5.toString())}</td>
                      <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupSums.col6.toString())}</td>
                      <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupSums.col7.toString())}</td>
                      <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupSums.col8.toString())}</td>
                      <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupSums.col9.toString())}</td>
                      <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupSums.col10.toString())}</td>
                      <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupSums.col11.toString())}</td>
                      <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupSums.col12.toString())}</td>
                      <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupSums.col13.toString())}</td>
                    </tr>
                  </React.Fragment>
                );
              });
            })()}
          </tbody>
          <tfoot className="bg-slate-950">
            <tr className="bg-slate-950">
              <td colSpan={3} className={footerTdCls}>মোট (টেবিল-১)</td>
              <td className={footerTdCls}>{toBengaliDigits(t1Totals.col4.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(t1Totals.col5.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(t1Totals.col6.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(t1Totals.col7.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(t1Totals.col8.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(t1Totals.col9.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(t1Totals.col10.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(t1Totals.col11.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(t1Totals.col12.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(t1Totals.col13.toString())}</td>
            </tr>
          </tfoot>
        </table>
        </div>

        {/* Section divider between Table 1 and Table 2 */}
        <div className="my-4 text-[11px] font-bold text-slate-800 flex flex-wrap items-center gap-x-3 gap-y-1 border-b border-t border-slate-200 py-1.5 px-2 bg-slate-50/50 rounded-lg">
          <p><span className="text-slate-500">শাখাঃ</span> আর্থিক প্রতিষ্ঠান বিভাগ</p>
          <span className="text-slate-300 hidden md:inline font-normal">|</span>
          <p><span className="text-slate-500">মাসের নামঃ</span> {formattedRange}</p>
        </div>

        {/* TABLE 2 (FINANCIAL INSTITUTIONS) */}
        <div className="table-container qr-table-container overflow-visible shadow-sm rounded-lg mb-8 bg-white border border-slate-300">
          <table ref={table2Ref} id="qr-detailed-1-table-2" className="w-full border-separate border-spacing-0 min-w-[1050px] border border-slate-300">
          <thead>
            <tr className="h-[34px]">
              <th rowSpan={2} className={`${yellowThCls} w-[40px]`}>ক্রঃ নং</th>
              <th rowSpan={2} className={`${yellowThCls} w-[68px]`}>মন্ত্রণালয়ের নাম</th>
              <th rowSpan={2} className={`${yellowThCls} w-[78px]`}>প্রতিষ্ঠানের নাম</th>
              <th colSpan={3} className={`${yellowThCls} h-[34px]`}>প্রারম্ভিক অমিমাংসিত</th>
              <th colSpan={3} className={`${yellowThCls} h-[34px]`}>প্রারম্ভিক মীমাংসিত</th>
              <th rowSpan={2} className={`${yellowThCls} w-[100px]`}>{cumPeriodEnd} পর্যন্ত অনিষ্পন্ন আপত্তির সংখ্যা</th>
              <th colSpan={3} className={`${yellowThCls} h-[34px]`}>অমিমাংসিত আপত্তিতে জড়িত টাকা</th>
            </tr>
            <tr className="h-[62px]">
              {/* Item 2.5 Header Text Fix */}
              <th className={yellowThRow2Cls}>১৯৭১-৭২ হতে {priorPeriodEnd} পর্যন্ত উত্থাপিত আপত্তির সংখ্যা</th>
              <th className={yellowThRow2Cls}>{formattedRange} পর্যন্ত উত্থাপিত আপত্তির সংখ্যা</th>
              <th className={yellowThRow2Cls}>{cumPeriodEnd} পর্যন্ত উত্থাপিত মোট আপত্তির সংখ্যা</th>
              
              <th className={yellowThRow2Cls}>১৯৭১-৭২ হতে {priorPeriodEnd} পর্যন্ত মোট নিষ্পত্তিকৃত আপত্তির সংখ্যা</th>
              <th className={yellowThRow2Cls}>{formattedRange} পর্যন্ত নিষ্পত্তিকৃত আপত্তির সংখ্যা</th>
              <th className={yellowThRow2Cls}>{cumPeriodEnd} পর্যন্ত মোট নিষ্পত্তিকৃত আপত্তির সংখ্যা</th>
              
              <th className={yellowThRow2Cls}>১৯৭১-৭২ হতে {priorPeriodEnd} পর্যন্ত অনিষ্পন্ন আপত্তিতে জড়িত টাকা</th>
              <th className={yellowThRow2Cls}>{formattedRange} পর্যন্ত নিষ্পত্তিকৃত আপত্তিতে জড়িত টাকা</th>
              <th className={yellowThRow2Cls}>১৯৭১-৭২ হতে {cumPeriodEnd} পর্যন্ত অনিষ্পন্ন আপত্তিতে জড়িত টাকা</th>
            </tr>
            <tr className="h-[28px] bg-[#e2e8f0]">
              <th className={yellowThRow3Cls}>১</th>
              <th className={yellowThRow3Cls}>২</th>
              <th className={yellowThRow3Cls}>৩</th>
              <th className={yellowThRow3Cls}>৪</th>
              <th className={yellowThRow3Cls}>৫</th>
              <th className={yellowThRow3Cls}>৬ = ৪+৫</th>
              <th className={yellowThRow3Cls}>৭</th>
              <th className={yellowThRow3Cls}>৮</th>
              <th className={yellowThRow3Cls}>৯ = (৭+৮)</th>
              <th className={yellowThRow3Cls}>১০ = ৬-৯</th>
              <th className={yellowThRow3Cls}>১১</th>
              <th className={yellowThRow3Cls}>১২</th>
              <th className={yellowThRow3Cls}>১৩ = ১১-১২</th>
            </tr>
          </thead>
          <tbody>
            {(() => {
              let serialCount = 0;
              return filteredTable2Data.map((group, gIdx) => {
                const groupSums = { col4: 0, col5: 0, col6: 0, col7: 0, col8: 0, col9: 0, col10: 0, col11: 0, col12: 0, col13: 0 };
                group.entities.forEach(ent => {
                  const d = getEntityData(ent);
                  groupSums.col4 += d.col4; groupSums.col5 += d.col5; groupSums.col6 += d.col6;
                  groupSums.col7 += d.col7; groupSums.col8 += d.col8; groupSums.col9 += d.col9;
                  groupSums.col10 += d.col10; groupSums.col11 += d.col11; groupSums.col12 += d.col12;
                  groupSums.col13 += d.col13;
                });

                const groupRows = group.entities.map((entity, eIdx) => {
                  serialCount++;
                  const isFirstOfGroup = eIdx === 0;

                  const matchSearch = searchTerm === '' ||
                    group.ministry.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    entity.toLowerCase().includes(searchTerm.toLowerCase());

                  const matchFilter = filterMinistry === '' || group.ministry.includes(filterMinistry);

                  if (!matchSearch || !matchFilter) return null;

                  const d = getEntityData(entity);

                  return (
                    <tr key={`t2-${gIdx}-${eIdx}`} className="hover:bg-amber-50/40 transition-colors">
                      <td className={numTdCls}>{toBengaliDigits(serialCount.toString())}</td>
                      {isFirstOfGroup && (
                        <td rowSpan={group.entities.length} className={`${tdCls} font-bold text-center align-middle p-0 bg-white`}>
                          <div
                            className="flex items-center justify-center w-full h-full py-2 px-1"
                            style={{ minHeight: `${Math.max(70, Math.ceil((group.ministry || '').length * 6.5) + 24)}px` }}
                          >
                            <span
                              className="inline-block whitespace-nowrap font-bold text-[10.5px] tracking-normal text-slate-900 select-none"
                              style={{ transform: 'rotate(-90deg)', transformOrigin: 'center center' }}
                            >
                              <HighlightText text={group.ministry} searchTerm={searchTerm} />
                            </span>
                          </div>
                        </td>
                      )}
                      <td className={tdCls}>
                        <HighlightText text={entity} searchTerm={searchTerm} />
                      </td>
                      <td className={numTdCls}>{toBengaliDigits(d.col4.toString())}</td>
                      <td className={numTdCls}>{toBengaliDigits(d.col5.toString())}</td>
                      <td className={numTdCls}>{toBengaliDigits(d.col6.toString())}</td>
                      <td className={numTdCls}>{toBengaliDigits(d.col7.toString())}</td>
                      <td className={numTdCls}>{toBengaliDigits(d.col8.toString())}</td>
                      <td className={numTdCls}>{toBengaliDigits(d.col9.toString())}</td>
                      <td className={numTdCls}>{toBengaliDigits(d.col10.toString())}</td>
                      <td className={numTdCls}>{toBengaliDigits(d.col11.toString())}</td>
                      <td className={numTdCls}>{toBengaliDigits(d.col12.toString())}</td>
                      <td className={numTdCls}>{toBengaliDigits(d.col13.toString())}</td>
                    </tr>
                  );
                });

                const hasMatchingEntities = groupRows.some(row => row !== null);
                if (!hasMatchingEntities) return null;

                return (
                  <React.Fragment key={`t2-group-${gIdx}`}>
                    {groupRows}
                    <tr className="bg-slate-100 font-black">
                      <td colSpan={3} className={`${tdCls} font-black text-center !bg-slate-200 text-slate-900 shadow-[inset_0_1px_0_rgba(255,255,255,0.6)]`}>
                        মোট ({group.ministry})
                      </td>
                      <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupSums.col4.toString())}</td>
                      <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupSums.col5.toString())}</td>
                      <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupSums.col6.toString())}</td>
                      <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupSums.col7.toString())}</td>
                      <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupSums.col8.toString())}</td>
                      <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupSums.col9.toString())}</td>
                      <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupSums.col10.toString())}</td>
                      <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupSums.col11.toString())}</td>
                      <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupSums.col12.toString())}</td>
                      <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupSums.col13.toString())}</td>
                    </tr>
                  </React.Fragment>
                );
              });
            })()}
          </tbody>
          <tfoot className="bg-slate-950">
            <tr className="bg-slate-950">
              <td colSpan={3} className={footerTdCls}>মোট (টেবিল-২)</td>
              <td className={footerTdCls}>{toBengaliDigits(t2Totals.col4.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(t2Totals.col5.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(t2Totals.col6.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(t2Totals.col7.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(t2Totals.col8.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(t2Totals.col9.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(t2Totals.col10.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(t2Totals.col11.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(t2Totals.col12.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(t2Totals.col13.toString())}</td>
            </tr>
            <tr className="bg-slate-950">
              <td colSpan={3} className={footerTdCls}>সর্বমোট</td>
              <td className={footerTdCls}>{toBengaliDigits(grandTotals.col4.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(grandTotals.col5.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(grandTotals.col6.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(grandTotals.col7.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(grandTotals.col8.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(grandTotals.col9.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(grandTotals.col10.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(grandTotals.col11.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(grandTotals.col12.toString())}</td>
              <td className={footerTdCls}>{toBengaliDigits(grandTotals.col13.toString())}</td>
            </tr>
          </tfoot>
        </table>
        </div>
      </div>
    </div>
  );
};

export default QR_Detailed_1;
