import { useState, useMemo, useRef, useEffect } from "react";
import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { SettlementEntry } from "../types.ts";
import {
  Trash2,
  Pencil,
  Calendar,
  Printer,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  FileText,
  Fingerprint,
  Banknote,
  ListOrdered,
  Archive,
  MapPin,
  CalendarDays,
  Sparkles,
  ClipboardList,
  Filter,
  X,
  Search,
  LayoutGrid,
  CalendarSearch,
  Check,
  ShieldCheck,
  XCircle,
  AlertCircle,
  MessageSquare,
  AlertTriangle,
  Eye,
  EyeOff,
  Building,
  Building2,
  Landmark,
  Hash,
  Globe,
  BarChart3,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import {
  toBengaliDigits,
  parseBengaliNumber,
  formatDateBN,
  toEnglishDigits,
} from "../utils/numberUtils.ts";
import HighlightText from "./HighlightText";
import DeleteConfirmationModal from "./DeleteConfirmationModal";
import SettledMinistryDetailModal, { SettledMinistryItem } from "./SettledMinistryDetailModal";
import { OFFICE_HEADER, MINISTRY_ENTITY_MAP } from "../constants.ts";
import { getCurrentCycle, getCycleForDate } from "../utils/cycleHelper.ts";
import { format, addMonths, subMonths, startOfMonth, endOfMonth } from "date-fns";
import { parseManualDate } from "../utils/dateValidation.ts";
import { formatBengaliDateDMY } from "../utils/syncHelper.ts";

const robustNormalize = (str: string = "") => {
  if (!str) return "";
  return str
    .normalize("NFC")
    .replace(/[\u200B-\u200D\uFEFF]/g, "")
    .replace(/\s+/g, " ")
    .trim();
};

interface SettlementTableProps {
  entries: SettlementEntry[];
  onDelete: (id: string, paraId?: string) => void;
  onEdit: (entry: SettlementEntry) => void;
  isLayoutEditable?: boolean;
  showFilters: boolean;
  setShowFilters: (val: boolean) => void;
  isAdminView?: boolean;
  onApprove?: (id: string) => void;
  onReject?: (id: string) => void;
  isAdmin?: boolean;
  highlightSearch?: string | null;
  onClearHighlight?: () => void;
  showAuditDetails?: boolean;
}

const isSFI = (type: string) => {
  if (!type) return false;
  const t = type.trim();
  return t === 'এসএফআই' || t === 'SFI' || t === 'sfi' || t === 'এস-এফ-আই' || t === 'এস এফ আই';
};

const isNonSFI = (type: string) => {
  if (!type) return false;
  const t = type.trim();
  return t.includes('নন') || t.toUpperCase().includes('NON-SFI');
};

const SettlementTable = React.forwardRef<HTMLDivElement, SettlementTableProps>(
  (
    {
      entries,
      onDelete,
      onEdit,
      isLayoutEditable,
      showFilters,
      setShowFilters,
      isAdminView = false,
      onApprove,
      onReject,
      isAdmin = false,
      highlightSearch = null,
      onClearHighlight,
      showAuditDetails = true,
    },
    ref,
  ) => {
    const [isCycleStatsExpanded, setIsCycleStatsExpanded] = useState<boolean>(false);
    const [showCycleHeaders, setShowCycleHeaders] = useState<boolean>(true);
    const [showSummary, setShowSummary] = useState(false);
    const cycleRefs = useRef<Record<string, HTMLDivElement | null>>({});

    const cycleInfo = useMemo(() => getCurrentCycle(), []);
    const tableRef = useRef<HTMLTableElement>(null);
    const cycleDropdownRef = useRef<HTMLDivElement>(null);
    const branchDropdownRef = useRef<HTMLDivElement>(null);
    const typeDropdownRef = useRef<HTMLDivElement>(null);
    const statusDropdownRef = useRef<HTMLDivElement>(null);
    const ministryDropdownRef = useRef<HTMLDivElement>(null);
    const entityDropdownRef = useRef<HTMLDivElement>(null);
    const summaryRef = useRef<HTMLDivElement>(null);
    const summaryButtonRef = useRef<HTMLButtonElement>(null);

    const [searchTerm, setSearchTerm] = useState("");
    const [filterParaType, setFilterParaType] = useState("");
    const [filterType, setFilterType] = useState("");
    const [filterStatus, setFilterStatus] = useState("");
    const [filterMinistries, setFilterMinistries] = useState<string[]>([]);
    const [filterEntities, setFilterEntities] = useState<string[]>([]);
    const [selectedCycles, setSelectedCycles] = useState<string[]>([]);
    const [isCustomDateActive, setIsCustomDateActive] = useState<boolean>(false);
    const [filterStartDate, setFilterStartDate] = useState<string>("");
    const [filterEndDate, setFilterEndDate] = useState<string>("");
    const [manualStartDate, setManualStartDate] = useState<string>(() => "");
    const [manualEndDate, setManualEndDate] = useState<string>(() => "");
    const [dateTab, setDateTab] = useState<'cycle' | 'custom'>('cycle');

    useEffect(() => {
      if (filterStartDate) {
        setManualStartDate(toBengaliDigits(format(new Date(filterStartDate), 'dd/MM/yyyy')));
      } else {
        setManualStartDate('');
      }
    }, [filterStartDate]);

    useEffect(() => {
      if (filterEndDate) {
        setManualEndDate(toBengaliDigits(format(new Date(filterEndDate), 'dd/MM/yyyy')));
      } else {
        setManualEndDate('');
      }
    }, [filterEndDate]);

    const [deleteConfirm, setDeleteConfirm] = useState<{
      id: string;
      paraId?: string;
    } | null>(null);

    const [deletingInfo, setDeletingInfo] = useState<{
      id: string;
      paraId?: string;
    } | null>(null);

    const [isCycleDropdownOpen, setIsCycleDropdownOpen] = useState(false);
    const [isBranchDropdownOpen, setIsBranchDropdownOpen] = useState(false);
    const [isTypeDropdownOpen, setIsTypeDropdownOpen] = useState(false);
    const [isStatusDropdownOpen, setIsStatusDropdownOpen] = useState(false);
    const [isMinistryDropdownOpen, setIsMinistryDropdownOpen] = useState(false);
    const [isEntityDropdownOpen, setIsEntityDropdownOpen] = useState(false);

    const [expandedEntries, setExpandedEntries] = useState<Set<string>>(
      new Set(),
    );

    const [settledDetailsModalData, setSettledDetailsModalData] = useState<{
      isOpen: boolean;
      branchType: string;
      cycleLabel: string;
      totalCount: number;
      ministries: SettledMinistryItem[];
    } | null>(null);

    useEffect(() => {
      if (highlightSearch) {
        setSearchTerm(highlightSearch);
        // Reset other filters to ensure the highlighted entry is visible
        setFilterParaType("");
        setFilterType("");
        setFilterStatus("");
        setFilterMinistries([]);
        setFilterEntities([]);
        setSelectedCycles([]);
      }
      return () => {
        if (highlightSearch) onClearHighlight?.();
      };
    }, [highlightSearch, onClearHighlight]);

    // Click outside listener to close custom dropdowns
    useEffect(() => {
      // FIX: Consolidated click-outside handler to resolve 'dropdownRef' undefined error.
      // The previous 'handleClickOutside' was redundant and contained invalid references.
      const handleGlobalClick = (e: MouseEvent) => {
        if (
          cycleDropdownRef.current &&
          !cycleDropdownRef.current.contains(e.target as Node)
        )
          setIsCycleDropdownOpen(false);
        if (
          branchDropdownRef.current &&
          !branchDropdownRef.current.contains(e.target as Node)
        )
          setIsBranchDropdownOpen(false);
        if (
          typeDropdownRef.current &&
          !typeDropdownRef.current.contains(e.target as Node)
        )
          setIsTypeDropdownOpen(false);
        if (
          statusDropdownRef.current &&
          !statusDropdownRef.current.contains(e.target as Node)
        )
          setIsStatusDropdownOpen(false);
        if (
          ministryDropdownRef.current &&
          !ministryDropdownRef.current.contains(e.target as Node)
        )
          setIsMinistryDropdownOpen(false);
        if (
          entityDropdownRef.current &&
          !entityDropdownRef.current.contains(e.target as Node)
        )
          setIsEntityDropdownOpen(false);
        if (
          summaryRef.current &&
          !summaryRef.current.contains(e.target as Node) &&
          summaryButtonRef.current &&
          !summaryButtonRef.current.contains(e.target as Node)
        ) {
          setShowSummary(false);
        }
      };
      document.addEventListener("mousedown", handleGlobalClick);
      return () => document.removeEventListener("mousedown", handleGlobalClick);
    }, []);

    const resetFilters = () => {
      setSearchTerm("");
      setFilterParaType("");
      setFilterType("");
      setFilterStatus("");
      setFilterMinistries([]);
      setFilterEntities([]);
      setSelectedCycles([]);
    };

    const ministryOptions = useMemo(() => {
      const set = new Set<string>();
      Object.keys(MINISTRY_ENTITY_MAP).forEach((m) => {
        if (m.trim()) set.add(m.trim());
      });
      // Separate "বস্ত্র" and "পাট" as requested
      (entries || []).forEach((e) => {
        const m = (e.ministryName || "").trim();
        if (m && m !== "বস্ত্র ও পাট মন্ত্রণালয়") {
          set.add(m);
        }
      });
      return Array.from(set).sort((a, b) => a.localeCompare(b, "bn"));
    }, [entries]);

    const entityOptions = useMemo(() => {
      const set = new Set<string>();
      if (filterMinistries.length > 0) {
        filterMinistries.forEach((selectedMin) => {
          const normSelectedMin = robustNormalize(selectedMin).toLowerCase();
          Object.entries(MINISTRY_ENTITY_MAP).forEach(([mName, ents]) => {
            const normM = robustNormalize(mName).toLowerCase();
            if (normSelectedMin.includes(normM) || normM.includes(normSelectedMin)) {
              ents.forEach((ent) => {
                if (ent.trim()) set.add(ent.trim());
              });
            }
          });
          (entries || []).forEach((e) => {
            const normEntryMin = robustNormalize(e.ministryName || "").toLowerCase();
            if (normSelectedMin.includes(normEntryMin) || normEntryMin.includes(normSelectedMin)) {
              if (e.entityName && e.entityName.trim()) {
                set.add(e.entityName.trim());
              }
            }
          });
        });
      } else {
        Object.values(MINISTRY_ENTITY_MAP).forEach((ents) => {
          ents.forEach((ent) => {
            if (ent.trim()) set.add(ent.trim());
          });
        });
        (entries || []).forEach((e) => {
          if (e.entityName && e.entityName.trim()) {
            set.add(e.entityName.trim());
          }
        });
      }
      return Array.from(set).sort((a, b) => a.localeCompare(b, "bn"));
    }, [filterMinistries, entries]);

    const cycleOptions = useMemo(() => {
      const options: { date: Date; label: string; cycleLabel: string }[] = [];
      const today = new Date();

      const startOffset = today.getDate() >= 16 ? -1 : 0;
      for (let i = startOffset; i < 24; i++) {
        const refDate = addMonths(today, -i);
        const firstOfTargetMonth = new Date(
          refDate.getFullYear(),
          refDate.getMonth(),
          1,
        );
        const cycle = getCycleForDate(firstOfTargetMonth);
        const label = `${toBengaliDigits(format(cycle.start, "dd/MM/yyyy"))} হতে ${toBengaliDigits(format(cycle.end, "dd/MM/yyyy"))}`;
        if (!options.some((o) => o.cycleLabel === cycle.label)) {
          options.push({
            date: firstOfTargetMonth,
            label,
            cycleLabel: cycle.label,
          });
        }
      }

      // Also ensure any cycle present in entries is included
      entries.forEach((entry) => {
        let entryDate = entry.issueDateISO;
        if (!entryDate && entry.createdAt) {
          const d = new Date(entry.createdAt);
          if (!isNaN(d.getTime())) entryDate = d.toISOString().split("T")[0];
        }
        if (entryDate) {
          try {
            const dateObj = new Date(entryDate);
            if (!isNaN(dateObj.getTime())) {
              const cycle = getCycleForDate(dateObj);
              if (!options.some((o) => o.cycleLabel === cycle.label)) {
                const label = `${toBengaliDigits(format(cycle.start, "dd/MM/yyyy"))} হতে ${toBengaliDigits(format(cycle.end, "dd/MM/yyyy"))}`;
                options.push({
                  date: dateObj,
                  label,
                  cycleLabel: cycle.label,
                });
              }
            }
          } catch (e) {}
        }
      });

      options.sort((a, b) => {
        const cA = getCycleForDate(a.date).start.getTime();
        const cB = getCycleForDate(b.date).start.getTime();
        return cB - cA;
      });

      return options;
    }, [entries]);

    const activeCycle = useMemo(() => {
      if (selectedCycles.length === 0) return null;
      const opt = cycleOptions.find((o) => o.cycleLabel === selectedCycles[0]);
      if (!opt) return null;
      return getCycleForDate(opt.date);
    }, [selectedCycles, cycleOptions]);

    const toggleExpand = (id: string) => {
      const next = new Set(expandedEntries);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      setExpandedEntries(next);
    };

    const IDBadge = ({ id }: { id: string }) => {
      const [copied, setCopied] = useState(false);
      if (!isLayoutEditable) return null;
      const handleCopy = (e: React.MouseEvent) => {
        e.stopPropagation();
        navigator.clipboard.writeText(id);
        setCopied(true);
        setTimeout(() => setCopied(false), 1500);
      };
      return (
        <span
          onClick={handleCopy}
          className={`absolute -top-3 left-2 bg-black text-white text-[9px] font-black px-2 py-0.5 rounded border border-white/30 z-[300] cursor-pointer no-print shadow-xl transition-all duration-200 hover:scale-150 hover:bg-blue-600 active:scale-95 flex items-center gap-1 origin-left ${copied ? "ring-2 ring-emerald-500 bg-emerald-600" : ""}`}
        >
          {copied ? "COPIED!" : `#${id}`}
        </span>
      );
    };

    const filteredEntries = useMemo(() => {
      return entries
        .map((entry) => {
          if (!entry.paragraphs || entry.paragraphs.length === 0) return entry;

          if (filterStatus === "settled") {
            const filteredParas = entry.paragraphs.filter(
              (p) => (p.status || "").trim() === "পূর্ণাঙ্গ"
            );
            if (filteredParas.length === entry.paragraphs.length) return entry;

            const inv = filteredParas.reduce((sum, p) => sum + (p.involvedAmount || 0), 0);
            const vRec = filteredParas.reduce((sum, p) => sum + (p.category === "ভ্যাট" ? (p.recoveredAmount || 0) : (p.vatRec || 0)), 0);
            const vAdj = filteredParas.reduce((sum, p) => sum + (p.category === "ভ্যাট" ? (p.adjustedAmount || 0) : (p.vatAdj || 0)), 0);
            const iRec = filteredParas.reduce((sum, p) => sum + (p.category === "আয়কর" ? (p.recoveredAmount || 0) : (p.itRec || 0)), 0);
            const iAdj = filteredParas.reduce((sum, p) => sum + (p.category === "আয়কর" ? (p.adjustedAmount || 0) : (p.itAdj || 0)), 0);
            const oRec = filteredParas.reduce((sum, p) => sum + (p.category === "অন্যান্য" ? (p.recoveredAmount || 0) : (p.othersRec || 0)), 0);
            const oAdj = filteredParas.reduce((sum, p) => sum + (p.category === "অন্যান্য" ? (p.adjustedAmount || 0) : (p.othersAdj || 0)), 0);
            const tRec = filteredParas.reduce((sum, p) => sum + (p.recoveredAmount || 0), 0);
            const tAdj = filteredParas.reduce((sum, p) => sum + (p.adjustedAmount || 0), 0);

            return {
              ...entry,
              paragraphs: filteredParas,
              involvedAmount: inv,
              vatRec: vRec,
              vatAdj: vAdj,
              itRec: iRec,
              itAdj: iAdj,
              othersRec: oRec,
              othersAdj: oAdj,
              totalRec: tRec,
              totalAdj: tAdj,
            };
          }

          if (filterStatus === "unsettled") {
            const filteredParas = entry.paragraphs.filter(
              (p) => (p.status || "").trim() === "আংশিক"
            );
            if (filteredParas.length === entry.paragraphs.length) return entry;

            const inv = filteredParas.reduce((sum, p) => sum + (p.involvedAmount || 0), 0);
            const vRec = filteredParas.reduce((sum, p) => sum + (p.category === "ভ্যাট" ? (p.recoveredAmount || 0) : (p.vatRec || 0)), 0);
            const vAdj = filteredParas.reduce((sum, p) => sum + (p.category === "ভ্যাট" ? (p.adjustedAmount || 0) : (p.vatAdj || 0)), 0);
            const iRec = filteredParas.reduce((sum, p) => sum + (p.category === "আয়কর" ? (p.recoveredAmount || 0) : (p.itRec || 0)), 0);
            const iAdj = filteredParas.reduce((sum, p) => sum + (p.category === "আয়কর" ? (p.adjustedAmount || 0) : (p.itAdj || 0)), 0);
            const oRec = filteredParas.reduce((sum, p) => sum + (p.category === "অন্যান্য" ? (p.recoveredAmount || 0) : (p.othersRec || 0)), 0);
            const oAdj = filteredParas.reduce((sum, p) => sum + (p.category === "অন্যান্য" ? (p.adjustedAmount || 0) : (p.othersAdj || 0)), 0);
            const tRec = filteredParas.reduce((sum, p) => sum + (p.recoveredAmount || 0), 0);
            const tAdj = filteredParas.reduce((sum, p) => sum + (p.adjustedAmount || 0), 0);

            return {
              ...entry,
              paragraphs: filteredParas,
              involvedAmount: inv,
              vatRec: vRec,
              vatAdj: vAdj,
              itRec: iRec,
              itAdj: iAdj,
              othersRec: oRec,
              othersAdj: oAdj,
              totalRec: tRec,
              totalAdj: tAdj,
            };
          }

          return entry;
        })
        .filter((entry) => {
          let entryDate = entry.issueDateISO || "";
          const matchDate = (() => {
            if (isCustomDateActive && (filterStartDate || filterEndDate)) {
              if (!entryDate) return false;
              if (filterStartDate && entryDate < filterStartDate) return false;
              if (filterEndDate && entryDate > filterEndDate) return false;
              return true;
            }
            if (selectedCycles.length === 0) return true;
            if (!entryDate) return false;
            return selectedCycles.some((cLabel) => {
              const opt = cycleOptions.find((o) => o.cycleLabel === cLabel);
              if (!opt) return false;
              const c = getCycleForDate(opt.date);
              const startStr = format(c.start, "yyyy-MM-dd");
              const endStr = format(c.end, "yyyy-MM-dd");
              return entryDate >= startStr && entryDate <= endStr;
            });
          })();

          const normalizedSearch = toEnglishDigits(
            searchTerm.trim().toLowerCase(),
          );
          const isNumericSearch = /^\d+$/.test(normalizedSearch);

          const matchSearch =
            searchTerm === "" ||
            (() => {
              // More robust cleaning for search matching
              const cleanNumber = (str: string) => {
                return toEnglishDigits(str.toLowerCase())
                  .replace(
                    /(কার্যপত্রের|কার্যপত্র|জারিপত্রের|জারিপত্র|ডায়েরির|ডায়েরি|পত্রের|পত্র|তারিখের|তারিখ|নং|ও|ের|র)[\s:\-–—]*/g,
                    "",
                  )
                  .trim();
              };

              const engIssue = cleanNumber(entry.issueLetterNoDate || "");
              const engLetter = cleanNumber(entry.letterNoDate || "");
              const engDiary = cleanNumber(entry.workpaperNoDate || "");
              const engWp = cleanNumber(entry.meetingWorkpaper || "");

              const isNumberMatch =
                engIssue.includes(normalizedSearch) ||
                engLetter.includes(normalizedSearch) ||
                engDiary.includes(normalizedSearch) ||
                engWp.includes(normalizedSearch);

              if (isNumericSearch) return isNumberMatch;

              // Also allow partial match on other fields for general search
              const descMatch = toEnglishDigits(
                (entry.remarks || "").toLowerCase(),
              ).includes(normalizedSearch);
              const branchMatch = toEnglishDigits(
                (entry.branchName || "").toLowerCase(),
              ).includes(normalizedSearch);
              const ministryMatch = toEnglishDigits(
                (entry.ministryName || "").toLowerCase(),
              ).includes(normalizedSearch);
              const entityMatch = toEnglishDigits(
                (entry.entityName || "").toLowerCase(),
              ).includes(normalizedSearch);

              return (
                isNumberMatch ||
                descMatch ||
                branchMatch ||
                ministryMatch ||
                entityMatch
              );
            })();

          const entryType = entry.isMeeting ? entry.meetingType : "বিএসআর";
          const matchType = filterType === "" || entryType === filterType;
          const matchParaType = (() => {
            if (filterParaType === "") return true;
            if (!entry.paraType) return false;
            
            const variations = [filterParaType, filterParaType.replace(' ', '-'), filterParaType.replace('-', ' ')];
            if (filterParaType === 'এসএফআই') variations.push('SFI', 'sfi', 'এস-এফ-আই', 'এস এফ আই');
            else if (filterParaType.includes('নন')) variations.push('NON-SFI', 'non-sfi', 'Non-SFI', 'নন-এসএফআই', 'নন-এস-এফ-আই', 'নন এস এফ আই');
            
            const normalizedEntryPara = entry.paraType.trim();
            return variations.some(v => normalizedEntryPara === v);
          })();

          const hasSettled =
            (entry.paragraphs && entry.paragraphs.some((p) => (p.status || "").trim() === "পূর্ণাঙ্গ")) ||
            (entry.isMeeting && (
              parseBengaliNumber((entry.meetingFullSettledParaCount || "").toString().trim()) > 0 ||
              parseBengaliNumber((entry.meetingSettledParaCount || "").toString().trim()) > 0
            ));

          const hasUnsettled =
            (entry.paragraphs && entry.paragraphs.some((p) => (p.status || "").trim() === "আংশিক")) ||
            (entry.isMeeting && (
              parseBengaliNumber((entry.meetingPartialSettledParaCount || "").toString().trim()) > 0
            ));

          const matchStatus =
            filterStatus === "" ||
            (filterStatus === "settled" && hasSettled) ||
            (filterStatus === "unsettled" && hasUnsettled) ||
            (filterStatus === "no-paras" &&
              (!entry.paragraphs || entry.paragraphs.length === 0));

          // Ministry Filter (Multi-select + separate পাট vs বস্ত্র)
          const matchMinistry = (() => {
            if (filterMinistries.length === 0) return true;
            const normEntryMin = robustNormalize(entry.ministryName || "").toLowerCase();
            const normEntryEnt = robustNormalize(entry.entityName || "").toLowerCase();

            return filterMinistries.some((min) => {
              const normMin = robustNormalize(min).toLowerCase();

              // Special handling for separate পাট vs বস্ত্র:
              if (normMin.includes("পাট")) {
                if (normEntryMin.includes("পাট") && !normEntryMin.includes("বস্ত্র")) return true;
                if (normEntryEnt.includes("পাট") || normEntryEnt.includes("বিজেএমসি") || normEntryEnt.includes("জুট")) return true;
                if (normEntryMin.includes("বস্ত্র ও পাট") && (normEntryEnt.includes("পাট") || normEntryEnt.includes("বিজেএমসি"))) return true;
                return false;
              }

              if (normMin.includes("বস্ত্র")) {
                if (normEntryMin.includes("বস্ত্র") && !normEntryMin.includes("পাট")) return true;
                if (normEntryEnt.includes("বস্ত্র") || normEntryEnt.includes("বিটিএমসি") || normEntryEnt.includes("রেশম")) return true;
                if (normEntryMin.includes("বস্ত্র ও পাট") && (normEntryEnt.includes("বস্ত্র") || normEntryEnt.includes("রেশম") || normEntryEnt.includes("বিটিএমসি"))) return true;
                return false;
              }

              if (normMin === normEntryMin) return true;
              return normEntryMin.includes(normMin) || normMin.includes(normEntryMin);
            });
          })();

          // Entity Filter (Multi-select)
          const matchEntity = (() => {
            if (filterEntities.length === 0) return true;
            const normEntryEnt = robustNormalize(entry.entityName || "").toLowerCase();
            return filterEntities.some((ent) => {
              const normEnt = robustNormalize(ent).toLowerCase();
              if (normEnt === normEntryEnt) return true;
              return normEntryEnt.includes(normEnt) || normEnt.includes(normEntryEnt);
            });
          })();

          const hasRaisedCount =
            entry.manualRaisedCount !== null &&
            entry.manualRaisedCount !== "" &&
            entry.manualRaisedCount !== "0" &&
            entry.manualRaisedCount !== "০";
          const hasRaisedAmount =
            entry.manualRaisedAmount !== null && entry.manualRaisedAmount !== 0;
          const hasMeaningfulContent =
            (entry.paragraphs && entry.paragraphs.length > 0) ||
            (entry.isMeeting && (entry.meetingUnsettledAmount || 0) > 0) ||
            hasRaisedCount ||
            hasRaisedAmount;

          // If we have a search term and it matches, we should show it regardless of "meaningful content"
          if (searchTerm !== "" && matchSearch)
            return matchDate && matchType && matchParaType && matchStatus && matchMinistry && matchEntity;

          // If filtering for no paragraphs, show even if it doesn't have "meaningful content"
          if (filterStatus === "no-paras" && matchStatus)
            return matchDate && matchType && matchParaType && matchMinistry && matchEntity;

          if (!hasMeaningfulContent && !isAdminView) return false;

          return (
            matchDate &&
            matchSearch &&
            matchType &&
            matchParaType &&
            matchStatus &&
            matchMinistry &&
            matchEntity
          );
        })
        .sort((a, b) => {
          const timeB = b.issueDateISO ? new Date(b.issueDateISO).getTime() : 0;
          const timeA = a.issueDateISO ? new Date(a.issueDateISO).getTime() : 0;
          if (timeB !== timeA) return timeB - timeA;

          const createdB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
          const createdA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
          return (isNaN(createdB) ? 0 : createdB) - (isNaN(createdA) ? 0 : createdA);
        });
    }, [
      entries,
      searchTerm,
      filterParaType,
      filterType,
      filterStatus,
      filterMinistries,
      filterEntities,
      selectedCycles,
      cycleOptions,
      isCustomDateActive,
      filterStartDate,
      filterEndDate,
    ]);

    const { cycleStats, groupedEntries } = useMemo(() => {
      const groupsMap: Record<string, SettlementEntry[]> = {};
      const groupsList: { label: string; entries: SettlementEntry[] }[] = [];

      filteredEntries.forEach((entry) => {
        let label = "Unknown";
        let entryDate = entry.issueDateISO;
        if (!entryDate && entry.createdAt) {
          const d = new Date(entry.createdAt);
          if (!isNaN(d.getTime())) {
            entryDate = d.toISOString().split("T")[0];
          }
        }

        if (entryDate) {
          try {
            const dateObj = new Date(entryDate);
            if (!isNaN(dateObj.getTime())) {
              label = getCycleForDate(dateObj).label;
            }
          } catch (e) {}
        }

        if (!groupsMap[label]) {
          groupsMap[label] = [];
          groupsList.push({ label, entries: groupsMap[label] });
        }
        groupsMap[label].push(entry);
      });

      const statsMap: Record<string, any> = {};
      groupsList.forEach((group) => {
        const totalLetters = group.entries.length;
        const sfiEntries = group.entries.filter((e) => isSFI(e.paraType));
        const nonSfiEntries = group.entries.filter(
          (e) => isNonSFI(e.paraType),
        );
        const sfiBSR = sfiEntries.filter(
          (e) => !e.isMeeting || e.meetingType === "বিএসআর",
        ).length;
        const sfiTri = sfiEntries.filter(
          (e) => e.meetingType === "ত্রিপক্ষীয় সভা",
        ).length;
        const nonSfiBSR = nonSfiEntries.filter(
          (e) => !e.isMeeting || e.meetingType === "বিএসআর",
        ).length;
        const nonSfiBi = nonSfiEntries.filter(
          (e) => e.meetingType === "দ্বিপক্ষীয় সভা",
        ).length;
        const cycleSettledParasCount = group.entries.reduce(
          (acc, ent) => {
            const paras = ent.paragraphs || [];
            if (filterStatus === "unsettled") {
              const pCount = paras.filter((p) => (p.status || "").trim() === "আংশিক").length;
              if (pCount > 0) return acc + pCount;
              if (ent.isMeeting) {
                const mPartial = parseBengaliNumber((ent.meetingPartialSettledParaCount || "").toString().trim());
                return acc + (mPartial > 0 ? mPartial : 0);
              }
              return acc;
            }
            const pCount = paras.filter((p) => (p.status || "").trim() === "পূর্ণাঙ্গ").length;
            if (pCount > 0) return acc + pCount;
            if (ent.isMeeting) {
              const mFull = parseBengaliNumber((ent.meetingFullSettledParaCount || "").toString().trim());
              const mSettled = parseBengaliNumber((ent.meetingSettledParaCount || "").toString().trim());
              return acc + (mFull > 0 ? mFull : mSettled > 0 ? mSettled : 0);
            }
            return acc;
          },
          0,
        );

        const getSettledDetails = (typeEntries: SettlementEntry[]) => {
          const ministryMap: Record<string, Record<string, number>> = {};
          const entityMap: Record<string, number> = {};

          typeEntries.forEach((ent) => {
            let count = 0;
            const paras = ent.paragraphs || [];
            const targetParas = paras.filter((p) =>
              filterStatus === "unsettled"
                ? (p.status || "").trim() === "আংশিক"
                : (p.status || "").trim() === "পূর্ণাঙ্গ"
            );

            if (targetParas.length > 0) {
              count = targetParas.length;
            } else if (ent.isMeeting) {
              if (filterStatus === "unsettled") {
                const mPartial = parseBengaliNumber((ent.meetingPartialSettledParaCount || "").toString().trim());
                count = mPartial > 0 ? mPartial : 0;
              } else {
                const mFull = parseBengaliNumber((ent.meetingFullSettledParaCount || "").toString().trim());
                const mSettled = parseBengaliNumber((ent.meetingSettledParaCount || "").toString().trim());
                count = mFull > 0 ? mFull : mSettled > 0 ? mSettled : 0;
              }
            }

            if (count > 0) {
              const ministry = (ent.ministryName || "").trim() || "মন্ত্রণালয় উল্লেখ নেই";
              const entity = (ent.entityName || "").trim() || "প্রতিষ্ঠান উল্লেখ নেই";

              if (!ministryMap[ministry]) {
                ministryMap[ministry] = {};
              }
              ministryMap[ministry][entity] = (ministryMap[ministry][entity] || 0) + count;
              entityMap[entity] = (entityMap[entity] || 0) + count;
            }
          });

          const total = Object.values(entityMap).reduce((a, b) => a + b, 0);
          const details = Object.entries(entityMap)
            .map(([name, count]) => `${name} ${toBengaliDigits(count)} টি`)
            .join(", ");

          const ministries: SettledMinistryItem[] = Object.entries(ministryMap).map(
            ([ministryName, entitiesObj]) => {
              const entities = Object.entries(entitiesObj).map(([entityName, count]) => ({
                entityName,
                count,
              }));
              const totalCount = entities.reduce((sum, e) => sum + e.count, 0);
              return {
                ministryName,
                totalCount,
                entities,
              };
            },
          );

          return { total, details, ministries };
        };

        const sfiSettled = getSettledDetails(sfiEntries);
        const nonSfiSettled = getSettledDetails(nonSfiEntries);
        const allSettled = getSettledDetails(group.entries);

        const getSettledAmount = (typeEntries: SettlementEntry[]) => {
          return typeEntries.reduce((sum, ent) => {
            const paras = ent.paragraphs || [];
            if (paras.length > 0) {
              const paraSum = paras.reduce(
                (pSum, p) => pSum + (Number(p.recoveredAmount) || 0) + (Number(p.adjustedAmount) || 0),
                0
              );
              return sum + paraSum;
            }
            return sum + (Number(ent.totalRec) || 0) + (Number(ent.totalAdj) || 0);
          }, 0);
        };

        const sfiSettledAmount = getSettledAmount(sfiEntries);
        const nonSfiSettledAmount = getSettledAmount(nonSfiEntries);

        statsMap[group.label] = {
          totalLetters,
          sfiEntries,
          nonSfiEntries,
          sfiBSR,
          sfiTri,
          nonSfiBSR,
          nonSfiBi,
          cycleSettledParasCount,
          sfiSettled,
          nonSfiSettled,
          allSettled,
          sfiSettledAmount,
          nonSfiSettledAmount,
        };
      });

      return { cycleStats: statsMap, groupedEntries: groupsList };
    }, [filteredEntries, filterStatus]);

    const grandTotals = useMemo(() => {
      return filteredEntries.reduce(
        (acc, entry) => {
          const paras = entry.paragraphs || [];
          
          let fullCount = 0;
          let partialCount = 0;
          if (paras.length > 0) {
            fullCount = paras.filter((p) => (p.status || "").trim() === "পূর্ণাঙ্গ").length;
            partialCount = paras.filter((p) => (p.status || "").trim() === "আংশিক").length;
          } else if (entry.isMeeting) {
            if (filterStatus !== "unsettled") {
              const mFull = parseBengaliNumber((entry.meetingFullSettledParaCount || "").toString().trim());
              const mSettled = parseBengaliNumber((entry.meetingSettledParaCount || "").toString().trim());
              fullCount = mFull > 0 ? mFull : mSettled > 0 ? mSettled : 0;
            }
            if (filterStatus !== "settled") {
              const mPartial = parseBengaliNumber((entry.meetingPartialSettledParaCount || "").toString().trim());
              partialCount = mPartial > 0 ? mPartial : 0;
            }
          }

          acc.fullParaCount += fullCount;
          acc.partialParaCount += partialCount;
          acc.paraCount += (filterStatus === "unsettled" ? partialCount : fullCount);

          // Use entry.involvedAmount if available as it includes meeting unsettled amounts
          acc.inv += entry.involvedAmount || paras.reduce((sum, p) => sum + (p.involvedAmount || 0), 0);

          const rCountRaw = entry.manualRaisedCount?.toString().trim() || "";
          const rCount =
            rCountRaw !== "" && rCountRaw !== "0" && rCountRaw !== "০"
              ? parseBengaliNumber(rCountRaw)
              : 0;
          const rAmount =
            entry.manualRaisedAmount !== null &&
            entry.manualRaisedAmount !== undefined &&
            entry.manualRaisedAmount !== 0
              ? Number(entry.manualRaisedAmount)
              : 0;
          acc.raisedCount += rCount;
          acc.raisedAmount += rAmount;
          acc.vRec += entry.vatRec || 0;
          acc.vAdj += entry.vatAdj || 0;
          acc.iRec += entry.itRec || 0;
          acc.iAdj += entry.itAdj || 0;
          acc.oRec += entry.othersRec || 0;
          acc.oAdj += entry.othersAdj || 0;
          acc.tRec += entry.totalRec || 0;
          acc.tAdj += entry.totalAdj || 0;
          return acc;
        },
        {
          fullParaCount: 0,
          partialParaCount: 0,
          paraCount: 0,
          inv: 0,
          raisedCount: 0,
          raisedAmount: 0,
          vRec: 0,
          vAdj: 0,
          iRec: 0,
          iAdj: 0,
          oRec: 0,
          oAdj: 0,
          tRec: 0,
          tAdj: 0,
        },
      );
    }, [filteredEntries, filterStatus]);

    const globalStats = useMemo(() => {
      const totalLetters = filteredEntries.length;
      const sfiEntries = filteredEntries.filter((e) => isSFI(e.paraType));
      const nonSfiEntries = filteredEntries.filter((e) => isNonSFI(e.paraType));

      const sfiBSR = sfiEntries.filter(
        (e) => !e.isMeeting || e.meetingType === "বিএসআর",
      ).length;
      const sfiTri = sfiEntries.filter(
        (e) => e.meetingType === "ত্রিপক্ষীয় সভা",
      ).length;
      const nonSfiBSR = nonSfiEntries.filter(
        (e) => !e.isMeeting || e.meetingType === "বিএসআর",
      ).length;
      const nonSfiBi = nonSfiEntries.filter(
        (e) => e.meetingType === "দ্বিপক্ষীয় সভা",
      ).length;

      const settledParas = filteredEntries.reduce(
        (acc, ent) => {
          const paras = ent.paragraphs || [];
          if (filterStatus === "unsettled") {
            const pCount = paras.filter((p) => (p.status || "").trim() === "আংশিক").length;
            if (pCount > 0) return acc + pCount;
            if (ent.isMeeting) {
              const mPartial = parseBengaliNumber((ent.meetingPartialSettledParaCount || "").toString().trim());
              return acc + (mPartial > 0 ? mPartial : 0);
            }
            return acc;
          }
          const pCount = paras.filter((p) => (p.status || "").trim() === "পূর্ণাঙ্গ").length;
          if (pCount > 0) return acc + pCount;
          if (ent.isMeeting) {
            const mFull = parseBengaliNumber((ent.meetingFullSettledParaCount || "").toString().trim());
            const mSettled = parseBengaliNumber((ent.meetingSettledParaCount || "").toString().trim());
            return acc + (mFull > 0 ? mFull : mSettled > 0 ? mSettled : 0);
          }
          return acc;
        },
        0,
      );

      const totalSettledAmount = filteredEntries.reduce((sum, ent) => {
        const paras = ent.paragraphs || [];
        if (paras.length > 0) {
          const paraSum = paras.reduce(
            (pSum, p) =>
              pSum +
              (Number(p.recoveredAmount) || 0) +
              (Number(p.adjustedAmount) || 0),
            0,
          );
          return sum + paraSum;
        }
        return sum + (Number(ent.totalRec) || 0) + (Number(ent.totalAdj) || 0);
      }, 0);

      return {
        totalLetters,
        sfi: {
          total: sfiEntries.length,
          bsr: sfiBSR,
          tri: sfiTri,
        },
        nonSfi: {
          total: nonSfiEntries.length,
          bsr: nonSfiBSR,
          bi: nonSfiBi,
        },
        settledParas,
        totalSettledAmount,
        totalInvolved: grandTotals.inv,
      };
    }, [filteredEntries, grandTotals, filterStatus]);

    const formatIssueInfoForDisplay = (info: string) => {
      if (!info) return "";
      const cleaned = info
        .replace(
          /(কার্যপত্রের|কার্যপত্র|জারিপত্রের|জারিপত্র|ডায়েরির|ডায়েরি|পত্রের|পত্র|তারিখের|তারিখ|নং|ও|ের|র)[\s:\-–—]*/g,
          "",
        )
        .trim();
      return cleaned ? cleaned + " খ্রি:" : "";
    };

    const formatDiaryInfoForDisplay = (info: string) => {
      if (!info) return "";
      const cleaned = info
        .replace(
          /(কার্যপত্রের|কার্যপত্র|জারিপত্রের|জারিপত্র|ডায়েরির|ডায়েরি|পত্রের|পত্র|তারিখের|তারিখ|নং|ও|ের|র)[\s:\-–—]*/g,
          "",
        )
        .trim();
      return cleaned ? cleaned + " খ্রি:" : "";
    };

    const formatLetterInfoForDisplay = (info: string) => {
      if (!info) return "";
      const cleaned = info
        .replace(
          /(কার্যপত্রের|কার্যপত্র|জারিপত্রের|জারিপত্র|ডায়েরির|ডায়েরি|পত্রের|পত্র|তারিখের|তারিখ|নং|ও|ের|র)[\s:\-–—]*/g,
          "",
        )
        .trim();
      return cleaned ? cleaned + " খ্রি:" : "";
    };

    const formatWorkpaperInfoForDisplay = (info: string) => {
      if (!info) return "";
      const cleaned = info
        .replace(
          /(কার্যপত্রের|কার্যপত্র|জারিপত্রের|জারিপত্র|ডায়েরির|ডায়েরি|পত্রের|পত্র|তারিখের|তারিখ|নং|ও|ের|র)[\s:\-–—]*/g,
          "",
        )
        .trim();
      return cleaned ? cleaned + " খ্রি:" : "";
    };

    const formatArchiveNoForTable = (val: string | undefined | null) => {
      if (!val || val.trim() === '') return '-';
      
      const trimmed = val.trim();
      let prefix = "";
      let rest = trimmed;
      
      if (trimmed.toLowerCase().startsWith("kg-")) {
        const dashIdx = trimmed.indexOf("-");
        prefix = trimmed.substring(0, dashIdx + 1).trim() + "\u00A0";
        rest = trimmed.substring(dashIdx + 1).trim();
      }
      
      if (!rest) return prefix ? prefix.trim() : '-';
      
      // Split rest by commas
      const parts = rest.split(',').map(p => p.trim()).filter(p => p !== '');
      if (parts.length === 0) return prefix ? prefix.trim() : '-';
      
      // Group parts: max 3 per line
      const lines: string[] = [];
      for (let i = 0; i < parts.length; i += 3) {
        const chunk = parts.slice(i, i + 3);
        lines.push(chunk.join(', '));
      }
      
      return prefix + lines.join('\n');
    };

    const splitCombinedInfo = (info: string, noPrefix: string, datePrefix: string) => {
      if (!info) return { no: "-", date: "-" };
      const parts = info.split(',');
      if (parts.length < 2) {
        const cleaned = info
          .replace(
            /(কার্যপত্রের|কার্যপত্র|জারিপত্রের|জারিপত্র|ডায়েরির|ডায়েরি|পত্রের|পত্র|তারিখের|তারিখ|নং|ও|ের|র)[\s:\-–—]*/g,
            "",
          )
          .trim();
        return { no: cleaned || "-", date: "-" };
      }
      let no = parts[0].replace(new RegExp(`.*${noPrefix}[\\s:\\-–—]*`), "").trim() || "-";
      let date = parts[1].replace(new RegExp(`.*${datePrefix}[\\s:\\-–—]*`), "").trim();
      if (date) {
        const cleanDate = date.replace(/খ্রি:?.*$/, '').trim();
        const dmy = formatBengaliDateDMY(cleanDate);
        date = (dmy || cleanDate) + " খ্রি:";
      } else {
        date = "-";
      }
      return { no, date };
    };

    // Headers reverted to font-black with sticky positioning
    const thBase =
      "sticky top-0 z-[120] border-r border-b border-slate-300 px-1 py-1.5 font-black text-center text-slate-900 text-[8.5px] leading-tight align-middle h-full bg-slate-200 shadow-[inset_0_1px_0_rgba(255,255,255,0.9)] bg-clip-border whitespace-nowrap";
    const thBase2 =
      "sticky top-[42px] z-[120] border-r border-b border-slate-300 px-1 py-1.5 font-black text-center text-slate-900 text-[8.5px] leading-tight align-middle h-full bg-slate-200 shadow-[inset_0_1px_0_rgba(255,255,255,0.7)] bg-clip-border whitespace-nowrap";
    const thBase3 =
      "sticky top-[80px] z-[120] border-r border-b border-slate-300 px-1 py-0.5 font-black text-center text-slate-700 text-[8px] leading-tight align-middle h-full bg-slate-200 shadow-[inset_0_1px_0_rgba(255,255,255,0.5)] bg-clip-border whitespace-nowrap";
    // Body cells reverted to font-bold
    const tdBase =
      "border border-slate-300 px-0.5 py-1.5 text-center align-middle text-[9px] leading-tight font-bold text-slate-900 relative";
    const tdMoney =
      "border border-slate-300 px-0.5 py-1 text-center align-middle text-[9px] font-black text-slate-950 relative whitespace-nowrap";

    const renderCellDescription = (entry: SettlementEntry, isExpanded: boolean) => {
      const hasNoParas = !entry.paragraphs || entry.paragraphs.length === 0;
      const isBsr = !entry.isMeeting && entry.meetingType === "বিএসআর";
      
      const letterParts = splitCombinedInfo(entry.letterNoDate || "", "পত্র নং", "পত্রের তারিখ");
      const diaryParts = splitCombinedInfo(entry.workpaperNoDate || "", "ডায়েরি নং", "ডায়েরির তারিখ");
      const issueParts = splitCombinedInfo(entry.issueLetterNoDate || "", "জারিপত্র নং", "জারিপত্রের তারিখ");
      const wpParts = splitCombinedInfo(entry.meetingWorkpaper || "", "কার্যপত্র নং", "কার্যপত্রের তারিখ");

      let currentSl = 1;
      const getNextLabel = (title: string) => {
        const num = toBengaliDigits(currentSl++);
        return `${num}. ${title}`;
      };

      const fields: Array<{ label: string; value: string; isBold?: boolean; highlight?: boolean }> = [
        { label: getNextLabel("শাখা ধরণ"), value: entry.paraType || "-" },
        { label: getNextLabel("চিঠির ধরণ"), value: entry.isMeeting ? entry.meetingType : "বিএসআর" },
        { label: getNextLabel("মন্ত্রণালয়"), value: entry.ministryName || "-", highlight: true },
        { label: getNextLabel("এনটিটি/সংস্থা"), value: entry.entityName || "-", highlight: true },
        { label: getNextLabel("শাখা (বিস্তারিত বিবরণ)"), value: entry.branchName || "-", highlight: true },
        { label: getNextLabel("নিরীক্ষা সাল"), value: toBengaliDigits(entry.auditYear) || "-" },
        { label: getNextLabel("পত্র নং"), value: letterParts.no || "-" },
        { label: getNextLabel("পত্রের তারিখ"), value: letterParts.date || "-" },
      ];

      if (isBsr || (diaryParts.no && diaryParts.no !== "-") || (diaryParts.date && diaryParts.date !== "-")) {
        fields.push(
          { label: getNextLabel("ডায়েরি নং"), value: diaryParts.no || "-" },
          { label: getNextLabel("ডায়েরি তারিখ"), value: diaryParts.date || "-" },
          { label: getNextLabel("জারিপত্র নং"), value: issueParts.no || "-" },
          { label: getNextLabel("জারিপত্র তারিখ"), value: issueParts.date || "-" }
        );
      } else {
        fields.push(
          { label: getNextLabel("জারিপত্র নং"), value: issueParts.no || "-" },
          { label: getNextLabel("জারিপত্র তারিখ"), value: issueParts.date || "-" }
        );
      }

      if (showAuditDetails) {
        fields.push({
          label: getNextLabel("প্রেরিত অনুচ্ছেদ সংখ্যা"),
          value: toBengaliDigits(entry.meetingSentParaCount || "০") + " টি"
        });
      }

      fields.push({
        label: getNextLabel("অনলাইন/অফলাইন স্ট্যাটাস"),
        value: entry.isSentOnline || "না"
      });

      fields.push({
        label: getNextLabel("আর্কাইভ নং"),
        value: formatArchiveNoForTable(entry.archiveNo) || "-"
      });

      if (isBsr) {
        fields.push({
          label: getNextLabel("মন্তব্য"),
          value: entry.remarks || "-",
          isBold: false
        });
      } else {
        fields.push(
          { label: getNextLabel("সভার তারিখ"), value: formatDateBN(entry.meetingDate) || "-" },
          { label: getNextLabel("আলোচিত অনুচ্ছেদ সংখ্যা"), value: toBengaliDigits(entry.meetingDiscussedParaCount || "০") + " টি" },
          { label: getNextLabel("সুপারিশকৃত অনুচ্ছেদ সংখ্যা"), value: toBengaliDigits(entry.meetingRecommendedParaCount || "০") + " টি" },
          { label: getNextLabel("কার্যপত্র নং"), value: wpParts.no || "-" },
          { label: getNextLabel("কার্যপত্র তারিখ"), value: wpParts.date || "-" },
          { label: getNextLabel("কার্যবিবরণী প্রাপ্তির তারিখ"), value: entry.meetingResponseDate || "-" },
          { label: getNextLabel("মন্তব্য"), value: entry.remarks || "-", isBold: false }
        );
      }

      return (
        <div className="w-full space-y-1 text-justify pt-0.5 pb-1">
            {hasNoParas && (
              <p className="text-[10px] leading-tight font-black text-red-600 underline underline-offset-2 tracking-tighter mb-1.5">
                উত্থাপিত এন্ট্রি (কোন অনুচ্ছেদ নেই)
              </p>
            )}
            
            {/* Render form fields sequentially */}
            {fields.map((f, idx) => {
              const displayVal = (f.value === "-" || !f.value) ? "" : f.value;
              return (
                <p key={idx} className="text-[10px] leading-tight text-justify">
                  <span className="font-black text-emerald-700">
                    {f.label}{f.label.includes("নং") ? "-" : ":"}
                  </span>{" "}
                  <span className={f.isBold === false ? "font-medium text-slate-800 italic whitespace-pre-wrap" : "font-bold text-slate-900"}>
                    {f.highlight && displayVal ? (
                      <HighlightText text={displayVal} searchTerm={searchTerm} />
                    ) : (
                      displayVal
                    )}
                  </span>
                </p>
              );
            })}
        </div>
      );
    };

    const renderMetadataGrid = (entry: SettlementEntry) => {
      const paras = entry.paragraphs || [];
      const fullMoney = paras
        .filter((p) => p.status === "পূর্ণাঙ্গ")
        .reduce((s, p) => s + p.involvedAmount, 0);
      const partialMoney = paras
        .filter((p) => p.status === "আংশিক")
        .reduce((s, p) => s + p.involvedAmount, 0);

      return (
        <div className="bg-slate-50/80 p-6 border-x border-b border-slate-200 rounded-b-xl animate-in slide-in-from-top-4 duration-500 shadow-inner">
          {isAdminView && isAdmin && (
            <div className="mb-6 p-4 bg-white border border-amber-200 rounded-2xl flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center">
                  <AlertCircle size={24} />
                </div>
                <div>
                  <p className="text-xs font-black text-slate-900">
                    এটি একটি অপেক্ষমাণ এন্ট্রি
                  </p>
                  <p className="text-[10px] font-bold text-slate-500">
                    অনুমোদন দিলে এটি মূল রেজিস্টারে যুক্ত করা যাবে।
                  </p>
                </div>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => onReject?.(entry.id)}
                  className="px-4 py-2 bg-red-50 text-red-600 rounded-xl font-black text-[11px] hover:bg-red-600 hover:text-white transition-all flex items-center gap-2 border border-red-100"
                >
                  <XCircle size={14} /> প্রত্যাখ্যান করুন
                </button>
                <button
                  onClick={() => onApprove?.(entry.id)}
                  className="px-5 py-2 bg-emerald-600 text-white rounded-xl font-black text-[11px] hover:bg-emerald-700 transition-all items-center gap-2 shadow-lg shadow-emerald-200"
                >
                  <ShieldCheck size={14} /> অনুমোদন দিন
                </button>
              </div>
            </div>
          )}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {(() => {
              const isBsr = !entry.isMeeting && entry.meetingType === "বিএসআর";
              const letterParts = splitCombinedInfo(entry.letterNoDate || "", "পত্র নং", "পত্রের তারিখ");
              const diaryParts = splitCombinedInfo(entry.workpaperNoDate || "", "ডায়েরি নং", "ডায়েরির তারিখ");
              const issueParts = splitCombinedInfo(entry.issueLetterNoDate || "", "জারিপত্র নং", "জারিপত্রের তারিখ");
              const wpParts = splitCombinedInfo(entry.meetingWorkpaper || "", "কার্যপত্র নং", "কার্যপত্রের তারিখ");

              let currentSl = 1;
              const getNextLabel = (title: string) => {
                const num = toBengaliDigits(currentSl++);
                return `${num}. ${title}`;
              };

              const fields: Array<{ label: string; value: string; icon: any; col: string }> = [
                { label: getNextLabel("শাখা ধরণ"), value: entry.paraType || "-", icon: Fingerprint, col: "sky" },
                { label: getNextLabel("চিঠির ধরণ"), value: entry.isMeeting ? entry.meetingType : "বিএসআর", icon: FileText, col: "emerald" },
                { label: getNextLabel("মন্ত্রণালয়"), value: entry.ministryName || "-", icon: MapPin, col: "amber" },
                { label: getNextLabel("এনটিটি/সংস্থা"), value: entry.entityName || "-", icon: FileText, col: "purple" },
                { label: getNextLabel("শাখা (বিস্তারিত বিবরণ)"), value: entry.branchName || "-", icon: MapPin, col: "sky" },
                { label: getNextLabel("নিরীক্ষা সাল"), value: toBengaliDigits(entry.auditYear) || "-", icon: Calendar, col: "emerald" },
                { label: getNextLabel("পত্র নং"), value: letterParts.no || "-", icon: FileText, col: "amber" },
                { label: getNextLabel("পত্রের তারিখ"), value: letterParts.date || "-", icon: Calendar, col: "amber" },
              ];

              if (isBsr || (diaryParts.no && diaryParts.no !== "-") || (diaryParts.date && diaryParts.date !== "-")) {
                fields.push(
                  { label: getNextLabel("ডায়েরি নং"), value: diaryParts.no || "-", icon: FileText, col: "emerald" },
                  { label: getNextLabel("ডায়েরি তারিখ"), value: diaryParts.date || "-", icon: Calendar, col: "emerald" },
                  { label: getNextLabel("জারিপত্র নং"), value: issueParts.no || "-", icon: FileText, col: "amber" },
                  { label: getNextLabel("জারিপত্র তারিখ"), value: issueParts.date || "-", icon: Calendar, col: "amber" }
                );
              } else {
                fields.push(
                  { label: getNextLabel("জারিপত্র নং"), value: issueParts.no || "-", icon: FileText, col: "amber" },
                  { label: getNextLabel("জারিপত্র তারিখ"), value: issueParts.date || "-", icon: Calendar, col: "amber" }
                );
              }

              if (showAuditDetails) {
                fields.push({
                  label: getNextLabel("প্রেরিত অনুচ্ছেদ সংখ্যা"),
                  value: toBengaliDigits(entry.meetingSentParaCount || "০") + " টি",
                  icon: ListOrdered,
                  col: "sky"
                });
              }

              fields.push({
                label: getNextLabel("অনলাইন/অফলাইন স্ট্যাটাস"),
                value: entry.isSentOnline || "না",
                icon: Globe,
                col: "emerald"
              });

              fields.push({
                label: getNextLabel("আর্কাইভ নং"),
                value: formatArchiveNoForTable(entry.archiveNo) || "-",
                icon: Archive,
                col: "purple"
              });

              if (isBsr) {
                fields.push({
                  label: getNextLabel("মন্তব্য"),
                  value: entry.remarks || "-",
                  icon: MessageSquare,
                  col: "purple"
                });
              } else {
                fields.push(
                  { label: getNextLabel("সভার তারিখ"), value: formatDateBN(entry.meetingDate) || "-", icon: Calendar, col: "amber" },
                  { label: getNextLabel("আলোচিত অনুচ্ছেদ সংখ্যা"), value: toBengaliDigits(entry.meetingDiscussedParaCount || "০") + " টি", icon: ListOrdered, col: "indigo" },
                  { label: getNextLabel("সুপারিশকৃত অনুচ্ছেদ সংখ্যা"), value: toBengaliDigits(entry.meetingRecommendedParaCount || "০") + " টি", icon: CheckCircle2, col: "emerald" },
                  { label: getNextLabel("কার্যপত্র নং"), value: wpParts.no || "-", icon: FileText, col: "purple" },
                  { label: getNextLabel("কার্যপত্র তারিখ"), value: wpParts.date || "-", icon: Calendar, col: "purple" },
                  { label: getNextLabel("কার্যবিবরণী প্রাপ্তির তারিখ"), value: entry.meetingResponseDate || "-", icon: Calendar, col: "purple" },
                  { label: getNextLabel("মন্তব্য"), value: entry.remarks || "-", icon: MessageSquare, col: "purple" }
                );
              }

              // Add stats description items as non-numbered items at the end
              fields.push(
                { label: "মোট জড়িত টাকা", value: toBengaliDigits(entry.involvedAmount ?? 0) + " টাকা", icon: Banknote, col: "amber" },
                { label: "অমীমাংসিত সংখ্যা", value: toBengaliDigits(entry.meetingUnsettledParas || "০") + " টি", icon: ListOrdered, col: "purple" },
                { label: "অমীমাংসিত টাকা", value: toBengaliDigits(entry.meetingUnsettledAmount ?? 0) + " টাকা", icon: Banknote, col: "sky" },
                { label: "মীমাংসিত সংখ্যা", value: toBengaliDigits(entry.paragraphs?.filter(p => p.status === "পূর্ণাঙ্গ").length || 0) + " টি", icon: CheckCircle2, col: "emerald" }
              );

              if (entry.manualRaisedCount || entry.manualRaisedAmount) {
                fields.push({
                  label: "উত্থাপিত আপত্তি",
                  value: `${toBengaliDigits(entry.manualRaisedCount || "০")} টি (${toBengaliDigits(Math.round(entry.manualRaisedAmount || 0))} টাকা)`,
                  icon: AlertTriangle,
                  col: "blue"
                });
              }

              return fields;
            })().map((item, i) => (
              <div
                key={i}
                className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm flex items-start gap-3"
              >
                <div
                  className={`p-2 rounded-lg bg-${item.col}-50 text-${item.col}-600`}
                >
                  <item.icon size={14} />
                </div>
                <div>
                  <p className="text-[9px] font-bold text-slate-400 uppercase tracking-tight">
                    {item.label}{item.label.includes("নং") ? "-" : ":"}
                  </p>
                  <p className="text-[11px] font-bold text-slate-900 leading-tight">
                    {(item.value === "-" || !item.value) ? "" : item.value}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      );
    };

    let lastRenderedCycle = "";
    // Footer text font-black
    const footerTdCls =
      "p-1 text-center font-black text-[10px] bg-slate-200 text-slate-900 border border-slate-300 shadow-[inset_0_1px_0_rgba(255,255,255,0.5)]";
    const filterInputCls =
      "w-full pl-7 pr-1.5 h-[38px] bg-white border border-slate-300 rounded-lg font-bold text-slate-900 text-[11px] outline-none focus:border-blue-600 focus:ring-4 focus:ring-blue-50 transition-all shadow-sm placeholder:text-slate-400 placeholder:font-bold";
    const customDropdownCls = (isOpen: boolean) =>
      `relative flex items-center gap-1.5 px-2 h-[38px] bg-white border rounded-lg cursor-pointer transition-all duration-300 ${isOpen ? "border-blue-600 ring-4 ring-blue-50 shadow-md z-[1010]" : "border-slate-300 shadow-sm hover:border-slate-400"}`;

    return (
      <div
        id="table-register-container"
        className="w-full relative animate-premium-page"
      >
        <IDBadge id="view-register-table" />
        {!isAdminView && (
          <div
            id="section-register-top-header"
            className="relative mb-6 no-print z-[99999]"
          >
            <IDBadge id="section-register-top-header" />
            <div className="flex flex-col md:flex-row items-center justify-between gap-4 bg-white p-4 rounded-[1.5rem] border border-slate-200 shadow-sm relative group transition-all duration-500 hover:shadow-md">
              <div className="flex items-center gap-4 relative z-10">
                <div className="w-14 h-14 bg-emerald-50 rounded-[1.2rem] text-emerald-600 flex items-center justify-center shadow-inner border border-emerald-100 group-hover:scale-105 transition-transform duration-500">
                  <ClipboardList size={28} strokeWidth={2} />
                </div>
                <div className="space-y-1">
                  <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                    মীমাংসা রেজিস্টার
                  </h2>
                  <div className="flex items-center gap-3">
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-500 text-white rounded-full font-bold text-[10px] shadow-sm border border-emerald-400/30">
                      <div className="h-1.5 w-1.5 rounded-full bg-white shadow-xs"></div>
                      <span>চলমান মাস: {toBengaliDigits(cycleInfo.label)}</span>
                    </div>
                    <p className="text-slate-400 font-bold text-[9px] uppercase tracking-[0.2em]">
                      Settlement Ledger
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3 relative z-10">
                <div className="relative">
                  <button
                    ref={summaryButtonRef}
                    onClick={() => setShowSummary(!showSummary)}
                    className={`px-5 py-3 rounded-xl font-black text-[12px] flex items-center gap-2 transition-all shadow-md ${showSummary ? "bg-blue-600 text-white shadow-blue-500/20" : "bg-blue-50 text-blue-700 border border-blue-100 hover:bg-blue-100 shadow-sm"}`}
                  >
                    <Sparkles
                      size={16}
                      className={
                        showSummary ? "text-blue-100" : "text-blue-500"
                      }
                    />{" "}
                    রেজিস্টার সারসংক্ষেপ
                  </button>

                  <AnimatePresence>
                    {showSummary && (
                      <div
                        ref={summaryRef}
                        className="absolute top-[calc(100%+12px)] right-0 z-[9999999]"
                      >
                        <motion.div
                          initial={{ opacity: 0, y: -10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                          transition={{
                            duration: 0.25,
                            ease: [0.23, 1, 0.32, 1],
                          }}
                          style={{
                            width: "450px",
                            maxHeight: "min(540px, 75vh)",
                          }}
                          className="bg-white rounded-[2rem] shadow-[0_40px_100px_-15px_rgba(0,0,0,0.4)] border border-slate-200 overflow-hidden no-print text-left flex flex-col"
                        >
                          <div className="bg-gradient-to-r from-emerald-700 to-teal-700 p-6 flex items-center justify-between shrink-0">
                            <div className="flex items-center gap-3 text-white">
                              <div className="w-10 h-10 bg-white/20 backdrop-blur-md rounded-xl flex items-center justify-center shadow-inner">
                                <Sparkles size={22} className="text-white" />
                              </div>
                              <div>
                                <h4 className="text-base font-black tracking-tight">
                                  রেজিস্টার সারসংক্ষেপ
                                </h4>
                                <p className="text-[10px] font-bold opacity-70 uppercase tracking-[0.2em]">
                                  Settlement Summary Overview
                                </p>
                              </div>
                            </div>
                            <button
                              onClick={() => setShowSummary(false)}
                              className="w-8 h-8 flex items-center justify-center hover:bg-white/20 rounded-full text-white transition-all duration-300"
                            >
                              <XCircle size={20} />
                            </button>
                          </div>

                          <div className="p-6 space-y-6 overflow-y-auto flex-1">
                            {/* Total Letters Card */}
                            <div className="relative overflow-hidden bg-slate-50 rounded-2xl p-5 border border-slate-200 group">
                              <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-full -mr-8 -mt-8 transition-transform group-hover:scale-150 duration-700"></div>
                              <div className="relative flex items-center justify-between">
                                <div>
                                  <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-1">
                                    সর্বমোট চিঠিপত্র
                                  </p>
                                  <h2 className="text-3xl font-black text-slate-900 tracking-tighter">
                                    {toBengaliDigits(globalStats.totalLetters)}{" "}
                                    <span className="text-sm font-bold text-slate-500">
                                      টি
                                    </span>
                                  </h2>
                                </div>
                                <Archive
                                  className="text-emerald-200"
                                  size={40}
                                />
                              </div>
                            </div>

                            {/* SFI Section */}
                            <div className="space-y-4">
                              <div className="flex items-center gap-3">
                                <div className="h-[2px] flex-1 bg-emerald-100"></div>
                                <h5 className="text-[11px] font-black text-emerald-700 uppercase tracking-[0.15em] flex items-center gap-2">
                                  <CheckCircle2 size={14} /> এসএফআই (SFI)
                                </h5>
                                <div className="h-[2px] flex-1 bg-emerald-100"></div>
                              </div>

                              <div className="grid grid-cols-2 gap-3">
                                <div className="bg-emerald-50/40 border border-emerald-100/50 rounded-xl p-3 hover:bg-emerald-50 transition-colors">
                                  <p className="text-[10px] font-bold text-emerald-600/70 uppercase mb-1">
                                    বিএসআর
                                  </p>
                                  <p className="text-base font-black text-slate-800">
                                    {toBengaliDigits(globalStats.sfi.bsr)} টি
                                  </p>
                                </div>
                                <div className="bg-emerald-50/40 border border-emerald-100/50 rounded-xl p-3 hover:bg-emerald-50 transition-colors">
                                  <p className="text-[10px] font-bold text-emerald-600/70 uppercase mb-1">
                                    ত্রিপক্ষীয় সভা
                                  </p>
                                  <p className="text-base font-black text-slate-800">
                                    {toBengaliDigits(globalStats.sfi.tri)} টি
                                  </p>
                                </div>
                              </div>
                              <div className="bg-emerald-600 text-white px-4 py-2 rounded-xl text-center">
                                <span className="text-xs font-black">
                                  মোট এসএফআই:{" "}
                                  {toBengaliDigits(globalStats.sfi.total)} টি
                                </span>
                              </div>
                            </div>

                            {/* Non-SFI Section */}
                            <div className="space-y-4">
                              <div className="flex items-center gap-3">
                                <div className="h-[2px] flex-1 bg-amber-100"></div>
                                <h5 className="text-[11px] font-black text-amber-700 uppercase tracking-[0.15em] flex items-center gap-2">
                                  <FileText size={14} /> নন এসএফআই (Non-SFI)
                                </h5>
                                <div className="h-[2px] flex-1 bg-amber-100"></div>
                              </div>

                              <div className="grid grid-cols-2 gap-3">
                                <div className="bg-amber-50/40 border border-amber-100/50 rounded-xl p-3 hover:bg-amber-50 transition-colors">
                                  <p className="text-[10px] font-bold text-amber-600/70 uppercase mb-1">
                                    বিএসআর
                                  </p>
                                  <p className="text-base font-black text-slate-800">
                                    {toBengaliDigits(globalStats.nonSfi.bsr)} টি
                                  </p>
                                </div>
                                <div className="bg-amber-50/40 border border-amber-100/50 rounded-xl p-3 hover:bg-amber-50 transition-colors">
                                  <p className="text-[10px] font-bold text-amber-600/70 uppercase mb-1">
                                    দ্বিপক্ষীয় সভা
                                  </p>
                                  <p className="text-base font-black text-slate-800">
                                    {toBengaliDigits(globalStats.nonSfi.bi)} টি
                                  </p>
                                </div>
                              </div>
                              <div className="bg-amber-600 text-white px-4 py-2 rounded-xl text-center">
                                <span className="text-xs font-black">
                                  মোট নন এসএফআই:{" "}
                                  {toBengaliDigits(globalStats.nonSfi.total)} টি
                                </span>
                              </div>
                            </div>

                            {/* Settled Paras & Amount */}
                            <div className="grid grid-cols-2 gap-4">
                              <div className="bg-emerald-50 border border-emerald-100 rounded-2xl p-4">
                                <p className="text-[10px] font-bold text-emerald-700 uppercase mb-1">
                                  মীমাংসিত অনুচ্ছেদ
                                </p>
                                <p className="text-xl font-black text-slate-900">
                                  {toBengaliDigits(globalStats.settledParas)} টি
                                </p>
                              </div>
                              <div className="bg-blue-50 border border-blue-100 rounded-2xl p-4">
                                <p className="text-[10px] font-bold text-blue-700 uppercase mb-1">
                                  মোট মীমাংসিত টাকা
                                </p>
                                <p className="text-xl font-black text-slate-900">
                                  {toBengaliDigits(
                                    Math.round(globalStats.totalSettledAmount),
                                  )}{" "}
                                  <span className="text-xs font-bold text-slate-500">
                                    টাকা
                                  </span>
                                </p>
                              </div>
                            </div>
                          </div>

                          <div className="bg-slate-900 p-4 text-center">
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.3em]">
                              Ledger Management System
                            </p>
                          </div>
                        </motion.div>
                      </div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </div>
          </div>
        )}

        {!isAdminView && (
          <div
            id="register-filters"
            className="!bg-white p-2.5 md:p-3 rounded-xl border border-slate-200 shadow-lg no-print mb-6 animate-in slide-in-from-top-4 duration-300 relative z-[1000] isolate"
          >
            <IDBadge id="register-filters" />
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7 gap-2">
              {/* Cycle / Custom Date Selection */}
              <div className="space-y-1" ref={cycleDropdownRef}>
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-tight ml-1">
                  সাইকেল / সময়কাল
                </label>
                <div
                  onClick={() => setIsCycleDropdownOpen(!isCycleDropdownOpen)}
                  className={customDropdownCls(isCycleDropdownOpen)}
                >
                  <CalendarDays size={14} className="text-blue-600 shrink-0" />
                  <span className="font-bold text-[11px] text-slate-900 truncate">
                    {isCustomDateActive && (filterStartDate || filterEndDate)
                      ? `${filterStartDate ? toBengaliDigits(format(new Date(filterStartDate), 'dd/MM/yyyy')) : ''} হতে ${filterEndDate ? toBengaliDigits(format(new Date(filterEndDate), 'dd/MM/yyyy')) : ''}`
                      : selectedCycles.length === 0
                        ? "সকল সাইকেল"
                        : selectedCycles.length === 1
                          ? cycleOptions.find((o) => o.cycleLabel === selectedCycles[0])?.label || toBengaliDigits(selectedCycles[0])
                          : `${toBengaliDigits(selectedCycles.length.toString())}টি সাইকেল`}
                  </span>
                  <ChevronDown
                    size={12}
                    className={`text-slate-400 ml-auto transition-transform duration-300 shrink-0 ${isCycleDropdownOpen ? "rotate-180 text-blue-600" : ""}`}
                  />

                  {isCycleDropdownOpen && (
                    <div className="absolute top-[calc(100%+12px)] left-0 w-[280px] sm:w-[310px] !bg-white border-2 border-slate-200 rounded-2xl shadow-[0_30px_60px_rgba(0,0,0,0.4)] z-[2000] overflow-hidden animate-in fade-in zoom-in-95 slide-in-from-top-4 duration-300 ease-out select-none">
                      <div className="p-2 border-b border-slate-100 flex items-center gap-1 bg-slate-50">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setDateTab('cycle');
                          }}
                          className={`flex-1 py-1 text-[11px] font-black rounded-lg transition-all cursor-pointer ${
                            dateTab === 'cycle'
                              ? 'bg-white text-blue-700 shadow-xs'
                              : 'text-slate-600 hover:text-slate-900'
                          }`}
                        >
                          সাইকেল তালিকা
                        </button>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setDateTab('custom');
                          }}
                          className={`flex-1 py-1 text-[11px] font-black rounded-lg transition-all cursor-pointer ${
                            dateTab === 'custom'
                              ? 'bg-white text-blue-700 shadow-xs'
                              : 'text-slate-600 hover:text-slate-900'
                          }`}
                        >
                          হতে - থেকে ডেট
                        </button>
                      </div>

                      {dateTab === 'cycle' && (
                        <div className="max-h-[320px] overflow-y-auto no-scrollbar !bg-white !bg-opacity-100 flex flex-col">
                          <div className="px-4 py-2.5 border-b border-slate-100 flex items-center justify-between sticky top-0 !bg-white !bg-opacity-100 z-[2010]">
                            <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest flex items-center gap-2">
                              <CalendarSearch size={12} /> সাইকেল নির্বাচন
                            </span>
                            {selectedCycles.length > 0 && (
                              <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
                                {toBengaliDigits(selectedCycles.length.toString())}টি
                              </span>
                            )}
                          </div>
                          <div className="p-2 space-y-1">
                            <div
                              key="all"
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedCycles([]);
                                setIsCustomDateActive(false);
                              }}
                              className={`flex items-center justify-between px-3 py-2 rounded-xl cursor-pointer transition-all !bg-opacity-100 ${selectedCycles.length === 0 && !isCustomDateActive ? "!bg-blue-600 !text-white shadow-lg font-black" : "hover:bg-slate-100 text-slate-700 font-bold bg-white"}`}
                            >
                              <span className="text-[12px]">সকল</span>
                              {selectedCycles.length === 0 && !isCustomDateActive && (
                                <Check size={14} strokeWidth={3} />
                              )}
                            </div>
                            {cycleOptions.map((opt, idx) => {
                              const isSelected = selectedCycles.includes(opt.cycleLabel) && !isCustomDateActive;
                              return (
                                <div
                                  key={idx}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setIsCustomDateActive(false);
                                    setSelectedCycles((prev) =>
                                      prev.includes(opt.cycleLabel)
                                        ? prev.filter((c) => c !== opt.cycleLabel)
                                        : [...prev, opt.cycleLabel]
                                    );
                                  }}
                                  className={`flex items-center justify-between px-3 py-2 rounded-xl cursor-pointer transition-all !bg-opacity-100 ${isSelected ? "!bg-blue-600 !text-white shadow-lg font-black" : "hover:bg-slate-100 text-slate-700 font-bold bg-white"}`}
                                >
                                  <span className="text-[12px] whitespace-nowrap">{opt.label}</span>
                                  {isSelected && (
                                    <Check size={14} strokeWidth={3} />
                                  )}
                                </div>
                              );
                            })}
                          </div>
                          <div className="p-2 border-t border-slate-100 sticky bottom-0 bg-white z-[2010]">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setIsCycleDropdownOpen(false);
                              }}
                              className="w-full py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-bold transition-colors cursor-pointer"
                            >
                              সম্পন্ন
                            </button>
                          </div>
                        </div>
                      )}

                      {dateTab === 'custom' && (
                        <div className="p-3 space-y-3 bg-white" onClick={(e) => e.stopPropagation()}>
                          <div className="text-[11px] font-black text-slate-800 flex items-center gap-1.5">
                            <CalendarDays size={13} className="text-blue-600" />
                            <span>কাংখিত সময়কাল নির্ধারণ (হতে - থেকে)</span>
                          </div>

                          <div className="space-y-2">
                            <div>
                              <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                                শুরুর তারিখ (হতে):
                              </label>
                              <div className="relative flex items-center border border-slate-300 rounded-lg px-2 py-1 bg-white focus-within:border-blue-500">
                                <input
                                  type="text"
                                  value={manualStartDate}
                                  onChange={(e) => {
                                    const val = e.target.value;
                                    setManualStartDate(val);
                                    const parsed = parseManualDate(val);
                                    if (parsed) {
                                      setFilterStartDate(format(parsed, 'yyyy-MM-dd'));
                                      setIsCustomDateActive(true);
                                    } else if (!val.trim()) {
                                      setFilterStartDate('');
                                    }
                                  }}
                                  onBlur={() => {
                                    const parsed = parseManualDate(manualStartDate);
                                    if (parsed) {
                                      setFilterStartDate(format(parsed, 'yyyy-MM-dd'));
                                      setManualStartDate(toBengaliDigits(format(parsed, 'dd/MM/yyyy')));
                                    } else if (!manualStartDate.trim()) {
                                      setFilterStartDate('');
                                      setManualStartDate('');
                                    } else if (filterStartDate) {
                                      setManualStartDate(toBengaliDigits(format(new Date(filterStartDate), 'dd/MM/yyyy')));
                                    }
                                  }}
                                  placeholder="০১/০১/২০২৬"
                                  className="w-full bg-transparent font-bold text-xs text-slate-800 outline-none p-0 border-none focus:ring-0 cursor-text"
                                  title="ক্যালেন্ডার বা ম্যানুয়ালি তারিখ লিখুন (যেমন: ০১/০১/২০২৬ বা 01/01/2026)"
                                />
                                <div className="relative shrink-0 ml-1">
                                  <input
                                    type="date"
                                    value={filterStartDate}
                                    onChange={(e) => {
                                      setFilterStartDate(e.target.value);
                                      setIsCustomDateActive(true);
                                    }}
                                    className="opacity-0 absolute inset-0 w-full h-full cursor-pointer z-10"
                                    title="ক্যালেন্ডার থেকে নির্বাচন করুন"
                                  />
                                  <Calendar size={14} className="text-blue-600 cursor-pointer" />
                                </div>
                              </div>
                            </div>
                            <div>
                              <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                                শেষের তারিখ (পর্যন্ত):
                              </label>
                              <div className="relative flex items-center border border-slate-300 rounded-lg px-2 py-1 bg-white focus-within:border-blue-500">
                                <input
                                  type="text"
                                  value={manualEndDate}
                                  onChange={(e) => {
                                    const val = e.target.value;
                                    setManualEndDate(val);
                                    const parsed = parseManualDate(val);
                                    if (parsed) {
                                      setFilterEndDate(format(parsed, 'yyyy-MM-dd'));
                                      setIsCustomDateActive(true);
                                    } else if (!val.trim()) {
                                      setFilterEndDate('');
                                    }
                                  }}
                                  onBlur={() => {
                                    const parsed = parseManualDate(manualEndDate);
                                    if (parsed) {
                                      setFilterEndDate(format(parsed, 'yyyy-MM-dd'));
                                      setManualEndDate(toBengaliDigits(format(parsed, 'dd/MM/yyyy')));
                                    } else if (!manualEndDate.trim()) {
                                      setFilterEndDate('');
                                      setManualEndDate('');
                                    } else if (filterEndDate) {
                                      setManualEndDate(toBengaliDigits(format(new Date(filterEndDate), 'dd/MM/yyyy')));
                                    }
                                  }}
                                  placeholder="৩১/০১/২০২৬"
                                  className="w-full bg-transparent font-bold text-xs text-slate-800 outline-none p-0 border-none focus:ring-0 cursor-text"
                                  title="ক্যালেন্ডার বা ম্যানুয়ালি তারিখ লিখুন (যেমন: ৩১/০১/২০২৬ বা 31/01/2026)"
                                />
                                <div className="relative shrink-0 ml-1">
                                  <input
                                    type="date"
                                    value={filterEndDate}
                                    onChange={(e) => {
                                      setFilterEndDate(e.target.value);
                                      setIsCustomDateActive(true);
                                    }}
                                    className="opacity-0 absolute inset-0 w-full h-full cursor-pointer z-10"
                                    title="ক্যালেন্ডার থেকে নির্বাচন করুন"
                                  />
                                  <Calendar size={14} className="text-blue-600 cursor-pointer" />
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Quick Presets: [ < ] [বিগত মাস] [চলতি মাস] [ > ] [গত ৩০ দিন] */}
                          <div className="flex flex-wrap items-center gap-1 pt-1 border-t border-slate-100">
                            {/* পূর্ববর্তী মাস নেভিগেশন বোতাম */}
                            <button
                              type="button"
                              onClick={() => {
                                const base = filterStartDate ? new Date(filterStartDate) : new Date();
                                const prevM = subMonths(base, 1);
                                const s = format(startOfMonth(prevM), 'yyyy-MM-dd');
                                const e = format(endOfMonth(prevM), 'yyyy-MM-dd');
                                setFilterStartDate(s);
                                setFilterEndDate(e);
                                setIsCustomDateActive(true);
                              }}
                              className="p-1 px-1.5 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-300 border border-slate-200 rounded text-slate-700 transition-colors cursor-pointer flex items-center justify-center shrink-0"
                              title="পূর্ববর্তী মাস (পেছনে যান - যতবার চাপবেন এক মাস করে পেছনে যাবে)"
                            >
                              <ChevronLeft size={12} />
                            </button>

                            {/* বিগত মাস */}
                            <button
                              type="button"
                              onClick={() => {
                                const now = new Date();
                                const s = format(startOfMonth(subMonths(now, 1)), 'yyyy-MM-dd');
                                const e = format(endOfMonth(subMonths(now, 1)), 'yyyy-MM-dd');
                                setFilterStartDate(s);
                                setFilterEndDate(e);
                                setIsCustomDateActive(true);
                              }}
                              className="px-2 py-0.5 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 border border-slate-200 rounded text-[10px] font-bold cursor-pointer"
                              title="বিগত মাস"
                            >
                              বিগত মাস
                            </button>

                            {/* চলতি মাস (বিগত মাসের ডান পাশে) */}
                            <button
                              type="button"
                              onClick={() => {
                                const now = new Date();
                                const s = format(startOfMonth(now), 'yyyy-MM-dd');
                                const e = format(endOfMonth(now), 'yyyy-MM-dd');
                                setFilterStartDate(s);
                                setFilterEndDate(e);
                                setIsCustomDateActive(true);
                              }}
                              className="px-2 py-0.5 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 border border-slate-200 rounded text-[10px] font-bold cursor-pointer"
                              title="চলতি মাস"
                            >
                              চলতি মাস
                            </button>

                            {/* পরবর্তী মাস নেভিগেশন বোতাম */}
                            <button
                              type="button"
                              onClick={() => {
                                const base = filterStartDate ? new Date(filterStartDate) : new Date();
                                const nextM = addMonths(base, 1);
                                const s = format(startOfMonth(nextM), 'yyyy-MM-dd');
                                const e = format(endOfMonth(nextM), 'yyyy-MM-dd');
                                setFilterStartDate(s);
                                setFilterEndDate(e);
                                setIsCustomDateActive(true);
                              }}
                              className="p-1 px-1.5 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-300 border border-slate-200 rounded text-slate-700 transition-colors cursor-pointer flex items-center justify-center shrink-0"
                              title="পরবর্তী মাস (সামনে যান)"
                            >
                              <ChevronRight size={12} />
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                const now = new Date();
                                const s = format(new Date(now.getTime() - 29 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd');
                                const e = format(now, 'yyyy-MM-dd');
                                setFilterStartDate(s);
                                setFilterEndDate(e);
                                setIsCustomDateActive(true);
                              }}
                              className="px-2 py-0.5 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 border border-slate-200 rounded text-[10px] font-bold cursor-pointer"
                            >
                              গত ৩০ দিন
                            </button>
                          </div>

                          <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-100">
                            <button
                              type="button"
                              onClick={() => {
                                setFilterStartDate("");
                                setFilterEndDate("");
                                setIsCustomDateActive(false);
                              }}
                              className="px-2.5 py-1 text-slate-500 hover:text-rose-600 rounded text-xs font-bold cursor-pointer"
                            >
                              মুছুন
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setIsCustomDateActive(true);
                                setIsCycleDropdownOpen(false);
                              }}
                              className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-black shadow-xs cursor-pointer"
                            >
                              প্রয়োগ করুন
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Branch Selection */}
              <div className="space-y-1" ref={branchDropdownRef}>
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-tight ml-1">
                  শাখা ধরণ
                </label>
                <div
                  onClick={() => setIsBranchDropdownOpen(!isBranchDropdownOpen)}
                  className={customDropdownCls(isBranchDropdownOpen)}
                >
                  <LayoutGrid className="text-blue-600 shrink-0" size={14} />
                  <span className="font-bold text-[11px] text-slate-900 truncate">
                    {filterParaType === "" ? "সকল শাখা" : filterParaType}
                  </span>
                  <ChevronDown
                    size={12}
                    className={`text-slate-400 ml-auto transition-transform duration-300 shrink-0 ${isBranchDropdownOpen ? "rotate-180 text-blue-600" : ""}`}
                  />

                  {isBranchDropdownOpen && (
                    <div className="absolute top-[calc(100%+12px)] left-0 w-full min-w-[220px] !bg-white border-2 border-slate-200 rounded-2xl shadow-[0_30px_60px_rgba(0,0,0,0.4)] z-[2000] overflow-hidden animate-in fade-in zoom-in-95 slide-in-from-top-4 duration-300 ease-out">
                      <div className="max-h-[320px] overflow-y-auto no-scrollbar !bg-white !bg-opacity-100 flex flex-col">
                        <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-center sticky top-0 !bg-white !bg-opacity-100 z-[2010]">
                          <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest flex items-center gap-2">
                            <LayoutGrid size={12} /> শাখা ধরণ নির্বাচন
                          </span>
                        </div>
                        <div className="p-2 space-y-1">
                          {[
                            { val: "", label: "সকল শাখা" },
                            { val: "এসএফআই", label: "এসএফআই" },
                            { val: "নন এসএফআই", label: "নন এসএফআই" },
                          ].map((opt, idx) => (
                            <div
                              key={idx}
                              onClick={(e) => {
                                e.stopPropagation();
                                setFilterParaType(opt.val);
                                setFilterType("");
                                setIsBranchDropdownOpen(false);
                              }}
                              className={`flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl cursor-pointer transition-all !bg-opacity-100 ${filterParaType === opt.val ? "!bg-blue-600 !text-white shadow-lg" : "hover:bg-slate-100 text-slate-700 font-bold bg-white"}`}
                            >
                              <span className="text-[13px]">{opt.label}</span>
                              {filterParaType === opt.val && (
                                <Check size={16} strokeWidth={3} />
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Letter Type Selection */}
              <div className="space-y-1" ref={typeDropdownRef}>
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-tight ml-1">
                  চিঠির ধরণ
                </label>
                <div
                  onClick={() => setIsTypeDropdownOpen(!isTypeDropdownOpen)}
                  className={customDropdownCls(isTypeDropdownOpen)}
                >
                  <FileText className="text-blue-600 shrink-0" size={14} />
                  <span className="font-bold text-[11px] text-slate-900 truncate">
                    {filterType === ""
                      ? "সকল ধরণ"
                      : filterType === "বিএসআর"
                        ? "বিএসআর (BSR)"
                        : filterType}
                  </span>
                  <ChevronDown
                    size={12}
                    className={`text-slate-400 ml-auto transition-transform duration-300 shrink-0 ${isTypeDropdownOpen ? "rotate-180 text-blue-600" : ""}`}
                  />

                  {isTypeDropdownOpen && (
                    <div className="absolute top-[calc(100%+12px)] right-0 w-full min-w-[220px] !bg-white border-2 border-slate-200 rounded-2xl shadow-[0_30px_60px_rgba(0,0,0,0.4)] z-[2000] overflow-hidden animate-in fade-in zoom-in-95 slide-in-from-top-4 duration-300 ease-out">
                      <div className="max-h-[320px] overflow-y-auto no-scrollbar !bg-white !bg-opacity-100 flex flex-col">
                        <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-center sticky top-0 !bg-white !bg-opacity-100 z-[2010]">
                          <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest flex items-center gap-2">
                            <FileText size={12} /> ধরণ নির্বাচন
                          </span>
                        </div>
                        <div className="p-2 space-y-1">
                          {[
                            { val: "", label: "সকল ধরণ", show: true },
                            {
                              val: "বিএসআর",
                              label: "বিএসআর (BSR)",
                              show: true,
                            },
                            {
                              val: "ত্রিপক্ষীয় সভা",
                              label: "ত্রিপক্ষীয় সভা",
                              show:
                                filterParaType === "এসএফআই" ||
                                filterParaType === "",
                            },
                            {
                              val: "দ্বিপক্ষীয় সভা",
                              label: "দ্বিপক্ষীয় সভা",
                              show:
                                filterParaType === "নন এসএফআই" ||
                                filterParaType === "",
                            },
                          ]
                            .filter((o) => o.show)
                            .map((opt, idx) => (
                              <div
                                key={idx}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setFilterType(opt.val);
                                  setIsTypeDropdownOpen(false);
                                }}
                                className={`flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl cursor-pointer transition-all !bg-opacity-100 ${filterType === opt.val ? "!bg-blue-600 !text-white shadow-lg" : "hover:bg-slate-100 text-slate-700 font-bold bg-white"}`}
                              >
                                <span className="text-[13px]">{opt.label}</span>
                                {filterType === opt.val && (
                                  <Check size={16} strokeWidth={3} />
                                )}
                              </div>
                            ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Status Selection */}
              <div className="space-y-1" ref={statusDropdownRef}>
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-tight ml-1">
                  অবস্থা
                </label>
                <div
                  onClick={() => setIsStatusDropdownOpen(!isStatusDropdownOpen)}
                  className={customDropdownCls(isStatusDropdownOpen)}
                >
                  <CheckCircle2 className="text-blue-600 shrink-0" size={14} />
                  <span className="font-bold text-[11px] text-slate-900 truncate">
                    {filterStatus === ""
                      ? "সকল অবস্থা"
                      : filterStatus === "settled"
                        ? "পূর্ণাঙ্গ নিষ্পত্তি"
                        : filterStatus === "no-paras"
                          ? "উত্থাপিত (অনুচ্ছেদ নেই)"
                          : "আংশিক/অনিষ্পত্তি"}
                  </span>
                  <ChevronDown
                    size={12}
                    className={`text-slate-400 ml-auto transition-transform duration-300 shrink-0 ${isStatusDropdownOpen ? "rotate-180 text-blue-600" : ""}`}
                  />

                  {isStatusDropdownOpen && (
                    <div className="absolute top-[calc(100%+12px)] right-0 w-full min-w-[220px] !bg-white border-2 border-slate-200 rounded-2xl shadow-[0_30px_60px_rgba(0,0,0,0.4)] z-[2000] overflow-hidden animate-in fade-in zoom-in-95 slide-in-from-top-4 duration-300 ease-out">
                      <div className="max-h-[320px] overflow-y-auto no-scrollbar !bg-white !bg-opacity-100 flex flex-col">
                        <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-center sticky top-0 !bg-white !bg-opacity-100 z-[2010]">
                          <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest flex items-center gap-2">
                            <CheckCircle2 size={12} /> অবস্থা নির্বাচন
                          </span>
                        </div>
                        <div className="p-2 space-y-1">
                          {[
                            { val: "", label: "সকল অবস্থা" },
                            { val: "settled", label: "পূর্ণাঙ্গ নিষ্পত্তি" },
                            { val: "unsettled", label: "আংশিক/অনিষ্পত্তি" },
                            {
                              val: "no-paras",
                              label: "উত্থাপিত (অনুচ্ছেদ নেই)",
                            },
                          ].map((opt, idx) => (
                            <div
                              key={idx}
                              onClick={(e) => {
                                e.stopPropagation();
                                setFilterStatus(opt.val);
                                setIsStatusDropdownOpen(false);
                              }}
                              className={`flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl cursor-pointer transition-all !bg-opacity-100 ${filterStatus === opt.val ? "!bg-blue-600 !text-white shadow-lg" : "hover:bg-slate-100 text-slate-700 font-bold bg-white"}`}
                            >
                              <span className="text-[13px]">{opt.label}</span>
                              {filterStatus === opt.val && (
                                <Check size={16} strokeWidth={3} />
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Ministry Selection */}
              <div className="space-y-1" ref={ministryDropdownRef}>
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-tight ml-1">
                  মন্ত্রণালয়
                </label>
                <div
                  onClick={() => setIsMinistryDropdownOpen(!isMinistryDropdownOpen)}
                  className={customDropdownCls(isMinistryDropdownOpen)}
                >
                  <Building2 className="text-blue-600 shrink-0" size={14} />
                  <span className="font-bold text-[11px] text-slate-900 truncate">
                    {filterMinistries.length === 0
                      ? "সকল মন্ত্রণালয়"
                      : filterMinistries.length === 1
                        ? filterMinistries[0]
                        : `${toBengaliDigits(filterMinistries.length.toString())}টি মন্ত্রণালয়`}
                  </span>
                  <ChevronDown
                    size={12}
                    className={`text-slate-400 ml-auto transition-transform duration-300 shrink-0 ${isMinistryDropdownOpen ? "rotate-180 text-blue-600" : ""}`}
                  />

                  {isMinistryDropdownOpen && (
                    <div className="absolute top-[calc(100%+12px)] left-0 w-full min-w-[220px] !bg-white border-2 border-slate-200 rounded-2xl shadow-[0_30px_60px_rgba(0,0,0,0.4)] z-[2000] overflow-hidden animate-in fade-in zoom-in-95 slide-in-from-top-4 duration-300 ease-out">
                      <div className="max-h-[320px] overflow-y-auto no-scrollbar !bg-white !bg-opacity-100 flex flex-col">
                        <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between sticky top-0 !bg-white !bg-opacity-100 z-[2010]">
                          <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest flex items-center gap-2">
                            <Building2 size={12} /> মন্ত্রণালয় নির্বাচন
                          </span>
                          {filterMinistries.length > 0 && (
                            <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
                              {toBengaliDigits(filterMinistries.length.toString())}টি
                            </span>
                          )}
                        </div>
                        <div className="p-2 space-y-1">
                          <div
                            onClick={(e) => {
                              e.stopPropagation();
                              setFilterMinistries([]);
                            }}
                            className={`flex items-center justify-between px-3 py-2 rounded-xl cursor-pointer transition-all !bg-opacity-100 ${filterMinistries.length === 0 ? "!bg-blue-600 !text-white shadow-lg font-black" : "hover:bg-slate-100 text-slate-700 font-bold bg-white"}`}
                          >
                            <span className="text-[12px] truncate">সকল মন্ত্রণালয়</span>
                            {filterMinistries.length === 0 && (
                              <Check size={14} strokeWidth={3} />
                            )}
                          </div>
                          {ministryOptions.map((m, idx) => {
                            const isSelected = filterMinistries.includes(m);
                            return (
                              <div
                                key={idx}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setFilterMinistries((prev) =>
                                    prev.includes(m)
                                      ? prev.filter((x) => x !== m)
                                      : [...prev, m]
                                  );
                                }}
                                className={`flex items-center justify-between px-3 py-2 rounded-xl cursor-pointer transition-all !bg-opacity-100 ${isSelected ? "!bg-blue-600 !text-white shadow-lg font-black" : "hover:bg-slate-100 text-slate-700 font-bold bg-white"}`}
                              >
                                <span className="text-[12px] truncate">{m}</span>
                                {isSelected && (
                                  <Check size={14} strokeWidth={3} />
                                )}
                              </div>
                            );
                          })}
                        </div>
                        <div className="p-2 border-t border-slate-100 sticky bottom-0 bg-white z-[2010]">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setIsMinistryDropdownOpen(false);
                            }}
                            className="w-full py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-bold transition-colors cursor-pointer"
                          >
                            সম্পন্ন
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Entity Selection */}
              <div className="space-y-1" ref={entityDropdownRef}>
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-tight ml-1">
                  সংস্থা
                </label>
                <div
                  onClick={() => setIsEntityDropdownOpen(!isEntityDropdownOpen)}
                  className={customDropdownCls(isEntityDropdownOpen)}
                >
                  <Landmark className="text-blue-600 shrink-0" size={14} />
                  <span className="font-bold text-[11px] text-slate-900 truncate">
                    {filterEntities.length === 0
                      ? "সকল সংস্থা"
                      : filterEntities.length === 1
                        ? filterEntities[0]
                        : `${toBengaliDigits(filterEntities.length.toString())}টি সংস্থা`}
                  </span>
                  <ChevronDown
                    size={12}
                    className={`text-slate-400 ml-auto transition-transform duration-300 shrink-0 ${isEntityDropdownOpen ? "rotate-180 text-blue-600" : ""}`}
                  />

                  {isEntityDropdownOpen && (
                    <div className="absolute top-[calc(100%+12px)] right-0 w-full min-w-[240px] !bg-white border-2 border-slate-200 rounded-2xl shadow-[0_30px_60px_rgba(0,0,0,0.4)] z-[2000] overflow-hidden animate-in fade-in zoom-in-95 slide-in-from-top-4 duration-300 ease-out">
                      <div className="max-h-[320px] overflow-y-auto no-scrollbar !bg-white !bg-opacity-100 flex flex-col">
                        <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between sticky top-0 !bg-white !bg-opacity-100 z-[2010]">
                          <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest flex items-center gap-2">
                            <Landmark size={12} /> সংস্থা নির্বাচন
                          </span>
                          {filterEntities.length > 0 && (
                            <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
                              {toBengaliDigits(filterEntities.length.toString())}টি
                            </span>
                          )}
                        </div>
                        <div className="p-2 space-y-1">
                          <div
                            onClick={(e) => {
                              e.stopPropagation();
                              setFilterEntities([]);
                            }}
                            className={`flex items-center justify-between px-3 py-2 rounded-xl cursor-pointer transition-all !bg-opacity-100 ${filterEntities.length === 0 ? "!bg-blue-600 !text-white shadow-lg font-black" : "hover:bg-slate-100 text-slate-700 font-bold bg-white"}`}
                          >
                            <span className="text-[12px] truncate">সকল সংস্থা</span>
                            {filterEntities.length === 0 && (
                              <Check size={14} strokeWidth={3} />
                            )}
                          </div>
                          {entityOptions.map((ent, idx) => {
                            const isSelected = filterEntities.includes(ent);
                            return (
                              <div
                                key={idx}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setFilterEntities((prev) =>
                                    prev.includes(ent)
                                      ? prev.filter((x) => x !== ent)
                                      : [...prev, ent]
                                  );
                                }}
                                className={`flex items-center justify-between px-3 py-2 rounded-xl cursor-pointer transition-all !bg-opacity-100 ${isSelected ? "!bg-blue-600 !text-white shadow-lg font-black" : "hover:bg-slate-100 text-slate-700 font-bold bg-white"}`}
                              >
                                <span className="text-[12px] truncate">{ent}</span>
                                {isSelected && (
                                  <Check size={14} strokeWidth={3} />
                                )}
                              </div>
                            );
                          })}
                        </div>
                        <div className="p-2 border-t border-slate-100 sticky bottom-0 bg-white z-[2010]">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setIsEntityDropdownOpen(false);
                            }}
                            className="w-full py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-bold transition-colors cursor-pointer"
                          >
                            সম্পন্ন
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Search Input */}
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-tight ml-1">
                  অনুসন্ধান
                </label>
                <div className="relative">
                  <Search
                    className="absolute left-2 top-1/2 -translate-y-1/2 text-blue-600"
                    size={12}
                  />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="জারিপত্র নং..."
                    className={filterInputCls}
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {!showCycleHeaders && (
          <div className="flex justify-end mb-4 no-print animate-in fade-in slide-in-from-top-2 duration-300">
            <button
              onClick={() => setShowCycleHeaders(true)}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-50 to-indigo-50 hover:from-blue-100 hover:to-indigo-100 border border-blue-200 hover:border-blue-300 text-blue-700 rounded-xl font-black text-[11px] transition-all shadow-sm cursor-pointer select-none group"
              title="সময়কাল অপশনটি পুনরায় দেখান"
            >
              <Eye size={14} className="animate-pulse text-blue-600 group-hover:scale-110 transition-transform" />
              <span>সময়কাল অপশনটি পুনরায় দেখান</span>
            </button>
          </div>
        )}

        <div id="settlement-register-table-container" className="table-container border border-slate-300 rounded-sm relative z-[1]">
          <IDBadge id="table-main-ledger" />
          <table
            id="table-main-ledger"
            ref={tableRef}
            className="w-full border-separate border-spacing-0"
          >
            <colgroup>
              <col className="w-[30px]" />
              <col className="w-[140px]" />
              <col className="w-[45px]" />
              <col className="w-[65px]" />
              <col className="w-[40px]" />
              <col className="w-[65px]" />
              <col className="w-[50px]" />
              <col className="w-[50px]" />
              <col className="w-[50px]" />
              <col className="w-[50px]" />
              <col className="w-[50px]" />
              <col className="w-[50px]" />
              <col className="w-[50px]" />
              <col className="w-[50px]" />
            </colgroup>
            <thead className="sticky top-0 z-[120] bg-slate-200 shadow-sm">
              <tr className="h-[42px]">
                <th rowSpan={2} className={thBase}>
                  ক্র: নং-
                </th>
                <th rowSpan={2} className={thBase}>
                  বিস্তারিত বিবরণ (২০ ফিল্ড)
                </th>
                <th rowSpan={2} className={thBase}>
                  অনু: নং-
                </th>
                <th rowSpan={2} className={thBase}>
                  জড়িত টাকা
                </th>
                <th colSpan={2} className={thBase}>
                  উত্থাপিত আপত্তি
                </th>
                <th colSpan={2} className={thBase}>
                  ভ্যাট
                </th>
                <th colSpan={2} className={thBase}>
                  আয়কর
                </th>
                <th colSpan={2} className={thBase}>
                  অন্যান্য
                </th>
                <th colSpan={2} className={thBase}>
                  মোট মীমাংসিত
                </th>
              </tr>
              <tr className="h-[38px]">
                <th className={thBase2}>সংখ্যা</th>
                <th className={thBase2}>টাকা</th>
                <th className={thBase2}>আদায়</th>
                <th className={thBase2}>সমন্বয়</th>
                <th className={thBase2}>আদায়</th>
                <th className={thBase2}>সমন্বয়</th>
                <th className={thBase2}>আদায়</th>
                <th className={thBase2}>সমন্বয়</th>
                <th className={thBase2}>আদায়</th>
                <th className={thBase2}>সমন্বয়</th>
              </tr>
              <tr className="h-[24px]">
                <th className={thBase3}>১</th>
                <th className={thBase3}>২</th>
                <th className={thBase3}>৩</th>
                <th className={thBase3}>৪</th>
                <th className={thBase3}>৫</th>
                <th className={thBase3}>৬</th>
                <th className={thBase3}>৭</th>
                <th className={thBase3}>৮</th>
                <th className={thBase3}>৯</th>
                <th className={thBase3}>১০</th>
                <th className={thBase3}>১১</th>
                <th className={thBase3}>১২</th>
                <th className={thBase3}>১৩</th>
                <th className={thBase3}>১৪</th>
              </tr>
            </thead>
            {groupedEntries.length > 0 ? (
              groupedEntries.map((group) => {
                const stats = cycleStats[group.label];
                return (
                  <tbody key={group.label}>
                    {/* Sticky Cycle Header */}
                    {showCycleHeaders && (
                      <tr className="settlement-cycle-header no-print">
                        <td
                          colSpan={14}
                          className="sticky top-[102px] z-[115] p-0 border border-slate-300 bg-slate-100"
                          style={{ position: "sticky", top: "102px", zIndex: 115 }}
                        >
                          <div
                            ref={(el) => {
                              cycleRefs.current[group.label] = el;
                            }}
                            onClick={() => {
                              setIsCycleStatsExpanded((prev) => !prev);
                            }}
                            className="bg-slate-100 border-b border-slate-300 px-4 py-2 flex items-center justify-between cursor-pointer hover:bg-blue-50 transition-all group/cycle-header shadow-sm"
                          >
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 bg-blue-600 text-white rounded-lg flex items-center justify-center shadow-md group-hover/cycle-header:scale-110 transition-transform">
                                <CalendarDays size={18} />
                              </div>
                              <div className="flex flex-col">
                                <span className="font-black text-[13px] text-slate-800 tracking-tight uppercase">
                                  সময়কাল:{" "}
                                  <span className="text-blue-700 font-black">
                                    {toBengaliDigits(group.label)}
                                  </span>
                                </span>
                                <div className="flex items-center gap-2">
                                  <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">
                                    Cycle Statistics
                                  </span>
                                  <div className="h-1 w-1 bg-slate-300 rounded-full"></div>
                                  <span className="text-[9px] font-black text-blue-600">
                                    মোট {toBengaliDigits(stats.totalLetters)} টি
                                    চিঠি
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center gap-3">
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setShowCycleHeaders(false);
                                }}
                                className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all active:scale-95 border border-transparent hover:border-red-200 flex items-center justify-center"
                                title="সময়কাল অপশনটি লুকান"
                              >
                                <EyeOff size={15} />
                              </button>
                              <div
                                className={`px-3 py-1 rounded-full text-[10px] font-black transition-all flex items-center gap-1.5 ${isCycleStatsExpanded ? "bg-blue-600 text-white shadow-lg shadow-blue-200" : "bg-white text-blue-600 border border-blue-200 hover:border-blue-400"}`}
                              >
                                {isCycleStatsExpanded
                                  ? "সংক্ষিপ্ত করুন"
                                  : "বিস্তারিত দেখুন"}
                                <ChevronDown
                                  size={12}
                                  className={`transition-transform duration-300 ${isCycleStatsExpanded ? "rotate-180" : ""}`}
                                />
                              </div>
                            </div>
                          </div>

                          {isCycleStatsExpanded && (
                            <div className="bg-white p-4 border-b border-slate-300 shadow-md animate-in fade-in slide-in-from-top-4 duration-500 ease-out">
                              <div className="flex flex-col gap-2.5">
                                {/* Row 1: SFI Branch Info */}
                                <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
                                  <div className="w-full md:w-[140px] shrink-0 h-[42px] px-3.5 bg-emerald-600 text-white rounded-xl shadow-sm flex items-center justify-center gap-1.5 text-[12px] font-black">
                                    <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                                    <span>এসএফআই শাখা</span>
                                  </div>

                                  {/* SFI Letters Card */}
                                  <div className="w-full md:w-[260px] shrink-0 h-[42px] flex items-center gap-2 px-3.5 bg-emerald-50/70 hover:bg-emerald-50/95 border-2 border-emerald-300/80 hover:border-emerald-500 rounded-xl transition-all duration-300 hover:shadow-[0_0_16px_rgba(16,185,129,0.22)] hover:-translate-y-0.5 cursor-default text-[12px] font-black">
                                    <span className="text-emerald-900 shrink-0">চিঠি:</span>
                                    <span className="text-white bg-emerald-600 px-2 py-0.5 rounded-lg text-[11px] font-black shadow-sm shrink-0">
                                      {toBengaliDigits(stats.sfiEntries.length)} টি
                                    </span>
                                    <span className="text-emerald-800/80 text-[11px] font-bold truncate">
                                      (বিএসআর {toBengaliDigits(stats.sfiBSR)}, সভা {toBengaliDigits(stats.sfiTri)})
                                    </span>
                                  </div>

                                  {/* SFI Settled Paragraphs Card */}
                                  <div
                                    onClick={() => {
                                      setSettledDetailsModalData({
                                        isOpen: true,
                                        branchType: "এসএফআই শাখা",
                                        cycleLabel: group.label,
                                        totalCount: stats.sfiSettled?.total || 0,
                                        ministries: stats.sfiSettled?.ministries || [],
                                      });
                                    }}
                                    className="flex-1 min-w-0 h-[42px] flex items-center justify-between gap-2 px-3.5 bg-emerald-50/70 hover:bg-emerald-100/90 border-2 border-emerald-300/80 hover:border-emerald-500 rounded-xl transition-all duration-300 hover:shadow-[0_0_16px_rgba(16,185,129,0.25)] hover:-translate-y-0.5 cursor-pointer text-[11px] font-black group/sfi-settled"
                                    title="মন্ত্রণালয় ও প্রতিষ্ঠানভিত্তিক বিস্তারিত দেখতে ক্লিক করুন"
                                  >
                                    <div className="flex items-center gap-2 min-w-0 flex-1 overflow-hidden">
                                      <CheckCircle2 size={15} className="text-emerald-600 shrink-0 group-hover/sfi-settled:scale-110 transition-transform" />
                                      <span className="text-emerald-900 shrink-0">মীমাংসিত অনুচ্ছেদ:</span>
                                      <span className="text-white bg-emerald-600 px-2 py-0.5 rounded-lg text-[11px] font-black shadow-sm shrink-0">
                                        {toBengaliDigits(stats.sfiSettled.total)} টি
                                      </span>
                                      {stats.sfiSettled.details && (
                                        <span className="text-emerald-800/80 font-bold text-[11px] truncate" title={stats.sfiSettled.details}>
                                          ({stats.sfiSettled.details})
                                        </span>
                                      )}
                                    </div>
                                    <span className="shrink-0 text-[10px] font-black bg-emerald-100 text-emerald-900 group-hover/sfi-settled:bg-emerald-700 group-hover/sfi-settled:text-white px-2.5 py-1 rounded-lg border border-emerald-300 group-hover/sfi-settled:border-emerald-700 transition-all flex items-center gap-1.5 shadow-2xs">
                                      <Eye size={12} className="text-emerald-700 group-hover/sfi-settled:text-white transition-colors" />
                                      <span className="font-black text-emerald-900 group-hover/sfi-settled:text-white transition-colors">মন্ত্রণালয় ও বিস্তারিত</span>
                                    </span>
                                  </div>

                                  {/* SFI Settled Total Amount */}
                                  <div className="w-full md:w-[240px] shrink-0 h-[42px] flex items-center justify-between gap-2 px-3.5 bg-emerald-50/70 hover:bg-emerald-50/95 border-2 border-emerald-300/80 hover:border-emerald-500 rounded-xl transition-all duration-300 hover:shadow-[0_0_16px_rgba(16,185,129,0.22)] hover:-translate-y-0.5 cursor-default text-[12px] font-black">
                                    <div className="flex items-center gap-2 shrink-0">
                                      <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse shadow-sm shadow-emerald-400 shrink-0"></div>
                                      <span className="text-emerald-900 shrink-0">মোট টাকা:</span>
                                    </div>
                                    <span className="text-emerald-700 bg-emerald-100/80 px-2.5 py-0.5 rounded-lg font-black text-[12px] border border-emerald-200 shrink-0">
                                      {toBengaliDigits(Math.round(stats.sfiSettledAmount))} টাকা
                                    </span>
                                  </div>
                                </div>

                                {/* Row 2: Non-SFI Branch Info */}
                                <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
                                  <div className="w-full md:w-[140px] shrink-0 h-[42px] px-3.5 bg-amber-600 text-white rounded-xl shadow-sm flex items-center justify-center gap-1.5 text-[12px] font-black">
                                    <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                                    <span>নন এসএফআই শাখা</span>
                                  </div>

                                  {/* Non-SFI Letters Card */}
                                  <div className="w-full md:w-[260px] shrink-0 h-[42px] flex items-center gap-2 px-3.5 bg-amber-50/70 hover:bg-amber-50/95 border-2 border-amber-300/80 hover:border-amber-500 rounded-xl transition-all duration-300 hover:shadow-[0_0_16px_rgba(245,158,11,0.22)] hover:-translate-y-0.5 cursor-default text-[12px] font-black">
                                    <span className="text-amber-900 shrink-0">চিঠি:</span>
                                    <span className="text-white bg-amber-600 px-2 py-0.5 rounded-lg text-[11px] font-black shadow-sm shrink-0">
                                      {toBengaliDigits(stats.nonSfiEntries.length)} টি
                                    </span>
                                    <span className="text-amber-800/80 text-[11px] font-bold truncate">
                                      (বিএসআর {toBengaliDigits(stats.nonSfiBSR)}, সভা {toBengaliDigits(stats.nonSfiBi)})
                                    </span>
                                  </div>

                                  {/* Non-SFI Settled Paragraphs Card */}
                                  <div
                                    onClick={() => {
                                      setSettledDetailsModalData({
                                        isOpen: true,
                                        branchType: "নন এসএফআই শাখা",
                                        cycleLabel: group.label,
                                        totalCount: stats.nonSfiSettled?.total || 0,
                                        ministries: stats.nonSfiSettled?.ministries || [],
                                      });
                                    }}
                                    className="flex-1 min-w-0 h-[42px] flex items-center justify-between gap-2 px-3.5 bg-amber-50/70 hover:bg-amber-100/90 border-2 border-amber-300/80 hover:border-amber-500 rounded-xl transition-all duration-300 hover:shadow-[0_0_16px_rgba(245,158,11,0.25)] hover:-translate-y-0.5 cursor-pointer text-[11px] font-black group/nonsfi-settled"
                                    title="মন্ত্রণালয় ও প্রতিষ্ঠানভিত্তিক বিস্তারিত দেখতে ক্লিক করুন"
                                  >
                                    <div className="flex items-center gap-2 min-w-0 flex-1 overflow-hidden">
                                      <CheckCircle2 size={15} className="text-amber-600 shrink-0 group-hover/nonsfi-settled:scale-110 transition-transform" />
                                      <span className="text-amber-900 shrink-0">মীমাংসিত অনুচ্ছেদ:</span>
                                      <span className="text-white bg-amber-600 px-2 py-0.5 rounded-lg text-[11px] font-black shadow-sm shrink-0">
                                        {toBengaliDigits(stats.nonSfiSettled.total)} টি
                                      </span>
                                      {stats.nonSfiSettled.details && (
                                        <span className="text-amber-800/80 font-bold text-[11px] truncate" title={stats.nonSfiSettled.details}>
                                          ({stats.nonSfiSettled.details})
                                        </span>
                                      )}
                                    </div>
                                    <span className="shrink-0 text-[10px] font-black bg-amber-100 text-amber-950 group-hover/nonsfi-settled:bg-amber-700 group-hover/nonsfi-settled:text-white px-2.5 py-1 rounded-lg border border-amber-300 group-hover/nonsfi-settled:border-amber-700 transition-all flex items-center gap-1.5 shadow-2xs">
                                      <Eye size={12} className="text-amber-700 group-hover/nonsfi-settled:text-white transition-colors" />
                                      <span className="font-black text-amber-950 group-hover/nonsfi-settled:text-white transition-colors">মন্ত্রণালয় ও বিস্তারিত</span>
                                    </span>
                                  </div>

                                  {/* Non-SFI Settled Total Amount */}
                                  <div className="w-full md:w-[240px] shrink-0 h-[42px] flex items-center justify-between gap-2 px-3.5 bg-amber-50/70 hover:bg-amber-50/95 border-2 border-amber-300/80 hover:border-amber-500 rounded-xl transition-all duration-300 hover:shadow-[0_0_16px_rgba(245,158,11,0.22)] hover:-translate-y-0.5 cursor-default text-[12px] font-black">
                                    <div className="flex items-center gap-2 shrink-0">
                                      <div className="w-2.5 h-2.5 bg-amber-500 rounded-full animate-pulse shadow-sm shadow-amber-400 shrink-0"></div>
                                      <span className="text-amber-900 shrink-0">মোট টাকা:</span>
                                    </div>
                                    <span className="text-amber-700 bg-amber-100/80 px-2.5 py-0.5 rounded-lg font-black text-[12px] border border-amber-200 shrink-0">
                                      {toBengaliDigits(Math.round(stats.nonSfiSettledAmount))} টাকা
                                    </span>
                                  </div>
                                </div>

                                {/* Row 3: Grand Total Info */}
                                <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3 pt-1 border-t border-slate-200/80">
                                  <div className="w-full md:w-[140px] shrink-0 h-[42px] px-3.5 bg-slate-800 text-white rounded-xl shadow-sm flex items-center justify-center gap-1.5 text-[12px] font-black">
                                    <BarChart3 size={14} className="text-blue-400 shrink-0" />
                                    <span>সর্বমোট</span>
                                  </div>

                                  {/* Total Letters Card */}
                                  <div className="w-full md:w-[260px] shrink-0 h-[42px] flex items-center justify-between gap-2 px-3.5 bg-slate-50 border-2 border-slate-300 rounded-xl shadow-sm text-slate-800 text-[12px] font-bold">
                                    <span>মোট চিঠি:</span>
                                    <span className="text-blue-700 font-black text-[12px] bg-blue-50 px-2.5 py-0.5 rounded-lg border border-blue-100 shrink-0">
                                      {toBengaliDigits(stats.totalLetters)} টি
                                    </span>
                                  </div>

                                  {/* Total Settled Paragraphs Card */}
                                  <div
                                    onClick={() => {
                                      setSettledDetailsModalData({
                                        isOpen: true,
                                        branchType: filterStatus === "unsettled" ? "সর্বমোট আংশিক (এসএফআই ও নন এসএফআই শাখা)" : "সর্বমোট (এসএফআই ও নন এসএফআই শাখা)",
                                        cycleLabel: group.label,
                                        totalCount: stats.cycleSettledParasCount,
                                        ministries: stats.allSettled?.ministries || [],
                                      });
                                    }}
                                    className="flex-1 min-w-0 h-[42px] flex items-center justify-between gap-2 px-3.5 bg-slate-50 hover:bg-blue-50/80 border-2 border-slate-300 hover:border-blue-400 rounded-xl shadow-sm hover:shadow-[0_0_16px_rgba(59,130,246,0.2)] hover:-translate-y-0.5 transition-all duration-300 text-[12px] font-bold text-slate-800 cursor-pointer group/total-settled"
                                    title="মন্ত্রণালয় ও প্রতিষ্ঠানভিত্তিক সর্বমোট বিস্তারিত দেখতে ক্লিক করুন"
                                  >
                                    <div className="flex items-center gap-1.5 shrink-0">
                                      <CheckCircle2 size={15} className="text-emerald-600 shrink-0 group-hover/total-settled:scale-110 transition-transform" />
                                      <span>{filterStatus === "unsettled" ? "সর্বমোট আংশিক অনুচ্ছেদ:" : "সর্বমোট মীমাংসিত অনুচ্ছেদ:"}</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <span className="text-emerald-700 bg-emerald-100/80 px-2.5 py-0.5 rounded-lg font-black text-[12px] border border-emerald-200 shrink-0">
                                        {toBengaliDigits(stats.cycleSettledParasCount)} টি
                                      </span>
                                      <span className="shrink-0 text-[10px] font-black bg-blue-100 text-blue-950 group-hover/total-settled:bg-blue-700 group-hover/total-settled:text-white px-2.5 py-1 rounded-lg border border-blue-300 group-hover/total-settled:border-blue-700 transition-all flex items-center gap-1.5 shadow-2xs">
                                        <Eye size={12} className="text-blue-700 group-hover/total-settled:text-white transition-colors" />
                                        <span className="font-black text-blue-950 group-hover/total-settled:text-white transition-colors">মন্ত্রণালয় ও বিস্তারিত</span>
                                      </span>
                                    </div>
                                  </div>

                                  {/* Grand Total Settled Money */}
                                  <div className="w-full md:w-[240px] shrink-0 h-[42px] flex items-center justify-between gap-2 px-3.5 bg-blue-50/80 hover:bg-blue-50 border-2 border-blue-300/80 hover:border-blue-400 rounded-xl transition-all duration-300 hover:shadow-[0_0_16px_rgba(59,130,246,0.22)] hover:-translate-y-0.5 cursor-default text-[12px] font-black">
                                    <div className="flex items-center gap-2 shrink-0">
                                      <div className="w-2.5 h-2.5 bg-blue-500 rounded-full animate-pulse shadow-sm shadow-blue-400 shrink-0"></div>
                                      <span className="text-blue-900 shrink-0">সর্বমোট টাকা:</span>
                                    </div>
                                    <span className="text-blue-700 bg-blue-100/80 px-2.5 py-0.5 rounded-lg font-black text-[12px] border border-blue-200 shrink-0">
                                      {toBengaliDigits(Math.round(stats.sfiSettledAmount + stats.nonSfiSettledAmount))} টাকা
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}
                        </td>
                      </tr>
                    )}

                    {/* Print-only cycle header */}
                    <tr className="hidden print:table-row bg-slate-100 border-y border-slate-300">
                      <td
                        colSpan={14}
                        className="px-4 py-2 border border-slate-300"
                      >
                        <span className="font-black text-[13px] text-slate-800 tracking-tight uppercase">
                          সময়কাল:{" "}
                          <span className="text-blue-700 font-black">
                            {toBengaliDigits(group.label)}
                          </span>
                        </span>
                      </td>
                    </tr>

                      {group.entries.map((entry, idx) => {
                        const isExpanded = expandedEntries.has(entry.id);
                        const paras = entry.paragraphs || [];
                        const entrySettledCount = paras.filter(
                          (p) => filterStatus === "unsettled" ? (p.status || "").trim() === "আংশিক" : (p.status || "").trim() === "পূর্ণাঙ্গ",
                        ).length;
                        let displayCount = entrySettledCount;
                        if (paras.length === 0 && entry.isMeeting) {
                          if (filterStatus === "unsettled") {
                            const mPartial = parseBengaliNumber((entry.meetingPartialSettledParaCount || "").toString().trim());
                            displayCount = mPartial > 0 ? mPartial : 0;
                          } else {
                            const mFull = parseBengaliNumber((entry.meetingFullSettledParaCount || "").toString().trim());
                            const mSettled = parseBengaliNumber((entry.meetingSettledParaCount || "").toString().trim());
                            displayCount = mFull > 0 ? mFull : mSettled > 0 ? mSettled : 0;
                          }
                        }
                        const entryInvolvedAmount = paras.reduce(
                          (sum, p) => sum + (p.involvedAmount || 0),
                          0,
                        );
                        const mRaisedCountRaw =
                          entry.manualRaisedCount?.toString().trim() || "";
                        const mRaisedCount =
                          mRaisedCountRaw === "" ||
                          mRaisedCountRaw === "0" ||
                          mRaisedCountRaw === "০"
                            ? "০"
                            : toBengaliDigits(mRaisedCountRaw);
                        const mRaisedAmount =
                          entry.manualRaisedAmount !== null &&
                          entry.manualRaisedAmount !== undefined &&
                          entry.manualRaisedAmount !== 0
                            ? entry.manualRaisedAmount
                            : 0;

                        const isDeletingEntry = deletingInfo && deletingInfo.id === entry.id && !deletingInfo.paraId;

                        if (isDeletingEntry) {
                          return (
                            <tr key={entry.id} className="bg-rose-50/60 transition-all duration-500 animate-pulse">
                              <td colSpan={14} className="p-8 text-center text-rose-600 font-extrabold text-sm border border-rose-200">
                                <div className="flex items-center justify-center gap-3">
                                  <div className="relative flex items-center justify-center">
                                    <span className="w-5 h-5 rounded-full border-2 border-rose-600 border-t-transparent animate-spin"></span>
                                  </div>
                                  <span>ডাটাবেজ থেকে সম্পূর্ণ এন্ট্রিটি মুছে ফেলা হচ্ছে... অনুগ্রহ করে অপেক্ষা করুন</span>
                                </div>
                              </td>
                            </tr>
                          );
                        }

                        return (
                          <React.Fragment key={entry.id}>
                            {paras.length > 0 ? (
                              paras.map((p, pIdx) => {
                                const isDeletingPara = deletingInfo && deletingInfo.id === entry.id && deletingInfo.paraId === p.id;
                                if (isDeletingPara) {
                                  return (
                                    <tr key={p.id} className="bg-rose-50/60 transition-all duration-500 animate-pulse">
                                      {pIdx === 0 && (
                                         <>
                                           <td rowSpan={paras.length} className={tdBase + " font-black bg-rose-50/30 text-rose-600 !align-top p-1 pt-2"}>
                                             <div className={`sticky ${showCycleHeaders ? (isCycleStatsExpanded ? "top-[290px]" : "top-[162px]") : "top-[104px]"} flex justify-center pt-0.5`}>
                                               <span className="inline-flex items-center justify-center w-5 h-5 rounded-full border border-rose-300 bg-rose-100/80 text-rose-700 text-[9.5px] font-black shadow-xs">
                                                 {toBengaliDigits(idx + 1)}
                                               </span>
                                             </div>
                                           </td>
                                           <td rowSpan={paras.length} className={tdBase + " bg-rose-50/30 text-rose-600 p-3 pt-2 !align-top"}>
                                             <div className={`sticky ${showCycleHeaders ? (isCycleStatsExpanded ? "top-[290px]" : "top-[162px]") : "top-[104px]"}`}>
                                               <div className="text-center font-bold text-[10px]">
                                                 বিবরণ লোড হচ্ছে...
                                               </div>
                                             </div>
                                           </td>
                                         </>
                                      )}
                                      <td colSpan={12} className="py-4 px-2 text-center text-rose-600 font-extrabold text-[11px] border border-rose-250">
                                        <div className="flex items-center justify-center gap-2">
                                          <span className="w-3.5 h-3.5 rounded-full border-2 border-rose-600 border-t-transparent animate-spin inline-block"></span>
                                          <span>এই মিমাংসিত অনুচ্ছেদটি মুছে ফেলা হচ্ছে... দয়া করে অপেক্ষা করুন</span>
                                        </div>
                                      </td>
                                    </tr>
                                  );
                                }

                                return (
                                  <tr
                                    key={p.id}
                                    className={`transition-colors group bg-white ${isAdminView ? "hover:bg-amber-100/50" : "hover:bg-blue-50/30"}`}
                                  >
                                  {pIdx === 0 && (
                                    <>
                                      <td
                                        rowSpan={paras.length}
                                        className={tdBase + " font-black !align-top bg-white p-1 pt-2"}
                                      >
                                        <div className={`sticky ${showCycleHeaders ? (isCycleStatsExpanded ? "top-[290px]" : "top-[162px]") : "top-[104px]"} flex justify-center pt-0.5`}>
                                          <span className="inline-flex items-center justify-center w-5 h-5 rounded-full border border-slate-300 bg-slate-100 text-slate-800 text-[9.5px] font-black shadow-xs">
                                            {toBengaliDigits(idx + 1)}
                                          </span>
                                        </div>
                                      </td>
                                      <td
                                        rowSpan={paras.length}
                                        className={
                                          tdBase +
                                          " text-left p-3 pt-2 !align-top bg-white"
                                        }
                                      >
                                        <div className={`sticky ${showCycleHeaders ? (isCycleStatsExpanded ? "top-[290px]" : "top-[162px]") : "top-[104px]"}`}>
                                          {renderCellDescription(entry, isExpanded)}
                                        </div>
                                      </td>
                                    </>
                                  )}
                                  <td className={tdBase}>
                                    <span className="font-bold">
                                      {toBengaliDigits(p.paraNo)}
                                    </span>
                                    <br />
                                    <span
                                      className={`px-1 text-[8px] text-white font-black rounded ${p.status === "পূর্ণাঙ্গ" ? "bg-emerald-600" : "bg-red-600"}`}
                                    >
                                      {p.status}
                                    </span>
                                  </td>
                                  <td className={tdMoney}>
                                    {toBengaliDigits(
                                      Math.round(p.involvedAmount),
                                    )}
                                  </td>
                                  {pIdx === 0 && (
                                    <>
                                      <td
                                        rowSpan={paras.length}
                                        className={tdBase + " text-blue-700"}
                                      >
                                        {mRaisedCount}
                                      </td>
                                      <td
                                        rowSpan={paras.length}
                                        className={tdMoney + " text-blue-800"}
                                      >
                                        {toBengaliDigits(
                                          Math.round(mRaisedAmount),
                                        )}
                                      </td>
                                    </>
                                  )}
                                  <td className={tdMoney}>
                                    {toBengaliDigits(
                                      Math.round(
                                        p.category === "ভ্যাট"
                                          ? p.recoveredAmount
                                          : 0,
                                      ),
                                    )}
                                  </td>
                                  <td className={tdMoney}>
                                    {toBengaliDigits(
                                      Math.round(
                                        p.category === "ভ্যাট"
                                          ? p.adjustedAmount
                                          : 0,
                                      ),
                                    )}
                                  </td>
                                  <td className={tdMoney}>
                                    {toBengaliDigits(
                                      Math.round(
                                        p.category === "আয়কর"
                                          ? p.recoveredAmount
                                          : 0,
                                      ),
                                    )}
                                  </td>
                                  <td className={tdMoney}>
                                    {toBengaliDigits(
                                      Math.round(
                                        p.category === "আয়কর"
                                          ? p.adjustedAmount
                                          : 0,
                                      ),
                                    )}
                                  </td>
                                  <td className={tdMoney}>
                                    {toBengaliDigits(
                                      Math.round(
                                        p.category === "অন্যান্য"
                                          ? p.recoveredAmount
                                          : 0,
                                      ),
                                    )}
                                  </td>
                                  <td className={tdMoney}>
                                    {toBengaliDigits(
                                      Math.round(
                                        p.category === "অন্যান্য"
                                          ? p.adjustedAmount
                                          : 0,
                                      ),
                                    )}
                                  </td>
                                  <td className={tdMoney}>
                                    {toBengaliDigits(
                                      Math.round(p.recoveredAmount),
                                    )}
                                  </td>
                                  <td className={tdMoney + " relative"}>
                                    {toBengaliDigits(
                                      Math.round(p.adjustedAmount),
                                    )}
                                    {!isAdminView && isAdmin && (
                                      <div className="absolute right-0 bottom-0.5 flex opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none group-hover:pointer-events-auto gap-0.5 no-print p-0.5">
                                        <button
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            onEdit(entries.find((orig) => orig.id === entry.id) || entry);
                                          }}
                                          className="p-1 text-blue-600 bg-white border rounded shadow-sm hover:bg-blue-50 cursor-pointer"
                                        >
                                          <Pencil size={11} />
                                        </button>
                                        <div className="relative inline-block ml-0.5">
                                          <button
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              setDeleteConfirm(deleteConfirm && deleteConfirm.id === entry.id && deleteConfirm.paraId === p.id ? null : { id: entry.id, paraId: p.id });
                                            }}
                                            className={`p-1 rounded shadow-sm transition-all duration-300 cursor-pointer ${deleteConfirm && deleteConfirm.id === entry.id && deleteConfirm.paraId === p.id ? "bg-red-100 text-red-700 ring-1 ring-red-500/20" : "bg-white text-red-600 border hover:bg-red-50"}`}
                                          >
                                            <Trash2 size={11} />
                                          </button>

                                          {deleteConfirm && deleteConfirm.id === entry.id && deleteConfirm.paraId === p.id && (
                                            <div 
                                              onClick={(e) => e.stopPropagation()}
                                              className="absolute bottom-full right-0 mb-3 z-[150] w-64 p-4 bg-white border-2 border-rose-200 rounded-2xl shadow-[0_15px_35px_rgba(244,63,94,0.18)] text-left animate-in zoom-in-95 duration-200 font-sans leading-normal normal-case pointer-events-auto"
                                              style={{ transformOrigin: "bottom right" }}
                                            >
                                              <div className="flex items-start gap-3">
                                                <div className="w-8 h-8 rounded-full bg-rose-50 flex items-center justify-center shrink-0 border border-rose-100 animate-bounce">
                                                  <AlertTriangle size={16} className="text-rose-600" />
                                                </div>
                                                <div className="space-y-1">
                                                  <p className="text-[12px] font-black text-slate-800 leading-tight">
                                                    অনুচ্ছেদ মুছে ফেলার অবগতি
                                                  </p>
                                                  <p className="text-[10px] font-medium text-slate-500 leading-normal">
                                                    আপনি কি নিশ্চিতভাবে এই মিমাংসিত অনুচ্ছেদটি মুছে ফেলতে চান?
                                                  </p>
                                                </div>
                                              </div>
                                              <div className="flex items-center justify-end gap-2.5 mt-3 pt-2.5 border-t border-slate-100">
                                                <button
                                                  onClick={(e) => {
                                                    e.stopPropagation();
                                                    setDeleteConfirm(null);
                                                  }}
                                                  className="px-3 py-1.5 text-[10px] text-slate-500 font-extrabold hover:text-slate-800 bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-200/60 transition-all cursor-pointer"
                                                >
                                                  না, বাতিল
                                                </button>
                                                <button
                                                  onClick={(e) => {
                                                    e.stopPropagation();
                                                    setDeleteConfirm(null);
                                                    setDeletingInfo({ id: entry.id, paraId: p.id });
                                                    setTimeout(() => {
                                                      onDelete(entry.id, p.id);
                                                      setDeletingInfo(null);
                                                    }, 1000);
                                                  }}
                                                  className="px-3.5 py-1.5 text-[10px] text-white font-extrabold bg-rose-600 hover:bg-rose-700 active:scale-95 rounded-lg shadow-sm shadow-rose-500/10 transition-all flex items-center gap-1.5 cursor-pointer"
                                                >
                                                  <Trash2 size={10} />
                                                  <span>হ্যাঁ, নিশ্চিত</span>
                                                </button>
                                              </div>
                                              {/* Arrow */}
                                              <div className="absolute top-full right-2.5 -translate-y-1 w-2.5 h-2.5 bg-white border-r-2 border-b-2 border-rose-200 rotate-45"></div>
                                            </div>
                                          )}
                                        </div>
                                      </div>
                                    )}
                                    {isAdminView && isAdmin && (
                                      <div className="absolute right-1 top-1/2 -translate-y-1/2 flex opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none group-hover:pointer-events-auto flex-col gap-1.5 no-print z-[100] animate-in fade-in slide-in-from-right-2">
                                        <button
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            onApprove?.(entry.id);
                                          }}
                                          className="w-7 h-7 bg-emerald-500/10 text-emerald-500 rounded-lg flex items-center justify-center border border-emerald-500/20 hover:bg-emerald-500 hover:text-white transition-all shadow-lg backdrop-blur-sm"
                                          title="অনুমোদন দিন"
                                        >
                                          <Check size={16} strokeWidth={3} />
                                        </button>
                                        <button
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            onReject?.(entry.id);
                                          }}
                                          className="w-7 h-7 bg-red-500/10 text-red-500 rounded-lg flex items-center justify-center border border-red-500/20 hover:bg-red-500 hover:text-white transition-all shadow-lg backdrop-blur-sm"
                                          title="বাতিল করুন"
                                        >
                                          <XCircle size={16} />
                                        </button>
                                      </div>
                                    )}
                                  </td>
                                </tr>
                              );
                            })
                            ) : (
                              <tr
                                className={`transition-colors group bg-white ${isAdminView ? "hover:bg-amber-100/50" : "hover:bg-blue-50/30"}`}
                              >
                                <td className={tdBase + " font-black"}>
                                  <span className="inline-flex items-center justify-center w-5 h-5 rounded-full border border-slate-300 bg-slate-100 text-slate-800 text-[9.5px] font-black shadow-xs">
                                    {toBengaliDigits(idx + 1)}
                                  </span>
                                </td>
                                <td
                                  className={
                                    tdBase +
                                    " text-left p-3"
                                  }
                                >
                                  {renderCellDescription(entry, isExpanded)}
                                </td>
                                <td className={tdBase}>-</td>
                                <td className={tdMoney}>০</td>
                                <td
                                  className={
                                    tdBase + " text-blue-700 font-black"
                                  }
                                >
                                  {mRaisedCount}
                                </td>
                                <td className={tdMoney + " text-blue-800"}>
                                  {toBengaliDigits(Math.round(mRaisedAmount))}
                                </td>
                                <td className={tdMoney}>০</td>
                                <td className={tdMoney}>০</td>
                                <td className={tdMoney}>০</td>
                                <td className={tdMoney}>০</td>
                                <td className={tdMoney}>০</td>
                                <td className={tdMoney}>০</td>
                                <td className={tdMoney}>০</td>
                                <td className={tdMoney + " relative"}>
                                  ০
                                  {!isAdminView && isAdmin && (
                                    <div className="absolute right-0 bottom-0.5 flex opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none group-hover:pointer-events-auto gap-0.5 no-print p-0.5">
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          onEdit(entries.find((orig) => orig.id === entry.id) || entry);
                                        }}
                                        className="p-1 text-blue-600 bg-white border rounded shadow-sm hover:bg-blue-50 cursor-pointer"
                                      >
                                        <Pencil size={11} />
                                      </button>
                                      <div className="relative inline-block ml-0.5">
                                        <button
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            setDeleteConfirm(deleteConfirm && deleteConfirm.id === entry.id && !deleteConfirm.paraId ? null : { id: entry.id });
                                          }}
                                          className={`p-1 rounded shadow-sm transition-all duration-300 cursor-pointer ${deleteConfirm && deleteConfirm.id === entry.id && !deleteConfirm.paraId ? "bg-red-100 text-red-700 ring-1 ring-red-500/20" : "bg-white text-red-600 border hover:bg-red-50"}`}
                                        >
                                          <Trash2 size={11} />
                                        </button>

                                        {deleteConfirm && deleteConfirm.id === entry.id && !deleteConfirm.paraId && (
                                          <div 
                                            onClick={(e) => e.stopPropagation()}
                                            className="absolute bottom-full right-0 mb-3 z-[150] w-64 p-4 bg-white border-2 border-rose-200 rounded-2xl shadow-[0_15px_35px_rgba(244,63,94,0.18)] text-left animate-in zoom-in-95 duration-200 font-sans leading-normal normal-case pointer-events-auto"
                                            style={{ transformOrigin: "bottom right" }}
                                          >
                                            <div className="flex items-start gap-3">
                                              <div className="w-8 h-8 rounded-full bg-rose-50 flex items-center justify-center shrink-0 border border-rose-100 animate-bounce">
                                                <AlertTriangle size={16} className="text-rose-600" />
                                              </div>
                                              <div className="space-y-1">
                                                <p className="text-[12px] font-black text-slate-800 leading-tight">
                                                  তথ্য মুছে ফেলার অবগতি
                                                </p>
                                                <p className="text-[10px] font-medium text-slate-500 leading-normal">
                                                  আপনি কি নিশ্চিতভাবে এই সম্পূর্ণ এন্ট্রিটি মুছে ফেলতে চান?
                                                </p>
                                              </div>
                                            </div>
                                            <div className="flex items-center justify-end gap-2.5 mt-3 pt-2.5 border-t border-slate-100">
                                              <button
                                                onClick={(e) => {
                                                  e.stopPropagation();
                                                  setDeleteConfirm(null);
                                                }}
                                                className="px-3 py-1.5 text-[10px] text-slate-500 font-extrabold hover:text-slate-800 bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-200/60 transition-all cursor-pointer"
                                              >
                                                না, বাতিল
                                              </button>
                                              <button
                                                onClick={(e) => {
                                                  e.stopPropagation();
                                                  setDeleteConfirm(null);
                                                  setDeletingInfo({ id: entry.id });
                                                  setTimeout(() => {
                                                    onDelete(entry.id);
                                                    setDeletingInfo(null);
                                                  }, 1000);
                                                }}
                                                className="px-3.5 py-1.5 text-[10px] text-white font-extrabold bg-rose-600 hover:bg-rose-700 active:scale-95 rounded-lg shadow-sm shadow-rose-500/10 transition-all flex items-center gap-1.5 cursor-pointer"
                                              >
                                                <Trash2 size={10} />
                                                <span>হ্যাঁ, নিশ্চিত</span>
                                              </button>
                                            </div>
                                            {/* Arrow */}
                                            <div className="absolute top-full right-2.5 -translate-y-1 w-2.5 h-2.5 bg-white border-r-2 border-b-2 border-rose-200 rotate-45"></div>
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                  )}
                                  {isAdminView && isAdmin && (
                                    <div className="absolute right-1 top-1/2 -translate-y-1/2 flex opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none group-hover:pointer-events-auto flex-col gap-1.5 no-print z-[100] animate-in fade-in slide-in-from-right-2">
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          onApprove?.(entry.id);
                                        }}
                                        className="w-7 h-7 bg-emerald-500/10 text-emerald-500 rounded-lg flex items-center justify-center border border-emerald-500/20 hover:bg-emerald-500 hover:text-white transition-all shadow-lg backdrop-blur-sm"
                                        title="অনুমোদন দিন"
                                      >
                                        <Check size={16} strokeWidth={3} />
                                      </button>
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          onReject?.(entry.id);
                                        }}
                                        className="w-7 h-7 bg-red-500/10 text-red-500 rounded-lg flex items-center justify-center border border-red-500/20 hover:bg-red-500 hover:text-white transition-all shadow-lg backdrop-blur-sm"
                                        title="বাতিল করুন"
                                      >
                                        <XCircle size={16} />
                                      </button>
                                    </div>
                                  )}
                                </td>
                              </tr>
                            )}
                            <tr
                              className={`${isAdminView ? "bg-amber-100/40" : "bg-blue-50/60"} font-black border-t border-slate-300 h-[38px]`}
                            >
                              <td
                                colSpan={2}
                                className="px-4 text-left italic text-[10px] text-blue-900 border border-slate-300"
                              >
                                {filterStatus === "unsettled" ? "মোট আংশিক অনুচ্ছেদ: " : "মোট মিমাংসিত অনুচ্ছেদ: "}
                                <span className={filterStatus === "unsettled" ? "text-amber-800 font-black" : "text-emerald-700"}>
                                  {toBengaliDigits(displayCount)} টি
                                </span>{" "}
                                | মোট জড়িত টাকা:{" "}
                                <span className="text-blue-700">
                                  {toBengaliDigits(
                                    Math.round(entryInvolvedAmount),
                                  )}
                                </span>
                              </td>
                              <td className={`text-center text-[10px] font-black border border-slate-300 ${filterStatus === "unsettled" ? "text-amber-800 bg-amber-50/50" : "text-emerald-800 bg-emerald-50/30"}`}>
                                {toBengaliDigits(displayCount)}
                              </td>
                              <td className="text-center text-[10px] text-blue-800 border border-slate-300 bg-blue-50/30">
                                {toBengaliDigits(
                                  Math.round(entryInvolvedAmount),
                                )}
                              </td>
                              <td className="text-center text-[10px] text-slate-700 border border-slate-300 bg-white/50">
                                {mRaisedCount}
                              </td>
                              <td className="text-center text-[10px] text-slate-700 border border-slate-300 bg-white/50">
                                {toBengaliDigits(Math.round(mRaisedAmount))}
                              </td>
                              <td className="text-center text-[10px] text-slate-700 border border-slate-300 bg-white/50">
                                {toBengaliDigits(Math.round(entry.vatRec || 0))}
                              </td>
                              <td className="text-center text-[10px] text-slate-700 border border-slate-300 bg-white/50">
                                {toBengaliDigits(Math.round(entry.vatAdj || 0))}
                              </td>
                              <td className="text-center text-[10px] text-slate-700 border border-slate-300 bg-white/50">
                                {toBengaliDigits(Math.round(entry.itRec || 0))}
                              </td>
                              <td className="text-center text-[10px] text-slate-700 border border-slate-300 bg-white/50">
                                {toBengaliDigits(Math.round(entry.itAdj || 0))}
                              </td>
                              <td className="text-center text-[10px] text-slate-700 border border-slate-300 bg-white/50">
                                {toBengaliDigits(
                                  Math.round(entry.othersRec || 0),
                                )}
                              </td>
                              <td className="text-center text-[10px] text-slate-700 border border-slate-300 bg-white/50">
                                {toBengaliDigits(
                                  Math.round(entry.othersAdj || 0),
                                )}
                              </td>
                              <td className="text-center text-[10px] text-blue-900 border border-slate-300 bg-emerald-100/30 font-black">
                                {toBengaliDigits(Math.round(entry.totalRec))}
                              </td>
                              <td className="text-center text-[10px] text-blue-900 border border-slate-300 bg-emerald-100/30 font-black">
                                {toBengaliDigits(Math.round(entry.totalAdj))}
                              </td>
                            </tr>
                          </React.Fragment>
                        );
                      })}
                    </tbody>
                  );
                })
              ) : (
                <tbody>
                  {/* Invisible baseline row to secure table-layout fixed column widths when empty */}
                  <tr className="h-0 p-0 border-0 pointer-events-none select-none invisible">
                    <td className="p-0 border-0 h-0"></td>
                    <td className="p-0 border-0 h-0"></td>
                    <td className="p-0 border-0 h-0"></td>
                    <td className="p-0 border-0 h-0"></td>
                    <td className="p-0 border-0 h-0"></td>
                    <td className="p-0 border-0 h-0"></td>
                    <td className="p-0 border-0 h-0"></td>
                    <td className="p-0 border-0 h-0"></td>
                    <td className="p-0 border-0 h-0"></td>
                    <td className="p-0 border-0 h-0"></td>
                    <td className="p-0 border-0 h-0"></td>
                    <td className="p-0 border-0 h-0"></td>
                    <td className="p-0 border-0 h-0"></td>
                    <td className="p-0 border-0 h-0"></td>
                  </tr>
                  <tr>
                    <td colSpan={14} className="py-20 text-center bg-white">
                      <div className="flex flex-col items-center gap-3 opacity-30">
                        <Archive size={40} />
                        <p className="text-sm font-black text-slate-900 tracking-widest">
                          রেজিস্টার খালি
                        </p>
                      </div>
                    </td>
                  </tr>
                </tbody>
              )}
            {!isAdminView && (
              <tfoot className="z-[100]">
                <tr className="h-[45px] bg-slate-200 text-slate-900 shadow-[0_-4px_10px_rgba(0,0,0,0.05)] border-t border-slate-300">
                  <td
                    colSpan={2}
                    className={
                      footerTdCls + " text-slate-900 uppercase tracking-wider font-black"
                    }
                  >
                    সর্বমোট (ফিল্টার ডাটা):
                  </td>
                  <td className={footerTdCls + " text-blue-700"}>
                    <div className="flex flex-col items-center justify-center leading-tight py-0.5">
                      {filterStatus === "unsettled" ? (
                        <span className="text-amber-800 font-black text-[11px]" title={`আংশিক নিষ্পন্ন: ${toBengaliDigits(grandTotals.partialParaCount)} টি`}>
                          {toBengaliDigits(grandTotals.partialParaCount)}
                        </span>
                      ) : (
                        <>
                          <span className="text-blue-700 font-black text-[11px]" title={`পূর্ণাঙ্গ নিষ্পন্ন: ${toBengaliDigits(grandTotals.fullParaCount)} টি`}>
                            {toBengaliDigits(grandTotals.fullParaCount)}
                          </span>
                          {filterStatus === "" && grandTotals.partialParaCount > 0 && (
                            <span
                              className="text-[8.5px] font-bold text-amber-800 bg-amber-100/90 px-1 py-0.5 rounded border border-amber-300 mt-0.5 whitespace-nowrap shadow-2xs"
                              title={`আংশিক নিষ্পন্ন: ${toBengaliDigits(grandTotals.partialParaCount)} টি`}
                            >
                              (+{toBengaliDigits(grandTotals.partialParaCount)} আংশিক)
                            </span>
                          )}
                        </>
                      )}
                    </div>
                  </td>
                  <td className={footerTdCls + " text-blue-700"}>
                    {toBengaliDigits(Math.round(grandTotals.inv))}
                  </td>
                  <td className={footerTdCls + " text-blue-700"}>
                    {toBengaliDigits(grandTotals.raisedCount)}
                  </td>
                  <td className={footerTdCls + " text-blue-700"}>
                    {toBengaliDigits(Math.round(grandTotals.raisedAmount))}
                  </td>
                  <td className={footerTdCls + " text-slate-900"}>
                    {toBengaliDigits(Math.round(grandTotals.vRec))}
                  </td>
                  <td className={footerTdCls + " text-slate-900"}>
                    {toBengaliDigits(Math.round(grandTotals.vAdj))}
                  </td>
                  <td className={footerTdCls + " text-slate-900"}>
                    {toBengaliDigits(Math.round(grandTotals.iRec))}
                  </td>
                  <td className={footerTdCls + " text-slate-900"}>
                    {toBengaliDigits(Math.round(grandTotals.iAdj))}
                  </td>
                  <td className={footerTdCls + " text-slate-900"}>
                    {toBengaliDigits(Math.round(grandTotals.oRec))}
                  </td>
                  <td className={footerTdCls + " text-slate-900"}>
                    {toBengaliDigits(Math.round(grandTotals.oAdj))}
                  </td>
                  <td className={footerTdCls + " text-blue-800 font-extrabold"}>
                    {toBengaliDigits(Math.round(grandTotals.tRec))}
                  </td>
                  <td className={footerTdCls + " text-blue-800 font-extrabold"}>
                    {toBengaliDigits(Math.round(grandTotals.tAdj))}
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>

        {settledDetailsModalData && (
          <SettledMinistryDetailModal
            isOpen={settledDetailsModalData.isOpen}
            onClose={() => setSettledDetailsModalData(null)}
            branchType={settledDetailsModalData.branchType}
            cycleLabel={settledDetailsModalData.cycleLabel}
            totalCount={settledDetailsModalData.totalCount}
            ministries={settledDetailsModalData.ministries}
          />
        )}
      </div>
    );
  },
);

export default SettlementTable;
