
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { Printer, ChevronLeft, Search, X, ChevronDown, Check, LayoutGrid, FileText, ChevronRight, Sparkles, BarChart3, Calendar, FileSpreadsheet } from 'lucide-react';
import { toBengaliDigits, toEnglishDigits, formatDateBN } from '../utils/numberUtils';
import { getCleanLetterTypeDisplay, isSFI, isNonSFI } from '../utils/branchUtils';
import { OFFICE_HEADER } from '../constants';
import { format as dateFnsFormat, subMonths, startOfMonth, endOfMonth } from 'date-fns';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import LetterDetailsModal from './LetterDetailsModal';
import { getReceivers } from './ReceiverManagement';
import { normalizeName as normNameUtils, resolveCanonicalName } from '../utils/nameUtils';

interface CorrespondenceDhakaReturnProps {
  correspondenceEntries: any[];
  activeCycle: any;
  setSelectedReportType: (type: string | null) => void;
  HistoricalFilter: React.FC;
  IDBadge: React.FC<{ id: string }>;
  showFilters: boolean;
}

export const isExcludedFromDhakaReturn = (letterType: string | null | undefined): boolean => {
  if (!letterType) return false;
  const lt = letterType.trim();
  return (
    lt === 'মিলিকরণ' ||
    lt.includes('মিলিকরণ') ||
    lt === 'অন্যান্য' ||
    lt.includes('অন্যান্য') ||
    lt.includes('কার্যপত্র')
  );
};

export const isTrilateralLetter = (entry: any): boolean => {
  if (!entry) return false;
  const lt = (entry.letterType || '').trim();
  if (isExcludedFromDhakaReturn(lt)) return false;
  if (lt === 'বিএসআর' || lt.includes('বিএসআর')) return false;
  return (
    lt === 'ত্রিপক্ষীয় সভা' ||
    lt === 'ত্রিপক্ষীয় সভা (কার্যবিবরণী)' ||
    lt === 'ত্রিপক্ষীয় সভার কার্যবিবরণী' ||
    lt === 'কার্যবিবরণী (ত্রি-সভা)' ||
    lt === 'কার্যবিবরনী (ত্রি-সভা)' ||
    lt === 'ত্রিপক্ষীয় সভা' ||
    lt === 'ত্রিপক্ষীয় সভা (কার্যবিবরণী)' ||
    lt.includes('ত্রিপক্ষীয়') ||
    lt.includes('ত্রিপক্ষীয়') ||
    lt.includes('ত্রি-সভা') ||
    (lt.includes('কার্যবিবরণী') && (isSFI(entry.paraType) || lt.includes('ত্রি'))) ||
    (lt.includes('কার্যবিবরনী') && (isSFI(entry.paraType) || lt.includes('ত্রি')))
  );
};

export const isBilateralLetter = (entry: any): boolean => {
  if (!entry) return false;
  const lt = (entry.letterType || '').trim();
  if (isExcludedFromDhakaReturn(lt)) return false;
  if (lt === 'বিএসআর' || lt.includes('বিএসআর')) return false;
  return (
    lt === 'দ্বিপক্ষীয় সভা' ||
    lt === 'দ্বিপক্ষীয় সভা (কার্যবিবরণী)' ||
    lt === 'দ্বিপক্ষীয় সভার কার্যবিবরণী' ||
    lt === 'কার্যবিবরণী (দ্বি-সভা)' ||
    lt === 'কার্যবিবরনী (দ্বি-সভা)' ||
    lt === 'দ্বিপক্ষীয় সভা' ||
    lt === 'দ্বিপক্ষীয় সভা (কার্যবিবরণী)' ||
    lt.includes('দ্বিপক্ষীয়') ||
    lt.includes('দ্বিপক্ষীয়') ||
    lt.includes('দ্বি-সভা') ||
    (lt.includes('কার্যবিবরণী') && (isNonSFI(entry.paraType) || lt.includes('দ্বি'))) ||
    (lt.includes('কার্যবিবরনী') && (isNonSFI(entry.paraType) || lt.includes('দ্বি')))
  );
};

const parseDate = (dateStr: string | null | undefined) => {
  if (!dateStr) return null;
  const cleanStr = toEnglishDigits(dateStr).trim();
  // Support DD/MM/YYYY, DD-MM-YYYY, DD.MM.YYYY AND YYYY-MM-DD
  const parts = cleanStr.split(/[-/.]/);
  if (parts.length === 3) {
    let d, m, y;
    if (parts[0].length === 4) {
      // YYYY-MM-DD
      y = parseInt(parts[0]);
      m = parseInt(parts[1]) - 1;
      d = parseInt(parts[2]);
    } else {
      // DD/MM/YYYY
      d = parseInt(parts[0]);
      m = parseInt(parts[1]) - 1;
      y = parseInt(parts[2]);
    }
    const fullY = y < 100 ? 2000 + y : y;
    const date = new Date(fullY, m, d);
    if (!isNaN(date.getTime())) {
      // Return date normalized to midnight
      return new Date(date.getFullYear(), date.getMonth(), date.getDate());
    }
  }
  const fallback = new Date(cleanStr);
  if (!isNaN(fallback.getTime())) {
    return new Date(fallback.getFullYear(), fallback.getMonth(), fallback.getDate());
  }
  return null;
};

const BENGALI_MONTHS = [
  'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
  'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
];

const BENGALI_WEEKDAYS = ['শনি', 'রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র'];

const CorrespondenceDhakaReturn: React.FC<CorrespondenceDhakaReturnProps> = ({
  correspondenceEntries,
  activeCycle,
  setSelectedReportType,
  HistoricalFilter,
  IDBadge,
  showFilters
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterParaType, setFilterParaType] = useState('সকল');
  const [filterLetterType, setFilterLetterType] = useState('সকল');
  const [startDate, setStartDate] = useState<Date>(() => new Date(2025, 5, 16));
  const [endDate, setEndDate] = useState<Date>(() => new Date());
  const selectedMonthDate = endDate;
  const setSelectedMonthDate = setEndDate;
  const [selectingDateType, setSelectingDateType] = useState<'start' | 'end'>('start');
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [currentViewDate, setCurrentViewDate] = useState<Date>(() => new Date(startDate.getFullYear(), startDate.getMonth(), 1));
  const calendarRef = useRef<HTMLDivElement>(null);

  const [manualStartDate, setManualStartDate] = useState<string>(() => toBengaliDigits(dateFnsFormat(startDate, 'dd/MM/yyyy')));
  const [manualEndDate, setManualEndDate] = useState<string>(() => toBengaliDigits(dateFnsFormat(endDate, 'dd/MM/yyyy')));

  useEffect(() => {
    setManualStartDate(toBengaliDigits(dateFnsFormat(startDate, 'dd/MM/yyyy')));
  }, [startDate]);

  useEffect(() => {
    setManualEndDate(toBengaliDigits(dateFnsFormat(endDate, 'dd/MM/yyyy')));
  }, [endDate]);

  const parseManualDate = (str: string): Date | null => {
    if (!str) return null;
    const clean = toEnglishDigits(str).trim();
    const parts = clean.split(/[-/.]/);
    if (parts.length === 3) {
      let d = 0, m = 0, y = 0;
      if (parts[0].length === 4) {
        y = parseInt(parts[0], 10);
        m = parseInt(parts[1], 10) - 1;
        d = parseInt(parts[2], 10);
      } else {
        d = parseInt(parts[0], 10);
        m = parseInt(parts[1], 10) - 1;
        y = parseInt(parts[2], 10);
        if (y < 100) y = 2000 + y;
      }
      if (y >= 1970 && y <= 2100 && m >= 0 && m <= 11 && d >= 1 && d <= 31) {
        const dt = new Date(y, m, d);
        if (!isNaN(dt.getTime()) && dt.getMonth() === m && dt.getDate() === d) return dt;
      }
    }
    return null;
  };

  const downloadExcel = () => {
    const container = document.querySelector('#correspondence-dhaka-container');
    const tables = container ? container.querySelectorAll('table') : document.querySelectorAll('table');
    if (tables.length === 0) return;

    let tablesHtml = '';
    tables.forEach((table, tableIdx) => {
      const clonedTable = table.cloneNode(true) as HTMLTableElement;
      const interactiveElements = clonedTable.querySelectorAll('.no-print, button, svg, input, select');
      interactiveElements.forEach(el => el.remove());
      
      // Ensure all br tags have mso-data-placement: same-cell so Excel never splits cells into separate rows
      clonedTable.querySelectorAll('br').forEach(br => {
        br.setAttribute('style', 'mso-data-placement:same-cell;');
      });

      tablesHtml += `
        <div style="margin-bottom: 30px;">
          ${tableIdx > 0 ? '<br><hr><br>' : ''}
          ${clonedTable.outerHTML}
        </div>
      `;
    });

    const filename = `চিঠিপত্র_সংক্রান্ত_রিটার্ণ_ঢাকা_${dateFnsFormat(new Date(), 'yyyy-MM-dd')}.xls`;

    const template = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
      <head>
        <meta http-equiv="content-type" content="application/vnd.ms-excel; charset=UTF-8">
        <!--[if gte mso 9]>
        <xml>
          <x:ExcelWorkbook>
            <x:ExcelWorksheets>
              <x:ExcelWorksheet>
                <x:Name>রিপোর্ট</x:Name>
                <x:WorksheetOptions>
                  <x:DisplayGridlines/>
                </x:WorksheetOptions>
              </x:ExcelWorksheet>
            </x:ExcelWorksheets>
          </x:ExcelWorkbook>
        </xml>
        <![endif]-->
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif, 'Hind Siliguri', sans-serif; }
          table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }
          th, td { border: 1px solid #cbd5e1 !important; padding: 8px 12px !important; text-align: center; font-size: 11px; vertical-align: middle; mso-number-format: "\\@"; white-space: normal; }
          th { background-color: #f1f5f9 !important; color: #0f172a !important; font-weight: bold !important; }
          .bg-slate-200, thead, tfoot { background-color: #e2e8f0 !important; font-weight: bold !important; }
          .bg-sky-100 { background-color: #e0f2fe !important; }
          .bg-amber-50 { background-color: #fef3c7 !important; }
          .bg-black { background-color: #090d16 !important; color: #ffffff !important; }
          tfoot td { background-color: #0f172a !important; color: #ffffff !important; font-weight: bold !important; }
          br { mso-data-placement: same-cell !important; }
        </style>
      </head>
      <body>
        <h2 style="text-align: center; margin-bottom: 10px; color: #1e3a8a;">চিঠিপত্র সংক্রান্ত রিটার্ণ (ঢাকা)</h2>
        <p style="text-align: center; margin-top: 0; margin-bottom: 20px; font-weight: bold; color: #475569; font-size: 12px;">
          ${filterParaType === 'সকল' ? 'সকল' : filterParaType} শাখার ${toBengaliDigits(dateFnsFormat(startDate, 'dd/MM/yyyy'))} হতে ${toBengaliDigits(dateFnsFormat(endDate, 'dd/MM/yyyy'))} খ্রি: তারিখ পর্যন্ত বকেয়া চিঠিপত্রের তালিকা।
        </p>
        ${tablesHtml}
      </body>
      </html>
    `;

    const blob = new Blob(['\ufeff' + template], { type: 'application/vnd.ms-excel;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const downloadWord = () => {
    const container = document.querySelector('#correspondence-dhaka-container');
    const tables = container ? container.querySelectorAll('table') : document.querySelectorAll('table');
    if (tables.length === 0) return;

    let tablesHtml = '';
    tables.forEach((table, tableIdx) => {
      const clonedTable = table.cloneNode(true) as HTMLTableElement;
      const interactiveElements = clonedTable.querySelectorAll('.no-print, button, svg, input, select');
      interactiveElements.forEach(el => el.remove());

      // Ensure all br tags have mso-data-placement: same-cell so Word never splits cells into separate rows
      clonedTable.querySelectorAll('br').forEach(br => {
        br.setAttribute('style', 'mso-data-placement:same-cell;');
      });

      tablesHtml += `
        <div style="margin-bottom: 30px;">
          ${tableIdx > 0 ? '<br><hr style="border: 1px solid #cbd5e1;"><br>' : ''}
          ${clonedTable.outerHTML}
        </div>
      `;
    });

    const filename = `চিঠিপত্র_সংক্রান্ত_রিটার্ণ_ঢাকা_${dateFnsFormat(new Date(), 'yyyy-MM-dd')}.doc`;

    const wordTemplate = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">
      <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>চিঠিপত্র সংক্রান্ত রিটার্ণ (ঢাকা)</title>
        <!--[if gte mso 9]>
        <xml>
          <w:WordDocument>
            <w:View>Print</w:View>
            <w:Zoom>100</w:Zoom>
            <w:DoNotOptimizeForBrowser/>
          </w:WordDocument>
        </xml>
        <![endif]-->
        <style>
          @page Section1 {
            size: 841.9pt 595.3pt; /* A4 Landscape: 297mm x 210mm */
            mso-page-orientation: landscape;
            margin: 0.5in 0.5in 0.5in 0.5in;
            mso-header-margin: 0.3in;
            mso-footer-margin: 0.3in;
          }
          div.Section1 {
            page: Section1;
          }
          body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, 'Hind Siliguri', 'Nikosh', 'Kalpurush', sans-serif;
            font-size: 10pt;
            color: #000000;
          }
          h2 {
            text-align: center;
            font-size: 14pt;
            color: #1e3a8a;
            margin: 0 0 6px 0;
            font-weight: bold;
          }
          p.subtitle {
            text-align: center;
            font-size: 11pt;
            color: #334155;
            margin: 0 0 16px 0;
            font-weight: bold;
          }
          table {
            border-collapse: collapse;
            width: 100%;
            mso-table-layout-alt: fixed;
            margin-bottom: 20px;
          }
          th, td {
            border: 1px solid #475569 !important;
            padding: 6px 8px !important;
            text-align: center;
            font-size: 9pt;
            vertical-align: middle;
            mso-number-format: "\\@";
            word-wrap: break-word;
          }
          th {
            background-color: #e2e8f0 !important;
            color: #0f172a !important;
            font-weight: bold !important;
          }
          .bg-slate-200 {
            background-color: #e2e8f0 !important;
            font-weight: bold !important;
          }
          tfoot td {
            background-color: #020617 !important;
            color: #ffffff !important;
            font-weight: bold !important;
          }
          br {
            mso-data-placement: same-cell !important;
          }
        </style>
      </head>
      <body>
        <div class="Section1">
          <h2>চিঠিপত্র সংক্রান্ত রিটার্ণ (ঢাকা)</h2>
          <p class="subtitle">
            ${filterParaType === 'সকল' ? 'সকল' : filterParaType} শাখার ${toBengaliDigits(dateFnsFormat(startDate, 'dd/MM/yyyy'))} হতে ${toBengaliDigits(dateFnsFormat(endDate, 'dd/MM/yyyy'))} খ্রি: তারিখ পর্যন্ত বকেয়া চিঠিপত্রের তালিকা।
          </p>
          ${tablesHtml}
        </div>
      </body>
      </html>
    `;

    const blob = new Blob(['\ufeff' + wordTemplate], { type: 'application/msword;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  useEffect(() => {
    if (isCalendarOpen) {
      setCurrentViewDate(new Date(startDate.getFullYear(), startDate.getMonth(), 1));
    }
  }, [isCalendarOpen]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (branchDropdownRef.current && !branchDropdownRef.current.contains(e.target as Node)) {
        setIsBranchDropdownOpen(false);
      }
      if (typeDropdownRef.current && !typeDropdownRef.current.contains(e.target as Node)) {
        setIsTypeDropdownOpen(false);
      }
      if (calendarRef.current && !calendarRef.current.contains(e.target as Node)) {
        setIsCalendarOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);
  
  const [isBranchDropdownOpen, setIsBranchDropdownOpen] = useState(false);
  const [isTypeDropdownOpen, setIsTypeDropdownOpen] = useState(false);
  const [showStats, setShowStats] = useState(false);
  const [dateInputText, setDateInputText] = useState(dateFnsFormat(selectedMonthDate, 'dd/MM/yyyy'));
  const [isSearchExpanded, setIsSearchExpanded] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isSearchExpanded && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [isSearchExpanded]);
  
  const branchDropdownRef = useRef<HTMLDivElement>(null);
  const typeDropdownRef = useRef<HTMLDivElement>(null);
  const dateInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setDateInputText(dateFnsFormat(selectedMonthDate, 'dd/MM/yyyy'));
  }, [selectedMonthDate]);

  const handleDateTextChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setDateInputText(val);
    
    // Simple DD/MM/YYYY parser
    const parts = val.split('/');
    if (parts.length === 3) {
      const d = parseInt(parts[0]);
      const m = parseInt(parts[1]) - 1;
      const y = parseInt(parts[2]);
      if (y > 1900 && y < 2100 && m >= 0 && m < 12 && d > 0 && d <= 31) {
        const newDate = new Date(y, m, d);
        if (!isNaN(newDate.getTime())) {
          setSelectedMonthDate(newDate);
        }
      }
    }
  };

  useEffect(() => {
    setFilterLetterType('সকল');
  }, [filterParaType]);

  const [showAuditorStatsModal, setShowAuditorStatsModal] = useState(false);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [detailsModalTitle, setDetailsModalTitle] = useState('');
  const [detailsModalLetters, setDetailsModalLetters] = useState<any[]>([]);
  const [highlightedKey, setHighlightedKey] = useState<string | null>(null);

  const [receiverImages, setReceiverImages] = useState<Record<string, string>>({});
  const [receiverDesignations, setReceiverDesignations] = useState<Record<string, string>>({});
  const [receiversList, setReceiversList] = useState<any[]>([]);

  const normalizeName = (name: string | null | undefined): string => {
    return normNameUtils(name) || 'অনির্ধারিত';
  };

  const getDisplayName = (name: string | null | undefined): string => {
    if (!name) return 'অনির্ধারিত';
    const raw = name.trim();
    if (!raw) return 'অনির্ধারিত';

    const resolved = resolveCanonicalName(raw, receiversList);
    if (resolved && resolved !== 'অনির্ধারিত') {
      return resolved.replace(/শাহ্রিন/g, 'শাহরিন').replace(/শাম্মীমা/g, 'শামীমা');
    }

    try {
      const recs = getReceivers();
      const resolvedRec = resolveCanonicalName(raw, recs);
      if (resolvedRec && resolvedRec !== 'অনির্ধারিত') {
        return resolvedRec.replace(/শাহ্রিন/g, 'শাহরিন').replace(/শাম্মীমা/g, 'শামীমা');
      }
    } catch (e) {}

    const directResolved = resolveCanonicalName(raw);
    if (directResolved && directResolved !== 'অনির্ধারিত') {
      return directResolved.replace(/শাহ্রিন/g, 'শাহরিন').replace(/শাম্মীমা/g, 'শামীমা');
    }

    const norm = normalizeName(raw);
    if (norm === 'অনির্ধারিত' || !norm) return 'অনির্ধারিত';

    let match = receiversList.find(r => normalizeName(r.name) === norm);
    if (!match) {
      match = receiversList.find(r => {
        const rNorm = normalizeName(r.name);
        return rNorm && (rNorm.includes(norm) || norm.includes(rNorm));
      });
    }
    let finalName = match ? match.name : name;
    return finalName ? finalName.replace(/শাহ্রিন/g, 'শাহরিন').replace(/শাম্মীমা/g, 'শামীমা') : 'অনির্ধারিত';
  };

  const getDisplayDesignation = (name: string | null | undefined): string => {
    if (!name) return 'অডিটর';
    const norm = normalizeName(name);
    const match = receiversList.find(r => normalizeName(r.name) === norm);
    return match && match.designation ? match.designation : (receiverDesignations[name] || receiverDesignations[norm] || "অডিটর");
  };

  const getDisplayImage = (name: string | null | undefined): string | null => {
    if (!name) return null;
    const norm = normalizeName(name);
    const match = receiversList.find(r => normalizeName(r.name) === norm);
    if (match) {
      return match.image || null;
    }
    return receiverImages[name] || receiverImages[norm] || null;
  };

  useEffect(() => {
    const fetchReceiverProfiles = async () => {
      const imagesMap: Record<string, string> = {};
      const designationsMap: Record<string, string> = {};
      let finalReceivers: any[] = [];

      const addProfile = (name: string, img: string | null, desig: string | null, fullItem: any = null) => {
        if (!name) return;
        const nameTrim = name.trim();
        const norm = normalizeName(nameTrim);
        if (img) {
          imagesMap[nameTrim] = img;
          imagesMap[norm] = img;
        }
        if (desig) {
          designationsMap[nameTrim] = desig;
          designationsMap[norm] = desig;
        }
        if (fullItem) {
          finalReceivers.push(fullItem);
        } else {
          finalReceivers.push({ name: nameTrim, image: img, designation: desig });
        }
      };

      // 1. Fetch from database (Supabase)
      if (isSupabaseConfigured) {
        try {
          const { data: dbReceivers } = await supabase
            .from('receivers')
            .select('name, image, designation');
          if (dbReceivers) {
            dbReceivers.forEach(r => {
              addProfile(r.name, r.image, r.designation, r);
            });
          }
        } catch (err) {
          console.error("Error fetching db receivers in Return:", err);
        }
      }

      // 2. Fetch from local storage keys
      const localKeys = [
        'ledger_correspondence_receivers_admin',
        'ledger_correspondence_receivers_sfi',
        'ledger_correspondence_receivers_nonsfi'
      ];
      localKeys.forEach(key => {
        try {
          const saved = localStorage.getItem(key);
          if (saved) {
            const items = JSON.parse(saved);
            if (Array.isArray(items)) {
              items.forEach((item: any) => {
                addProfile(item.name, item.image, item.designation, item);
              });
            }
          }
        } catch (e) {
          console.error("Error parsing local receivers:", e);
        }
      });

      setReceiverImages(imagesMap);
      setReceiverDesignations(designationsMap);
      setReceiversList(finalReceivers);
    };

    fetchReceiverProfiles();
  }, [correspondenceEntries]);

  const handleCountClick = (title: string, letters: any[]) => {
    if (letters.length === 0) return;
    setDetailsModalTitle(title);
    setDetailsModalLetters(letters);
    setIsDetailsModalOpen(true);
    setHighlightedKey(title);
  };

  const getHighlightClass = (key: string) => {
    return highlightedKey === key ? 'clicked-cell-highlight' : '';
  };

  const branchOptions = useMemo(() => ['সকল', 'এসএফআই', 'নন এসএফআই'], []);

  const typeOptions = useMemo(() => {
    if (filterParaType === 'এসএফআই') {
      
      return ['সকল', 'বিএসআর', 'কার্যবিবরণী (ত্রি-সভা)'];
    }
    if (filterParaType === 'নন এসএফআই') {
      return ['সকল', 'বিএসআর', 'কার্যবিবরণী (দ্বি-সভা)'];

    }
    return ['সকল', 'বিএসআর', 'কার্যবিবরণী (ত্রি-সভা)', 'কার্যবিবরণী (দ্বি-সভা)'];
  }, [filterParaType]);

  const cycleOptions = useMemo(() => {
    const options = [];
    const banglaMonths: Record<string, string> = {
      'January': 'জানুয়ারি', 'February': 'ফেব্রুয়ারি', 'March': 'মার্চ', 'April': 'এপ্রিল',
      'May': 'মে', 'June': 'জুন', 'July': 'জুলাই', 'August': 'আগস্ট',
      'September': 'সেপ্টেম্বর', 'October': 'অক্টোবর', 'November': 'নভেম্বর', 'December': 'ডিসেম্বর'
    };
    const today = new Date();
    for (let i = 0; i < 24; i++) {
      const refDate = new Date(today.getFullYear(), today.getMonth() - i, 1);
      const monthNameEng = dateFnsFormat(refDate, 'MMMM');
      const yearEng = dateFnsFormat(refDate, 'yyyy');
      const label = `${banglaMonths[monthNameEng]}/${toBengaliDigits(yearEng)}`;
      options.push({ date: refDate, label });
    }
    return options;
  }, []);

  const currentSelectedLabel = useMemo(() => {
    const banglaMonths: Record<string, string> = {
      'January': 'জানুয়ারি', 'February': 'ফেব্রুয়ারি', 'March': 'মার্চ', 'April': 'এপ্রিল',
      'May': 'মে', 'June': 'জুন', 'July': 'জুলাই', 'August': 'আগস্ট',
      'September': 'সেপ্টেম্বর', 'October': 'অক্টোবর', 'November': 'নভেম্বর', 'December': 'ডিসেম্বর'
    };
    const monthNameEng = dateFnsFormat(selectedMonthDate, 'MMMM');
    const yearEng = dateFnsFormat(selectedMonthDate, 'yyyy');
    return `${banglaMonths[monthNameEng]}/${toBengaliDigits(yearEng)}`;
  }, [selectedMonthDate]);

  const filteredData = useMemo(() => {
    let data = correspondenceEntries || [];

    // 1. Basic exclusions for Dhaka Return:
    // Exclude 'অন্যান্য', 'কার্যপত্র (দ্বি-সভা)', 'কার্যপত্র (ত্রি-সভা)', and 'মিলিকরণ'
    data = data.filter(e => !isExcludedFromDhakaReturn(e.letterType));

    // 2. Filter by selected date range (হতে - থেকে)
    const startMidnight = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate()).getTime();
    const endMidnight = new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate(), 23, 59, 59, 999).getTime();
    
    data = data.filter(e => {
      // 1. Check if it's settled (has valid issue no AND date)
      const issueNo = (e.issueLetterNo || '').trim();
      const hasValidIssueNo = issueNo !== '' && 
                              issueNo !== '০' && 
                              issueNo !== '0' && 
                              issueNo !== 'নং' && 
                              issueNo !== 'নং-' && 
                              issueNo !== 'নং -' &&
                              !/^নং\s*$/.test(issueNo);

      const hasValidIssueDate = e.issueLetterDate && 
                                e.issueLetterDate.trim() !== '' && 
                                e.issueLetterDate !== '০' && 
                                e.issueLetterDate !== '0';

      if (hasValidIssueNo && hasValidIssueDate) {
        const iDate = parseDate(e.issueLetterDate);
        if (iDate) {
          // If issued on or before end date, it's SETTLED (not pending)
          if (iDate.getTime() <= endMidnight) {
            return false; 
          }
        }
      }

      // 2. If not settled, it must have a diary date to be considered
      const dDate = parseDate(e.diaryDate);
      if (!dDate) return false;
      
      // 3. Must be received within startDate to endDate
      const dTime = dDate.getTime();
      if (dTime < startMidnight || dTime > endMidnight) return false;
      
      return true; // Still Pending
    });
    
    if (filterParaType !== 'সকল') {
      data = data.filter(e => e.paraType === filterParaType);
    }
    
    if (filterLetterType !== 'সকল') {
      if (filterLetterType === 'বিএসআর') {
        data = data.filter(e => e.letterType === 'বিএসআর' || (e.letterType || '').includes('বিএসআর'));
      } else if (
        filterLetterType === 'কার্যবিবরণী (ত্রি-সভা)' || 
        filterLetterType === 'কার্যবিবরনী (ত্রি-সভা)' ||
        filterLetterType.includes('ত্রি-সভা') ||
        filterLetterType.includes('ত্রিপক্ষীয়') ||
        filterLetterType.includes('ত্রিপক্ষীয়')
      ) {
        data = data.filter(e => isTrilateralLetter(e));
      } else if (
        filterLetterType === 'কার্যবিবরণী (দ্বি-সভা)' || 
        filterLetterType === 'কার্যবিবরনী (দ্বি-সভা)' ||
        filterLetterType.includes('দ্বি-সভা') ||
        filterLetterType.includes('দ্বিপক্ষীয়') ||
        filterLetterType.includes('দ্বিপক্ষীয়')
      ) {
        data = data.filter(e => isBilateralLetter(e));
      } else {
        data = data.filter(e => e.letterType === filterLetterType);
      }
    }

    if (searchTerm.trim()) {
      data = data.filter(entry => 
        (entry.description || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (entry.diaryNo || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (entry.letterNo || '').toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    return [...data].sort((a, b) => {
      const dateA = parseDate(a.diaryDate)?.getTime() ?? 0;
      const dateB = parseDate(b.diaryDate)?.getTime() ?? 0;
      if (dateA !== dateB) return dateA - dateB;
      const noA = parseInt(toEnglishDigits(String(a.diaryNo || '')).replace(/\D/g, ''), 10) || 0;
      const noB = parseInt(toEnglishDigits(String(b.diaryNo || '')).replace(/\D/g, ''), 10) || 0;
      return noA - noB;
    });
  }, [correspondenceEntries, searchTerm, filterParaType, filterLetterType, startDate, endDate]);

  const excludedEntries = useMemo(() => {
    let data = correspondenceEntries || [];

    // Only letters excluded from main Dhaka Return table (যেমন: কার্যপত্র, মিলিকরণ, অন্যান্য)
    data = data.filter(e => isExcludedFromDhakaReturn(e.letterType));

    const startMidnight = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate()).getTime();
    const endMidnight = new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate(), 23, 59, 59, 999).getTime();

    data = data.filter(e => {
      const issueNo = (e.issueLetterNo || '').trim();
      const hasValidIssueNo = issueNo !== '' &&
                              issueNo !== '০' &&
                              issueNo !== '0' &&
                              issueNo !== 'নং' &&
                              issueNo !== 'নং-' &&
                              issueNo !== 'নং -' &&
                              !/^নং\s*$/.test(issueNo);

      const hasValidIssueDate = e.issueLetterDate &&
                                e.issueLetterDate.trim() !== '' &&
                                e.issueLetterDate !== '০' &&
                                e.issueLetterDate !== '0';

      if (hasValidIssueNo && hasValidIssueDate) {
        const iDate = parseDate(e.issueLetterDate);
        if (iDate && iDate.getTime() <= endMidnight) {
          return false;
        }
      }

      const dDate = parseDate(e.diaryDate);
      if (!dDate) return false;

      const dTime = dDate.getTime();
      if (dTime < startMidnight || dTime > endMidnight) return false;

      return true;
    });

    if (filterParaType !== 'সকল') {
      data = data.filter(e => e.paraType === filterParaType);
    }

    if (searchTerm.trim()) {
      data = data.filter(entry =>
        (entry.description || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (entry.diaryNo || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (entry.letterNo || '').toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    return [...data].sort((a, b) => {
      const dateA = parseDate(a.diaryDate)?.getTime() ?? 0;
      const dateB = parseDate(b.diaryDate)?.getTime() ?? 0;
      if (dateA !== dateB) return dateA - dateB;
      const noA = parseInt(toEnglishDigits(String(a.diaryNo || '')).replace(/\D/g, ''), 10) || 0;
      const noB = parseInt(toEnglishDigits(String(b.diaryNo || '')).replace(/\D/g, ''), 10) || 0;
      return noA - noB;
    });
  }, [correspondenceEntries, searchTerm, filterParaType, startDate, endDate]);

  const thS = "px-1 py-1 font-black text-center text-[10px] bg-slate-200 text-slate-900 leading-tight align-middle h-full bg-clip-border";
  const customDropdownCls = (isOpen: boolean) => `relative flex items-center gap-3 px-4 h-[44px] bg-slate-50 border rounded-xl cursor-pointer transition-all duration-300 ${isOpen ? 'border-emerald-600 ring-4 ring-emerald-50 shadow-md z-[1010]' : 'border-slate-300 shadow-sm hover:border-slate-300'}`;
  const tdS = "px-2 py-2 text-[11px] text-center font-bold leading-tight min-h-[40px] align-middle break-words";
  
  const reportingLimitDate = useMemo(() => {
    return selectedMonthDate;
  }, [selectedMonthDate]);

  const reportingDateBN = useMemo(() => 
    toBengaliDigits(dateFnsFormat(reportingLimitDate, 'dd/MM/yyyy')),
    [reportingLimitDate]
  );

  const reportingMonthYearBN = toBengaliDigits(dateFnsFormat(new Date(activeCycle.end), 'MMMM/yyyy'))
    .replace('January', 'জানুয়ারি').replace('February', 'ফেব্রুয়ারি').replace('March', 'মার্চ')
    .replace('April', 'এপ্রিল').replace('May', 'মে').replace('June', 'জুন')
    .replace('July', 'জুলাই').replace('August', 'আগস্ট').replace('September', 'সেপ্টেম্বর')
    .replace('October', 'অক্টোবর').replace('November', 'নভেম্বর').replace('December', 'ডিসেম্বর');

  const getHistoricalPresentation = (entry: any, reportingDate: Date | null) => {
    if (!entry.presentationDate || !String(entry.presentationDate).trim()) {
      return {
        isPresented: false,
        presentationDateFormatted: '-',
        position: 'অডিটর'
      };
    }

    const pDate = parseDate(entry.presentationDate);
    if (!pDate) {
      return {
        isPresented: false,
        presentationDateFormatted: '-',
        position: 'অডিটর'
      };
    }

    if (reportingDate) {
      const repLimit = new Date(
        reportingDate.getFullYear(),
        reportingDate.getMonth(),
        reportingDate.getDate()
      );
      if (pDate.getTime() > repLimit.getTime()) {
        return {
          isPresented: false,
          presentationDateFormatted: '-',
          position: 'অডিটর'
        };
      }
    }

    return {
      isPresented: true,
      presentationDateFormatted: formatDateBN(entry.presentationDate),
      position: entry.presentedToName || 'অডিটর'
    };
  };

  const auditorWiseStats = useMemo(() => {
    const stats: Record<string, { 
      rawName: string;
      total: number; auditor: number; aao: number; dd: number; others: number;
      auditorLetters: any[]; aaoLetters: any[]; ddLetters: any[]; othersLetters: any[]; totalLetters: any[]
    }> = {};
    
    filteredData.forEach(entry => {
      const hist = getHistoricalPresentation(entry, selectedMonthDate);
      const pos = hist.position;

      const rawAud = (entry.receiverName || entry.presentedToName || '').trim();
      const officialDisplay = getDisplayName(rawAud);
      const auditorKey = normalizeName(officialDisplay) || 'অনির্ধারিত';

      if (!stats[auditorKey]) {
        stats[auditorKey] = { 
          rawName: officialDisplay,
          total: 0, auditor: 0, aao: 0, dd: 0, others: 0,
          auditorLetters: [], aaoLetters: [], ddLetters: [], othersLetters: [], totalLetters: []
        };
      }
      
      const entryForDetails = {
        ...entry,
        presentationDate: hist.isPresented ? entry.presentationDate : '',
        presentedToName: pos
      };

      stats[auditorKey].total++;
      stats[auditorKey].totalLetters.push(entryForDetails);
      
      if (pos.includes('অডিটর')) {
        stats[auditorKey].auditor++;
        stats[auditorKey].auditorLetters.push(entryForDetails);
      } else if (pos.includes('এএন্ডএও') || pos.includes('সুপার')) {
        stats[auditorKey].aao++;
        stats[auditorKey].aaoLetters.push(entryForDetails);
      } else if (pos.includes('উপপরিচালক')) {
        stats[auditorKey].dd++;
        stats[auditorKey].ddLetters.push(entryForDetails);
      } else {
        stats[auditorKey].others++;
        stats[auditorKey].othersLetters.push(entryForDetails);
      }
    });
    
    return Object.entries(stats).map(([key, data]) => ({ name: data.rawName, ...data }));
  }, [filteredData, selectedMonthDate]);

  const summaryStats = useMemo(() => {
    const stats = {
      total: 0,
      totalParas: 0,
      sfi: { total: 0, bsr: 0, kb: 0, paras: 0 },
      nonSfi: { total: 0, bsr: 0, kb: 0, paras: 0 }
    };
    
    filteredData.forEach(e => {
      stats.total++;
      const paras = parseInt(toEnglishDigits(e.totalParas || '0')) || 0;
      stats.totalParas += paras;

      if (e.paraType === 'এসএফআই' || isSFI(e.paraType)) {
        stats.sfi.total++;
        stats.sfi.paras += paras;
        if (e.letterType === 'বিএসআর' || (e.letterType || '').includes('বিএসআর')) stats.sfi.bsr++;
        if (isTrilateralLetter(e)) stats.sfi.kb++;
      } else if (e.paraType === 'নন এসএফআই' || isNonSFI(e.paraType)) {
        stats.nonSfi.total++;
        stats.nonSfi.paras += paras;
        if (e.letterType === 'বিএসআর' || (e.letterType || '').includes('বিএসআর')) stats.nonSfi.bsr++;
        if (isBilateralLetter(e)) stats.nonSfi.kb++;
      }
    });
    return stats;
  }, [filteredData]);

  const getPositionColor = (name: string) => {
    const pos = name || 'অডিটর';
    if (pos.includes('অডিটর')) return 'bg-red-500 text-white';
    if (pos.includes('সুপার')) return 'bg-yellow-400 text-black';
    if (pos.includes('এএন্ডএও')) return 'bg-blue-600 text-white';
    if (pos.includes('উপপরিচালক')) return 'bg-green-600 text-white';
    return 'bg-slate-100 text-slate-700';
  };

  return (
    <div id="correspondence-dhaka-container" className="space-y-4 py-2 px-[4px] w-full animate-report-page relative">
      <IDBadge id="correspondence-dhaka-container" />

      <div className="bg-white w-full overflow-visible px-0 py-6 relative animate-table-entrance">
        {/* Header container for Title, Reporting Period and Statistics in a single line on desktop/xl screens */}
        <div className="flex flex-col xl:flex-row items-center justify-between gap-4 mb-8 pt-4 pb-6 border-b border-slate-100 w-full px-4 sm:px-6">
          
          {/* Left: Title Header styled as split-block button */}
          <div className="flex items-stretch h-[38px] w-fit max-w-[95%] shadow-[0_4px_12px_rgba(0,0,0,0.1)] select-none rounded-lg overflow-hidden border border-slate-200/50 shrink-0 transition-all duration-300">
            {/* Left Icon Area: Off-white bg & gray bottom border */}
            <div className={`flex flex-col shrink-0 h-full transition-all duration-300 ${isSearchExpanded ? 'w-8' : 'w-10'}`}>
              <div className="flex-1 flex items-center justify-center bg-[#f8fafc]">
                <FileText className={`text-red-700 stroke-[2.5] transition-all duration-300 ${isSearchExpanded ? 'w-3.5 h-3.5' : 'w-4 h-4'}`} />
              </div>
              <div className="h-[3px] bg-[#94a3b8]" />
            </div>
            
            {/* Right Text Area: Rich Royal Blue/Indigo with dark bottom bar */}
            <div className={`flex-1 flex flex-col h-full transition-all duration-300 ${isSearchExpanded ? 'min-w-[120px] sm:min-w-[140px]' : 'min-w-[160px] sm:min-w-[200px]'}`}>
              <div className="flex-1 bg-[#1e40af] flex items-center justify-center px-2.5 sm:px-4">
                <span className={`text-white font-bold tracking-wide text-center transition-all duration-300 whitespace-nowrap ${isSearchExpanded ? 'text-[9.5px] sm:text-[11px]' : 'text-[11px] sm:text-[12px]'}`}>
                  {isSearchExpanded ? 'চিঠিপত্র রিটার্ণ (ঢাকা)' : 'চিঠিপত্র সংক্রান্ত রিটার্ণ (ঢাকা)'}
                </span>
              </div>
              <div className="h-[3px] bg-[#1e3a8a]" />
            </div>
          </div>

          {/* Right/Middle: Group of Compact Controls */}
          <div className="flex flex-wrap xl:flex-nowrap items-center justify-center xl:justify-end gap-1.5 sm:gap-2 w-full xl:w-auto">
            {/* 1. Reporting Period Date Range Picker (হতে - থেকে) */}
            <div className="relative shrink-0 select-none z-[400]" ref={calendarRef}>
              <div 
                onClick={() => setIsCalendarOpen(!isCalendarOpen)}
                className="relative inline-flex items-center gap-2 px-3 h-[35px] bg-slate-50 border border-slate-300 hover:border-emerald-600 hover:ring-2 hover:ring-emerald-50 transition-all text-slate-800 rounded-xl text-[11px] sm:text-[11.5px] font-bold shadow-sm cursor-pointer"
              >
                <span className={`text-slate-500 leading-none transition-all duration-300 ${isSearchExpanded ? 'hidden xl:inline' : 'hidden sm:inline'}`}>সময়কাল:</span> 
                <span className="text-slate-800 flex items-center gap-1 font-black leading-none">
                  {toBengaliDigits(dateFnsFormat(startDate, 'dd/MM/yyyy'))} হতে {toBengaliDigits(dateFnsFormat(endDate, 'dd/MM/yyyy'))}
                  <Calendar size={11} className="text-emerald-600 group-hover:scale-110 transition-transform duration-200" />
                </span>
                <ChevronDown size={11} className={`text-slate-400 transition-transform duration-300 lg:inline shrink-0 ${isCalendarOpen ? 'rotate-180 text-emerald-600' : ''}`} />
              </div>

              {isCalendarOpen && (
                <div className="absolute top-[110%] left-0 sm:left-auto sm:right-0 lg:left-1/2 lg:-translate-x-1/2 w-[320px] sm:w-[350px] max-w-[calc(100vw-24px)] bg-white border border-slate-200 shadow-2xl rounded-2xl p-4 z-[9999] animate-in fade-in slide-in-from-top-2 duration-200">
                  {/* Calendar Top Header with Title & Close */}
                  <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-100">
                    <div className="flex items-center gap-1.5 text-xs font-black text-slate-800">
                      <Calendar size={13} className="text-emerald-600" />
                      <span>রিপোর্টিং সময়কাল নির্বাচন (হতে - থেকে)</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setIsCalendarOpen(false)}
                      className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
                    >
                      <X size={14} />
                    </button>
                  </div>

                  {/* Start & End Date Selection Cards */}
                  <div className="grid grid-cols-2 gap-2 mb-3">
                    {/* Start Date Card */}
                    <div
                      onClick={() => {
                        setSelectingDateType('start');
                        setCurrentViewDate(new Date(startDate.getFullYear(), startDate.getMonth(), 1));
                      }}
                      className={`relative p-2 rounded-xl border text-left transition-all ${
                        selectingDateType === 'start'
                          ? 'border-emerald-600 bg-emerald-50/70 ring-2 ring-emerald-200 shadow-xs'
                          : 'border-slate-200 bg-slate-50 hover:bg-slate-100/70'
                      }`}
                    >
                      <span className="block text-[10px] font-bold text-slate-500">শুরুর তারিখ (হতে)</span>
                      <div className="flex items-center justify-between mt-0.5 gap-1">
                        <input
                          type="text"
                          value={manualStartDate}
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectingDateType('start');
                            setCurrentViewDate(new Date(startDate.getFullYear(), startDate.getMonth(), 1));
                          }}
                          onFocus={() => {
                            setSelectingDateType('start');
                          }}
                          onChange={(e) => {
                            const val = e.target.value;
                            setManualStartDate(val);
                            const parsed = parseManualDate(val);
                            if (parsed) {
                              setStartDate(parsed);
                              if (parsed > endDate) setEndDate(parsed);
                              setCurrentViewDate(new Date(parsed.getFullYear(), parsed.getMonth(), 1));
                            }
                          }}
                          onBlur={() => {
                            const parsed = parseManualDate(manualStartDate);
                            if (parsed) {
                              setStartDate(parsed);
                              setManualStartDate(toBengaliDigits(dateFnsFormat(parsed, 'dd/MM/yyyy')));
                            } else {
                              setManualStartDate(toBengaliDigits(dateFnsFormat(startDate, 'dd/MM/yyyy')));
                            }
                          }}
                          placeholder="০১/০১/২০২৬"
                          className="w-full bg-transparent font-extrabold text-xs text-slate-800 outline-none p-0 border-none focus:ring-0 cursor-text"
                          title="ক্যালেন্ডার বা ম্যানুয়ালি তারিখ লিখুন (যেমন: ০১/১০/২০২৬ বা 01/10/2026)"
                        />
                        <div className="relative shrink-0">
                          <input
                            type="date"
                            value={dateFnsFormat(startDate, 'yyyy-MM-dd')}
                            onChange={(e) => {
                              const val = e.target.value;
                              if (val) {
                                const [y, m, d] = val.split('-').map(Number);
                                const newD = new Date(y, m - 1, d);
                                setStartDate(newD);
                                if (newD > endDate) setEndDate(newD);
                                setCurrentViewDate(new Date(y, m - 1, 1));
                              }
                            }}
                            className="opacity-0 absolute inset-0 w-full h-full cursor-pointer z-10"
                            title="ক্যালেন্ডার থেকে নির্বাচন করুন"
                          />
                          <Calendar size={13} className="text-emerald-600" />
                        </div>
                      </div>
                    </div>

                    {/* End Date Card */}
                    <div
                      onClick={() => {
                        setSelectingDateType('end');
                        setCurrentViewDate(new Date(endDate.getFullYear(), endDate.getMonth(), 1));
                      }}
                      className={`relative p-2 rounded-xl border text-left transition-all ${
                        selectingDateType === 'end'
                          ? 'border-emerald-600 bg-emerald-50/70 ring-2 ring-emerald-200 shadow-xs'
                          : 'border-slate-200 bg-slate-50 hover:bg-slate-100/70'
                      }`}
                    >
                      <span className="block text-[10px] font-bold text-slate-500">শেষের তারিখ (পর্যন্ত)</span>
                      <div className="flex items-center justify-between mt-0.5 gap-1">
                        <input
                          type="text"
                          value={manualEndDate}
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectingDateType('end');
                            setCurrentViewDate(new Date(endDate.getFullYear(), endDate.getMonth(), 1));
                          }}
                          onFocus={() => {
                            setSelectingDateType('end');
                          }}
                          onChange={(e) => {
                            const val = e.target.value;
                            setManualEndDate(val);
                            const parsed = parseManualDate(val);
                            if (parsed) {
                              setEndDate(parsed);
                              if (parsed < startDate) setStartDate(parsed);
                              setCurrentViewDate(new Date(parsed.getFullYear(), parsed.getMonth(), 1));
                            }
                          }}
                          onBlur={() => {
                            const parsed = parseManualDate(manualEndDate);
                            if (parsed) {
                              setEndDate(parsed);
                              setManualEndDate(toBengaliDigits(dateFnsFormat(parsed, 'dd/MM/yyyy')));
                            } else {
                              setManualEndDate(toBengaliDigits(dateFnsFormat(endDate, 'dd/MM/yyyy')));
                            }
                          }}
                          placeholder="৩১/০১/২০২৬"
                          className="w-full bg-transparent font-extrabold text-xs text-slate-800 outline-none p-0 border-none focus:ring-0 cursor-text"
                          title="ক্যালেন্ডার বা ম্যানুয়ালি তারিখ লিখুন (যেমন: ৩১/১০/২০২৬ বা 31/10/2026)"
                        />
                        <div className="relative shrink-0">
                          <input
                            type="date"
                            value={dateFnsFormat(endDate, 'yyyy-MM-dd')}
                            onChange={(e) => {
                              const val = e.target.value;
                              if (val) {
                                const [y, m, d] = val.split('-').map(Number);
                                const newD = new Date(y, m - 1, d);
                                setEndDate(newD);
                                if (newD < startDate) setStartDate(newD);
                                setCurrentViewDate(new Date(y, m - 1, 1));
                              }
                            }}
                            className="opacity-0 absolute inset-0 w-full h-full cursor-pointer z-10"
                            title="ক্যালেন্ডার থেকে নির্বাচন করুন"
                          />
                          <Calendar size={13} className="text-emerald-600" />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Quick Presets: [ < ] [বিগত মাস] [চলতি মাস] [ > ] [চলতি বছর] [গত ৩০ দিন] */}
                  <div className="flex flex-wrap items-center gap-1 mb-3 pb-2.5 border-b border-slate-100">
                    {/* পূর্ববর্তী মাস নেভিগেশন বোতাম */}
                    <button
                      type="button"
                      onClick={() => {
                        const base = startDate || new Date();
                        const prevM = subMonths(base, 1);
                        const s = startOfMonth(prevM);
                        const e = endOfMonth(prevM);
                        setStartDate(s);
                        setEndDate(e);
                        setCurrentViewDate(new Date(s.getFullYear(), s.getMonth(), 1));
                      }}
                      className="p-1 px-1.5 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-300 border border-slate-200 rounded-lg text-slate-700 transition-colors cursor-pointer flex items-center justify-center shrink-0"
                      title="পূর্ববর্তী মাস (পেছনে যান - যতবার চাপবেন এক মাস করে পেছনে যাবে)"
                    >
                      <ChevronLeft size={13} />
                    </button>

                    {/* বিগত মাস */}
                    <button
                      type="button"
                      onClick={() => {
                        const now = new Date();
                        const s = startOfMonth(subMonths(now, 1));
                        const e = endOfMonth(subMonths(now, 1));
                        setStartDate(s);
                        setEndDate(e);
                        setCurrentViewDate(new Date(s.getFullYear(), s.getMonth(), 1));
                      }}
                      className="px-2 py-0.5 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-300 border border-slate-200 rounded-lg text-[10px] font-bold text-slate-700 transition-colors cursor-pointer"
                      title="বিগত মাস"
                    >
                      বিগত মাস
                    </button>

                    {/* চলতি মাস (বিগত মাসের ডান পাশে) */}
                    <button
                      type="button"
                      onClick={() => {
                        const now = new Date();
                        const s = startOfMonth(now);
                        const e = endOfMonth(now);
                        setStartDate(s);
                        setEndDate(e);
                        setCurrentViewDate(new Date(now.getFullYear(), now.getMonth(), 1));
                      }}
                      className="px-2 py-0.5 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-300 border border-slate-200 rounded-lg text-[10px] font-bold text-slate-700 transition-colors cursor-pointer"
                      title="চলতি মাস"
                    >
                      চলতি মাস
                    </button>

                    {/* পরবর্তী মাস নেভিগেশন বোতাম */}
                    <button
                      type="button"
                      onClick={() => {
                        const base = startDate || new Date();
                        const nextM = new Date(base.getFullYear(), base.getMonth() + 1, 1);
                        const s = startOfMonth(nextM);
                        const e = endOfMonth(nextM);
                        setStartDate(s);
                        setEndDate(e);
                        setCurrentViewDate(new Date(s.getFullYear(), s.getMonth(), 1));
                      }}
                      className="p-1 px-1.5 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-300 border border-slate-200 rounded-lg text-slate-700 transition-colors cursor-pointer flex items-center justify-center shrink-0"
                      title="পরবর্তী মাস (সামনে যান)"
                    >
                      <ChevronRight size={13} />
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const now = new Date();
                        const s = new Date(now.getFullYear(), 0, 1);
                        const e = new Date(now.getFullYear(), 11, 31);
                        setStartDate(s);
                        setEndDate(e);
                        setCurrentViewDate(new Date(now.getFullYear(), now.getMonth(), 1));
                      }}
                      className="px-2 py-0.5 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-300 border border-slate-200 rounded-lg text-[10px] font-bold text-slate-700 transition-colors cursor-pointer"
                    >
                      চলতি বছর
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const now = new Date();
                        const s = new Date(now.getTime() - 29 * 24 * 60 * 60 * 1000);
                        setStartDate(s);
                        setEndDate(now);
                        setCurrentViewDate(new Date(s.getFullYear(), s.getMonth(), 1));
                      }}
                      className="px-2 py-0.5 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-300 border border-slate-200 rounded-lg text-[10px] font-bold text-slate-700 transition-colors cursor-pointer"
                    >
                      গত ৩০ দিন
                    </button>
                  </div>

                  {/* Calendar Header with Navigation */}
                  <div className="flex items-center justify-between mb-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setCurrentViewDate(prev => new Date(prev.getFullYear(), prev.getMonth() - 1, 1));
                      }}
                      className="p-1 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-emerald-700 transition-colors cursor-pointer"
                      type="button"
                    >
                      <ChevronLeft size={16} />
                    </button>
                    
                    <span className="font-extrabold text-[13px] text-slate-800">
                      {BENGALI_MONTHS[currentViewDate.getMonth()]} {toBengaliDigits(currentViewDate.getFullYear().toString())}
                    </span>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setCurrentViewDate(prev => new Date(prev.getFullYear(), prev.getMonth() + 1, 1));
                      }}
                      className="p-1 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-emerald-700 transition-colors cursor-pointer"
                      type="button"
                    >
                      <ChevronRight size={16} />
                    </button>
                  </div>

                  {/* Calendar Week Days */}
                  <div className="grid grid-cols-7 gap-1 text-center mb-1">
                    {BENGALI_WEEKDAYS.map((wd, i) => (
                      <span key={i} className="text-[10px] font-black text-slate-400 py-0.5">
                        {wd}
                      </span>
                    ))}
                  </div>

                  {/* Calendar Days Grid */}
                  <div className="grid grid-cols-7 gap-1">
                    {(() => {
                      const Y = currentViewDate.getFullYear();
                      const M = currentViewDate.getMonth();
                      const firstDay = new Date(Y, M, 1);
                      
                      let startOffset = (firstDay.getDay() + 1) % 7; 
                      
                      const daysInMonth = new Date(Y, M + 1, 0).getDate();
                      const prevMonthDays = new Date(Y, M, 0).getDate();
                      
                      const cells = [];
                      
                      // Trailing days
                      for (let i = startOffset - 1; i >= 0; i--) {
                        const d = prevMonthDays - i;
                        const dateObj = new Date(Y, M - 1, d);
                        cells.push({ day: d, isCurrentMonth: false, dateObj });
                      }
                      
                      // Current month days
                      for (let d = 1; d <= daysInMonth; d++) {
                        const dateObj = new Date(Y, M, d);
                        cells.push({ day: d, isCurrentMonth: true, dateObj });
                      }
                      
                      // Lead days
                      const totalCells = cells.length > 35 ? 42 : 35;
                      const remaining = totalCells - cells.length;
                      for (let d = 1; d <= remaining; d++) {
                        const dateObj = new Date(Y, M + 1, d);
                        cells.push({ day: d, isCurrentMonth: false, dateObj });
                      }

                      const startStr = dateFnsFormat(startDate, 'yyyy-MM-dd');
                      const endStr = dateFnsFormat(endDate, 'yyyy-MM-dd');

                      return cells.map((cell, idx) => {
                        const dateStr = dateFnsFormat(cell.dateObj, 'yyyy-MM-dd');
                        const isStart = dateStr === startStr;
                        const isEnd = dateStr === endStr;
                        const isInRange = dateStr > startStr && dateStr < endStr;

                        let cellCls = "text-[11.5px] font-bold h-7 flex items-center justify-center transition-all cursor-pointer relative ";
                        if (isStart && isEnd) {
                          cellCls += "bg-emerald-600 text-white font-black rounded-lg shadow-sm z-10";
                        } else if (isStart) {
                          cellCls += "bg-emerald-600 text-white font-black rounded-l-lg shadow-sm z-10";
                        } else if (isEnd) {
                          cellCls += "bg-emerald-600 text-white font-black rounded-r-lg shadow-sm z-10";
                        } else if (isInRange) {
                          cellCls += "bg-emerald-100/70 text-emerald-950 font-extrabold rounded-none";
                        } else if (cell.isCurrentMonth) {
                          cellCls += "text-slate-800 hover:bg-emerald-50 hover:text-emerald-700 rounded-lg";
                        } else {
                          cellCls += "text-slate-300 hover:bg-slate-50 hover:text-slate-400 rounded-lg";
                        }

                        return (
                          <div
                            key={idx}
                            onClick={(e) => {
                              e.stopPropagation();
                              const clickedDate = cell.dateObj;
                              if (selectingDateType === 'start') {
                                if (clickedDate > endDate) {
                                  setStartDate(clickedDate);
                                  setEndDate(clickedDate);
                                  setSelectingDateType('end');
                                } else {
                                  setStartDate(clickedDate);
                                  setSelectingDateType('end');
                                }
                              } else {
                                if (clickedDate < startDate) {
                                  setStartDate(clickedDate);
                                  setSelectingDateType('end');
                                } else {
                                  setEndDate(clickedDate);
                                }
                              }
                            }}
                            className={cellCls}
                          >
                            <span>{toBengaliDigits(cell.day.toString())}</span>
                          </div>
                        );
                      });
                    })()}
                  </div>

                  {/* Footer with Apply button and Range Display */}
                  <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-slate-100 text-xs">
                    <div className="text-[10.5px] font-bold text-slate-600">
                      <span>{toBengaliDigits(dateFnsFormat(startDate, 'dd/MM/yyyy'))}</span>
                      <span className="mx-1 text-slate-400">হতে</span>
                      <span>{toBengaliDigits(dateFnsFormat(endDate, 'dd/MM/yyyy'))}</span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          const now = new Date();
                          const s = new Date(2025, 5, 16);
                          setStartDate(s);
                          setEndDate(now);
                          setCurrentViewDate(new Date(s.getFullYear(), s.getMonth(), 1));
                          setSelectingDateType('start');
                        }}
                        className="px-2 py-1 text-[10.5px] font-bold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                      >
                        রিসেট
                      </button>
                      <button
                        type="button"
                        onClick={() => setIsCalendarOpen(false)}
                        className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-[11px] transition-all shadow-xs flex items-center gap-1 cursor-pointer active:scale-95"
                      >
                        <Check size={12} className="stroke-[3]" />
                        <span>প্রয়োগ করুন</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* 2. Branch Filter Dropdown */}
            <div className="relative shrink-0 no-print" ref={branchDropdownRef}>
              <div 
                onClick={() => {
                  setIsBranchDropdownOpen(!isBranchDropdownOpen);
                  setIsTypeDropdownOpen(false);
                  setIsCalendarOpen(false);
                }}
                className={`relative flex items-center gap-1.5 px-2.5 h-[35px] bg-slate-50 border rounded-xl cursor-pointer transition-all duration-300 shadow-sm min-w-[100px] sm:min-w-[115px] ${isBranchDropdownOpen ? 'border-emerald-600 ring-2 ring-emerald-50 bg-white' : 'border-slate-300 hover:border-emerald-600 hover:ring-2 hover:ring-emerald-50'}`}
              >
                <LayoutGrid size={13} className="text-emerald-600 shrink-0" />
                <span className="font-extrabold text-[11px] sm:text-[11.5px] text-slate-800 break-words leading-none">
                  {filterParaType === 'সকল' ? 'সকল শাখা' : filterParaType}
                </span>
                <ChevronDown size={11} className={`text-slate-400 ml-auto transition-transform duration-300 shrink-0 ${isBranchDropdownOpen ? 'rotate-180 text-emerald-600' : ''}`} />
              </div>
              
              {isBranchDropdownOpen && (
                <div className="absolute top-full left-0 w-full pt-1 transition-all duration-200 ease-out z-[2000]">
                  <div className="w-full bg-white border border-slate-200 rounded-xl shadow-xl overflow-hidden">
                    <div className="max-h-[220px] overflow-y-auto no-scrollbar">
                      {branchOptions.map((opt, idx) => (
                        <div 
                          key={idx} 
                          onClick={() => {
                            setFilterParaType(opt);
                            setIsBranchDropdownOpen(false);
                          }} 
                          className={`flex items-center justify-between px-3 py-2 cursor-pointer transition-all ${filterParaType === opt ? 'bg-emerald-600 text-white' : 'hover:bg-emerald-50 text-slate-700 font-bold text-[11.5px]'}`}
                        >
                          <span>{opt === 'সকল' ? 'সকল শাখা' : opt}</span>
                          {filterParaType === opt && <Check size={12} strokeWidth={3} />}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* 3. Type Filter Dropdown */}
            <div className="relative shrink-0 no-print" ref={typeDropdownRef}>
              <div 
                onClick={() => {
                  setIsTypeDropdownOpen(!isTypeDropdownOpen);
                  setIsBranchDropdownOpen(false);
                  setIsCalendarOpen(false);
                }}
                className={`relative flex items-center gap-1.5 px-2.5 h-[35px] bg-slate-50 border rounded-xl cursor-pointer transition-all duration-300 shadow-sm min-w-[110px] sm:min-w-[125px] ${isTypeDropdownOpen ? 'border-emerald-600 ring-2 ring-emerald-50 bg-white' : 'border-slate-300 hover:border-emerald-600 hover:ring-2 hover:ring-emerald-50'}`}
              >
                <FileText size={13} className="text-emerald-600 shrink-0" />
                <span className="font-extrabold text-[11px] sm:text-[11.5px] text-slate-800 break-words leading-none">
                  {filterLetterType === 'সকল' ? 'চিঠির ধরন' : filterLetterType}
                </span>
                <ChevronDown size={11} className={`text-slate-400 ml-auto transition-transform duration-300 shrink-0 ${isTypeDropdownOpen ? 'rotate-180 text-emerald-600' : ''}`} />
              </div>
              
              {isTypeDropdownOpen && (
                <div className="absolute top-full left-0 w-full pt-1 transition-all duration-200 ease-out z-[2000]">
                  <div className="w-full bg-white border border-slate-200 rounded-xl shadow-xl overflow-hidden">
                    <div className="py-0">
                      {typeOptions.map((opt, idx) => (
                        <div 
                          key={idx} 
                          onClick={() => {
                            setFilterLetterType(opt);
                            setIsTypeDropdownOpen(false);
                          }} 
                          className={`flex items-center justify-between px-3 py-2 cursor-pointer transition-all ${filterLetterType === opt ? 'bg-emerald-600 text-white' : 'hover:bg-emerald-50 text-slate-700 font-bold text-[11.5px]'}`}
                        >
                          <span>{opt === 'সকল' ? 'চিঠির ধরন' : opt}</span>
                          {filterLetterType === opt && <Check size={12} strokeWidth={3} />}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* 4. Excel Download Button */}
            <button
              type="button"
              onClick={downloadExcel}
              className="flex items-center justify-center w-10 h-[35px] bg-emerald-50 text-emerald-700 hover:text-emerald-800 border border-emerald-100 hover:border-emerald-300 hover:bg-white hover:shadow-md transition-all duration-300 rounded-xl cursor-pointer shrink-0 no-print"
              title="এক্সেল ফাইল ডাউনলোড করুন (.xls)"
            >
              <FileSpreadsheet size={15} className="stroke-[2.5]" />
            </button>

            {/* Word Download Button */}
            <button
              type="button"
              onClick={downloadWord}
              className="flex items-center justify-center w-10 h-[35px] bg-blue-50 text-blue-700 hover:text-blue-800 border border-blue-200 hover:border-blue-400 hover:bg-white hover:shadow-md transition-all duration-300 rounded-xl cursor-pointer shrink-0 no-print"
              title="ওয়ার্ড ফাইল ডাউনলোড করুন (.doc)"
            >
              <FileText size={15} className="stroke-[2.5]" />
            </button>

            {/* 5. Statistics Trigger Button */}
            <button 
              onClick={() => setShowAuditorStatsModal(true)}
              className="flex items-center justify-center gap-1.5 px-2.5 h-[35px] bg-slate-50 border border-slate-300 rounded-xl cursor-pointer transition-all duration-300 hover:border-emerald-600 hover:ring-2 hover:ring-emerald-50 shadow-sm text-slate-800 text-[11px] sm:text-[11.5px] font-black shrink-0 no-print"
            >
              <BarChart3 size={13} className="text-emerald-600 shrink-0" />
              <span className="leading-none">পরিসংখ্যান</span>
            </button>
          </div>
        </div>

        <div className="table-container qr-table-container relative overflow-visible w-full">
          <table className="w-full border-separate table-fixed border-spacing-0 !table-auto min-w-[1000px] xl:min-w-full">
            <colgroup>
              <col className="w-[40px]" />
              <col className="w-[219px]" />
              <col className="w-[54px]" />
              <col className="w-[54px]" />
              <col className="w-[55px]" />
              <col className="w-[59px]" />
              <col className="w-[55px]" />
              <col className="w-[55px]" />
              <col className="w-[55px]" />
              <col className="w-[60px]" />
              <col className="w-[44px]" />
              <col className="w-[50px]" />
              <col className="w-[50px]" />
            </colgroup>
            <thead>
              <tr className="h-[42px]">
                <th rowSpan={2} className={thS}>ক্রমিক নং</th>
                <th rowSpan={2} className={thS}>এনটিটি/প্রতিষ্ঠানের নাম</th>
                <th rowSpan={2} className={thS}>ডায়েরি নং ও তারিখ</th>
                <th rowSpan={2} className={thS}>পত্রের স্মারক নং ও তারিখ</th>
                <th colSpan={5} className={thS}>চিঠি-পত্রের ধরণ ও অনুচ্ছেদ সংখ্যা</th>
                <th rowSpan={2} className={thS}>Amms status</th>
                <th rowSpan={2} className={thS}>উপস্থাপনের তারিখ</th>
                <th rowSpan={2} className={thS}>বর্তমান অবস্থান</th>
                <th rowSpan={2} className={thS}>মন্তব্য</th>
              </tr>
              <tr className="h-[38px]">
                <th className={thS}>বিএসআর (SFI)</th>
                <th className={thS}>বিএসআর (NON-SFI)</th>
                <th className={thS}>ত্রি-পক্ষীয় (SFI)</th>
                <th className={thS}>দ্বি-পক্ষীয় (NON-SFI)</th>
                <th className={thS}>অন্যান্য</th>
              </tr>
              <tr className="h-[26px] bg-slate-200">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13].map(n => (
                  <th key={n} className={`${thS} text-[9px] font-bold text-slate-700 py-0.5`}>
                    {toBengaliDigits(n.toString())}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filteredData.length > 0 ? filteredData.map((entry, idx) => {
                const hist = getHistoricalPresentation(entry, selectedMonthDate);
                return (
                  <tr key={entry.id} className="no-hover-row group bg-white hover:bg-blue-100/70 transition-all duration-200 cursor-default">
                    <td className={tdS}>{toBengaliDigits(idx + 1)}</td>
                    <td className={`${tdS} text-justify px-2 transition-colors`}>{entry.description}</td>
                    <td className={tdS}>
                      {entry.diaryNo ? (entry.diaryDate ? `${entry.diaryNo},` : entry.diaryNo) : ''}
                      <br style={{ msoDataPlacement: 'same-cell' } as any} />
                      {formatDateBN(entry.diaryDate)}
                    </td>
                    <td className={tdS}>
                      {entry.letterNo ? (entry.letterDate ? `${entry.letterNo},` : entry.letterNo) : ''}
                      <br style={{ msoDataPlacement: 'same-cell' } as any} />
                      {formatDateBN(entry.letterDate)}
                    </td>
                    <td className={tdS}>{(entry.letterType === 'বিএসআর' || (entry.letterType || '').includes('বিএসআর')) && (entry.paraType === 'এসএফআই' || isSFI(entry.paraType)) ? `(অনু: ${toBengaliDigits(entry.totalParas)}টি)` : ''}</td>
                    <td className={tdS}>{(entry.letterType === 'বিএসআর' || (entry.letterType || '').includes('বিএসআর')) && (entry.paraType === 'নন এসএফআই' || isNonSFI(entry.paraType)) ? `(অনু: ${toBengaliDigits(entry.totalParas)}টি)` : ''}</td>
                    <td className={tdS}>{isTrilateralLetter(entry) ? `${getCleanLetterTypeDisplay(entry.letterType)} (অনু: ${toBengaliDigits(entry.totalParas)}টি)` : ''}</td>
                    <td className={tdS}>
                      {isBilateralLetter(entry) ? (
                        (() => {
                          const cleanType = getCleanLetterTypeDisplay(entry.letterType);
                          const displayType = (cleanType === 'কার্যপত্র' || cleanType === 'কার্যবিবরণী')
                            ? (cleanType === 'কার্যপত্র' ? 'দ্বি-সভা (কার্যপত্র)' : 'দ্বি-সভা (কার্যবিবরনী)')
                            : (cleanType || 'দ্বি-সভা (কার্যবিবরনী)');
                          return `${displayType} (অনু: ${toBengaliDigits(entry.totalParas)}টি)`;
                        })()
                      ) : ''}
                    </td>
                    <td className={tdS}>-</td>
                    <td className={tdS}>{entry.isOnline === 'হ্যাঁ' ? 'হ্যাঁ' : 'না'}</td>
                    <td className={tdS}>{hist.presentationDateFormatted}</td>
                    <td className={`${tdS} py-1 px-1 text-center align-middle`}>
                      <div className="flex items-center justify-center w-full">
                        <span className={`inline-flex items-center justify-center px-2.5 py-0.5 text-[9.5px] font-black rounded-full shadow-xs whitespace-nowrap leading-tight tracking-tight ${getPositionColor(hist.position)}`}>
                          {getDisplayName(hist.position)}
                        </span>
                      </div>
                    </td>
                    <td className={tdS}>{entry.remarks || 'চলমান'}</td>
                  </tr>
                );
              }) : (
                <tr><td colSpan={13} className="py-20 text-center font-black text-slate-400 bg-slate-50 italic">এই সাইকেলে কোনো চিঠিপত্র তথ্য পাওয়া যায়নি।</td></tr>
              )}
            </tbody>
            <tfoot className="z-[120]">
              <tr className="bg-black text-white font-black text-[12px] h-11 shadow-[0_-5px_15px_rgba(0,0,0,0.05)]">
                <td colSpan={2} className="px-4 text-left bg-black text-white">সর্বমোট চিঠিপত্র (ফিল্টারকৃত):</td>
                <td colSpan={2} className="px-4 text-center bg-black text-emerald-400">{toBengaliDigits(filteredData.length)} টি</td>
                <td colSpan={9} className="bg-black"></td>
              </tr>
            </tfoot>
          </table>

          {/* Footnote for Excluded Letters (কার্যপত্র ও অন্যান্য) */}
          <div className="mt-5 p-4 bg-amber-50/70 border border-amber-200 rounded-xl space-y-2.5 text-slate-800">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-amber-200/80 pb-2">
              <div className="flex items-center gap-2">
                <span className="inline-flex items-center justify-center px-2 py-0.5 bg-amber-600 text-white text-[10px] font-black rounded-md uppercase tracking-wider">
                  ফুটনোট / বিশেষ দ্রষ্টব্য
                </span>
                <span className="text-[12px] font-black text-amber-950">
                  মূল টেবিলে যুক্ত করা হয়নি এমন ‘কার্যপত্র’ ও অন্যান্য চিঠিপত্রের বিবরণ ({toBengaliDigits(excludedEntries.length)} টি):
                </span>
              </div>
              <span className="text-[10.5px] font-bold text-amber-800">
                * ঢাকা রিটার্নের মূল ছকে শুধুমাত্র বিএসআর ও সভার কার্যবিবরণী অন্তর্ভুক্ত হয়; কার্যপত্র মূল টেবিলে যুক্ত হয় না।
              </span>
            </div>

            {excludedEntries.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full border-collapse border border-amber-200 bg-white rounded-lg overflow-hidden text-[11px]">
                  <thead>
                    <tr className="bg-amber-100/80 text-slate-900 font-black">
                      <th className="border border-amber-200 px-2 py-1.5 text-center w-[45px]">ক্র: নং</th>
                      <th className="border border-amber-200 px-3 py-1.5 text-left">এনটিটি / প্রতিষ্ঠানের নাম (পত্রের বিবরণ)</th>
                      <th className="border border-amber-200 px-2.5 py-1.5 text-center">শাখা</th>
                      <th className="border border-amber-200 px-2.5 py-1.5 text-center">পত্রের ধরণ (কারণ)</th>
                      <th className="border border-amber-200 px-2.5 py-1.5 text-center">ডায়েরি নং ও তারিখ</th>
                      <th className="border border-amber-200 px-2.5 py-1.5 text-center">পত্র নং ও তারিখ</th>
                      <th className="border border-amber-200 px-2.5 py-1.5 text-center">অনুচ্ছেদ সংখ্যা</th>
                      <th className="border border-amber-200 px-2.5 py-1.5 text-center">গ্রহীতা / বর্তমান অবস্থান</th>
                    </tr>
                  </thead>
                  <tbody>
                    {excludedEntries.map((entry, idx) => {
                      const hist = getHistoricalPresentation(entry, selectedMonthDate);
                      const cleanType = getCleanLetterTypeDisplay(entry.letterType) || entry.letterType || 'কার্যপত্র';
                      return (
                        <tr key={entry.id || idx} className="hover:bg-amber-50/50 font-bold text-slate-800">
                          <td className="border border-amber-200 px-2 py-1.5 text-center">{toBengaliDigits(idx + 1)}</td>
                          <td className="border border-amber-200 px-3 py-1.5 text-justify text-slate-900 font-black">{entry.description}</td>
                          <td className="border border-amber-200 px-2.5 py-1.5 text-center">{entry.paraType || '-'}</td>
                          <td className="border border-amber-200 px-2.5 py-1.5 text-center">
                            <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 border border-amber-300 text-[10px] font-black">
                              {cleanType}
                            </span>
                          </td>
                          <td className="border border-amber-200 px-2.5 py-1.5 text-center">
                            {entry.diaryNo ? `${toBengaliDigits(entry.diaryNo)},` : '-'}<br style={{ msoDataPlacement: 'same-cell' } as any} />
                            <span className="text-[10px] text-slate-500">{formatDateBN(entry.diaryDate)}</span>
                          </td>
                          <td className="border border-amber-200 px-2.5 py-1.5 text-center">
                            {entry.letterNo ? `${toBengaliDigits(entry.letterNo)},` : '-'}<br style={{ msoDataPlacement: 'same-cell' } as any} />
                            <span className="text-[10px] text-slate-500">{formatDateBN(entry.letterDate)}</span>
                          </td>
                          <td className="border border-amber-200 px-2.5 py-1.5 text-center font-black text-emerald-700">
                            {toBengaliDigits(entry.totalParas || '০')} টি
                          </td>
                          <td className="border border-amber-200 px-2.5 py-1.5 text-center">
                            <span>{getDisplayName(entry.receiverName || hist.position)}</span>
                            <span className="block text-[9.5px] text-slate-500">({getDisplayName(hist.position)})</span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-[11px] font-bold text-slate-500 italic">
                নির্বাচিত সময়কালে মূল টেবিলের বাইরে কোনো বকেয়া কার্যপত্র বা অন্যান্য চিঠি নেই।
              </p>
            )}
          </div>
        </div>
      </div>
      {/* Auditor Statistics Modal */}
      {showAuditorStatsModal && createPortal(
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[99999] flex items-center justify-center p-4 xl:p-8 animate-in fade-in duration-200">
          <div className={`w-full ${isDetailsModalOpen ? 'max-w-[95%] lg:max-w-7xl h-[85vh]' : 'max-w-2xl max-h-[90vh]'} flex flex-col lg:flex-row items-stretch gap-4 transition-all duration-300`}>
            
            {/* Auditor Stats Card */}
            <div className={`bg-white rounded-3xl shadow-2xl overflow-hidden flex flex-col transition-all duration-300 ${isDetailsModalOpen ? 'w-full lg:w-[29%] shrink-0 h-full' : 'w-full max-h-full'}`}>
               <div className="bg-slate-900 px-6 py-3.5 flex items-center justify-between shrink-0">
                 <div className="flex items-center gap-3">
                   <div className="w-10 h-10 bg-blue-600/20 rounded-xl flex items-center justify-center">
                     <BarChart3 size={20} className="text-blue-400" />
                   </div>
                   <div>
                     <h3 className="text-white font-bold text-[16px]">অডিটর ভিত্তিক পরিসংখ্যান</h3>
                     <p className="text-slate-400 text-[11px] font-bold">কার কাছে কয়টি চিঠি আছে তার বিস্তারিত হিসাব</p>
                   </div>
                 </div>
                 <button 
                  onClick={() => {
                    setShowAuditorStatsModal(false);
                    setIsDetailsModalOpen(false);
                  }}
                  className="w-10 h-10 flex items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20 transition-all"
                >
                  <X size={20} />
                </button>
              </div>
              
              <div className={`overflow-y-auto no-scrollbar flex-1 min-h-0 ${isDetailsModalOpen ? 'p-2 sm:p-3' : 'p-3 sm:p-6'}`}>
                <table className="w-full border-collapse table-fixed">
                  <colgroup>
                    <col className={isDetailsModalOpen ? "w-[28%]" : "w-[36%]"} />
                    <col className={isDetailsModalOpen ? "w-[18%]" : "w-[16%]"} />
                    <col className={isDetailsModalOpen ? "w-[18%]" : "w-[16%]"} />
                    <col className={isDetailsModalOpen ? "w-[18%]" : "w-[16%]"} />
                    <col className={isDetailsModalOpen ? "w-[18%]" : "w-[16%]"} />
                  </colgroup>
                  <thead>
                    <tr className="bg-slate-100">
                      <th className={`${isDetailsModalOpen ? 'px-0.5 py-1 text-[8.5px] sm:text-[9.5px]' : 'px-1 py-1.5 text-[10px] sm:text-[11px]'} text-center font-black text-slate-700 leading-tight`}>অডিটর</th>
                      <th className={`${isDetailsModalOpen ? 'px-0.5 py-1 text-[8.5px] sm:text-[9.5px]' : 'px-1 py-1.5 text-[10px] sm:text-[11px]'} text-center font-black text-slate-700 leading-tight`}>অডিটরের</th>
                      <th className={`${isDetailsModalOpen ? 'px-0.5 py-1 text-[8.5px] sm:text-[9.5px]' : 'px-1 py-1.5 text-[10px] sm:text-[11px]'} text-center font-black text-slate-700 leading-tight`}>এএন্ডএও</th>
                      <th className={`${isDetailsModalOpen ? 'px-0.5 py-1 text-[8.5px] sm:text-[9.5px]' : 'px-1 py-1.5 text-[10px] sm:text-[11px]'} text-center font-black text-slate-700 leading-tight`}>উপপরিচালক</th>
                      <th className={`${isDetailsModalOpen ? 'px-0.5 py-1 text-[8.5px] sm:text-[9.5px]' : 'px-1 py-1.5 text-[10px] sm:text-[11px]'} text-center font-black text-slate-700 leading-tight`}>মোট</th>
                    </tr>
                  </thead>
                  <tbody>
                    {auditorWiseStats.map((stat, idx) => (
                      <tr key={idx} className="hover:bg-blue-50/50 transition-colors">
                        <td className={`${isDetailsModalOpen ? 'p-0.5' : 'px-1 py-2'} text-center align-middle overflow-hidden`}>
                          <div className="flex flex-col items-center justify-center gap-0.5 sm:gap-1 w-full mx-auto px-0.5 overflow-hidden">
                            {getDisplayImage(stat.name) ? (
                              <img 
                                src={getDisplayImage(stat.name)!} 
                                alt={getDisplayName(stat.name)} 
                                className={`${isDetailsModalOpen ? 'w-6 h-6 sm:w-7 sm:h-7 rounded-lg' : 'w-8 h-8 sm:w-10 sm:h-10 rounded-xl'} object-cover border border-slate-100 shrink-0 shadow-sm`} 
                                referrerPolicy="no-referrer"
                              />
                            ) : (
                              <div className={`${isDetailsModalOpen ? 'w-6 h-6 sm:w-7 sm:h-7 text-[8px] rounded-lg' : 'w-8 h-8 sm:w-10 sm:h-10 text-xs rounded-xl'} bg-blue-50 text-blue-600 flex items-center justify-center font-black shrink-0 uppercase shadow-sm`}>
                                {getDisplayName(stat.name).slice(0, 2)}
                              </div>
                            )}
                            <div className="flex flex-col items-center w-full min-w-0 overflow-hidden">
                              <span className={`${isDetailsModalOpen ? 'text-[7.5px] sm:text-[8px] tracking-tight' : 'text-[9.5px] sm:text-[11px]'} font-extrabold text-slate-800 leading-tight text-center break-words whitespace-normal w-full`}>{getDisplayName(stat.name)}</span>
                              <span className={`${isDetailsModalOpen ? 'text-[6.5px] sm:text-[7px]' : 'text-[7.5px] sm:text-[9px]'} font-bold text-slate-400 leading-none mt-0.5 text-center break-words whitespace-normal w-full`}>
                                {getDisplayDesignation(stat.name)}
                              </span>
                            </div>
                          </div>
                        </td>
                        <td 
                          className={`${isDetailsModalOpen ? 'px-0.5 py-1 text-[8.5px] sm:text-[10px]' : 'px-1 py-1.5 text-[10px] sm:text-[11.5px]'} text-center font-black text-red-600 bg-red-50/30 cursor-pointer hover:bg-red-100/50 transition-all ${getHighlightClass(`${getDisplayName(stat.name)} - অডিটরের কাছে`)}`}
                          onClick={() => handleCountClick(`${getDisplayName(stat.name)} - অডিটরের কাছে`, stat.auditorLetters)}
                        >
                          {toBengaliDigits(stat.auditor)} টি
                        </td>
                        <td 
                          className={`${isDetailsModalOpen ? 'px-0.5 py-1 text-[8.5px] sm:text-[10px]' : 'px-1 py-1.5 text-[10px] sm:text-[11.5px]'} text-center font-black text-blue-600 bg-blue-50/30 cursor-pointer hover:bg-blue-100/50 transition-all ${getHighlightClass(`${getDisplayName(stat.name)} - এএন্ডএও`)}`}
                          onClick={() => handleCountClick(`${getDisplayName(stat.name)} - এএন্ডএও`, stat.aaoLetters)}
                        >
                          {toBengaliDigits(stat.aao)} টি
                        </td>
                        <td 
                          className={`${isDetailsModalOpen ? 'px-0.5 py-1 text-[8.5px] sm:text-[10px]' : 'px-1 py-1.5 text-[10px] sm:text-[11.5px]'} text-center font-black text-green-600 bg-green-50/30 cursor-pointer hover:bg-green-100/50 transition-all ${getHighlightClass(`${getDisplayName(stat.name)} - উপপরিচালক`)}`}
                          onClick={() => handleCountClick(`${getDisplayName(stat.name)} - উপপরিচালক`, stat.ddLetters)}
                        >
                          {toBengaliDigits(stat.dd)} টি
                        </td>
                        <td 
                          className={`${isDetailsModalOpen ? 'px-0.5 py-1 text-[8.5px] sm:text-[10px]' : 'px-1 py-1.5 text-[10px] sm:text-[11.5px]'} text-center font-black text-slate-900 bg-slate-50 cursor-pointer hover:bg-slate-200/50 transition-all ${getHighlightClass(`${getDisplayName(stat.name)} - মোট`)}`}
                          onClick={() => handleCountClick(`${getDisplayName(stat.name)} - মোট`, stat.totalLetters)}
                        >
                          {toBengaliDigits(stat.total)} টি
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                
                {auditorWiseStats.length === 0 && (
                  <div className="py-10 text-center text-slate-400 font-bold italic">
                    কোনো তথ্য পাওয়া যায়নি।
                  </div>
                )}
              </div>
              
              <div className="bg-slate-50 px-6 py-3.5 flex justify-end border-t border-slate-100 shrink-0">
                <button 
                  onClick={() => {
                    setShowAuditorStatsModal(false);
                    setIsDetailsModalOpen(false);
                  }}
                  className="px-6 py-2 bg-slate-900 text-white rounded-xl font-bold text-[12px] hover:bg-slate-800 transition-all shadow-md"
                >
                  বন্ধ করুন
                </button>
              </div>
            </div>

            {/* Embedded letters detail card */}
            {isDetailsModalOpen && (
              <div className="w-full lg:flex-1 h-full flex flex-col overflow-hidden animate-in slide-in-from-right-8 duration-300">
                <LetterDetailsModal 
                  isOpen={isDetailsModalOpen}
                  onClose={() => setIsDetailsModalOpen(false)}
                  title={detailsModalTitle}
                  letters={detailsModalLetters}
                  isEmbedded={true}
                />
              </div>
            )}

          </div>
        </div>,
        document.body
      )}
      {/* Letter Details Modal (fallback only) */}
      {!showAuditorStatsModal && (
        <LetterDetailsModal 
          isOpen={isDetailsModalOpen}
          onClose={() => setIsDetailsModalOpen(false)}
          title={detailsModalTitle}
          letters={detailsModalLetters}
        />
      )}
    </div>
  );
};

  export default CorrespondenceDhakaReturn;