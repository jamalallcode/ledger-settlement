import React, { useMemo, useRef, useLayoutEffect, useState, useEffect } from 'react';
import { Printer, FileSpreadsheet, Sparkles, ChevronDown, Check, X, CalendarDays, Building2, Landmark } from 'lucide-react';
import { toBengaliDigits, toEnglishDigits, parseBengaliNumber } from '../utils/numberUtils';
import { format, subMonths, addMonths, setDate, format as dateFnsFormat } from 'date-fns';
import HighlightText from './HighlightText';
import { SettlementEntry } from '../types';
import { MINISTRY_ENTITY_MAP, ENTRY_START_DATE } from '../constants';
import { getQuarterlyCycleForDate } from '../utils/cycleHelper';

interface QRProps {
  entries: SettlementEntry[];
  prevStats: any;
  activeCycle: any;
  IDBadge: React.FC<{ id: string }>;
  onBack?: () => void;
  searchTerm?: string;
  filterMinistry?: string;
  monthPickerElement?: React.ReactNode;
  customTitle?: string;
}

const robustNormalize = (str: string = '') => {
  return str.normalize('NFC').replace(/[\u200B-\u200D\uFEFF]/g, '').replace(/\s+/g, ' ').trim();
};

const isEntityMatch = (entryEntity: string = '', targetEntity: string = ''): boolean => {
  const normEntry = robustNormalize(entryEntity);
  const normTarget = robustNormalize(targetEntity);
  if (!normEntry || !normTarget) return false;
  if (normEntry === normTarget) return true;

  // Cottage / Handicraft / Small Industries / BSCIC
  if ((normTarget.includes("কুটির") || normTarget.includes("হস্ত") || normTarget.includes("বিসিক")) && 
      (normEntry.includes("কুটির") || normEntry.includes("হস্ত") || normEntry.includes("বিসিক"))) return true;

  // Sugar & Food Industries (বিএসএফআইসি / চিনি ও খাদ্য)
  if ((normTarget.includes("চিনি") || normTarget.includes("খাদ্য") || normTarget.includes("বিএসএফআইসি")) && 
      (normEntry.includes("চিনি") || normEntry.includes("খাদ্য") || normEntry.includes("বিএসএফআইসি"))) return true;

  // Chemical Industries (BCIC / বিসিআইসি / রসায়ন)
  if ((normTarget.includes("রসায়ন") || normTarget.includes("রসায়ন") || normTarget.includes("বিসিআইসি")) && 
      (normEntry.includes("রসায়ন") || normEntry.includes("রসায়ন") || normEntry.includes("বিসিআইসি"))) return true;

  // Banks & Financial Institutions
  if (normTarget.includes("সোনালী") && normEntry.includes("সোনালী")) return true;
  if (normTarget.includes("জনতা") && normEntry.includes("জনতা")) return true;
  if (normTarget.includes("অগ্রণী") && normEntry.includes("অগ্রণী")) return true;
  if (normTarget.includes("রূপালী") && normEntry.includes("রূপালী")) return true;
  if (normTarget.includes("কৃষি") && normEntry.includes("কৃষি")) return true;
  if (normTarget.includes("বাংলাদেশ ব্যাংক") && normEntry.includes("বাংলাদেশ ব্যাংক")) return true;
  if (normTarget.includes("ডেভেলপমেন্ট") && normEntry.includes("ডেভেলপমেন্ট")) return true;
  if (normTarget.includes("গৃহনির্মাণ") && normEntry.includes("গৃহনির্মাণ")) return true;
  if (normTarget.includes("কর্মসংস্থান") && normEntry.includes("কর্মসংস্থান")) return true;
  if (normTarget.includes("বেসিক") && normEntry.includes("বেসিক")) return true;
  if (normTarget.includes("আনসার") && normEntry.includes("আনসার")) return true;
  if (normTarget.includes("ইনভেস্ট") && normEntry.includes("ইনভেস্ট")) return true;
  if (normTarget.includes("সাধারণ বীমা") && normEntry.includes("সাধারণ বীমা")) return true;
  if (normTarget.includes("জীবন বীমা") && normEntry.includes("জীবন বীমা")) return true;
  if (normTarget.includes("প্রবাসী কল্যাণ") && normEntry.includes("প্রবাসী কল্যাণ")) return true;

  // Jute & Textiles (Patkol vs Pat)
  const isPatkolTarget = normTarget.includes("পাটকল") || normTarget.includes("বিজেএমসি") || normTarget.includes("জুট");
  const isPatkolEntry = normEntry.includes("পাটকল") || normEntry.includes("বিজেএমসি") || normEntry.includes("জুট");
  if (isPatkolTarget || isPatkolEntry) return isPatkolTarget && isPatkolEntry;

  const isPatTarget = normTarget.includes("পাট") && !normTarget.includes("পাটকল") && !normTarget.includes("বিজেএমসি");
  const isPatEntry = normEntry.includes("পাট") && !normEntry.includes("পাটকল") && !normEntry.includes("বিজেএমসি");
  if (isPatTarget || isPatEntry) return isPatTarget && isPatEntry;

  // Commerce / Aviation / Tourism
  if (normTarget.includes("টিসিবি") && normEntry.includes("টিসিবি")) return true;
  if ((normTarget.includes("আমদানি") || normTarget.includes("রপ্তানি")) && 
      (normEntry.includes("আমদানি") || normEntry.includes("রপ্তানি"))) return true;
  if (normTarget.includes("বিমান") && normEntry.includes("বিমান")) return true;
  if (normTarget.includes("পর্যটন") && normEntry.includes("পর্যটন")) return true;

  return normEntry.includes(normTarget) || normTarget.includes(normEntry);
};

// Categorization helper
const isFinancialInstitution = (ministryName: string) => {
  return robustNormalize(ministryName).includes(robustNormalize('আর্থিক প্রতিষ্ঠান বিভাগ'));
};

const QR_3: React.FC<QRProps> = ({ entries, prevStats, activeCycle, IDBadge, searchTerm = '', filterMinistry = '', monthPickerElement, customTitle }) => {
  // Standard calendar quarter date calculation:
  // Quarters: Q1 (Jan-Mar), Q2 (Apr-Jun), Q3 (Jul-Sep), Q4 (Oct-Dec)
  // Each quarter start date is the 16th of the month preceding the quarter's start month.
  // Each quarter end date is the 15th of the quarter's end month.
  const getQuarterInfo = (date: Date) => {
    const cycleEndMonth = date.getMonth(); // 0 to 11
    const year = date.getFullYear();
    let quarterStartMonth = 0;
    let quarterEndMonth = 2;
    let quarterYear = year;

    if (cycleEndMonth >= 0 && cycleEndMonth <= 2) {
      quarterStartMonth = 0; // Jan
      quarterEndMonth = 2;   // Mar
    } else if (cycleEndMonth >= 3 && cycleEndMonth <= 5) {
      quarterStartMonth = 3; // Apr
      quarterEndMonth = 5;   // Jun
    } else if (cycleEndMonth >= 6 && cycleEndMonth <= 8) {
      quarterStartMonth = 6; // Jul
      quarterEndMonth = 8;   // Sep
    } else {
      quarterStartMonth = 9; // Oct
      quarterEndMonth = 11;  // Dec
    }

    const start = new Date(quarterYear, quarterStartMonth, 1);
    const end = new Date(quarterYear, quarterEndMonth + 1, 0);
    
    const months = ["জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"];
    const startMonthName = months[quarterStartMonth];
    const endMonthName = months[quarterEndMonth];
    
    const startYearShort = format(new Date(quarterYear, quarterStartMonth, 1), 'yy');
    const endYearShort = format(new Date(quarterYear, quarterEndMonth, 1), 'yy');

    const formattedRange = `${startMonthName}/${toBengaliDigits(startYearShort)} হতে ${endMonthName}/${toBengaliDigits(endYearShort)}`;
    
    return {
      startDate: start,
      endDate: end,
      startMonthName,
      endMonthName,
      formattedRange
    };
  };

  const { startDate, endDate, startMonthName, endMonthName, formattedRange } = getQuarterInfo(activeCycle.end);
  const prevMonthDate = subMonths(startDate, 1);

  const getPrevQuarterEndInfo = () => {
    const months = ["জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"];
    const cycleEndMonth = activeCycle.end.getMonth(); // 0 to 11
    const quarterYear = activeCycle.end.getFullYear();
    
    let quarterStartMonth = 0;
    if (cycleEndMonth >= 0 && cycleEndMonth <= 2) {
      quarterStartMonth = 0; // Jan
    } else if (cycleEndMonth >= 3 && cycleEndMonth <= 5) {
      quarterStartMonth = 3; // Apr
    } else if (cycleEndMonth >= 6 && cycleEndMonth <= 8) {
      quarterStartMonth = 6; // Jul
    } else {
      quarterStartMonth = 9; // Oct
    }
    
    let prevMonthIdx = 0;
    let prevYear = quarterYear;
    
    if (quarterStartMonth === 0) { // Jan
      prevMonthIdx = 11; // Dec
      prevYear = quarterYear - 1;
    } else if (quarterStartMonth === 3) { // Apr
      prevMonthIdx = 2; // Mar
    } else if (quarterStartMonth === 6) { // Jul
      prevMonthIdx = 5; // Jun
    } else if (quarterStartMonth === 9) { // Oct
      prevMonthIdx = 8; // Sep
    }
    
    return {
      monthName: months[prevMonthIdx],
      year: toBengaliDigits(prevYear.toString())
    };
  };
  
  const prevQuarterEnd = getPrevQuarterEndInfo();

  // Dynamic extraction of all Table 1 entities from MINISTRY_ENTITY_MAP
  const table1EntitiesList = useMemo(() => {
    const list: { ministryName: string; entityName: string }[] = [];
    Object.entries(MINISTRY_ENTITY_MAP).forEach(([mName, entities]) => {
      if (!isFinancialInstitution(mName)) {
        entities.forEach(ent => {
          list.push({ ministryName: mName, entityName: ent });
        });
      }
    });
    return list;
  }, []);

  // Dynamic extraction of all Table 2 entities from MINISTRY_ENTITY_MAP
  const table2EntitiesList = useMemo(() => {
    const list: { ministryName: string; entityName: string }[] = [];
    Object.entries(MINISTRY_ENTITY_MAP).forEach(([mName, entities]) => {
      if (isFinancialInstitution(mName)) {
        entities.forEach(ent => {
          list.push({ ministryName: mName, entityName: ent });
        });
      }
    });
    return list;
  }, []);

  const [isPrevLedgerOpen, setIsPrevLedgerOpen] = React.useState(false);
  const [isPrevLedgerTable2Open, setIsPrevLedgerTable2Open] = React.useState(false);

  // Multi-select filters state (Cycle, Ministry, Entity)
  const [selectedCycles, setSelectedCycles] = useState<string[]>([]);
  const [selectedMinistries, setSelectedMinistries] = useState<string[]>([]);
  const [selectedEntities, setSelectedEntities] = useState<string[]>([]);

  const [isCycleOpen, setIsCycleOpen] = useState(false);
  const [isMinOpen, setIsMinOpen] = useState(false);
  const [isEntOpen, setIsEntOpen] = useState(false);

  const cycleDropdownRef = useRef<HTMLDivElement>(null);
  const minDropdownRef = useRef<HTMLDivElement>(null);
  const entDropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (cycleDropdownRef.current && !cycleDropdownRef.current.contains(e.target as Node)) {
        setIsCycleOpen(false);
      }
      if (minDropdownRef.current && !minDropdownRef.current.contains(e.target as Node)) {
        setIsMinOpen(false);
      }
      if (entDropdownRef.current && !entDropdownRef.current.contains(e.target as Node)) {
        setIsEntOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const cycleOptions = useMemo(() => {
    const list: { label: string; start: Date; end: Date; startStr: string; endStr: string }[] = [];
    const baseDate = activeCycle?.end ? new Date(activeCycle.end) : new Date();
    for (let i = -3; i <= 3; i++) {
      const targetDate = addMonths(baseDate, i * 3);
      const c = getQuarterlyCycleForDate(targetDate);
      if (!list.some(item => item.label === c.label)) {
        list.push({
          label: c.label,
          start: c.start,
          end: c.end,
          startStr: format(c.start, 'yyyy-MM-dd'),
          endStr: format(c.end, 'yyyy-MM-dd'),
        });
      }
    }
    return list;
  }, [activeCycle]);

  const ministryOptions = useMemo(() => {
    return Object.keys(MINISTRY_ENTITY_MAP);
  }, []);

  const entityOptions = useMemo(() => {
    const set = new Set<string>();
    const entries = selectedMinistries.length > 0
      ? Object.entries(MINISTRY_ENTITY_MAP).filter(([m]) => selectedMinistries.includes(m))
      : Object.entries(MINISTRY_ENTITY_MAP);
    entries.forEach(([_, ents]) => ents.forEach(ent => set.add(ent)));
    return Array.from(set);
  }, [selectedMinistries]);

  const [cutoffMonth, setCutoffMonth] = React.useState(() => {
    const saved = localStorage.getItem('opening_balance_cutoff_month');
    if (saved) {
      const [y, m] = saved.split('-').map(Number);
      if (y > 2025 || (y === 2025 && m >= 12)) {
        return saved;
      }
    }
    return '2026-03';
  });

  const getMonthOptions = () => {
    const options = [];
    const currentDate = new Date();
    const currentYear = currentDate.getFullYear();
    const currentMonth = currentDate.getMonth();
    const startYear = 2024;
    const monthNamesBN = ["জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"];
    
    for (let y = currentYear; y >= startYear; y--) {
      const maxM = (y === currentYear) ? currentMonth : 11;
      for (let m = maxM; m >= 0; m--) {
        if (y < 2026 || (y === 2026 && m < 2)) {
          continue;
        }
        const val = `${y}-${String(m + 1).padStart(2, '0')}`;
        const lbl = `${monthNamesBN[m]}/${toBengaliDigits(y.toString())}`;
        options.push({ value: val, label: lbl });
      }
    }
    return options;
  };

  const getCutoffMonthInfo = (monthStr: string) => {
    const months = ["জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"];
    const [yearNum, monthNum] = monthStr.split('-').map(Number);
    const mIdx = monthNum - 1;
    const monthNameBN = months[mIdx];
    const yearBN = toBengaliDigits(yearNum.toString());
    const yearShortBN = toBengaliDigits(String(yearNum).slice(-2));
    
    const nextMonthDate = new Date(yearNum, mIdx + 1, 1);
    const nextMonthNameBN = months[nextMonthDate.getMonth()];
    const nextMonthYearBN = toBengaliDigits(nextMonthDate.getFullYear().toString());
    const nextMonthStrStr = `${nextMonthDate.getFullYear()}-${String(nextMonthDate.getMonth() + 1).padStart(2, '0')}-01`;

    return {
      monthNameBN,
      yearBN,
      yearShortBN,
      formattedLong: `${monthNameBN}/${yearBN}`,
      formattedShort: `${monthNameBN}/${yearShortBN}`,
      nextMonthNameBN,
      nextMonthYearBN,
      nextMonthFormattedLong: `${nextMonthNameBN}/${nextMonthYearBN}`,
      transitionStartStr: nextMonthStrStr
    };
  };

  const cutoffInfo = getCutoffMonthInfo(cutoffMonth);

  const getStorageKeyTable1 = (monthStr: string) => {
    if (monthStr === '2025-06') return 'qr3_table1_prev_ledger_june2025';
    return `qr3_table1_prev_ledger_${monthStr}`;
  };

  const getStorageKeyTable2 = (monthStr: string) => {
    if (monthStr === '2025-06') return 'qr3_table2_prev_ledger_june2025';
    return `qr3_table2_prev_ledger_${monthStr}`;
  };

  // Helper to get base starting values from prevStats
  const getEntityStats = (entName: string) => {
    const baseMap = (prevStats?.entitiesNonSFI && Object.keys(prevStats.entitiesNonSFI).length > 0)
      ? prevStats.entitiesNonSFI
      : (prevStats?.entitiesSFI || {});
    let stats = baseMap[entName];
    if (!stats) {
      const keys = Object.keys(baseMap);
      const foundKey = keys.find(k => robustNormalize(k).includes(robustNormalize(entName)) || robustNormalize(entName).includes(robustNormalize(k)));
      if (foundKey) {
        stats = baseMap[foundKey];
      }
    }
    return stats || { unsettledCount: 0, unsettledAmount: 0, settledCount: 0, settledAmount: 0 };
  };

  const [prevLedgerTable1Data, setPrevLedgerTable1Data] = React.useState<Record<string, { june25Raised: number; june25Settled: number; june25UnsettledAmount: number }>>(() => {
    const initialMonth = localStorage.getItem('opening_balance_cutoff_month') || '2025-06';
    const key = initialMonth === '2025-06' ? 'qr3_table1_prev_ledger_june2025' : `qr3_table1_prev_ledger_${initialMonth}`;
    const saved = localStorage.getItem(key);
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    const defaults: Record<string, { june25Raised: number; june25Settled: number; june25UnsettledAmount: number }> = {};
    table1EntitiesList.forEach(({ entityName }) => {
      const base = getEntityStats(entityName);
      defaults[entityName] = {
        june25Raised: (base?.unsettledCount || 0),
        june25Settled: (base?.settledCount || 0),
        june25UnsettledAmount: (base?.unsettledAmount || 0)
      };
    });
    return defaults;
  });

  const [prevLedgerTable2Data, setPrevLedgerTable2Data] = React.useState<Record<string, { june25Raised: number; june25Settled: number; june25UnsettledAmount: number }>>(() => {
    const initialMonth = localStorage.getItem('opening_balance_cutoff_month') || '2025-06';
    const key = initialMonth === '2025-06' ? 'qr3_table2_prev_ledger_june2025' : `qr3_table2_prev_ledger_${initialMonth}`;
    const saved = localStorage.getItem(key);
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    const defaults: Record<string, { june25Raised: number; june25Settled: number; june25UnsettledAmount: number }> = {};
    table2EntitiesList.forEach(({ entityName }) => {
      const base = getEntityStats(entityName);
      defaults[entityName] = {
        june25Raised: (base?.unsettledCount || 0),
        june25Settled: (base?.settledCount || 0),
        june25UnsettledAmount: (base?.unsettledAmount || 0)
      };
    });
    return defaults;
  });

  const handleSavePrevLedgerTable1 = (updated: typeof prevLedgerTable1Data) => {
    setPrevLedgerTable1Data(updated);
    localStorage.setItem(getStorageKeyTable1(cutoffMonth), JSON.stringify(updated));
  };

  const handleSavePrevLedgerTable2 = (updated: typeof prevLedgerTable2Data) => {
    setPrevLedgerTable2Data(updated);
    localStorage.setItem(getStorageKeyTable2(cutoffMonth), JSON.stringify(updated));
  };

  const handleInputChangeTable1 = (entName: string, field: 'june25Raised' | 'june25Settled' | 'june25UnsettledAmount', value: number) => {
    const updated = {
      ...prevLedgerTable1Data,
      [entName]: {
        ...(prevLedgerTable1Data[entName] || { june25Raised: 0, june25Settled: 0, june25UnsettledAmount: 0 }),
        [field]: value
      }
    };
    handleSavePrevLedgerTable1(updated);
  };

  const handleInputChangeTable2 = (entName: string, field: 'june25Raised' | 'june25Settled' | 'june25UnsettledAmount', value: number) => {
    const updated = {
      ...prevLedgerTable2Data,
      [entName]: {
        ...(prevLedgerTable2Data[entName] || { june25Raised: 0, june25Settled: 0, june25UnsettledAmount: 0 }),
        [field]: value
      }
    };
    handleSavePrevLedgerTable2(updated);
  };

  React.useEffect(() => {
    const key = getStorageKeyTable1(cutoffMonth);
    const saved = localStorage.getItem(key);
    if (saved) {
      try {
        setPrevLedgerTable1Data(JSON.parse(saved));
      } catch (e) {
        console.error(e);
      }
    } else {
      const defaults: Record<string, { june25Raised: number; june25Settled: number; june25UnsettledAmount: number }> = {};
      table1EntitiesList.forEach(({ entityName }) => {
        const base = getEntityStats(entityName);
        defaults[entityName] = {
          june25Raised: (base?.unsettledCount || 0),
          june25Settled: (base?.settledCount || 0),
          june25UnsettledAmount: (base?.unsettledAmount || 0)
        };
      });
      setPrevLedgerTable1Data(defaults);
    }
  }, [cutoffMonth]);

  React.useEffect(() => {
    const key = getStorageKeyTable2(cutoffMonth);
    const saved = localStorage.getItem(key);
    if (saved) {
      try {
        setPrevLedgerTable2Data(JSON.parse(saved));
      } catch (e) {
        console.error(e);
      }
    } else {
      const defaults: Record<string, { june25Raised: number; june25Settled: number; june25UnsettledAmount: number }> = {};
      table2EntitiesList.forEach(({ entityName }) => {
        const base = getEntityStats(entityName);
        defaults[entityName] = {
          june25Raised: (base?.unsettledCount || 0),
          june25Settled: (base?.settledCount || 0),
          june25UnsettledAmount: (base?.unsettledAmount || 0)
        };
      });
      setPrevLedgerTable2Data(defaults);
    }
  }, [cutoffMonth]);

  React.useEffect(() => {
    const handleReload = () => {
      const savedCutoff = localStorage.getItem('opening_balance_cutoff_month');
      if (savedCutoff) {
        setCutoffMonth(savedCutoff);
      }
      const activeCutoff = savedCutoff || cutoffMonth;
      const key1 = getStorageKeyTable1(activeCutoff);
      const saved1 = localStorage.getItem(key1);
      if (saved1) {
        try {
          setPrevLedgerTable1Data(JSON.parse(saved1));
        } catch (e) { console.error(e); }
      }
      const key2 = getStorageKeyTable2(activeCutoff);
      const saved2 = localStorage.getItem(key2);
      if (saved2) {
        try {
          setPrevLedgerTable2Data(JSON.parse(saved2));
        } catch (e) { console.error(e); }
      }
    };
    window.addEventListener('prev_ledgers_updated', handleReload);
    return () => window.removeEventListener('prev_ledgers_updated', handleReload);
  }, [cutoffMonth]);

  const prevLedgerRows = useMemo(() => {
    const rows: any[] = [];
    let sl = 1;
    
    table1EntitiesList.forEach(({ ministryName, entityName }) => {
      const ledger = prevLedgerTable1Data[entityName] || { june25Raised: 0, june25Settled: 0, june25UnsettledAmount: 0 };
      
      // Calculate transition settled and raised from July 1, 2025 up to cycle start
      const cycleStartStr = dateFnsFormat(startDate, 'yyyy-MM-dd');
      const transitionEntries = entries.filter(e => {
        if (robustNormalize(e.entityName) !== robustNormalize(entityName)) return false;
        if (robustNormalize(e.ministryName) !== robustNormalize(ministryName)) return false;
        if (robustNormalize(e.paraType || '') !== robustNormalize('নন এসএফআই')) return false;

        const entryDate = e.issueDateISO || (e.createdAt ? e.createdAt.split('T')[0] : '');
        return entryDate !== '' && entryDate >= cutoffInfo.transitionStartStr && entryDate < cycleStartStr;
      });

      let transitionRaisedCount = 0;
      let transitionRaisedAmount = 0;
      let transitionSettledCount = 0;
      let transitionSettledAmount = 0;
      const processedParaIds = new Set<string>();

      transitionEntries.forEach(entry => {
        const rCountRaw = entry.manualRaisedCount?.toString().trim() || "";
        if (rCountRaw !== "" && rCountRaw !== "0" && rCountRaw !== "০") {
          transitionRaisedCount += parseBengaliNumber(rCountRaw);
        }
        if (entry.manualRaisedAmount) transitionRaisedAmount += parseBengaliNumber(String(entry.manualRaisedAmount || '0'));

        if (entry.paragraphs) {
          entry.paragraphs.forEach(p => {
            const cleanParaNo = String(p.paraNo || '').trim();
            const hasDigit = /[১-৯1-9]/.test(cleanParaNo);
            if (p.id && !processedParaIds.has(p.id) && hasDigit) {
              processedParaIds.add(p.id);
              const status = robustNormalize(p.status || '');
              const settledAmt = parseBengaliNumber(String(p.recoveredAmount || '0')) + parseBengaliNumber(String(p.adjustedAmount || '0'));
              if (status === robustNormalize('পূর্ণাঙ্গ')) { 
                transitionSettledCount++; 
                transitionSettledAmount += settledAmt;
              }
            }
          });
        }
      });

      const unsettledCountJune25 = Math.max(0, ledger.june25Raised - ledger.june25Settled);
      const totalSettledCount = ledger.june25Settled + transitionSettledCount;
      const totalUnsettledCount = Math.max(0, ledger.june25Raised + transitionRaisedCount - totalSettledCount);
      const totalUnsettledAmount = Math.max(0, ledger.june25UnsettledAmount + transitionRaisedAmount - transitionSettledAmount);

      rows.push({
        sl,
        ministryName,
        entityName,
        june25Raised: ledger.june25Raised,
        june25Settled: ledger.june25Settled,
        unsettledCountJune25,
        june25UnsettledAmount: ledger.june25UnsettledAmount,
        transitionRaisedCount,
        transitionRaisedAmount,
        transitionSettledCount,
        transitionSettledAmount,
        totalSettledCount,
        totalUnsettledCount,
        totalUnsettledAmount
      });
      
      sl++;
    });

    return rows;
  }, [prevLedgerTable1Data, entries, startDate, table1EntitiesList]);

  const prevLedgerTable2Rows = useMemo(() => {
    const rows: any[] = [];
    let sl = 1;
    
    table2EntitiesList.forEach(({ ministryName, entityName }) => {
      const ledger = prevLedgerTable2Data[entityName] || { june25Raised: 0, june25Settled: 0, june25UnsettledAmount: 0 };
      
      // Calculate transition settled and raised from July 1, 2025 up to cycle start
      const cycleStartStr = dateFnsFormat(startDate, 'yyyy-MM-dd');
      const transitionEntries = entries.filter(e => {
        if (robustNormalize(e.entityName) !== robustNormalize(entityName)) return false;
        if (robustNormalize(e.ministryName) !== robustNormalize(ministryName)) return false;
        if (robustNormalize(e.paraType || '') !== robustNormalize('নন এসএফআই')) return false;

        const entryDate = e.issueDateISO || (e.createdAt ? e.createdAt.split('T')[0] : '');
        return entryDate !== '' && entryDate >= cutoffInfo.transitionStartStr && entryDate < cycleStartStr;
      });

      let transitionRaisedCount = 0;
      let transitionRaisedAmount = 0;
      let transitionSettledCount = 0;
      let transitionSettledAmount = 0;
      const processedParaIds = new Set<string>();

      transitionEntries.forEach(entry => {
        const rCountRaw = entry.manualRaisedCount?.toString().trim() || "";
        if (rCountRaw !== "" && rCountRaw !== "0" && rCountRaw !== "০") {
          transitionRaisedCount += parseBengaliNumber(rCountRaw);
        }
        if (entry.manualRaisedAmount) transitionRaisedAmount += parseBengaliNumber(String(entry.manualRaisedAmount || '0'));

        if (entry.paragraphs) {
          entry.paragraphs.forEach(p => {
            const cleanParaNo = String(p.paraNo || '').trim();
            const hasDigit = /[১-৯1-9]/.test(cleanParaNo);
            if (p.id && !processedParaIds.has(p.id) && hasDigit) {
              processedParaIds.add(p.id);
              const status = robustNormalize(p.status || '');
              const settledAmt = parseBengaliNumber(String(p.recoveredAmount || '0')) + parseBengaliNumber(String(p.adjustedAmount || '0'));
              if (status === robustNormalize('পূর্ণাঙ্গ')) { 
                transitionSettledCount++; 
                transitionSettledAmount += settledAmt;
              }
            }
          });
        }
      });

      const unsettledCountJune25 = Math.max(0, ledger.june25Raised - ledger.june25Settled);
      const totalSettledCount = ledger.june25Settled + transitionSettledCount;
      const totalUnsettledCount = Math.max(0, ledger.june25Raised + transitionRaisedCount - totalSettledCount);
      const totalUnsettledAmount = Math.max(0, ledger.june25UnsettledAmount + transitionRaisedAmount - transitionSettledAmount);

      rows.push({
        sl,
        ministryName,
        entityName,
        june25Raised: ledger.june25Raised,
        june25Settled: ledger.june25Settled,
        unsettledCountJune25,
        june25UnsettledAmount: ledger.june25UnsettledAmount,
        transitionRaisedCount,
        transitionRaisedAmount,
        transitionSettledCount,
        transitionSettledAmount,
        totalSettledCount,
        totalUnsettledCount,
        totalUnsettledAmount
      });
      
      sl++;
    });

    return rows;
  }, [prevLedgerTable2Data, entries, startDate, table2EntitiesList]);

  const handlePaste = (
    e: React.ClipboardEvent<HTMLInputElement>,
    startRowIndex: number,
    startColField: 'june25Raised' | 'june25Settled' | 'june25UnsettledAmount'
  ) => {
    const text = e.clipboardData.getData('text');
    if (!text.includes('\t') && !text.includes('\n')) {
      return;
    }

    e.preventDefault();

    const pastedRows = text
      .split(/\r?\n/)
      .map(row => row.split('\t'))
      .filter(row => row.length > 0 && !(row.length === 1 && row[0] === ''));

    if (pastedRows.length === 0) return;

    const fields: Array<'june25Raised' | 'june25Settled' | 'june25UnsettledAmount'> = [
      'june25Raised',
      'june25Settled',
      'june25UnsettledAmount'
    ];
    const startColIndex = fields.indexOf(startColField);

    const updated = { ...prevLedgerTable1Data };

    for (let r = 0; r < pastedRows.length; r++) {
      const rowIndex = startRowIndex + r;
      if (rowIndex >= prevLedgerRows.length) break;

      const entityName = prevLedgerRows[rowIndex].entityName;
      if (!entityName) continue;

      const pastedCols = pastedRows[r];
      for (let c = 0; c < pastedCols.length; c++) {
        const colIndex = startColIndex + c;
        if (colIndex >= fields.length) break;

        const field = fields[colIndex];
        const rawValue = pastedCols[c].trim();
        const value = parseBengaliNumber(rawValue);

        if (!updated[entityName]) {
          updated[entityName] = { june25Raised: 0, june25Settled: 0, june25UnsettledAmount: 0 };
        }
        updated[entityName][field] = value;
      }
    }

    handleSavePrevLedgerTable1(updated);
  };

  const handlePasteTable2 = (
    e: React.ClipboardEvent<HTMLInputElement>,
    startRowIndex: number,
    startColField: 'june25Raised' | 'june25Settled' | 'june25UnsettledAmount'
  ) => {
    const text = e.clipboardData.getData('text');
    if (!text.includes('\t') && !text.includes('\n')) {
      return;
    }

    e.preventDefault();

    const pastedRows = text
      .split(/\r?\n/)
      .map(row => row.split('\t'))
      .filter(row => row.length > 0 && !(row.length === 1 && row[0] === ''));

    if (pastedRows.length === 0) return;

    const fields: Array<'june25Raised' | 'june25Settled' | 'june25UnsettledAmount'> = [
      'june25Raised',
      'june25Settled',
      'june25UnsettledAmount'
    ];
    const startColIndex = fields.indexOf(startColField);

    const updated = { ...prevLedgerTable2Data };

    for (let r = 0; r < pastedRows.length; r++) {
      const rowIndex = startRowIndex + r;
      if (rowIndex >= prevLedgerTable2Rows.length) break;

      const entityName = prevLedgerTable2Rows[rowIndex].entityName;
      if (!entityName) continue;

      const pastedCols = pastedRows[r];
      for (let c = 0; c < pastedCols.length; c++) {
        const colIndex = startColIndex + c;
        if (colIndex >= fields.length) break;

        const field = fields[colIndex];
        const rawValue = pastedCols[c].trim();
        const value = parseBengaliNumber(rawValue);

        if (!updated[entityName]) {
          updated[entityName] = { june25Raised: 0, june25Settled: 0, june25UnsettledAmount: 0 };
        }
        updated[entityName][field] = value;
      }
    }

    handleSavePrevLedgerTable2(updated);
  };

  const prevLedgerGrandTotals = useMemo(() => {
    return prevLedgerRows.reduce((acc, row) => {
      acc.june25Raised += row.june25Raised;
      acc.june25Settled += row.june25Settled;
      acc.unsettledCountJune25 += row.unsettledCountJune25;
      acc.june25UnsettledAmount += row.june25UnsettledAmount;
      acc.transitionRaisedCount += row.transitionRaisedCount;
      acc.transitionRaisedAmount += row.transitionRaisedAmount;
      acc.transitionSettledCount += row.transitionSettledCount;
      acc.transitionSettledAmount += row.transitionSettledAmount;
      acc.totalSettledCount += row.totalSettledCount;
      acc.totalUnsettledCount += row.totalUnsettledCount;
      acc.totalUnsettledAmount += row.totalUnsettledAmount;
      return acc;
    }, {
      june25Raised: 0, june25Settled: 0, unsettledCountJune25: 0, june25UnsettledAmount: 0,
      transitionRaisedCount: 0, transitionRaisedAmount: 0, transitionSettledCount: 0, transitionSettledAmount: 0,
      totalSettledCount: 0, totalUnsettledCount: 0, totalUnsettledAmount: 0
    });
  }, [prevLedgerRows]);

  const prevLedgerTable2GrandTotals = useMemo(() => {
    return prevLedgerTable2Rows.reduce((acc, row) => {
      acc.june25Raised += row.june25Raised;
      acc.june25Settled += row.june25Settled;
      acc.unsettledCountJune25 += row.unsettledCountJune25;
      acc.june25UnsettledAmount += row.june25UnsettledAmount;
      acc.transitionRaisedCount += row.transitionRaisedCount;
      acc.transitionRaisedAmount += row.transitionRaisedAmount;
      acc.transitionSettledCount += row.transitionSettledCount;
      acc.transitionSettledAmount += row.transitionSettledAmount;
      acc.totalSettledCount += row.totalSettledCount;
      acc.totalUnsettledCount += row.totalUnsettledCount;
      acc.totalUnsettledAmount += row.totalUnsettledAmount;
      return acc;
    }, {
      june25Raised: 0, june25Settled: 0, unsettledCountJune25: 0, june25UnsettledAmount: 0,
      transitionRaisedCount: 0, transitionRaisedAmount: 0, transitionSettledCount: 0, transitionSettledAmount: 0,
      totalSettledCount: 0, totalUnsettledCount: 0, totalUnsettledAmount: 0
    });
  }, [prevLedgerTable2Rows]);

  const downloadPrevLedgerExcel = () => {
    const tableElement = document.getElementById('prev-ledger-table-modal');
    if (!tableElement) return;

    const clonedTable = tableElement.cloneNode(true) as HTMLTableElement;
    const interactiveElements = clonedTable.querySelectorAll('.no-print, button, svg, input, select');
    // Replace inputs with text values in the cloned table
    const inputs = clonedTable.querySelectorAll('input');
    inputs.forEach(input => {
      const parent = input.parentNode;
      if (parent) {
        parent.textContent = input.value;
      }
    });
    interactiveElements.forEach(el => el.remove());

    const filename = `পূর্ব_জের_টেবিল_১_${dateFnsFormat(new Date(), 'yyyy-MM-dd')}.xls`;

    const template = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
      <head>
        <meta http-equiv="content-type" content="application/vnd.ms-excel; charset=UTF-8">
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif, 'Hind Siliguri', sans-serif; }
          table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }
          th, td { border: 1px solid #cbd5e1 !important; padding: 8px 12px !important; text-align: center; font-size: 11px; vertical-align: middle; }
          th { background-color: #f1f5f9 !important; color: #0f172a !important; font-weight: bold !important; }
          .bg-slate-200, thead, tfoot { background-color: #e2e8f0 !important; font-weight: bold !important; }
          tfoot td { background-color: #0f172a !important; color: #ffffff !important; font-weight: bold !important; }
        </style>
      </head>
      <body>
        <h2 style="text-align: center; margin-bottom: 20px; color: #1e3a8a;">টেবিল-১ এর পূর্ব জের (জুলাই/২০২৫ হতে ${prevQuarterEnd.monthName}/${prevQuarterEnd.year} পর্যন্ত)</h2>
        ${clonedTable.outerHTML}
      </body>
      </html>
    `;

    const blob = new Blob([template], { type: 'application/vnd.ms-excel;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const downloadPrevLedgerTable2Excel = () => {
    const tableElement = document.getElementById('prev-ledger-table-2-modal');
    if (!tableElement) return;

    const clonedTable = tableElement.cloneNode(true) as HTMLTableElement;
    const interactiveElements = clonedTable.querySelectorAll('.no-print, button, svg, input, select');
    // Replace inputs with text values in the cloned table
    const inputs = clonedTable.querySelectorAll('input');
    inputs.forEach(input => {
      const parent = input.parentNode;
      if (parent) {
        parent.textContent = input.value;
      }
    });
    interactiveElements.forEach(el => el.remove());

    const filename = `পূর্ব_জের_টেবিল_২_${dateFnsFormat(new Date(), 'yyyy-MM-dd')}.xls`;

    const template = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
      <head>
        <meta http-equiv="content-type" content="application/vnd.ms-excel; charset=UTF-8">
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif, 'Hind Siliguri', sans-serif; }
          table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }
          th, td { border: 1px solid #cbd5e1 !important; padding: 8px 12px !important; text-align: center; font-size: 11px; vertical-align: middle; }
          th { background-color: #f1f5f9 !important; color: #0f172a !important; font-weight: bold !important; }
          .bg-slate-200, thead, tfoot { background-color: #e2e8f0 !important; font-weight: bold !important; }
          tfoot td { background-color: #0f172a !important; color: #ffffff !important; font-weight: bold !important; }
        </style>
      </head>
      <body>
        <h2 style="text-align: center; margin-bottom: 20px; color: #1e3a8a;">টেবিল-২ এর পূর্ব জের (জুলাই/২০২৫ হতে ${prevQuarterEnd.monthName}/${prevQuarterEnd.year} পর্যন্ত)</h2>
        ${clonedTable.outerHTML}
      </body>
      </html>
    `;

    const blob = new Blob([template], { type: 'application/vnd.ms-excel;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const formatNumberSimple = (val: number | undefined | null) => {
    if (val === undefined || val === null || val === 0) return '০';
    return toBengaliDigits(Math.round(val).toString());
  };

  const renderPrevLedgerModal = () => {
    if (!isPrevLedgerOpen) return null;

    return (
      <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[11000] flex items-center justify-center p-4 animate-in fade-in duration-300 no-print">
        <div className="bg-white rounded-3xl border-2 border-slate-300 w-full max-w-7xl max-h-[92vh] overflow-hidden flex flex-col shadow-2xl animate-in zoom-in-95 duration-300 text-left">
          
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
            <div className="text-left flex flex-col md:flex-row md:items-center gap-4">
              <div>
                <h2 className="text-[15px] font-black text-slate-900 flex items-center gap-2">
                  <Sparkles size={18} className="text-amber-500" />
                  টেবিল-১ এর পূর্ব জের সেটআপ ও গণনা তালিকা
                </h2>
                <p className="text-[10px] font-bold text-slate-500 mt-1">
                  ১৯৭১-৭২ হতে {cutoffInfo.formattedLong} পর্যন্ত উত্থাপিত ও নিষ্পত্তিকৃত আপত্তির সংখ্যাগুলো ইনপুট দিন। {cutoffInfo.nextMonthFormattedLong} হতে নিষ্পত্তি স্বয়ংক্রিয়ভাবে হিসাব হবে।
                </p>
              </div>

              {/* Dynamic Month Selector */}
              <div className="flex items-center gap-2.5 bg-gradient-to-r from-amber-50 to-amber-100/50 border border-amber-200/80 rounded-xl px-3.5 py-1.5 shadow-sm text-xs shrink-0">
                <span className="font-extrabold text-amber-900 tracking-wide">জেরের মাস:</span>
                <select
                  value={cutoffMonth}
                  onChange={(e) => {
                    setCutoffMonth(e.target.value);
                    localStorage.setItem('opening_balance_cutoff_month', e.target.value);
                  }}
                  className="bg-white border border-amber-300 rounded-lg px-2.5 py-1 font-black text-slate-800 focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 focus:outline-none cursor-pointer shadow-sm hover:bg-slate-50 transition-all text-xs"
                >
                  {getMonthOptions().map(opt => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                  ))}
                </select>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  if (window.confirm("আপনি কি নিশ্চিতভাবে সকল পূর্ব জের তথ্য রিসেট করতে চান?")) {
                    localStorage.removeItem(getStorageKeyTable1(cutoffMonth));
                    const defaults: Record<string, { june25Raised: number; june25Settled: number; june25UnsettledAmount: number }> = {};
                    table1EntitiesList.forEach(({ entityName }) => {
                      const base = getEntityStats(entityName);
                      defaults[entityName] = {
                        june25Raised: (base?.unsettledCount || 0),
                        june25Settled: (base?.settledCount || 0),
                        june25UnsettledAmount: (base?.unsettledAmount || 0)
                      };
                    });
                    setPrevLedgerTable1Data(defaults);
                  }
                }}
                className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl font-black text-[10px] border border-rose-200 transition-all cursor-pointer"
              >
                রিসেট করুন
              </button>
              <button
                type="button"
                onClick={downloadPrevLedgerExcel}
                className="p-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 rounded-xl cursor-pointer"
                title="এক্সেল ফাইল ডাউনলোড করুন"
              >
                <FileSpreadsheet size={16} />
              </button>
              <button
                type="button"
                onClick={() => setIsPrevLedgerOpen(false)}
                className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl cursor-pointer border border-slate-200"
              >
                ✕
              </button>
            </div>
          </div>

          {/* Table Container */}
          <div className="flex-1 overflow-auto bg-white relative">
            <div className="p-6 pt-0">
              <table id="prev-ledger-table-modal" className="w-full border-separate border-spacing-0 border-l border-t border-slate-400 !table-auto text-center">
                <thead className="bg-slate-100 sticky top-0 z-20 shadow-sm">
                  <tr>
                    <th className={`${thCls} w-[45px]`} rowSpan={2}>ক্র নং</th>
                    <th className={`${thCls} w-[150px]`} rowSpan={2}>মন্ত্রণালয়ের নাম</th>
                    <th className={`${thCls} w-[180px]`} rowSpan={2}>সংস্থার নাম</th>
                    <th className={`${thCls} w-[130px]`} colSpan={3}>{cutoffInfo.formattedLong} পর্যন্ত প্রারম্ভিক জের (ইনপুট)</th>
                    <th className={`${thCls} w-[240px]`} colSpan={4}>{cutoffInfo.nextMonthFormattedLong} হতে {prevQuarterEnd.monthName}/{prevQuarterEnd.year} পর্যন্ত সমন্বয় (রেজিস্টার হতে)</th>
                    <th className={`${thCls} w-[300px]`} colSpan={3}>১৯৭১-৭২ হতে {prevQuarterEnd.monthName}/{prevQuarterEnd.year} পর্যন্ত মোট সমন্বয়কৃত পূর্ব জের</th>
                  </tr>
                  <tr>
                    <th className={thCls}>১৯৭১-৭২ হতে {cutoffInfo.formattedShort} উত্থাপিত</th>
                    <th className={thCls}>১৯৭১-৭২ হতে {cutoffInfo.formattedShort} নিষ্পত্তিকৃত</th>
                    <th className={thCls}>{cutoffInfo.formattedShort} অমীমাংসিত টাকা</th>
                    <th className={thCls}>উত্থাপিত সংখ্যা</th>
                    <th className={thCls}>উত্থাপিত টাকা</th>
                    <th className={thCls}>নিষ্পত্তিকৃত সংখ্যা</th>
                    <th className={thCls}>নিষ্পত্তিকৃত টাকা</th>
                    <th className={thCls}>মোট নিষ্পত্তিকৃত সংখ্যা</th>
                    <th className={thCls}>মোট অনিষ্পন্ন সংখ্যা</th>
                    <th className={thCls}>মোট অনিষ্পন্ন টাকা</th>
                  </tr>
                  <tr className="bg-slate-50 text-[9px] font-black text-slate-500">
                    {["১", "২", "৩", "৪ (ইনপুট)", "৫ (ইনপুট)", "৬ (ইনপুট)", "৭ (উত্থাপন)", "৮ (উত্থাপন)", "৯ (মীমাংসা)", "১০ (মীমাংসা)", "১১=৫+৯", "১২=৪+৭-১১", "১৩=৬+৮-১০"].map((l, i) => (
                      <th key={i} className={thCls + " py-1"}>{l}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {prevLedgerRows.map((row, idx) => {
                    const showMinistry = idx === 0 || prevLedgerRows[idx - 1].ministryName !== row.ministryName;
                    const rowSpan = prevLedgerRows.filter(r => r.ministryName === row.ministryName).length;

                    return (
                      <tr key={row.entityName} className="hover:bg-slate-50 transition-colors">
                        <td className={numTdCls}>{toBengaliDigits(row.sl.toString())}</td>
                        {showMinistry && (
                          <td rowSpan={rowSpan} className={tdCls + " text-[10px] font-black text-center bg-slate-50/10"}>
                            {row.ministryName}
                          </td>
                        )}
                        <td className={tdCls + " text-[10px] font-bold text-left"}>{row.entityName}</td>
                        
                        {/* Input fields with copy-paste listeners */}
                        <td className="border-r border-b border-slate-400 p-1 bg-amber-50/20">
                          <input
                            type="text"
                            className="w-full text-center font-black text-xs bg-amber-50/30 hover:bg-amber-100/40 focus:bg-white border border-amber-200 hover:border-amber-300 focus:border-blue-500 rounded px-1.5 py-1 text-slate-900 outline-none transition-all"
                            value={row.june25Raised === 0 ? '' : toBengaliDigits(row.june25Raised.toString())}
                            placeholder="০"
                            onChange={e => {
                              const val = parseBengaliNumber(e.target.value);
                              handleInputChangeTable1(row.entityName, 'june25Raised', val);
                            }}
                            onPaste={e => handlePaste(e, idx, 'june25Raised')}
                          />
                        </td>
                        <td className="border-r border-b border-slate-400 p-1 bg-amber-50/20">
                          <input
                            type="text"
                            className="w-full text-center font-black text-xs bg-amber-50/30 hover:bg-amber-100/40 focus:bg-white border border-amber-200 hover:border-amber-300 focus:border-blue-500 rounded px-1.5 py-1 text-slate-900 outline-none transition-all"
                            value={row.june25Settled === 0 ? '' : toBengaliDigits(row.june25Settled.toString())}
                            placeholder="০"
                            onChange={e => {
                              const val = parseBengaliNumber(e.target.value);
                              handleInputChangeTable1(row.entityName, 'june25Settled', val);
                            }}
                            onPaste={e => handlePaste(e, idx, 'june25Settled')}
                          />
                        </td>
                        <td className="border-r border-b border-slate-400 p-1 bg-amber-50/20">
                          <input
                            type="text"
                            className="w-full text-center font-black text-xs bg-amber-50/30 hover:bg-amber-100/40 focus:bg-white border border-amber-200 hover:border-amber-300 focus:border-blue-500 rounded px-1.5 py-1 text-slate-900 outline-none transition-all"
                            value={row.june25UnsettledAmount === 0 ? '' : toBengaliDigits(row.june25UnsettledAmount.toString())}
                            placeholder="০"
                            onChange={e => {
                              const val = parseBengaliNumber(e.target.value);
                              handleInputChangeTable1(row.entityName, 'june25UnsettledAmount', val);
                            }}
                            onPaste={e => handlePaste(e, idx, 'june25UnsettledAmount')}
                          />
                        </td>

                        {/* Read only calculated transition values */}
                        <td className={numTdCls + " bg-slate-50 text-slate-700 font-bold"}>
                          {formatNumberSimple(row.transitionRaisedCount)}
                        </td>
                        <td className={numTdCls + " bg-slate-50 text-slate-700 font-bold"}>
                          {row.transitionRaisedAmount === 0 ? '০' : formatNumberSimple(row.transitionRaisedAmount)}
                        </td>
                        <td className={numTdCls + " bg-slate-50 text-slate-700 font-bold"}>
                          {formatNumberSimple(row.transitionSettledCount)}
                        </td>
                        <td className={numTdCls + " bg-slate-50 text-emerald-700 font-extrabold"}>
                          {row.transitionSettledAmount === 0 ? '০' : formatNumberSimple(row.transitionSettledAmount)}
                        </td>

                        {/* Cumulative balances */}
                        <td className={numTdCls + " bg-blue-50/10 font-bold text-slate-900"}>
                          {formatNumberSimple(row.totalSettledCount)}
                        </td>
                        <td className={numTdCls + " bg-blue-50/20 font-black text-blue-900"}>
                          {formatNumberSimple(row.totalUnsettledCount)}
                        </td>
                        <td className={numTdCls + " bg-blue-50/30 font-extrabold text-slate-900"}>
                          {row.totalUnsettledAmount === 0 ? '০' : formatNumberSimple(row.totalUnsettledAmount)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="bg-slate-200 font-extrabold text-[10px] text-slate-900">
                    <td className={footerTdCls} colSpan={3}>সর্বমোট</td>
                    <td className={footerNumTdCls}>{formatNumberSimple(prevLedgerGrandTotals.june25Raised)}</td>
                    <td className={footerNumTdCls}>{formatNumberSimple(prevLedgerGrandTotals.june25Settled)}</td>
                    <td className={footerNumTdCls}>{formatNumberSimple(prevLedgerGrandTotals.june25UnsettledAmount)}</td>
                    <td className={footerNumTdCls}>{formatNumberSimple(prevLedgerGrandTotals.transitionRaisedCount)}</td>
                    <td className={footerNumTdCls}>{formatNumberSimple(prevLedgerGrandTotals.transitionRaisedAmount)}</td>
                    <td className={footerNumTdCls}>{formatNumberSimple(prevLedgerGrandTotals.transitionSettledCount)}</td>
                    <td className={footerNumTdCls}>{formatNumberSimple(prevLedgerGrandTotals.transitionSettledAmount)}</td>
                    <td className={footerNumTdCls}>{formatNumberSimple(prevLedgerGrandTotals.totalSettledCount)}</td>
                    <td className={footerNumTdCls + " text-blue-900"}>{formatNumberSimple(prevLedgerGrandTotals.totalUnsettledCount)}</td>
                    <td className={footerNumTdCls}>{formatNumberSimple(prevLedgerGrandTotals.totalUnsettledAmount)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

          {/* Footer controls */}
          <div className="px-6 py-4 border-t border-slate-200 bg-slate-50 flex justify-end">
            <button
              type="button"
              onClick={() => setIsPrevLedgerOpen(false)}
              className="px-8 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-black text-xs transition-all cursor-pointer shadow-lg active:scale-95 border-b-4 border-blue-800"
            >
              সংরক্ষণ করুন ও বন্ধ করুন
            </button>
          </div>

        </div>
      </div>
    );
  };

  const renderPrevLedgerTable2Modal = () => {
    if (!isPrevLedgerTable2Open) return null;

    return (
      <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[11000] flex items-center justify-center p-4 animate-in fade-in duration-300 no-print">
        <div className="bg-white rounded-3xl border-2 border-slate-300 w-full max-w-7xl max-h-[92vh] overflow-hidden flex flex-col shadow-2xl animate-in zoom-in-95 duration-300 text-left">
          
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
            <div className="text-left flex flex-col md:flex-row md:items-center gap-4">
              <div>
                <h2 className="text-[15px] font-black text-slate-900 flex items-center gap-2">
                  <Sparkles size={18} className="text-amber-500" />
                  টেবিল-২ এর পূর্ব জের সেটআপ ও গণনা তালিকা
                </h2>
                <p className="text-[10px] font-bold text-slate-500 mt-1">
                  ১৯৭১-৭২ হতে {cutoffInfo.formattedLong} পর্যন্ত উত্থাপিত ও নিষ্পত্তিকৃত আপত্তির সংখ্যাগুলো ইনপুট দিন। {cutoffInfo.nextMonthFormattedLong} হতে নিষ্পত্তি স্বয়ংক্রিয়ভাবে হিসাব হবে।
                </p>
              </div>

              {/* Dynamic Month Selector */}
              <div className="flex items-center gap-2.5 bg-gradient-to-r from-amber-50 to-amber-100/50 border border-amber-200/80 rounded-xl px-3.5 py-1.5 shadow-sm text-xs shrink-0">
                <span className="font-extrabold text-amber-900 tracking-wide">জেরের মাস:</span>
                <select
                  value={cutoffMonth}
                  onChange={(e) => {
                    setCutoffMonth(e.target.value);
                    localStorage.setItem('opening_balance_cutoff_month', e.target.value);
                  }}
                  className="bg-white border border-amber-300 rounded-lg px-2.5 py-1 font-black text-slate-800 focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 focus:outline-none cursor-pointer shadow-sm hover:bg-slate-50 transition-all text-xs"
                >
                  {getMonthOptions().map(opt => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                  ))}
                </select>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  if (window.confirm("আপনি কি নিশ্চিতভাবে সকল পূর্ব জের তথ্য রিসেট করতে চান?")) {
                    localStorage.removeItem(getStorageKeyTable2(cutoffMonth));
                    const defaults: Record<string, { june25Raised: number; june25Settled: number; june25UnsettledAmount: number }> = {};
                    table2EntitiesList.forEach(({ entityName }) => {
                      const base = getEntityStats(entityName);
                      defaults[entityName] = {
                        june25Raised: (base?.unsettledCount || 0),
                        june25Settled: (base?.settledCount || 0),
                        june25UnsettledAmount: (base?.unsettledAmount || 0)
                      };
                    });
                    setPrevLedgerTable2Data(defaults);
                  }
                }}
                className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl font-black text-[10px] border border-rose-200 transition-all cursor-pointer"
              >
                রিসেট করুন
              </button>
              <button
                type="button"
                onClick={downloadPrevLedgerTable2Excel}
                className="p-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 rounded-xl cursor-pointer"
                title="এক্সেল ফাইল ডাউনলোড করুন"
              >
                <FileSpreadsheet size={16} />
              </button>
              <button
                type="button"
                onClick={() => setIsPrevLedgerTable2Open(false)}
                className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl cursor-pointer border border-slate-200"
              >
                ✕
              </button>
            </div>
          </div>

          {/* Table Container */}
          <div className="flex-1 overflow-auto bg-white relative">
            <div className="p-6 pt-0">
              <table id="prev-ledger-table-2-modal" className="w-full border-separate border-spacing-0 border-l border-t border-slate-400 !table-auto text-center">
                <thead className="bg-slate-100 sticky top-0 z-20 shadow-sm">
                  <tr>
                    <th className={`${thCls} w-[45px]`} rowSpan={2}>ক্র নং</th>
                    <th className={`${thCls} w-[150px]`} rowSpan={2}>মন্ত্রণালয়ের নাম</th>
                    <th className={`${thCls} w-[180px]`} rowSpan={2}>সংস্থার নাম</th>
                    <th className={`${thCls} w-[130px]`} colSpan={3}>{cutoffInfo.formattedLong} পর্যন্ত প্রারম্ভিক জের (ইনপুট)</th>
                    <th className={`${thCls} w-[240px]`} colSpan={4}>{cutoffInfo.nextMonthFormattedLong} হতে {prevQuarterEnd.monthName}/{prevQuarterEnd.year} পর্যন্ত সমন্বয় (রেজিস্টার হতে)</th>
                    <th className={`${thCls} w-[300px]`} colSpan={3}>১৯৭১-৭২ হতে {prevQuarterEnd.monthName}/{prevQuarterEnd.year} পর্যন্ত মোট সমন্বয়কৃত পূর্ব জের</th>
                  </tr>
                  <tr>
                    <th className={thCls}>১৯৭১-৭২ হতে {cutoffInfo.formattedShort} উত্থাপিত</th>
                    <th className={thCls}>১৯৭১-৭২ হতে {cutoffInfo.formattedShort} নিষ্পত্তিকৃত</th>
                    <th className={thCls}>{cutoffInfo.formattedShort} অমীমাংসিত টাকা</th>
                    <th className={thCls}>উত্থাপিত সংখ্যা</th>
                    <th className={thCls}>উত্থাপিত টাকা</th>
                    <th className={thCls}>নিষ্পত্তিকৃত সংখ্যা</th>
                    <th className={thCls}>নিষ্পত্তিকৃত টাকা</th>
                    <th className={thCls}>মোট নিষ্পত্তিকৃত সংখ্যা</th>
                    <th className={thCls}>মোট অনিষ্পন্ন সংখ্যা</th>
                    <th className={thCls}>মোট অনিষ্পন্ন টাকা</th>
                  </tr>
                  <tr className="bg-slate-50 text-[9px] font-black text-slate-500">
                    {["১", "২", "৩", "৪ (ইনপুট)", "৫ (ইনপুট)", "৬ (ইনপুট)", "৭ (উত্থাপন)", "৮ (উত্থাপন)", "৯ (মীমাংসা)", "১০ (মীমাংসা)", "১১=৫+৯", "১২=৪+৭-১১", "১৩=৬+৮-১০"].map((l, i) => (
                      <th key={i} className={thCls + " py-1"}>{l}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {prevLedgerTable2Rows.map((row, idx) => {
                    const showMinistry = idx === 0 || prevLedgerTable2Rows[idx - 1].ministryName !== row.ministryName;
                    const rowSpan = prevLedgerTable2Rows.filter(r => r.ministryName === row.ministryName).length;

                    return (
                      <tr key={row.entityName} className="hover:bg-slate-50 transition-colors">
                        <td className={numTdCls}>{toBengaliDigits(row.sl.toString())}</td>
                        {showMinistry && (
                          <td rowSpan={rowSpan} className={tdCls + " text-[10px] font-black text-center bg-slate-50/10"}>
                            {row.ministryName}
                          </td>
                        )}
                        <td className={tdCls + " text-[10px] font-bold text-left"}>{row.entityName}</td>
                        
                        {/* Input fields with copy-paste listeners */}
                        <td className="border-r border-b border-slate-400 p-1 bg-amber-50/20">
                          <input
                            type="text"
                            className="w-full text-center font-black text-xs bg-amber-50/30 hover:bg-amber-100/40 focus:bg-white border border-amber-200 hover:border-amber-300 focus:border-blue-500 rounded px-1.5 py-1 text-slate-900 outline-none transition-all"
                            value={row.june25Raised === 0 ? '' : toBengaliDigits(row.june25Raised.toString())}
                            placeholder="০"
                            onChange={e => {
                              const val = parseBengaliNumber(e.target.value);
                              handleInputChangeTable2(row.entityName, 'june25Raised', val);
                            }}
                            onPaste={e => handlePasteTable2(e, idx, 'june25Raised')}
                          />
                        </td>
                        <td className="border-r border-b border-slate-400 p-1 bg-amber-50/20">
                          <input
                            type="text"
                            className="w-full text-center font-black text-xs bg-amber-50/30 hover:bg-amber-100/40 focus:bg-white border border-amber-200 hover:border-amber-300 focus:border-blue-500 rounded px-1.5 py-1 text-slate-900 outline-none transition-all"
                            value={row.june25Settled === 0 ? '' : toBengaliDigits(row.june25Settled.toString())}
                            placeholder="০"
                            onChange={e => {
                              const val = parseBengaliNumber(e.target.value);
                              handleInputChangeTable2(row.entityName, 'june25Settled', val);
                            }}
                            onPaste={e => handlePasteTable2(e, idx, 'june25Settled')}
                          />
                        </td>
                        <td className="border-r border-b border-slate-400 p-1 bg-amber-50/20">
                          <input
                            type="text"
                            className="w-full text-center font-black text-xs bg-amber-50/30 hover:bg-amber-100/40 focus:bg-white border border-amber-200 hover:border-amber-300 focus:border-blue-500 rounded px-1.5 py-1 text-slate-900 outline-none transition-all"
                            value={row.june25UnsettledAmount === 0 ? '' : toBengaliDigits(row.june25UnsettledAmount.toString())}
                            placeholder="০"
                            onChange={e => {
                              const val = parseBengaliNumber(e.target.value);
                              handleInputChangeTable2(row.entityName, 'june25UnsettledAmount', val);
                            }}
                            onPaste={e => handlePasteTable2(e, idx, 'june25UnsettledAmount')}
                          />
                        </td>

                        {/* Read only calculated transition values */}
                        <td className={numTdCls + " bg-slate-50 text-slate-700 font-bold"}>
                          {formatNumberSimple(row.transitionRaisedCount)}
                        </td>
                        <td className={numTdCls + " bg-slate-50 text-slate-700 font-bold"}>
                          {row.transitionRaisedAmount === 0 ? '০' : formatNumberSimple(row.transitionRaisedAmount)}
                        </td>
                        <td className={numTdCls + " bg-slate-50 text-slate-700 font-bold"}>
                          {formatNumberSimple(row.transitionSettledCount)}
                        </td>
                        <td className={numTdCls + " bg-slate-50 text-emerald-700 font-extrabold"}>
                          {row.transitionSettledAmount === 0 ? '০' : formatNumberSimple(row.transitionSettledAmount)}
                        </td>

                        {/* Cumulative balances */}
                        <td className={numTdCls + " bg-blue-50/10 font-bold text-slate-900"}>
                          {formatNumberSimple(row.totalSettledCount)}
                        </td>
                        <td className={numTdCls + " bg-blue-50/20 font-black text-blue-900"}>
                          {formatNumberSimple(row.totalUnsettledCount)}
                        </td>
                        <td className={numTdCls + " bg-blue-50/30 font-extrabold text-slate-900"}>
                          {row.totalUnsettledAmount === 0 ? '০' : formatNumberSimple(row.totalUnsettledAmount)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="bg-slate-200 font-extrabold text-[10px] text-slate-900">
                    <td className={footerTdCls} colSpan={3}>সর্বমোট</td>
                    <td className={footerNumTdCls}>{formatNumberSimple(prevLedgerTable2GrandTotals.june25Raised)}</td>
                    <td className={footerNumTdCls}>{formatNumberSimple(prevLedgerTable2GrandTotals.june25Settled)}</td>
                    <td className={footerNumTdCls}>{formatNumberSimple(prevLedgerTable2GrandTotals.june25UnsettledAmount)}</td>
                    <td className={footerNumTdCls}>{formatNumberSimple(prevLedgerTable2GrandTotals.transitionRaisedCount)}</td>
                    <td className={footerNumTdCls}>{formatNumberSimple(prevLedgerTable2GrandTotals.transitionRaisedAmount)}</td>
                    <td className={footerNumTdCls}>{formatNumberSimple(prevLedgerTable2GrandTotals.transitionSettledCount)}</td>
                    <td className={footerNumTdCls}>{formatNumberSimple(prevLedgerTable2GrandTotals.transitionSettledAmount)}</td>
                    <td className={footerNumTdCls}>{formatNumberSimple(prevLedgerTable2GrandTotals.totalSettledCount)}</td>
                    <td className={footerNumTdCls + " text-blue-900"}>{formatNumberSimple(prevLedgerTable2GrandTotals.totalUnsettledCount)}</td>
                    <td className={footerNumTdCls}>{formatNumberSimple(prevLedgerTable2GrandTotals.totalUnsettledAmount)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

          {/* Footer controls */}
          <div className="px-6 py-4 border-t border-slate-200 bg-slate-50 flex justify-end">
            <button
              type="button"
              onClick={() => setIsPrevLedgerTable2Open(false)}
              className="px-8 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-black text-xs transition-all cursor-pointer shadow-lg active:scale-95 border-b-4 border-blue-800"
            >
              সংরক্ষণ করুন ও বন্ধ করুন
            </button>
          </div>

        </div>
      </div>
    );
  };

  const downloadExcel = () => {
    const tables = document.querySelectorAll('table');
    if (tables.length === 0) return;

    let tablesHtml = '';
    tables.forEach((table, tableIdx) => {
      const clonedTable = table.cloneNode(true) as HTMLTableElement;
      const interactiveElements = clonedTable.querySelectorAll('.no-print, button, svg, input, select');
      interactiveElements.forEach(el => el.remove());
      
      tablesHtml += `
        <div style="margin-bottom: 40px;">
          ${tableIdx > 0 ? '<br><hr><br>' : ''}
          ${clonedTable.outerHTML}
        </div>
      `;
    });

    const filename = `${(customTitle || 'ত্রৈমাসিক_রিটার্ন_৩').replace(/\s+/g, '_')}_${format(new Date(), 'yyyy-MM-dd')}.xls`;

    const template = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
      <head>
        <meta http-equiv="content-type" content="application/vnd.ms-excel; charset=UTF-8">
        <!--[if gte mso 9]>
        <xml>
          <x:ExcelWorkbook>
            <x:ExcelWorksheets>
              <x:ExcelWorksheet>
                <x:Name>রিপোর্ট</x:Name>
                <x:WorksheetOptions>
                  <x:DisplayGridlines/>
                </x:WorksheetOptions>
              </x:ExcelWorksheet>
            </x:ExcelWorksheets>
          </x:ExcelWorkbook>
        </xml>
        <![endif]-->
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif, 'Hind Siliguri', sans-serif; }
          table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }
          th, td { border: 1px solid #cbd5e1 !important; padding: 8px 12px !important; text-align: center; font-size: 11px; vertical-align: middle; }
          th { background-color: #f1f5f9 !important; color: #0f172a !important; font-weight: bold !important; }
          .bg-slate-200, thead, tfoot { background-color: #e2e8f0 !important; font-weight: bold !important; }
          .bg-sky-100 { background-color: #e0f2fe !important; }
          .bg-amber-50 { background-color: #fef3c7 !important; }
          .bg-black { background-color: #090d16 !important; color: #ffffff !important; }
          tfoot td { background-color: #0f172a !important; color: #ffffff !important; font-weight: bold !important; }
        </style>
      </head>
      <body>
        <h2 style="text-align: center; margin-bottom: 20px; color: #1e3a8a;">${customTitle || 'ত্রৈমাসিক রিটার্ন - ৩'}</h2>
        ${tablesHtml}
      </body>
      </html>
    `;

    const blob = new Blob([template], { type: 'application/vnd.ms-excel;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const getMonthNameBN = (date: Date) => {
    const months = ["জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"];
    return months[date.getMonth()];
  };

  const formatYearBN = (date: Date) => toBengaliDigits(format(date, 'yyyy'));
  const formatShortYearBN = (date: Date) => toBengaliDigits(format(date, 'yy'));

  const processData = (isFI: boolean) => {
    const map = new Map<string, any>();
    const cycleStartStr = activeCycle?.start ? dateFnsFormat(activeCycle.start, 'yyyy-MM-dd') : '';
    const cycleEndStr = activeCycle?.end ? dateFnsFormat(activeCycle.end, 'yyyy-MM-dd') : '';

    // Initialize with all entities from MINISTRY_ENTITY_MAP
    Object.entries(MINISTRY_ENTITY_MAP).forEach(([mName, entities]) => {
      if (isFI !== isFinancialInstitution(mName)) return;

      entities.forEach(entityName => {
        const key = `${mName}|${entityName}`;

        const getStatsFromMap = (mapObj: Record<string, any> | undefined) => {
          if (!mapObj) return { unsettledCount: 0, unsettledAmount: 0, settledCount: 0, settledAmount: 0 };
          let matchKey = entityName;
          if (robustNormalize(entityName) === robustNormalize("হস্ত ও কুটির শিল্প সংস্থা")) {
            matchKey = "ক্ষুদ্র ও কুটির শিল্প";
          } else if (robustNormalize(entityName) === robustNormalize("রসায়ন শিল্প সংস্থা")) {
            matchKey = "রসায়ন শিল্প";
          }
          let res = mapObj[matchKey] || mapObj[entityName];
          if (!res) {
            const keys = Object.keys(mapObj);
            const foundKey = keys.find(k => isEntityMatch(k, entityName));
            if (foundKey) res = mapObj[foundKey];
          }
          return res || { unsettledCount: 0, unsettledAmount: 0, settledCount: 0, settledAmount: 0 };
        };

        let baseUnsettledCount = 0;
        let baseUnsettledAmount = 0;
        let baseSettledCount = 0;

        let sfiObj: any = null;
        let nonSfiObj: any = null;

        if (prevStats) {
          sfiObj = getStatsFromMap(prevStats.entitiesSFI);
          nonSfiObj = getStatsFromMap(prevStats.entitiesNonSFI);
        }

        if (sfiObj || nonSfiObj) {
          const sC = sfiObj?.unsettledCount || 0;
          const nsC = nonSfiObj?.unsettledCount || 0;
          const sA = sfiObj?.unsettledAmount || 0;
          const nsA = nonSfiObj?.unsettledAmount || 0;
          const sQA = (sfiObj && sfiObj.unsettledQuarterlyAmount !== undefined && sfiObj.unsettledQuarterlyAmount !== null)
            ? sfiObj.unsettledQuarterlyAmount 
            : sA;
          const nsQA = (nonSfiObj && nonSfiObj.unsettledQuarterlyAmount !== undefined && nonSfiObj.unsettledQuarterlyAmount !== null)
            ? nonSfiObj.unsettledQuarterlyAmount 
            : nsA;
          const sS = sfiObj?.settledCount || 0;
          const nsS = nonSfiObj?.settledCount || 0;

          if (sQA === nsQA || nsQA === 0 || sfiObj === nonSfiObj) {
            baseUnsettledAmount = sQA;
          } else if (sQA === 0) {
            baseUnsettledAmount = nsQA;
          } else {
            baseUnsettledAmount = sQA + nsQA;
          }

          if (sC === nsC || nsC === 0 || sfiObj === nonSfiObj) {
            baseUnsettledCount = sC;
          } else if (sC === 0) {
            baseUnsettledCount = nsC;
          } else {
            baseUnsettledCount = sC + nsC;
          }

          if (sS === nsS || nsS === 0 || sfiObj === nonSfiObj) {
            baseSettledCount = sS;
          } else if (sS === 0) {
            baseSettledCount = nsS;
          } else {
            baseSettledCount = sS + nsS;
          }
        }

        let priorRaisedCount = 0;
        let priorRaisedAmount = 0;
        let priorSettledCount = 0;
        let priorSettledAmount = 0;

        let currentRaisedCount = 0;
        let currentRaisedAmount = 0;
        let currentSettledCount = 0;
        let currentSettledAmount = 0;

        (entries || []).forEach(e => {
          if (isEntityMatch(e.entityName || '', entityName)) {
            // Extract raised count
            let rCount = 0;
            const rCountRaw = e.manualRaisedCount?.toString().trim() || "";
            if (rCountRaw !== "" && rCountRaw !== "0" && rCountRaw !== "০") {
              rCount = parseBengaliNumber(rCountRaw);
            }

            // Extract raised amount
            let rAmount = 0;
            if (e.manualRaisedAmount) {
              rAmount = parseBengaliNumber(String(e.manualRaisedAmount));
            }

            // Extract settled amount
            let settledAmt = 0;
            if (e.paragraphs && e.paragraphs.length > 0) {
              e.paragraphs.forEach(p => {
                settledAmt += parseBengaliNumber(String(p.recoveredAmount || '0')) + parseBengaliNumber(String(p.adjustedAmount || '0'));
              });
            } else {
              if (e.settledAmount) {
                settledAmt += parseBengaliNumber(String(e.settledAmount));
              } else if (e.manualSettledAmount) {
                settledAmt += parseBengaliNumber(String(e.manualSettledAmount));
              } else {
                const rec = (e.totalRec || 0) + (e.totalAdj || 0);
                if (rec > 0) settledAmt += rec;
              }
            }

            // Extract settled count (only full settlements count towards settled paragraph count)
            let sCount = 0;
            if (e.paragraphs && e.paragraphs.length > 0) {
              sCount = e.paragraphs.filter(p => robustNormalize(p.status || '') === robustNormalize('পূর্ণাঙ্গ')).length;
            } else {
              const rawFc = parseBengaliNumber(String(e.fullCount || e.meetingFullSettledParaCount || e.meetingSettledParaCount || 0));
              if (settledAmt > 0 && (rawFc === settledAmt || rawFc > 500)) {
                sCount = 1;
              } else {
                sCount = rawFc;
              }
            }

            // Categorize by date relative to active cycle using string comparison (yyyy-MM-dd)
            const entryDateRaw = e.issueDateISO || (e.createdAt ? e.createdAt.split('T')[0] : '');
            const entryDate = entryDateRaw ? entryDateRaw.split('T')[0] : '';

            if (selectedCycles.length > 0) {
              const matchedCycle = cycleOptions.find(c => selectedCycles.includes(c.label) && entryDate >= c.startStr && entryDate <= c.endStr);
              if (matchedCycle) {
                currentRaisedCount += rCount;
                currentRaisedAmount += rAmount;
                currentSettledCount += sCount;
                currentSettledAmount += settledAmt;
              }
            } else if (cycleStartStr && cycleEndStr && entryDate) {
              if (entryDate < cycleStartStr) {
                priorRaisedCount += rCount;
                priorRaisedAmount += rAmount;
                priorSettledCount += sCount;
                priorSettledAmount += settledAmt;
              } else if (entryDate >= cycleStartStr && entryDate <= cycleEndStr) {
                currentRaisedCount += rCount;
                currentRaisedAmount += rAmount;
                currentSettledCount += sCount;
                currentSettledAmount += settledAmt;
              }
            } else {
              currentRaisedCount += rCount;
              currentRaisedAmount += rAmount;
              currentSettledCount += sCount;
              currentSettledAmount += settledAmt;
            }
          }
        });

        const pCount = Math.max(0, (baseUnsettledCount + priorRaisedCount) - (baseSettledCount + priorSettledCount));
        const pAmount = Math.max(0, Math.round(baseUnsettledAmount) + Math.round(priorRaisedAmount) - Math.round(priorSettledAmount));

        map.set(key, {
          ministryName: mName,
          entityName: entityName,
          pCount,
          pAmount,
          cCount: currentRaisedCount,
          cAmount: currentRaisedAmount,
          sCount: currentSettledCount,
          sAmount: currentSettledAmount,
        });
      });
    });

    // Group by Ministry for the two-level display
    const ministryGroups: any[] = [];
    const ministryMap = new Map<string, any[]>();

    Array.from(map.values()).forEach(item => {
      if (!ministryMap.has(item.ministryName)) {
        ministryMap.set(item.ministryName, []);
      }
      ministryMap.get(item.ministryName)?.push(item);
    });

    ministryMap.forEach((entities, ministry) => {
      const matchSelectedMin = selectedMinistries.length === 0 || selectedMinistries.includes(ministry);
      const matchMinistry = (filterMinistry === '' || robustNormalize(ministry).includes(robustNormalize(filterMinistry))) && matchSelectedMin;
      const matchSearch = searchTerm === '' || 
        robustNormalize(ministry).toLowerCase().includes(searchTerm.toLowerCase()) ||
        entities.some(ent => robustNormalize(ent.entityName).toLowerCase().includes(searchTerm.toLowerCase()));

      if (matchMinistry && matchSearch) {
        const filteredEntities = entities.filter(ent => {
          if (selectedEntities.length > 0 && !selectedEntities.some(se => isEntityMatch(ent.entityName, se))) {
            return false;
          }
          if (searchTerm === '') return true;
          return robustNormalize(ent.entityName).toLowerCase().includes(searchTerm.toLowerCase()) || 
                 robustNormalize(ministry).toLowerCase().includes(searchTerm.toLowerCase());
        });

        if (filteredEntities.length > 0) {
          ministryGroups.push({
            ministry,
            entities: filteredEntities
          });
        }
      }
    });

    return ministryGroups;
  };

  const filteredTable1Data = useMemo(() => processData(false), [entries, prevStats, searchTerm, filterMinistry, activeCycle, selectedCycles, selectedMinistries, selectedEntities, cycleOptions]);
  const filteredTable2Data = useMemo(() => processData(true), [entries, prevStats, searchTerm, filterMinistry, activeCycle, selectedCycles, selectedMinistries, selectedEntities, cycleOptions]);

  const grandTotals = useMemo(() => {
    const totals = { pC: 0, pA: 0, cC: 0, cA: 0, tC: 0, tA: 0, sC: 0, sA: 0, fC: 0, fA: 0 };
    [...filteredTable1Data, ...filteredTable2Data].forEach(mGroup => {
      mGroup.entities.forEach((ent: any) => {
        const totalObjectionCount = ent.pCount + ent.cCount;
        const totalObjectionAmount = ent.pAmount + ent.cAmount;
        const finalObjectionCount = totalObjectionCount - ent.sCount;
        const finalObjectionAmount = totalObjectionAmount - ent.sAmount;

        totals.pC += ent.pCount; totals.pA += ent.pAmount;
        totals.cC += ent.cCount; totals.cA += ent.cAmount;
        totals.tC += totalObjectionCount; totals.tA += totalObjectionAmount;
        totals.sC += ent.sCount; totals.sA += ent.sAmount;
        totals.fC += finalObjectionCount; totals.fA += finalObjectionAmount;
      });
    });
    return totals;
  }, [filteredTable1Data, filteredTable2Data]);

  const table1Ref = useRef<HTMLTableElement>(null);
  const table2Ref = useRef<HTMLTableElement>(null);

  useLayoutEffect(() => {
    const updateFooterStickyOffsets = () => {
      [table1Ref.current, table2Ref.current].forEach((table) => {
        if (!table) return;
        const bottomFooter = table.querySelector('.qr-sticky-footer-bottom') as HTMLElement | null;
        if (bottomFooter) {
          const hBottom = bottomFooter.getBoundingClientRect().height;
          if (hBottom > 0) {
            table.style.setProperty('--qr-footer-bottom-h', `${Math.round(hBottom)}px`);
          }
        }
      });
    };

    updateFooterStickyOffsets();
    const t1 = setTimeout(updateFooterStickyOffsets, 50);
    const t2 = setTimeout(updateFooterStickyOffsets, 150);
    const t3 = setTimeout(updateFooterStickyOffsets, 400);

    window.addEventListener('resize', updateFooterStickyOffsets);
    if (document.fonts) {
      document.fonts.ready.then(updateFooterStickyOffsets);
    }

    const observers: ResizeObserver[] = [];
    if (window.ResizeObserver) {
      [table1Ref.current, table2Ref.current].forEach((table) => {
        if (table) {
          const ro = new ResizeObserver(updateFooterStickyOffsets);
          ro.observe(table);
          observers.push(ro);
        }
      });
    }

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      window.removeEventListener('resize', updateFooterStickyOffsets);
      observers.forEach((ro) => ro.disconnect());
    };
  }, [filteredTable1Data, filteredTable2Data]);

  const thCls = "sticky z-[144] p-1 font-black text-center text-slate-900 text-[10px] leading-tight align-middle bg-[#e2e8f0] border-r border-b border-slate-300 bg-clip-border whitespace-nowrap";
  const thClsWithTop = "sticky top-0 z-[145] p-1 font-black text-center text-slate-900 text-[9.5px] leading-tight align-middle bg-[#e2e8f0] border-r border-b border-t border-slate-300 bg-clip-border whitespace-normal";
  const thRow3Cls = "sticky z-[143] p-1 font-black text-center text-slate-700 text-[9.5px] leading-tight align-middle bg-[#e2e8f0] border-r border-b border-slate-300 bg-clip-border whitespace-nowrap";
  const tdCls = "border-r border-b border-slate-200/90 p-1.5 text-[10px] text-slate-800 align-middle bg-white";
  const numTdCls = "border-r border-b border-slate-200/90 p-1.5 text-[10px] text-slate-900 text-center align-middle font-bold bg-white";
  const footerTdCls = "border-r border-b border-slate-800 p-2.5 text-[10.5px] text-white align-middle bg-slate-950 font-black shadow-[inset_0_2px_0_rgba(255,255,255,0.15)]";
  const footerNumTdCls = "border-r border-b border-slate-800 p-2.5 text-[10.5px] text-white text-center align-middle font-black bg-slate-950 shadow-[inset_0_2px_0_rgba(255,255,255,0.15)]";

  const renderTable = (data: any[], tableId: string) => {
    let globalIdx = 1;
    const totals = { pC: 0, pA: 0, cC: 0, cA: 0, tC: 0, tA: 0, sC: 0, sA: 0, fC: 0, fA: 0 };

    return (
      <div className={`table-container qr-table-container ${tableId === 'table-2' ? '' : 'mb-10'} overflow-visible shadow-sm rounded-lg bg-white border border-slate-300`}>
        <style>{`
          #qr-3-table-1, #qr-3-table-2 {
            --qr-footer-bottom-h: 28px;
          }
          #qr-3-table-1 thead,
          #qr-3-table-2 thead {
            position: -webkit-sticky !important;
            position: sticky !important;
            top: 0px !important;
            z-index: 140 !important;
            background-color: #e2e8f0 !important;
          }
          #qr-3-table-1 thead th,
          #qr-3-table-2 thead th {
            position: -webkit-sticky !important;
            position: sticky !important;
            background-color: #e2e8f0 !important;
            background-clip: padding-box !important;
            vertical-align: middle !important;
            opacity: 1 !important;
            box-shadow: none !important;
            box-sizing: border-box !important;
          }
          #qr-3-table-1 thead tr:first-child,
          #qr-3-table-1 thead tr:nth-child(1),
          #qr-3-table-2 thead tr:first-child,
          #qr-3-table-2 thead tr:nth-child(1) {
            height: 48px !important;
            max-height: 48px !important;
          }
          #qr-3-table-1 thead tr:first-child th,
          #qr-3-table-1 thead tr:nth-child(1) th,
          #qr-3-table-2 thead tr:first-child th,
          #qr-3-table-2 thead tr:nth-child(1) th {
            top: 0px !important;
            z-index: 145 !important;
          }
          #qr-3-table-1 thead tr:first-child th:not([rowspan]):not([rowSpan]),
          #qr-3-table-2 thead tr:first-child th:not([rowspan]):not([rowSpan]) {
            top: 0px !important;
            height: 48px !important;
            max-height: 48px !important;
            box-sizing: border-box !important;
            z-index: 145 !important;
            border-bottom: 1px solid #94a3b8 !important;
          }
          #qr-3-table-1 thead tr:first-child th[rowspan],
          #qr-3-table-1 thead tr:first-child th[rowSpan],
          #qr-3-table-2 thead tr:first-child th[rowspan],
          #qr-3-table-2 thead tr:first-child th[rowSpan] {
            top: 0px !important;
            height: 80px !important;
            max-height: 80px !important;
            min-height: 80px !important;
            box-sizing: border-box !important;
            z-index: 146 !important;
            border-bottom: 1px solid #94a3b8 !important;
          }
          #qr-3-table-1 thead tr:nth-child(2),
          #qr-3-table-2 thead tr:nth-child(2) {
            height: 32px !important;
            max-height: 32px !important;
          }
          #qr-3-table-1 thead tr:nth-child(2) th,
          #qr-3-table-2 thead tr:nth-child(2) th {
            top: 48px !important;
            height: 32px !important;
            max-height: 32px !important;
            min-height: 32px !important;
            box-sizing: border-box !important;
            z-index: 144 !important;
            border-bottom: 1px solid #94a3b8 !important;
          }
          #qr-3-table-1 thead tr:nth-child(3),
          #qr-3-table-2 thead tr:nth-child(3) {
            height: 28px !important;
            max-height: 28px !important;
            background-color: #e2e8f0 !important;
          }
          #qr-3-table-1 thead tr:nth-child(3) th,
          #qr-3-table-2 thead tr:nth-child(3) th {
            top: 80px !important;
            height: 28px !important;
            max-height: 28px !important;
            min-height: 28px !important;
            box-sizing: border-box !important;
            z-index: 143 !important;
            background-color: #e2e8f0 !important;
            background-clip: padding-box !important;
            border-bottom: 1px solid #cbd5e1 !important;
            box-shadow: none !important;
            white-space: nowrap !important;
          }
          #qr-3-table-1 thead tr:first-child th:first-child,
          #qr-3-table-2 thead tr:first-child th:first-child {
            width: 45px !important;
            min-width: 45px !important;
            white-space: nowrap !important;
          }
          /* Column 2 (মন্ত্রণালয়ের নাম) - 50% reduced width */
          #qr-3-table-1 thead tr:first-child th:nth-child(2),
          #qr-3-table-2 thead tr:first-child th:nth-child(2) {
            width: 55px !important;
            min-width: 55px !important;
            max-width: 60px !important;
          }
          /* All "সংখ্যা" columns (Columns 4, 6, 8, 10, 12) - matching Column 8 */
          #qr-3-table-1 thead tr:nth-child(2) th:nth-child(1),
          #qr-3-table-2 thead tr:nth-child(2) th:nth-child(1),
          #qr-3-table-1 thead tr:nth-child(2) th:nth-child(3),
          #qr-3-table-2 thead tr:nth-child(2) th:nth-child(3),
          #qr-3-table-1 thead tr:nth-child(2) th:nth-child(5),
          #qr-3-table-2 thead tr:nth-child(2) th:nth-child(5),
          #qr-3-table-1 thead tr:nth-child(2) th:nth-child(7),
          #qr-3-table-2 thead tr:nth-child(2) th:nth-child(7),
          #qr-3-table-1 thead tr:nth-child(2) th:nth-child(9),
          #qr-3-table-2 thead tr:nth-child(2) th:nth-child(9),
          #qr-3-table-1 thead tr:nth-child(3) th:nth-child(4),
          #qr-3-table-2 thead tr:nth-child(3) th:nth-child(4),
          #qr-3-table-1 thead tr:nth-child(3) th:nth-child(6),
          #qr-3-table-2 thead tr:nth-child(3) th:nth-child(6),
          #qr-3-table-1 thead tr:nth-child(3) th:nth-child(8),
          #qr-3-table-2 thead tr:nth-child(3) th:nth-child(8),
          #qr-3-table-1 thead tr:nth-child(3) th:nth-child(10),
          #qr-3-table-2 thead tr:nth-child(3) th:nth-child(10),
          #qr-3-table-1 thead tr:nth-child(3) th:nth-child(12),
          #qr-3-table-2 thead tr:nth-child(3) th:nth-child(12) {
            width: 55px !important;
            min-width: 55px !important;
            max-width: 60px !important;
            white-space: nowrap !important;
          }
          /* All "টাকা" columns (Columns 5, 7, 9, 11, 13) - including Column 9 */
          #qr-3-table-1 thead tr:nth-child(2) th:nth-child(2),
          #qr-3-table-2 thead tr:nth-child(2) th:nth-child(2),
          #qr-3-table-1 thead tr:nth-child(2) th:nth-child(4),
          #qr-3-table-2 thead tr:nth-child(2) th:nth-child(4),
          #qr-3-table-1 thead tr:nth-child(2) th:nth-child(6),
          #qr-3-table-2 thead tr:nth-child(2) th:nth-child(6),
          #qr-3-table-1 thead tr:nth-child(2) th:nth-child(8),
          #qr-3-table-2 thead tr:nth-child(2) th:nth-child(8),
          #qr-3-table-1 thead tr:nth-child(2) th:nth-child(10),
          #qr-3-table-2 thead tr:nth-child(2) th:nth-child(10),
          #qr-3-table-1 thead tr:nth-child(3) th:nth-child(5),
          #qr-3-table-2 thead tr:nth-child(3) th:nth-child(5),
          #qr-3-table-1 thead tr:nth-child(3) th:nth-child(7),
          #qr-3-table-2 thead tr:nth-child(3) th:nth-child(7),
          #qr-3-table-1 thead tr:nth-child(3) th:nth-child(9),
          #qr-3-table-2 thead tr:nth-child(3) th:nth-child(9),
          #qr-3-table-1 thead tr:nth-child(3) th:nth-child(11),
          #qr-3-table-2 thead tr:nth-child(3) th:nth-child(11),
          #qr-3-table-1 thead tr:nth-child(3) th:nth-child(13),
          #qr-3-table-2 thead tr:nth-child(3) th:nth-child(13) {
            min-width: 90px !important;
          }
          #qr-3-table-1 tfoot,
          #qr-3-table-1 tfoot tr,
          #qr-3-table-1 tfoot td,
          #qr-3-table-1 tfoot th,
          #qr-3-table-2 tfoot,
          #qr-3-table-2 tfoot tr,
          #qr-3-table-2 tfoot td,
          #qr-3-table-2 tfoot th {
            position: -webkit-sticky !important;
            position: sticky !important;
            bottom: 0px !important;
            z-index: 150 !important;
            background-color: #020617 !important;
            color: #ffffff !important;
            background-clip: padding-box !important;
          }
          #qr-3-table-1 .qr-sticky-footer-offset td,
          #qr-3-table-2 .qr-sticky-footer-offset td {
            bottom: var(--qr-footer-bottom-h, 28px) !important;
            border-bottom: 1px solid #94a3b8 !important;
          }
          #qr-3-table-1 .qr-sticky-footer-bottom td,
          #qr-3-table-2 .qr-sticky-footer-bottom td {
            border-top: 1px solid #94a3b8 !important;
          }
        `}</style>
        <table
          ref={tableId === 'table-1' ? table1Ref : table2Ref}
          id={tableId === 'table-1' ? 'qr-3-table-1' : 'qr-3-table-2'}
          className="w-full border-separate border-spacing-0 min-w-[950px] !table-auto border border-slate-300"
        >
          <thead>
            <tr className="h-[48px]">
              <th rowSpan={2} className={`${thClsWithTop} w-[45px] min-w-[45px] !whitespace-nowrap`}>ক্রঃ নং</th>
              <th rowSpan={2} className={`${thClsWithTop} w-[55px] min-w-[55px] max-w-[60px]`}>মন্ত্রণালয়ের নাম</th>
              <th rowSpan={2} className={`${thClsWithTop} min-w-[110px] w-[calc(14%-2px)]`}>সংস্থার নাম</th>
              <th colSpan={2} className={`${thClsWithTop} min-w-[145px]`}>{getMonthNameBN(prevMonthDate)}/{formatYearBN(prevMonthDate)} পর্যন্ত অমীমাংসিত অডিট আপত্তি</th>
              <th colSpan={2} className={`${thClsWithTop} min-w-[145px]`}>{getMonthNameBN(startDate)}/{formatShortYearBN(startDate)} হতে {getMonthNameBN(endDate)}/{formatShortYearBN(endDate)} পর্যন্ত উত্থাপিত অডিট আপত্তি</th>
              <th colSpan={2} className={`${thClsWithTop} min-w-[145px]`}>মোট অডিট আপত্তি</th>
              <th colSpan={2} className={`${thClsWithTop} min-w-[145px]`}>{getMonthNameBN(startDate)}/{formatShortYearBN(startDate)} হতে {getMonthNameBN(endDate)}/{formatShortYearBN(endDate)} পর্যন্ত মীমাংসিত অডিট আপত্তি</th>
              <th colSpan={2} className={`${thClsWithTop} min-w-[145px]`}>{getMonthNameBN(endDate)}/{formatYearBN(endDate)} পর্যন্ত অমীমাংসিত অডিট আপত্তি</th>
            </tr>
            <tr className="h-[32px]">
              <th className={`${thCls} w-[55px] min-w-[55px] !whitespace-nowrap`}>সংখ্যা</th>
              <th className={`${thCls} min-w-[90px]`}>টাকা</th>
              <th className={`${thCls} w-[55px] min-w-[55px] !whitespace-nowrap`}>সংখ্যা</th>
              <th className={`${thCls} min-w-[90px]`}>টাকা</th>
              <th className={`${thCls} w-[55px] min-w-[55px] !whitespace-nowrap`}>সংখ্যা</th>
              <th className={`${thCls} min-w-[90px]`}>টাকা</th>
              <th className={`${thCls} w-[55px] min-w-[55px] !whitespace-nowrap`}>সংখ্যা</th>
              <th className={`${thCls} min-w-[90px]`}>টাকা</th>
              <th className={`${thCls} w-[55px] min-w-[55px] !whitespace-nowrap`}>সংখ্যা</th>
              <th className={`${thCls} min-w-[90px]`}>টাকা</th>
            </tr>
            <tr className="h-[28px] bg-[#e2e8f0]">
              {[1, 2, 3, 4, 5, 6, 7, '৮ = ৪+৬', '৯ = ৫+৭', 10, 11, '১২ = ৮-১০', '১৩ = ৯-১১'].map((n, i) => {
                const isCountCol = [3, 5, 7, 9, 11].includes(i);
                const isAmountCol = [4, 6, 8, 10, 12].includes(i);
                const widthCls = isCountCol 
                  ? 'w-[55px] min-w-[55px] max-w-[60px]' 
                  : isAmountCol 
                  ? 'min-w-[90px]' 
                  : i === 0 
                  ? 'w-[45px] min-w-[45px]' 
                  : i === 1 
                  ? 'w-[55px] min-w-[55px] max-w-[60px]' 
                  : 'min-w-[110px]';
                return (
                  <th key={i} className={`${thRow3Cls} ${widthCls} !whitespace-nowrap`}>
                    {typeof n === 'string' ? toBengaliDigits(n) : toBengaliDigits(n.toString())}
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {data.map((mGroup, mIdx) => {
              const groupTotals = { pC: 0, pA: 0, cC: 0, cA: 0, tC: 0, tA: 0, sC: 0, sA: 0, fC: 0, fA: 0 };

              return (
                <React.Fragment key={mIdx}>
                  {mGroup.entities.map((ent: any, eIdx: number) => {
                    const totalObjectionCount = ent.pCount + ent.cCount;
                    const totalObjectionAmount = ent.pAmount + ent.cAmount;
                    const finalObjectionCount = totalObjectionCount - ent.sCount;
                    const finalObjectionAmount = totalObjectionAmount - ent.sAmount;

                    groupTotals.pC += ent.pCount; groupTotals.pA += ent.pAmount;
                    groupTotals.cC += ent.cCount; groupTotals.cA += ent.cAmount;
                    groupTotals.tC += totalObjectionCount; groupTotals.tA += totalObjectionAmount;
                    groupTotals.sC += ent.sCount; groupTotals.sA += ent.sAmount;
                    groupTotals.fC += finalObjectionCount; groupTotals.fA += finalObjectionAmount;

                    totals.pC += ent.pCount; totals.pA += ent.pAmount;
                    totals.cC += ent.cCount; totals.cA += ent.cAmount;
                    totals.tC += totalObjectionCount; totals.tA += totalObjectionAmount;
                    totals.sC += ent.sCount; totals.sA += ent.sAmount;
                    totals.fC += finalObjectionCount; totals.fA += finalObjectionAmount;

                    return (
                      <tr key={`${mIdx}-${eIdx}`} className="hover:bg-slate-50 transition-colors">
                        {eIdx === 0 && (
                          <td rowSpan={mGroup.entities.length} className={numTdCls}>{toBengaliDigits((globalIdx++).toString())}</td>
                        )}
                        {eIdx === 0 && (
                          <td rowSpan={mGroup.entities.length} className={`${tdCls} font-black text-center align-middle p-0 bg-white w-[55px] min-w-[55px] max-w-[60px]`}>
                            <div
                              className="flex items-center justify-center w-full h-full py-2 px-1"
                              style={{ minHeight: `${Math.max(70, Math.ceil((mGroup.ministry || '').length * 6.5) + 24)}px` }}
                            >
                              <span
                                className="inline-block whitespace-nowrap font-bold text-[10.5px] tracking-normal text-slate-900 select-none"
                                style={{ transform: 'rotate(-90deg)', transformOrigin: 'center center' }}
                              >
                                <HighlightText text={mGroup.ministry} searchTerm={searchTerm} />
                              </span>
                            </div>
                          </td>
                        )}
                        <td className={tdCls}>
                          <HighlightText text={ent.entityName} searchTerm={searchTerm} />
                        </td>
                        <td className={numTdCls}>{toBengaliDigits(ent.pCount.toString())}</td>
                        <td className={numTdCls}>{toBengaliDigits(ent.pAmount.toString())}</td>
                        <td className={numTdCls}>{toBengaliDigits(ent.cCount.toString())}</td>
                        <td className={numTdCls}>{toBengaliDigits(ent.cAmount.toString())}</td>
                        <td className={numTdCls}>{toBengaliDigits(totalObjectionCount.toString())}</td>
                        <td className={numTdCls}>{toBengaliDigits(totalObjectionAmount.toString())}</td>
                        <td className={numTdCls}>{toBengaliDigits(ent.sCount.toString())}</td>
                        <td className={numTdCls}>{toBengaliDigits(ent.sAmount.toString())}</td>
                        <td className={numTdCls}>{toBengaliDigits(finalObjectionCount.toString())}</td>
                        <td className={numTdCls}>{toBengaliDigits(finalObjectionAmount.toString())}</td>
                      </tr>
                    );
                  })}
                  <tr className="bg-slate-100 font-black">
                    <td colSpan={3} className={`${tdCls} font-black text-center !bg-slate-200 text-slate-900 shadow-[inset_0_1px_0_rgba(255,255,255,0.6)]`}>
                      মোট ({mGroup.ministry})
                    </td>
                    <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupTotals.pC.toString())}</td>
                    <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupTotals.pA.toString())}</td>
                    <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupTotals.cC.toString())}</td>
                    <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupTotals.cA.toString())}</td>
                    <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupTotals.tC.toString())}</td>
                    <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupTotals.tA.toString())}</td>
                    <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupTotals.sC.toString())}</td>
                    <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupTotals.sA.toString())}</td>
                    <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupTotals.fC.toString())}</td>
                    <td className={`${numTdCls} font-black !bg-slate-100/90`}>{toBengaliDigits(groupTotals.fA.toString())}</td>
                  </tr>
                </React.Fragment>
              );
            })}
            <tr className={`font-black h-[28px] qr-sticky-footer no-hover-row ${tableId === 'table-2' ? 'qr-sticky-footer-offset' : 'qr-sticky-footer-bottom'}`}>
              <td colSpan={3} className={footerTdCls + " text-center"}>মোট</td>
              <td className={footerNumTdCls}>{toBengaliDigits(totals.pC.toString())}</td>
              <td className={footerNumTdCls}>{toBengaliDigits(totals.pA.toString())}</td>
              <td className={footerNumTdCls}>{toBengaliDigits(totals.cC.toString())}</td>
              <td className={footerNumTdCls}>{toBengaliDigits(totals.cA.toString())}</td>
              <td className={footerNumTdCls}>{toBengaliDigits(totals.tC.toString())}</td>
              <td className={footerNumTdCls}>{toBengaliDigits(totals.tA.toString())}</td>
              <td className={footerNumTdCls}>{toBengaliDigits(totals.sC.toString())}</td>
              <td className={footerNumTdCls}>{toBengaliDigits(totals.sA.toString())}</td>
              <td className={footerNumTdCls}>{toBengaliDigits(totals.fC.toString())}</td>
              <td className={footerNumTdCls}>{toBengaliDigits(totals.fA.toString())}</td>
            </tr>
            {tableId === 'table-2' && (
              <tr className="font-black h-[28px] qr-sticky-footer qr-sticky-footer-bottom no-hover-row">
                <td colSpan={3} className={footerTdCls + " text-center"}>সর্বমোট</td>
                <td className={footerNumTdCls}>{toBengaliDigits(grandTotals.pC.toString())}</td>
                <td className={footerNumTdCls}>{toBengaliDigits(grandTotals.pA.toString())}</td>
                <td className={footerNumTdCls}>{toBengaliDigits(grandTotals.cC.toString())}</td>
                <td className={footerNumTdCls}>{toBengaliDigits(grandTotals.cA.toString())}</td>
                <td className={footerNumTdCls}>{toBengaliDigits(grandTotals.tC.toString())}</td>
                <td className={footerNumTdCls}>{toBengaliDigits(grandTotals.tA.toString())}</td>
                <td className={footerNumTdCls}>{toBengaliDigits(grandTotals.sC.toString())}</td>
                <td className={footerNumTdCls}>{toBengaliDigits(grandTotals.sA.toString())}</td>
                <td className={footerNumTdCls}>{toBengaliDigits(grandTotals.fC.toString())}</td>
                <td className={footerNumTdCls}>{toBengaliDigits(grandTotals.fA.toString())}</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <div id="qr-3-container" className="w-full mx-auto py-4 px-[4px] bg-white rounded-xl relative animate-in fade-in duration-500 font-sans">
      <IDBadge id="qr-3-container" />
      
      {/* Action Bar (No Print) */}
      <div className="flex flex-wrap justify-end items-center gap-3 mb-4 no-print">
        <div className="flex items-center gap-2 flex-wrap">
          {monthPickerElement && (
            <div className="select-none relative z-[300]">
              {monthPickerElement}
            </div>
          )}

          {/* Cycle Multi-Select Filter */}
          <div className="relative select-none z-[300]" ref={cycleDropdownRef}>
            <div
              onClick={() => setIsCycleOpen(!isCycleOpen)}
              className={`flex items-center gap-1.5 px-3 py-1.5 border transition-all rounded-lg cursor-pointer text-[11px] font-bold shadow-xs ${
                selectedCycles.length > 0
                  ? 'bg-blue-50 text-blue-800 border-blue-300'
                  : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border-slate-200'
              }`}
            >
              <CalendarDays size={13} className="text-blue-600 shrink-0" />
              <span className="truncate max-w-[130px]">
                {selectedCycles.length === 0
                  ? 'সকল সাইকেল'
                  : selectedCycles.length === 1
                  ? selectedCycles[0]
                  : `${toBengaliDigits(selectedCycles.length.toString())}টি সাইকেল`}
              </span>
              {selectedCycles.length > 0 && (
                <span className="ml-0.5 px-1.5 py-0.2 bg-blue-600 text-white rounded-full text-[9px]">
                  {toBengaliDigits(selectedCycles.length.toString())}
                </span>
              )}
              <ChevronDown
                size={12}
                className={`text-slate-400 transition-transform duration-200 ${isCycleOpen ? 'rotate-180 text-blue-600' : ''}`}
              />
            </div>

            {isCycleOpen && (
              <div className="absolute top-[calc(100%+4px)] right-0 w-[270px] bg-white border border-slate-200 rounded-xl shadow-xl z-[9999] p-2 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="px-2 py-1.5 border-b border-slate-100 flex items-center justify-between mb-1">
                  <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest flex items-center gap-1.5">
                    <CalendarDays size={11} /> সাইকেল নির্বাচন
                  </span>
                </div>
                <div className="max-h-[220px] overflow-y-auto space-y-0.5">
                  <div
                    onClick={() => setSelectedCycles([])}
                    className={`flex items-center justify-between px-2.5 py-1.5 rounded-lg cursor-pointer text-[11px] font-bold transition-colors ${
                      selectedCycles.length === 0
                        ? 'bg-blue-600 text-white'
                        : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <span>সকল সাইকেল</span>
                    {selectedCycles.length === 0 && <Check size={13} />}
                  </div>
                  {cycleOptions.map((opt, idx) => {
                    const isSelected = selectedCycles.includes(opt.label);
                    return (
                      <div
                        key={idx}
                        onClick={() => {
                          if (isSelected) {
                            setSelectedCycles(selectedCycles.filter(c => c !== opt.label));
                          } else {
                            setSelectedCycles([...selectedCycles, opt.label]);
                          }
                        }}
                        className={`flex items-center justify-between px-2.5 py-1.5 rounded-lg cursor-pointer text-[11px] font-bold transition-colors ${
                          isSelected
                            ? 'bg-blue-50 text-blue-800'
                            : 'hover:bg-slate-50 text-slate-700'
                        }`}
                      >
                        <span className="truncate">{opt.label}</span>
                        <input
                          type="checkbox"
                          checked={isSelected}
                          readOnly
                          className="w-3.5 h-3.5 text-blue-600 rounded border-slate-300 pointer-events-none"
                        />
                      </div>
                    );
                  })}
                </div>
                <div className="mt-2 pt-1.5 border-t border-slate-100 flex justify-end">
                  <button
                    type="button"
                    onClick={() => setIsCycleOpen(false)}
                    className="px-3 py-1 bg-blue-600 text-white text-[10px] font-bold rounded-md hover:bg-blue-700 cursor-pointer shadow-xs"
                  >
                    সম্পন্ন
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Ministry Multi-Select Filter */}
          <div className="relative select-none z-[290]" ref={minDropdownRef}>
            <div
              onClick={() => setIsMinOpen(!isMinOpen)}
              className={`flex items-center gap-1.5 px-3 py-1.5 border transition-all rounded-lg cursor-pointer text-[11px] font-bold shadow-xs ${
                selectedMinistries.length > 0
                  ? 'bg-blue-50 text-blue-800 border-blue-300'
                  : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border-slate-200'
              }`}
            >
              <Building2 size={13} className="text-blue-600 shrink-0" />
              <span className="truncate max-w-[130px]">
                {selectedMinistries.length === 0
                  ? 'সকল মন্ত্রণালয়'
                  : selectedMinistries.length === 1
                  ? selectedMinistries[0]
                  : `${toBengaliDigits(selectedMinistries.length.toString())}টি মন্ত্রণালয়`}
              </span>
              {selectedMinistries.length > 0 && (
                <span className="ml-0.5 px-1.5 py-0.2 bg-blue-600 text-white rounded-full text-[9px]">
                  {toBengaliDigits(selectedMinistries.length.toString())}
                </span>
              )}
              <ChevronDown
                size={12}
                className={`text-slate-400 transition-transform duration-200 ${isMinOpen ? 'rotate-180 text-blue-600' : ''}`}
              />
            </div>

            {isMinOpen && (
              <div className="absolute top-[calc(100%+4px)] right-0 w-[260px] bg-white border border-slate-200 rounded-xl shadow-xl z-[9999] p-2 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="px-2 py-1.5 border-b border-slate-100 flex items-center justify-between mb-1">
                  <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest flex items-center gap-1.5">
                    <Building2 size={11} /> মন্ত্রণালয় নির্বাচন
                  </span>
                  {selectedMinistries.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setSelectedMinistries([])}
                      className="text-[10px] text-red-600 hover:underline cursor-pointer"
                    >
                      ক্লিয়ার
                    </button>
                  )}
                </div>
                <div className="max-h-[220px] overflow-y-auto space-y-0.5">
                  <div
                    onClick={() => {
                      setSelectedMinistries([]);
                    }}
                    className={`flex items-center justify-between px-2.5 py-1.5 rounded-lg cursor-pointer text-[11px] font-bold transition-colors ${
                      selectedMinistries.length === 0
                        ? 'bg-blue-600 text-white'
                        : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <span>সকল মন্ত্রণালয়</span>
                    {selectedMinistries.length === 0 && <Check size={13} />}
                  </div>
                  {ministryOptions.map((m, idx) => {
                    const isSelected = selectedMinistries.includes(m);
                    return (
                      <div
                        key={idx}
                        onClick={() => {
                          if (isSelected) {
                            setSelectedMinistries(selectedMinistries.filter(item => item !== m));
                          } else {
                            setSelectedMinistries([...selectedMinistries, m]);
                          }
                        }}
                        className={`flex items-center justify-between px-2.5 py-1.5 rounded-lg cursor-pointer text-[11px] font-bold transition-colors ${
                          isSelected
                            ? 'bg-blue-50 text-blue-800'
                            : 'hover:bg-slate-50 text-slate-700'
                        }`}
                      >
                        <span className="truncate">{m}</span>
                        <input
                          type="checkbox"
                          checked={isSelected}
                          readOnly
                          className="w-3.5 h-3.5 text-blue-600 rounded border-slate-300 pointer-events-none"
                        />
                      </div>
                    );
                  })}
                </div>
                <div className="mt-2 pt-1.5 border-t border-slate-100 flex justify-end">
                  <button
                    type="button"
                    onClick={() => setIsMinOpen(false)}
                    className="px-3 py-1 bg-blue-600 text-white text-[10px] font-bold rounded-md hover:bg-blue-700 cursor-pointer shadow-xs"
                  >
                    সম্পন্ন
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Entity Multi-Select Filter */}
          <div className="relative select-none z-[280]" ref={entDropdownRef}>
            <div
              onClick={() => setIsEntOpen(!isEntOpen)}
              className={`flex items-center gap-1.5 px-3 py-1.5 border transition-all rounded-lg cursor-pointer text-[11px] font-bold shadow-xs ${
                selectedEntities.length > 0
                  ? 'bg-blue-50 text-blue-800 border-blue-300'
                  : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border-slate-200'
              }`}
            >
              <Landmark size={13} className="text-blue-600 shrink-0" />
              <span className="truncate max-w-[130px]">
                {selectedEntities.length === 0
                  ? 'সকল সংস্থা'
                  : selectedEntities.length === 1
                  ? selectedEntities[0]
                  : `${toBengaliDigits(selectedEntities.length.toString())}টি সংস্থা`}
              </span>
              {selectedEntities.length > 0 && (
                <span className="ml-0.5 px-1.5 py-0.2 bg-blue-600 text-white rounded-full text-[9px]">
                  {toBengaliDigits(selectedEntities.length.toString())}
                </span>
              )}
              <ChevronDown
                size={12}
                className={`text-slate-400 transition-transform duration-200 ${isEntOpen ? 'rotate-180 text-blue-600' : ''}`}
              />
            </div>

            {isEntOpen && (
              <div className="absolute top-[calc(100%+4px)] right-0 w-[260px] bg-white border border-slate-200 rounded-xl shadow-xl z-[9999] p-2 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="px-2 py-1.5 border-b border-slate-100 flex items-center justify-between mb-1">
                  <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest flex items-center gap-1.5">
                    <Landmark size={11} /> সংস্থা নির্বাচন
                  </span>
                  {selectedEntities.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setSelectedEntities([])}
                      className="text-[10px] text-red-600 hover:underline cursor-pointer"
                    >
                      ক্লিয়ার
                    </button>
                  )}
                </div>
                <div className="max-h-[220px] overflow-y-auto space-y-0.5">
                  <div
                    onClick={() => {
                      setSelectedEntities([]);
                    }}
                    className={`flex items-center justify-between px-2.5 py-1.5 rounded-lg cursor-pointer text-[11px] font-bold transition-colors ${
                      selectedEntities.length === 0
                        ? 'bg-blue-600 text-white'
                        : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <span>সকল সংস্থা</span>
                    {selectedEntities.length === 0 && <Check size={13} />}
                  </div>
                  {entityOptions.map((ent, idx) => {
                    const isSelected = selectedEntities.includes(ent);
                    return (
                      <div
                        key={idx}
                        onClick={() => {
                          if (isSelected) {
                            setSelectedEntities(selectedEntities.filter(item => item !== ent));
                          } else {
                            setSelectedEntities([...selectedEntities, ent]);
                          }
                        }}
                        className={`flex items-center justify-between px-2.5 py-1.5 rounded-lg cursor-pointer text-[11px] font-bold transition-colors ${
                          isSelected
                            ? 'bg-blue-50 text-blue-800'
                            : 'hover:bg-slate-50 text-slate-700'
                        }`}
                      >
                        <span className="truncate">{ent}</span>
                        <input
                          type="checkbox"
                          checked={isSelected}
                          readOnly
                          className="w-3.5 h-3.5 text-blue-600 rounded border-slate-300 pointer-events-none"
                        />
                      </div>
                    );
                  })}
                </div>
                <div className="mt-2 pt-1.5 border-t border-slate-100 flex justify-end">
                  <button
                    type="button"
                    onClick={() => setIsEntOpen(false)}
                    className="px-3 py-1 bg-blue-600 text-white text-[10px] font-bold rounded-md hover:bg-blue-700 cursor-pointer shadow-xs"
                  >
                    সম্পন্ন
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Reset Filters button if any active */}


          <button
            type="button"
            onClick={downloadExcel}
            className="flex items-center justify-center w-9 h-9 bg-emerald-50 text-emerald-700 hover:text-emerald-800 border border-emerald-200 hover:border-emerald-300 hover:bg-emerald-100 transition-all rounded-lg cursor-pointer shrink-0 shadow-xs"
            title="এক্সেল ফাইল ডাউনলোড করুন"
          >
            <FileSpreadsheet size={16} className="stroke-[2.5]" />
          </button>
        </div>
      </div>

      {/* Print-only title to ensure perfect centering in print mode */}
      <div className="hidden print:block text-center mb-3">
        <h1 className="text-2xl font-black text-slate-900 tracking-tight">
          {customTitle || "ত্রৈমাসিক রিটার্ন - ৩"}
        </h1>
        <p className="text-[12px] font-bold text-slate-700 mt-1">
          {activeCycle.label}
        </p>
      </div>

      {/* Header Section with symmetric layout */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-5 pt-1 relative z-[260] no-print">
        {/* Left Column: Spacer / Placeholder for alignment */}
        <div className="hidden md:flex items-center gap-2 w-auto justify-start">
        </div>

        {/* Center Column: Title */}
        <h1 className="text-2.5xl font-black text-slate-900 tracking-tight text-center md:absolute md:left-1/2 md:-translate-x-1/2">
          {customTitle || "ত্রৈমাসিক রিটার্ন - ৩"}
        </h1>

        {/* Right Column: Spacer */}
        <div className="flex items-center gap-2.5 w-full md:w-auto justify-end flex-wrap">
        </div>
      </div>

      <div className="mb-3 text-[11px] font-bold text-slate-800 flex flex-wrap items-center gap-x-3 gap-y-1 border-b border-t border-slate-200 py-1.5 px-2 bg-slate-50/50 rounded-lg">
        <p><span className="text-slate-500">বিষয়ঃ</span> মন্ত্রণালয়/সংস্থা ভিত্তিক অমীমাংসিত অডিট আপত্তির ত্রৈমাসিক বিবরণ</p>
        <span className="text-slate-300 hidden md:inline font-normal">|</span>
        <p><span className="text-slate-500">শাখাঃ</span> নন এসএফআই শাখা</p>
        <span className="text-slate-300 hidden md:inline font-normal">|</span>
        <p><span className="text-slate-500">মাসের নামঃ</span> {formattedRange}</p>
      </div>

      {renderTable(filteredTable1Data, 'table-1')}
      
      <div className="my-3 text-[11px] font-bold text-slate-800 flex flex-wrap items-center gap-x-3 gap-y-1 border-b border-t border-slate-200 py-1.5 px-2 bg-slate-50/50 rounded-lg">
        <p><span className="text-slate-500">বিষয়ঃ</span> মন্ত্রণালয়/সংস্থা ভিত্তিক অমীমাংসিত অডিট আপত্তির ত্রৈমাসিক বিবরণ</p>
        <span className="text-slate-300 hidden md:inline font-normal">|</span>
        <p><span className="text-slate-500">মাসের নামঃ</span> {formattedRange}</p>
      </div>
      {renderTable(filteredTable2Data, 'table-2')}

      {renderPrevLedgerModal()}
      {renderPrevLedgerTable2Modal()}

    </div>
  );
};

export default QR_3;