// CorrespondenceTable - চিঠিপত্র রেজিস্টার টেবিল (২২টি ইনপুট ফিল্ড প্রদর্শন সমর্থিত)
import React, { useMemo, useState, useRef, useEffect } from "react";
import { createPortal } from "react-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  Mail,
  Calendar,
  Hash,
  FileText,
  User,
  Users,
  MapPin,
  Inbox,
  Computer,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  ArrowRightCircle,
  ListOrdered,
  Banknote,
  BookOpen,
  Clock,
  Printer,
  Pencil,
  Trash2,
  CalendarRange,
  Check,
  XCircle,
  Send,
  UserCheck,
  Plus,
  Search,
  ChevronDown,
  Sparkles,
  Save,
  CalendarSearch,
  LayoutGrid,
  CalendarDays,
  AlertTriangle,
  AlertCircle,
  MessageSquare,
  Edit3,
  RotateCcw,
  Filter,
  X,
  Eye,
  EyeOff,
  HelpCircle,
} from "lucide-react";
import { isSFI, isNonSFI, getCleanLetterTypeDisplay } from "../utils/branchUtils";
import {
  toBengaliDigits,
  parseBengaliNumber,
  toEnglishDigits,
  formatDateBN,
} from "../utils/numberUtils";
import HighlightText from "./HighlightText";
import DeleteConfirmationModal from "./DeleteConfirmationModal";
import { getCurrentCycle, getCycleForDate } from "../utils/cycleHelper";
import { format, addMonths, subMonths, startOfMonth, endOfMonth } from "date-fns";
import { parseManualDate } from "../utils/dateValidation";
import { CorrespondenceEntry, SettlementEntry } from "../types";
import { SettledDataModal, findMatchedSettlements } from "./SettledDataModal";
import LetterDetailsModal from "./LetterDetailsModal";

interface CorrespondenceTableProps {
  entries: CorrespondenceEntry[];
  settlementEntries?: SettlementEntry[];
  onBack: () => void;
  isLayoutEditable?: boolean;
  isAdmin?: boolean;
  onEdit?: (entry: any) => void;
  onInlineUpdate?: (entry: any) => void;
  onDelete?: (id: string) => void;
  onApprove?: (id: string) => void;
  onReject?: (id: string) => void;
  showFilters: boolean;
  setShowFilters: (val: boolean) => void;
  highlightSearch?: string | null;
  onClearHighlight?: () => void;
}

/**
 * Segmented Table Date Input for Table Cells with Auto-focus
 */
const SegmentedTableDateInput: React.FC<{
  value: string;
  onChange: (val: string) => void;
  accent: "blue" | "amber";
}> = ({ value, onChange, accent }) => {
  // Expect value as YYYY-MM-DD
  const [y, m, d] = value ? value.split("-") : ["", "", ""];
  const dayRef = useRef<HTMLInputElement>(null);
  const monthRef = useRef<HTMLInputElement>(null);
  const yearRef = useRef<HTMLInputElement>(null);

  const update = (nD: string, nM: string, nY: string) => {
    const finalY = nY.padStart(4, "0");
    const finalM = nM.padStart(2, "0");
    const finalD = nD.padStart(2, "0");
    updateValue(`${finalY}-${finalM}-${finalD}`);
  };

  const updateValue = (val: string) => {
    onChange(val);
  };

  const dayVal = d && d !== "00" ? toBengaliDigits(d) : "";
  const monthVal = m && m !== "00" ? toBengaliDigits(m) : "";
  const yearVal = y && y !== "0000" ? toBengaliDigits(y) : "";

  const focusCls =
    accent === "blue"
      ? "focus-within:border-blue-400 focus-within:ring-blue-50"
      : "focus-within:border-amber-400 focus-within:ring-amber-50";

  const inputCls =
    "w-full bg-transparent border-none outline-none text-center font-black text-[10px] p-0 placeholder:text-slate-300";

  return (
    <div
      className={`flex items-center gap-0.5 px-1 h-6 bg-white border border-slate-200 rounded-md ${focusCls} transition-all`}
    >
      <input
        ref={dayRef}
        type="text"
        placeholder="দিন"
        className={`${inputCls} flex-[1]`}
        value={dayVal}
        onChange={(e) => {
          const v = toEnglishDigits(e.target.value)
            .replace(/\D/g, "")
            .slice(0, 2);
          if (v && parseInt(v) > 31) return;
          update(v, m, y);
          if (v.length === 2) monthRef.current?.focus();
        }}
      />
      <span className="text-slate-300 text-[8px] font-black">/</span>
      <input
        ref={monthRef}
        type="text"
        placeholder="মাস"
        className={`${inputCls} flex-[1]`}
        value={monthVal}
        onChange={(e) => {
          const v = toEnglishDigits(e.target.value)
            .replace(/\D/g, "")
            .slice(0, 2);
          if (v && parseInt(v) > 12) return;
          update(d, v, y);
          if (v.length === 2) yearRef.current?.focus();
        }}
      />
      <span className="text-slate-300 text-[8px] font-black">/</span>
      <input
        ref={yearRef}
        type="text"
        placeholder="বছর"
        className={`${inputCls} flex-[1.8]`}
        value={yearVal}
        onChange={(e) => {
          const v = toEnglishDigits(e.target.value)
            .replace(/\D/g, "")
            .slice(0, 4);
          update(d, m, v);
        }}
        onBlur={() => {
          if (y && y.length === 2) update(d, m, "20" + y);
        }}
      />
    </div>
  );
};

/**
 * Premium Dropdown Component for Inline Presentation Name Update
 */
const PremiumInlineSelect: React.FC<{
  value: string;
  onSelect: (val: string) => void;
  disabled?: boolean;
}> = ({ value, onSelect, disabled }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [openUp, setOpenUp] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const saved = localStorage.getItem("ledger_correspondence_presented_to");
    const defaultList = ["সুপার", "এএন্ডএও", "উপপরিচালক"];

    const filterUnwanted = (s: string) =>
      s !== "পরিচালক" && s !== "মহাপরিচালক" && s !== "উপ-পরিচালক";

    if (saved) {
      const parsed = JSON.parse(saved).filter(filterUnwanted);
      const merged = Array.from(new Set([...defaultList, ...parsed])).filter(
        filterUnwanted,
      );
      setSuggestions(merged);
    } else {
      setSuggestions(defaultList);
    }
  }, []);

  const handleToggle = () => {
    if (disabled) return;
    if (!isOpen && dropdownRef.current) {
      const rect = dropdownRef.current.getBoundingClientRect();
      const spaceBelow = window.innerHeight - rect.bottom;
      setOpenUp(spaceBelow < 250);
    }
    setIsOpen(!isOpen);
    setSearchTerm("");
  };

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(e.target as Node)
      )
        setIsOpen(false);
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleAddNew = () => {
    const trimmed = searchTerm.trim();
    if (
      !trimmed ||
      trimmed === "পরিচালক" ||
      trimmed === "মহাপরিচালক" ||
      trimmed === "উপ-পরিচালক"
    )
      return;
    const next = Array.from(new Set([trimmed, ...suggestions]));
    setSuggestions(next);
    localStorage.setItem(
      "ledger_correspondence_presented_to",
      JSON.stringify(next),
    );
    onSelect(trimmed);
    setIsOpen(false);
  };

  const filtered = suggestions.filter((s) =>
    s.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  return (
    <div className="relative w-full" ref={dropdownRef}>
      <div
        onClick={handleToggle}
        className={`w-full h-6 px-1.5 bg-slate-50 border rounded-lg flex items-center justify-between transition-all ${disabled ? "cursor-not-allowed opacity-70" : "cursor-pointer"} ${isOpen ? "border-blue-500 ring-2 ring-blue-50 bg-white shadow-sm" : "border-slate-200 hover:border-slate-300"}`}
      >
        <span
          className={`text-[10px] font-black truncate ${value ? "text-slate-900" : "text-slate-400"}`}
        >
          {value || "বাছুন..."}
        </span>
        {!disabled && (
          <ChevronDown
            size={10}
            className={`text-slate-400 transition-transform ${isOpen ? "rotate-180" : ""}`}
          />
        )}
      </div>

      {isOpen && (
        <div
          className={`absolute ${openUp ? "bottom-[calc(100%+4px)]" : "top-[calc(100%+4px)]"} left-0 w-32 bg-white border border-slate-200 rounded-xl shadow-2xl z-[1000] overflow-hidden animate-in fade-in slide-in-from-top-1 duration-200 border-t-2 border-t-blue-600`}
        >
          <div className="p-2 bg-slate-50 border-b border-slate-100">
            <div className="relative">
              <Search
                className="absolute left-2 top-1/2 -translate-y-1/2 text-slate-400"
                size={10}
              />
              <input
                autoFocus
                type="text"
                placeholder="খুঁজুন..."
                className="w-full h-7 pl-6 pr-2 bg-white border border-slate-200 rounded-lg text-[10px] font-black outline-none focus:border-blue-400"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          <div className="max-h-40 overflow-y-auto no-scrollbar py-1">
            {value && (
              <div
                onClick={() => {
                  onSelect("");
                  setIsOpen(false);
                }}
                className="px-3 py-1.5 mx-1 mb-1 rounded-lg cursor-pointer flex items-center gap-2 bg-red-50 text-red-600 hover:bg-red-100 transition-all border border-red-100"
              >
                <XCircle size={10} />
                <span className="text-[10px] font-black uppercase tracking-tighter">
                  সিলেকশন মুছুন
                </span>
              </div>
            )}
            {filtered.map((opt, i) => (
              <div
                key={i}
                onClick={() => {
                  const nextVal = value === opt ? "" : opt;
                  onSelect(nextVal);
                  setIsOpen(false);
                }}
                className={`px-3 py-1.5 cursor-pointer flex items-center justify-between transition-all ${value === opt ? "bg-blue-600 text-white" : "hover:bg-blue-50 text-slate-700 font-black text-[10px]"}`}
              >
                <span>{opt}</span>
                {value === opt && <Check size={10} strokeWidth={3} />}
              </div>
            ))}
            {searchTerm &&
              !suggestions.includes(searchTerm) &&
              searchTerm !== "পরিচালক" &&
              searchTerm !== "মহাপরিচালক" &&
              searchTerm !== "উপ-পরিচালক" && (
                <div
                  onClick={handleAddNew}
                  className="px-3 py-1.5 cursor-pointer bg-emerald-50 text-emerald-600 font-black text-[10px] flex items-center gap-2 hover:bg-emerald-100"
                >
                  <Plus size={10} /> নতুন পদবি: "{searchTerm}"
                </div>
              )}
          </div>
        </div>
      )}
    </div>
  );
};

const CorrespondenceTable: React.FC<CorrespondenceTableProps> = ({
  entries,
  settlementEntries = [],
  onBack,
  isLayoutEditable,
  isAdmin,
  onEdit,
  onInlineUpdate,
  onDelete,
  onApprove,
  onReject,
  showFilters,
  setShowFilters,
  highlightSearch = null,
  onClearHighlight,
}) => {
  const [pendingChanges, setPendingChanges] = useState<
    Record<string, Partial<CorrespondenceEntry>>
  >({});
  const [recentlyUpdatedMap, setRecentlyUpdatedMap] = useState<
    Record<string, boolean>
  >({});
  const [validationErrorMap, setValidationErrorMap] = useState<
    Record<string, string>
  >({});
  const [isUpdating, setIsUpdating] = useState(false);
  const [showSummary, setShowSummary] = useState(false);
  const [isCycleStatsExpanded, setIsCycleStatsExpanded] = useState<boolean>(false);
  const [showCycleHeaders, setShowCycleHeaders] = useState<boolean>(true);
  const cycleRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const [deleteConfirm, setDeleteConfirm] = useState<{
    id: string;
    x: number;
    y: number;
  } | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [selectedCommentText, setSelectedCommentText] = useState<string | null>(null);
  const [editingCommentId, setEditingCommentId] = useState<string | null>(null);
  const [viewingSettlementLetter, setViewingSettlementLetter] = useState<CorrespondenceEntry | null>(null);
  const [dummyDeclinedMap, setDummyDeclinedMap] = useState<Record<string, boolean>>({});
  const [activeInlineEditingCell, setActiveInlineEditingCell] = useState<{ id: string; col: 'col4' | 'col5' } | null>(null);
  const [inlineEditingRowId, setInlineEditingRowId] = useState<string | null>(null);
  const [uncommittedWarningId, setUncommittedWarningId] = useState<string | null>(null);

  useEffect(() => {
    const handleScrollOrResize = () => {
      setDeleteConfirm(null);
    };
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setDeleteConfirm(null);
      }
    };
    window.addEventListener("scroll", handleScrollOrResize, true);
    window.addEventListener("resize", handleScrollOrResize);
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("scroll", handleScrollOrResize, true);
      window.removeEventListener("resize", handleScrollOrResize);
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, []);

  // Filter States
  const [searchTerm, setSearchTerm] = useState("");
  const [filterParaType, setFilterParaType] = useState("");
  const [filterType, setFilterType] = useState("");
  const [filterReceiver, setFilterReceiver] = useState("");
  const [filterStatus, setFilterStatus] = useState(""); // "", "চলমান", "নিষ্পন্ন"
  const [selectedCycleDate, setSelectedCycleDate] = useState<Date | null>(null);
  const [filterStartDate, setFilterStartDate] = useState<string>("");
  const [filterEndDate, setFilterEndDate] = useState<string>("");
  const [manualStartDate, setManualStartDate] = useState<string>(() => "");
  const [manualEndDate, setManualEndDate] = useState<string>(() => "");
  const [isCustomDateActive, setIsCustomDateActive] = useState<boolean>(false);
  const [dateTab, setDateTab] = useState<'cycle' | 'custom'>('custom');

  useEffect(() => {
    if (filterStartDate) {
      setManualStartDate(toBengaliDigits(format(new Date(filterStartDate), 'dd/MM/yyyy')));
    } else {
      setManualStartDate('');
    }
  }, [filterStartDate]);

  useEffect(() => {
    if (filterEndDate) {
      setManualEndDate(toBengaliDigits(format(new Date(filterEndDate), 'dd/MM/yyyy')));
    } else {
      setManualEndDate('');
    }
  }, [filterEndDate]);

  const [cycleDetailModal, setCycleDetailModal] = useState<{
    isOpen: boolean;
    title: string;
    letters: CorrespondenceEntry[];
  }>({
    isOpen: false,
    title: "",
    letters: [],
  });

  const [unsettledClickNoticeMap, setUnsettledClickNoticeMap] = useState<
    Record<string, boolean>
  >({});

  const triggerUnsettledNotice = (entryId: string) => {
    setUnsettledClickNoticeMap((prev) => ({ ...prev, [entryId]: true }));
    setTimeout(() => {
      setUnsettledClickNoticeMap((prev) => ({ ...prev, [entryId]: false }));
    }, 4000);
  };

  const [dhakaNoticeMap, setDhakaNoticeMap] = useState<
    Record<string, boolean>
  >({});

  const triggerDhakaNotice = (entryId: string) => {
    setDhakaNoticeMap((prev) => ({ ...prev, [entryId]: true }));
    setTimeout(() => {
      setDhakaNoticeMap((prev) => ({ ...prev, [entryId]: false }));
    }, 6000);
  };

  const [isCycleDropdownOpen, setIsCycleDropdownOpen] = useState(false);
  const [isStatusDropdownOpen, setIsStatusDropdownOpen] = useState(false);
  const [isBranchDropdownOpen, setIsBranchDropdownOpen] = useState(false);
  const [isTypeDropdownOpen, setIsTypeDropdownOpen] = useState(false);
  const [isReceiverDropdownOpen, setIsReceiverDropdownOpen] = useState(false);

  useEffect(() => {
    if (highlightSearch) {
      setSearchTerm(highlightSearch);
      // Reset other filters to ensure the highlighted entry is visible
      setFilterParaType("");
      setFilterType("");
      setFilterReceiver("");
      setFilterStatus("");
      setSelectedCycleDate(null);
      setIsCustomDateActive(false);
      setFilterStartDate("");
      setFilterEndDate("");
    }
    return () => {
      if (highlightSearch) onClearHighlight?.();
    };
  }, [highlightSearch, onClearHighlight]);

  const cycleDropdownRef = useRef<HTMLDivElement>(null);
  const statusDropdownRef = useRef<HTMLDivElement>(null);
  const branchDropdownRef = useRef<HTMLDivElement>(null);
  const typeDropdownRef = useRef<HTMLDivElement>(null);
  const receiverDropdownRef = useRef<HTMLDivElement>(null);
  const summaryRef = useRef<HTMLDivElement>(null);
  const summaryButtonRef = useRef<HTMLButtonElement>(null);

  const cycleInfo = useMemo(() => getCurrentCycle(), []);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        cycleDropdownRef.current &&
        !cycleDropdownRef.current.contains(event.target as Node)
      )
        setIsCycleDropdownOpen(false);
      if (
        statusDropdownRef.current &&
        !statusDropdownRef.current.contains(event.target as Node)
      )
        setIsStatusDropdownOpen(false);
      if (
        branchDropdownRef.current &&
        !branchDropdownRef.current.contains(event.target as Node)
      )
        setIsBranchDropdownOpen(false);
      if (
        typeDropdownRef.current &&
        !typeDropdownRef.current.contains(event.target as Node)
      )
        setIsTypeDropdownOpen(false);
      if (
        receiverDropdownRef.current &&
        !receiverDropdownRef.current.contains(event.target as Node)
      )
        setIsReceiverDropdownOpen(false);
      if (
        summaryRef.current &&
        !summaryRef.current.contains(event.target as Node) &&
        summaryButtonRef.current &&
        !summaryButtonRef.current.contains(event.target as Node)
      ) {
        setShowSummary(false);
      }

      // কলাম ৪ বা ৫ এডিট আনলক করা অবস্থায় বাইরে ক্লিক করলে (যদি কোনো এডিট না হয়ে থাকে) অটো-লক করা
      const targetEl = event.target as HTMLElement | null;
      if (
        targetEl &&
        !targetEl.closest("[data-inline-col='col4']") &&
        !targetEl.closest("[data-inline-col='col5']")
      ) {
        setActiveInlineEditingCell(null);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const cycleOptions = useMemo(() => {
    const options = [];
    const banglaMonths: Record<string, string> = {
      January: "জানুয়ারি",
      February: "ফেব্রুয়ারি",
      March: "মার্চ",
      April: "এপ্রিল",
      May: "মে",
      June: "জুন",
      July: "জুলাই",
      August: "আগস্ট",
      September: "সেপ্টেম্বর",
      October: "অক্টোবর",
      November: "নভেম্বর",
      December: "ডিসেম্বর",
    };
    const today = new Date();
    for (let i = 0; i < 24; i++) {
      const refDate = addMonths(today, -i);
      const firstOfTargetMonth = new Date(
        refDate.getFullYear(),
        refDate.getMonth(),
        1,
      );
      const cycle = getCycleForDate(firstOfTargetMonth);
      const monthNameEng = format(firstOfTargetMonth, "MMMM");
      const yearEng = format(firstOfTargetMonth, "yyyy");
      const label = `${banglaMonths[monthNameEng]} ${toBengaliDigits(yearEng)} সাইকেল`;
      options.push({
        date: firstOfTargetMonth,
        label,
        cycleLabel: cycle.label,
      });
    }
    return options;
  }, []);

  const activeCycle = useMemo(() => {
    if (!selectedCycleDate) return null;
    return getCycleForDate(selectedCycleDate);
  }, [selectedCycleDate]);

  const IDBadge = ({ id }: { id: string }) => {
    const [copied, setCopied] = useState(false);
    if (!isLayoutEditable) return null;
    const handleCopy = (e: React.MouseEvent) => {
      e.stopPropagation();
      navigator.clipboard.writeText(id);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    };
    return (
      <span
        onClick={handleCopy}
        className={`absolute -top-3 left-2 bg-black text-white text-[9px] font-black px-2 py-0.5 rounded border border-white/30 z-[300] cursor-pointer no-print shadow-xl transition-all duration-200 hover:scale-150 hover:bg-blue-600 active:scale-95 flex items-center gap-1 origin-left ${copied ? "ring-2 ring-emerald-500 bg-emerald-600" : ""}`}
      >
        {copied ? "COPIED!" : `#${id}`}
      </span>
    );
  };

  const { ongoingCount, settledCount } = useMemo(() => {
    let ongoing = 0;
    let settled = 0;
    entries.forEach((e) => {
      const hasIssue = Boolean(
        (e.issueLetterNo && String(e.issueLetterNo).trim()) ||
        (e.issueLetterDate && String(e.issueLetterDate).trim())
      );
      if (!hasIssue) {
        ongoing++;
      } else {
        settled++;
      }
    });
    return { ongoingCount: ongoing, settledCount: settled };
  }, [entries]);

  const uniqueReceivers = useMemo(() => {
    const receivers = new Set<string>();
    entries.forEach(entry => {
      if (entry.receiverName) {
        receivers.add(entry.receiverName);
      }
    });
    return Array.from(receivers).sort();
  }, [entries]);

  const filteredEntries = useMemo(() => {
    return entries
      .filter((entry) => {
        const normalizedSearch = toEnglishDigits(
          searchTerm.toLowerCase().trim(),
        );
        const isNumericSearch = /^\d+$/.test(normalizedSearch);
        const matchSearch =
          !searchTerm ||
          (searchTerm === "__UNASSIGNED__" ? (!entry.receiverName || entry.receiverName.trim() === "") && (!entry.presentedToName || entry.presentedToName.trim() === "") : 
          (() => {
            const engLetter = toEnglishDigits(
              entry.letterNo.toLowerCase(),
            ).trim();
            const engDiary = toEnglishDigits(
              entry.diaryNo.toLowerCase(),
            ).trim();
            const engIssue = toEnglishDigits(
              (entry.issueLetterNo || "").toLowerCase(),
            ).trim();
            const engArchive = toEnglishDigits(
              (entry.archiveNo || "").toLowerCase(),
            ).trim();
            const engDigitalFile = toEnglishDigits(
              (entry.digitalFileNo || "").toLowerCase(),
            ).trim();

            const cleanNormalizedSearch = normalizedSearch.replace(/\s+/g, "");
            const cleanArchive = engArchive.replace(/\s+/g, "");
            const cleanDigitalFile = engDigitalFile.replace(/\s+/g, "");

            const isExactNumberMatch =
              engLetter === normalizedSearch ||
              engDiary === normalizedSearch ||
              engIssue === normalizedSearch ||
              engIssue.replace(/[^\d]/g, "") === normalizedSearch ||
              engArchive === normalizedSearch ||
              cleanArchive === cleanNormalizedSearch ||
              (cleanArchive && cleanNormalizedSearch && cleanArchive.replace(/^(ka|kg)-/i, "") === cleanNormalizedSearch.replace(/^(ka|kg)-/i, "")) ||
              engDigitalFile === normalizedSearch ||
              cleanDigitalFile === cleanNormalizedSearch;

            const isArchiveMatch =
              engArchive.includes(normalizedSearch) ||
              (cleanArchive && cleanNormalizedSearch && cleanArchive.includes(cleanNormalizedSearch));
            const isDigitalFileMatch =
              engDigitalFile.includes(normalizedSearch) ||
              (cleanDigitalFile && cleanNormalizedSearch && cleanDigitalFile.includes(cleanNormalizedSearch));

            const isDescriptionMatch = toEnglishDigits(
              entry.description.toLowerCase(),
            ).includes(normalizedSearch);
            const isReceiverMatch = toEnglishDigits(
              (entry.receiverName || "").toLowerCase(),
            ).includes(normalizedSearch);
            const isRemarksMatch = toEnglishDigits(
              (entry.remarks || "").toLowerCase(),
            ).includes(normalizedSearch);

            if (isNumericSearch) {
              return (
                isExactNumberMatch ||
                cleanArchive.replace(/^(ka|kg)-/i, "") === normalizedSearch
              );
            }
            return (
              isExactNumberMatch ||
              isArchiveMatch ||
              isDigitalFileMatch ||
              isDescriptionMatch ||
              isReceiverMatch ||
              isRemarksMatch
            );
          })());

        const matchBranch = (() => {
          if (!filterParaType) return true;
          if (!entry.paraType) return false;
          
          if (isSFI(filterParaType)) {
            return isSFI(entry.paraType);
          }
          
          if (isNonSFI(filterParaType)) {
            return isNonSFI(entry.paraType);
          }
          
          const variations = [filterParaType, filterParaType.replace(' ', '-'), filterParaType.replace('-', ' ')];
          const normalizedEntryPara = entry.paraType.trim();
          return variations.some(v => normalizedEntryPara === v);
        })();
        const matchType = !filterType || (() => {
          if (filterType === "দ্বিপক্ষীয় সভা" || filterType === "দ্বি-সভা (কার্যবিবরনী)") {
            return entry.letterType === "দ্বিপক্ষীয় সভা" || entry.letterType === "দ্বিপক্ষীয় সভা (কার্যবিবরণী)" || entry.letterType === "দ্বি-সভা (কার্যবিবরনী)" || entry.letterType === "দ্বি-সভা (কার্যবিবরণী)";
          }
          if (filterType === "কার্যপত্র (দ্বি-সভা)" || filterType === "দ্বি-সভা (কার্যপত্র)") {
            return entry.letterType === "কার্যপত্র (দ্বি-সভা)" || entry.letterType === "দ্বিপক্ষীয় সভা (কার্যপত্র)" || entry.letterType === "দ্বি-সভা (কার্যপত্র)";
          }
          if (filterType === "ত্রিপক্ষীয় সভা") {
            return entry.letterType === "ত্রিপক্ষীয় সভা" || entry.letterType === "ত্রিপক্ষীয় সভা (কার্যবিবরণী)";
          }
          if (filterType === "কার্যপত্র (ত্রি-সভা)") {
            return entry.letterType === "কার্যপত্র (ত্রি-সভা)" || entry.letterType === "ত্রিপক্ষীয় সভা (কার্যপত্র)";
          }
          if (filterType === "মিলকরণ" || filterType === "মিলিকরণ") {
            return entry.letterType === "মিলকরণ" || entry.letterType === "মিলিকরণ" || (entry.letterType || '').includes("মিলকরণ") || (entry.letterType || '').includes("মিলিকরণ");
          }
          return entry.letterType === filterType;
        })();
        const matchReceiver = !filterReceiver || entry.receiverName === filterReceiver;

        let matchCycle = true;
        if (isCustomDateActive && (filterStartDate || filterEndDate)) {
          if (!entry.diaryDate) {
            matchCycle = false;
          } else {
            const dStr = toEnglishDigits(entry.diaryDate).trim();
            if (filterStartDate && dStr < filterStartDate) matchCycle = false;
            if (filterEndDate && dStr > filterEndDate) matchCycle = false;
          }
        } else if (activeCycle && entry.diaryDate) {
          matchCycle =
            entry.diaryDate >= format(activeCycle.start, "yyyy-MM-dd") &&
            entry.diaryDate <= format(activeCycle.end, "yyyy-MM-dd");
        }

        const matchStatus = (() => {
          if (!filterStatus) return true;
          const hasIssue = Boolean(
            (entry.issueLetterNo && String(entry.issueLetterNo).trim()) ||
            (entry.issueLetterDate && String(entry.issueLetterDate).trim())
          );
          if (filterStatus === "চলমান") {
            return !hasIssue;
          }
          if (filterStatus === "নিষ্পন্ন") {
            return hasIssue || entry.isSettled === "হ্যাঁ" || entry.isSettled === "না";
          }
          return true;
        })();

        return matchSearch && matchBranch && matchType && matchReceiver && matchCycle && matchStatus;
      })
      .sort((a, b) => {
        const dateA = a.diaryDate || "";
        const dateB = b.diaryDate || "";
        if (dateA === dateB) {
          return (
            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
          );
        }
        return dateB.localeCompare(dateA);
      });
  }, [entries, searchTerm, filterParaType, filterType, filterReceiver, filterStatus, activeCycle, isCustomDateActive, filterStartDate, filterEndDate]);

  const stats = useMemo(() => {
    const total = filteredEntries.length;

    const sfi = filteredEntries.filter((e) => isSFI(e.paraType));
    const nonSfi = filteredEntries.filter((e) => isNonSFI(e.paraType));

    const getLetterTypeCount = (list: CorrespondenceEntry[], type: string) =>
      list.filter((e) => {
        if (type === "ত্রিপক্ষীয় সভা (কার্যপত্র)") {
          return (
            e.letterType === "ত্রিপক্ষীয় সভা (কার্যপত্র)" ||
            e.letterType === "কার্যপত্র (ত্রি-সভা)"
          );
        }
        if (type === "ত্রিপক্ষীয় সভা (কার্যবিবরণী)") {
          return (
            e.letterType === "ত্রিপক্ষীয় সভা (কার্যবিবরণী)" ||
            e.letterType === "ত্রিপক্ষীয় সভা"
          );
        }
        if (type === "দ্বিপক্ষীয় সভা (কার্যপত্র)") {
          return (
            e.letterType === "দ্বিপক্ষীয় সভা (কার্যপত্র)" ||
            e.letterType === "কার্যপত্র (দ্বি-সভা)"
          );
        }
        if (type === "দ্বিপক্ষীয় সভা (কার্যবিবরণী)") {
          return (
            e.letterType === "দ্বিপক্ষীয় সভা (কার্যবিবরণী)" ||
            e.letterType === "দ্বিপক্ষীয় সভা"
          );
        }
        if (type === "মিলিকরণ" || type === "মিলকরণ") {
          return (
            e.letterType === "মিলিকরণ" ||
            e.letterType === "মিলকরণ" ||
            (e.letterType || "").includes("মিলকরণ") ||
            (e.letterType || "").includes("মিলিকরণ")
          );
        }
        if (type === "অন্যান্য") {
          return (
            e.letterType === "অন্যান্য" ||
            (!e.letterType ||
              (!e.letterType.includes("বিএসআর") &&
                !e.letterType.includes("দ্বিপক্ষীয়") &&
                !e.letterType.includes("দ্বি-সভা") &&
                !e.letterType.includes("ত্রিপক্ষীয়") &&
                !e.letterType.includes("ত্রি-সভা") &&
                !e.letterType.includes("মিলকরণ") &&
                !e.letterType.includes("মিলিকরণ")))
          );
        }
        return e.letterType === type;
      }).length;

    return {
      total,
      sfi: {
        total: sfi.length,
        bsr: getLetterTypeCount(sfi, "বিএসআর"),
        triWork: getLetterTypeCount(sfi, "ত্রিপক্ষীয় সভা (কার্যপত্র)"),
        triMin: getLetterTypeCount(sfi, "ত্রিপক্ষীয় সভা (কার্যবিবরণী)"),
        biWork: getLetterTypeCount(sfi, "দ্বিপক্ষীয় সভা (কার্যপত্র)"),
        biMin: getLetterTypeCount(sfi, "দ্বিপক্ষীয় সভা (কার্যবিবরণী)"),
        reconciliation: getLetterTypeCount(sfi, "মিলিকরণ"),
        others: getLetterTypeCount(sfi, "অন্যান্য"),
      },
      nonSfi: {
        total: nonSfi.length,
        bsr: getLetterTypeCount(nonSfi, "বিএসআর"),
        biWork: getLetterTypeCount(nonSfi, "দ্বিপক্ষীয় সভা (কার্যপত্র)"),
        biMin: getLetterTypeCount(nonSfi, "দ্বিপক্ষীয় সভা (কার্যবিবরণী)"),
        triWork: getLetterTypeCount(nonSfi, "ত্রিপক্ষীয় সভা (কার্যপত্র)"),
        triMin: getLetterTypeCount(nonSfi, "ত্রিপক্ষীয় সভা (কার্যবিবরণী)"),
        reconciliation: getLetterTypeCount(nonSfi, "মিলিকরণ"),
        others: getLetterTypeCount(nonSfi, "অন্যান্য"),
      },
    };
  }, [filteredEntries]);

  const { cycleStats, groupedEntries } = useMemo(() => {
    const groupsMap: Record<string, CorrespondenceEntry[]> = {};
    const groupsList: { label: string; entries: CorrespondenceEntry[] }[] = [];

    filteredEntries.forEach((entry) => {
      let label = "Unknown";
      if (entry.diaryDate) {
        try {
          const dateObj = new Date(entry.diaryDate);
          if (!isNaN(dateObj.getTime())) {
            label = getCycleForDate(dateObj).label;
          }
        } catch (e) {}
      }

      if (!groupsMap[label]) {
        groupsMap[label] = [];
        groupsList.push({ label, entries: groupsMap[label] });
      }
      groupsMap[label].push(entry);
    });

    const statsMap: Record<string, any> = {};
    groupsList.forEach((group) => {
      const sfi = group.entries.filter((e) => isSFI(e.paraType));
      const nonSfi = group.entries.filter((e) => isNonSFI(e.paraType));
      const getCount = (list: CorrespondenceEntry[], type: string) =>
        list.filter((e) => {
          if (type === "ত্রিপক্ষীয় সভা (কার্যপত্র)") {
            return e.letterType === "ত্রিপক্ষীয় সভা (কার্যপত্র)" || e.letterType === "কার্যপত্র (ত্রি-সভা)";
          }
          if (type === "ত্রিপক্ষীয় সভা (কার্যবিবরণী)") {
            return e.letterType === "ত্রিপক্ষীয় সভা (কার্যবিবরণী)" || e.letterType === "ত্রিপক্ষীয় সভা";
          }
          if (type === "দ্বিপক্ষীয় সভা (কার্যপত্র)") {
            return e.letterType === "দ্বিপক্ষীয় সভা (কার্যপত্র)" || e.letterType === "কার্যপত্র (দ্বি-সভা)" || e.letterType === "দ্বি-সভা (কার্যপত্র)";
          }
          if (type === "দ্বিপক্ষীয় সভা (কার্যবিবরণী)") {
            return e.letterType === "দ্বিপক্ষীয় সভা (কার্যবিবরণী)" || e.letterType === "দ্বিপক্ষীয় সভা" || e.letterType === "দ্বি-সভা (কার্যবিবরনী)" || e.letterType === "দ্বি-সভা (কার্যবিবরণী)";
          }
          if (type === "মিলিকরণ" || type === "মিলকরণ") {
            return e.letterType === "মিলিকরণ" || e.letterType === "মিলকরণ" || (e.letterType || '').includes("মিলকরণ") || (e.letterType || '').includes("মিলিকরণ");
          }
          return e.letterType === type;
        }).length;

      statsMap[group.label] = {
        total: group.entries.length,
        sfi: {
          total: sfi.length,
          bsr: getCount(sfi, "বিএসআর"),
          triWork: getCount(sfi, "ত্রিপক্ষীয় সভা (কার্যপত্র)"),
          triMin: getCount(sfi, "ত্রিপক্ষীয় সভা (কার্যবিবরণী)"),
          reconciliation: getCount(sfi, "মিলিকরণ"),
        },
        nonSfi: {
          total: nonSfi.length,
          bsr: getCount(nonSfi, "বিএসআর"),
          biWork: getCount(nonSfi, "দ্বিপক্ষীয় সভা (কার্যপত্র)"),
          biMin: getCount(nonSfi, "দ্বিপক্ষীয় সভা (কার্যবিবরণী)"),
          reconciliation: getCount(nonSfi, "মিলিকরণ"),
        },
      };
    });

    return { cycleStats: statsMap, groupedEntries: groupsList };
  }, [filteredEntries]);

  const checkIssueValidation = (entryData: Partial<CorrespondenceEntry>): string | null => {
    const isSettled = entryData.isSettled;
    if (isSettled === "হ্যাঁ" || isSettled === "না") {
      const hasIssueNo = Boolean(entryData.issueLetterNo && String(entryData.issueLetterNo).trim());
      const hasIssueDate = Boolean(entryData.issueLetterDate && String(entryData.issueLetterDate).trim());

      if (!hasIssueNo && !hasIssueDate) {
        return "আপনি জারিপত্র নং ও তারিখ লেখেন নি।";
      }
      if (!hasIssueNo) {
        return "আপনি জারিপত্র নম্বর লেখেন নি।";
      }
      if (!hasIssueDate) {
        return "আপনি জারিপত্র তারিখ লেখেন নি।";
      }
    }

    // Dhaka Return date cannot be earlier than Sent to Dhaka date
    if (entryData.sentToDhakaDate && entryData.returnedFromDhakaDate) {
      if (entryData.returnedFromDhakaDate < entryData.sentToDhakaDate) {
        return "ঢাকা হতে ফেরত তারিখ ঢাকায় প্রেরণের তারিখের পূর্বের হতে পারবে না।";
      }
    }

    return null;
  };

  const handleInlineChange = (
    entryId: string,
    field: keyof CorrespondenceEntry,
    value: any,
  ) => {
    setValidationErrorMap((prev) => {
      if (!prev[entryId]) return prev;
      const next = { ...prev };
      delete next[entryId];
      return next;
    });
    setPendingChanges((prev) => {
      const entry = entries.find((e) => e.id === entryId);
      const currentPending = { ...(prev[entryId] || {}) };

      const normalizeVal = (v: any) =>
        v === undefined || v === null ? "" : String(v).trim();
      const originalValue = entry ? (entry as any)[field] : undefined;

      if (normalizeVal(value) === normalizeVal(originalValue)) {
        delete currentPending[field];
      } else {
        currentPending[field] = value;
      }

      const next = { ...prev };
      if (Object.keys(currentPending).length === 0) {
        delete next[entryId];
      } else {
        next[entryId] = currentPending;
      }
      return next;
    });
  };

  const saveAllChanges = async () => {
    if (Object.keys(pendingChanges).length === 0) return;

    let hasError = false;
    const newValidationErrors: Record<string, string> = {};

    for (const entryId in pendingChanges) {
      const entry = entries.find((e) => e.id === entryId);
      if (!entry) continue;
      const merged = { ...entry, ...pendingChanges[entryId] };
      const errorMsg = checkIssueValidation(merged);
      if (errorMsg) {
        hasError = true;
        newValidationErrors[entryId] = `সংরক্ষণ করা হয়নি! ${errorMsg}`;
      }
    }

    if (hasError) {
      setValidationErrorMap((prev) => ({ ...prev, ...newValidationErrors }));
      return;
    }

    setIsUpdating(true);

    try {
      const updatedIds: string[] = [];
      for (const entryId in pendingChanges) {
        const entry = entries.find((e) => e.id === entryId);
        if (entry && onInlineUpdate) {
          await onInlineUpdate({ ...entry, ...pendingChanges[entryId] });
          updatedIds.push(entryId);
        }
      }
      setPendingChanges({});
      setValidationErrorMap({});
      setActiveInlineEditingCell(null);
      setInlineEditingRowId(null);
      updatedIds.forEach((id) => {
        setRecentlyUpdatedMap((prev) => ({ ...prev, [id]: true }));
        setTimeout(() => {
          setRecentlyUpdatedMap((prev) => ({ ...prev, [id]: false }));
        }, 5000);
      });
    } catch (err) {
      console.error("Update failed", err);
    } finally {
      setIsUpdating(false);
    }
  };

  const saveRowChanges = async (entryId: string) => {
    const rowChanges = pendingChanges[entryId];
    if (!rowChanges) return;

    const entry = entries.find((e) => e.id === entryId);
    if (!entry) return;

    const merged = { ...entry, ...rowChanges };
    const errorMsg = checkIssueValidation(merged);

    if (errorMsg) {
      // BLOCK SAVE! DO NOT call onInlineUpdate!
      setValidationErrorMap((prev) => ({
        ...prev,
        [entryId]: `সংরক্ষণ করা হয়নি! ${errorMsg}`,
      }));
      return;
    }

    setIsUpdating(true);

    try {
      if (onInlineUpdate) {
        await onInlineUpdate(merged);
      }
      setValidationErrorMap((prev) => {
        const next = { ...prev };
        delete next[entryId];
        return next;
      });
      setPendingChanges((prev) => {
        const next = { ...prev };
        delete next[entryId];
        return next;
      });
      setActiveInlineEditingCell((prev) => (prev?.id === entryId ? null : prev));
      setInlineEditingRowId((prev) => (prev === entryId ? null : prev));
      setRecentlyUpdatedMap((prev) => ({ ...prev, [entryId]: true }));
      setTimeout(() => {
        setRecentlyUpdatedMap((prev) => ({ ...prev, [entryId]: false }));
      }, 5000);
    } catch (err) {
      console.error("Update failed", err);
    } finally {
      setIsUpdating(false);
    }
  };



  // Header font-black with sticky support
  const thCls =
    "sticky top-0 z-[120] border-r border-b border-slate-300 px-1 sm:px-1.5 py-2 text-center align-middle font-black text-slate-900 text-[10px] sm:text-[11px] bg-slate-200 shadow-[inset_0_1px_0_rgba(255,255,255,0.9)] bg-clip-border whitespace-nowrap leading-tight";
  const thSubCls =
    "sticky top-[40px] z-[120] border-r border-b border-slate-300 px-1 py-1 text-center align-middle font-black text-slate-700 text-[9.5px] sm:text-[10.5px] bg-slate-200 shadow-[inset_0_1px_0_rgba(255,255,255,0.5)] bg-clip-border whitespace-nowrap leading-tight";
  // Data cells font-bold
  const tdCls =
    "border border-slate-300 px-2 py-2 text-[10px] sm:text-[10.5px] text-slate-800 font-bold leading-tight align-top transition-colors group-hover:bg-blue-50/50 break-words relative";
  const labelCls = "text-[10px] font-bold text-emerald-800 shrink-0";
  const valCls = "text-[10px] font-black text-slate-950";
  const customDropdownCls = (isOpen: boolean) =>
    `relative flex items-center gap-3 px-4 h-[48px] bg-white border rounded-xl cursor-pointer transition-all duration-300 ${isOpen ? "border-blue-600 ring-4 ring-blue-50 shadow-md z-[1010]" : "border-slate-300 shadow-sm hover:border-slate-400"}`;

  const hasChanges = Object.keys(pendingChanges).length > 0;

  const clearFilters = () => {
    setSearchTerm("");
    setFilterParaType("");
    setFilterType("");
    setFilterReceiver("");
    setFilterStatus("");
    setSelectedCycleDate(null);
    onClearHighlight?.();
  };

  const isFiltered = searchTerm || filterParaType || filterType || filterReceiver || filterStatus || selectedCycleDate;

  return (
    <div
      id="section-correspondence-register"
      className="w-full relative animate-premium-page"
    >
      {/* Header Controls */}
      <div className="relative mb-6 no-print z-[99999]">
        <IDBadge id="section-correspondence-top-header" />
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 bg-white p-4 rounded-[1.5rem] border border-slate-200 shadow-sm relative group transition-all duration-500 hover:shadow-md">
          <div className="flex items-center gap-4 relative z-10">
            <div className="w-14 h-14 bg-emerald-50 rounded-[1.2rem] text-emerald-600 flex items-center justify-center shadow-inner border border-emerald-100 group-hover:scale-105 transition-transform duration-500">
              <Mail size={28} strokeWidth={2} />
            </div>
            <div className="space-y-1">
              <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                প্রাপ্ত চিঠিপত্র সংক্রান্ত রেজিস্টার
              </h2>
              <div className="flex items-center gap-3">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-blue-500 text-white rounded-full font-bold text-[10px] shadow-sm border border-blue-400/30">
                  <CalendarRange size={12} />
                  <span>সাইকেল: {toBengaliDigits(cycleInfo.label)}</span>
                </div>
                <p className="text-slate-400 font-bold text-[9px] uppercase tracking-[0.2em]">
                  Correspondence Ledger
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 relative z-10">
            <div className="relative">
              <button
                ref={summaryButtonRef}
                onClick={() => setShowSummary(!showSummary)}
                className={`px-5 py-3 rounded-xl font-black text-[12px] flex items-center gap-2 transition-all shadow-md ${showSummary ? "bg-blue-600 text-white shadow-blue-500/20" : "bg-blue-50 text-blue-700 border border-blue-100 hover:bg-blue-100 shadow-sm"}`}
              >
                <Sparkles
                  size={16}
                  className={showSummary ? "text-blue-100" : "text-blue-500"}
                />{" "}
                রেজিস্টার সারসংক্ষেপ
              </button>

              <AnimatePresence>
                {showSummary && (
                  <motion.div
                    ref={summaryRef}
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{
                      duration: 0.25,
                      ease: [0.23, 1, 0.32, 1],
                    }}
                    style={{
                      position: "absolute",
                      top: "calc(100% + 12px)",
                      right: 0,
                      width: "450px",
                      zIndex: 9999999,
                      maxHeight: "min(540px, 75vh)",
                    }}
                    className="bg-white rounded-[2rem] shadow-[0_40px_100px_-15px_rgba(0,0,0,0.4)] border border-slate-200 overflow-hidden no-print text-left flex flex-col"
                  >
                    <div className="bg-gradient-to-r from-blue-700 to-indigo-700 p-6 flex items-center justify-between shrink-0">
                      <div className="flex items-center gap-3 text-white">
                        <div className="w-10 h-10 bg-white/20 backdrop-blur-md rounded-xl flex items-center justify-center shadow-inner">
                          <Sparkles size={22} className="text-white" />
                        </div>
                        <div>
                          <h4 className="text-base font-black tracking-tight">
                            রেজিস্টার সারসংক্ষেপ
                          </h4>
                          <p className="text-[10px] font-bold opacity-70 uppercase tracking-[0.2em]">
                            Register Summary Overview
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={() => setShowSummary(false)}
                        className="w-8 h-8 flex items-center justify-center hover:bg-white/20 rounded-full text-white transition-all duration-300"
                      >
                        <XCircle size={20} />
                      </button>
                    </div>

                    <div className="p-6 space-y-6 overflow-y-auto flex-1">
                      {/* Total Letters Card */}
                      <div className="relative overflow-hidden bg-slate-50 rounded-2xl p-5 border border-slate-200 group">
                        <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/5 rounded-full -mr-8 -mt-8 transition-transform group-hover:scale-150 duration-700"></div>
                        <div className="relative flex items-center justify-between">
                          <div>
                            <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-1">
                              সর্বমোট চিঠিপত্র
                            </p>
                            <h2 className="text-3xl font-black text-slate-900 tracking-tighter">
                              {toBengaliDigits(stats.total)}{" "}
                              <span className="text-sm font-bold text-slate-500">
                                টি
                              </span>
                            </h2>
                          </div>
                          <Inbox className="text-blue-200" size={40} />
                        </div>
                      </div>

                      {/* SFI Section */}
                      <div className="space-y-4">
                        <div className="flex items-center gap-3">
                          <div className="h-[2px] flex-1 bg-emerald-100"></div>
                          <h5 className="text-[11px] font-black text-emerald-700 uppercase tracking-[0.15em] flex items-center gap-2">
                            <CheckCircle2 size={14} /> এসএফআই (SFI)
                          </h5>
                          <div className="h-[2px] flex-1 bg-emerald-100"></div>
                        </div>

                        <div className="grid grid-cols-2 gap-2.5">
                          <div className="bg-emerald-50/40 border border-emerald-100/50 rounded-xl p-2.5 hover:bg-emerald-50 transition-colors">
                            <p className="text-[9.5px] font-bold text-emerald-600/70 uppercase mb-0.5">
                              বিএসআর
                            </p>
                            <p className="text-sm font-black text-slate-800">
                              {toBengaliDigits(stats.sfi.bsr)} টি
                            </p>
                          </div>
                          <div className="bg-emerald-50/40 border border-emerald-100/50 rounded-xl p-2.5 hover:bg-emerald-50 transition-colors">
                            <p className="text-[9.5px] font-bold text-emerald-600/70 uppercase mb-0.5">
                              মিলিকরণ
                            </p>
                            <p className="text-sm font-black text-slate-800">
                              {toBengaliDigits(stats.sfi.reconciliation)} টি
                            </p>
                          </div>
                          <div className="bg-emerald-50/40 border border-emerald-100/50 rounded-xl p-2.5 hover:bg-emerald-50 transition-colors">
                            <p className="text-[9.5px] font-bold text-emerald-600/70 uppercase mb-0.5">
                              ত্রিপক্ষীয় (কার্যপত্র)
                            </p>
                            <p className="text-sm font-black text-slate-800">
                              {toBengaliDigits(stats.sfi.triWork)} টি
                            </p>
                          </div>
                          <div className="bg-emerald-50/40 border border-emerald-100/50 rounded-xl p-2.5 hover:bg-emerald-50 transition-colors">
                            <p className="text-[9.5px] font-bold text-emerald-600/70 uppercase mb-0.5">
                              ত্রিপক্ষীয় (বিবরণী)
                            </p>
                            <p className="text-sm font-black text-slate-800">
                              {toBengaliDigits(stats.sfi.triMin)} টি
                            </p>
                          </div>
                          {stats.sfi.biWork > 0 && (
                            <div className="bg-emerald-50/40 border border-emerald-100/50 rounded-xl p-2.5 hover:bg-emerald-50 transition-colors">
                              <p className="text-[9.5px] font-bold text-emerald-600/70 uppercase mb-0.5">
                                দ্বিপক্ষীয় (কার্যপত্র)
                              </p>
                              <p className="text-sm font-black text-slate-800">
                                {toBengaliDigits(stats.sfi.biWork)} টি
                              </p>
                            </div>
                          )}
                          {stats.sfi.biMin > 0 && (
                            <div className="bg-emerald-50/40 border border-emerald-100/50 rounded-xl p-2.5 hover:bg-emerald-50 transition-colors">
                              <p className="text-[9.5px] font-bold text-emerald-600/70 uppercase mb-0.5">
                                দ্বিপক্ষীয় (বিবরণী)
                              </p>
                              <p className="text-sm font-black text-slate-800">
                                {toBengaliDigits(stats.sfi.biMin)} টি
                              </p>
                            </div>
                          )}
                          {stats.sfi.others > 0 && (
                            <div className="bg-emerald-50/40 border border-emerald-100/50 rounded-xl p-2.5 hover:bg-emerald-50 transition-colors">
                              <p className="text-[9.5px] font-bold text-emerald-600/70 uppercase mb-0.5">
                                অন্যান্য
                              </p>
                              <p className="text-sm font-black text-slate-800">
                                {toBengaliDigits(stats.sfi.others)} টি
                              </p>
                            </div>
                          )}
                        </div>
                        <div className="bg-emerald-600 text-white px-4 py-2 rounded-xl text-center">
                          <span className="text-xs font-black">
                            মোট এসএফআই: {toBengaliDigits(stats.sfi.total)} টি
                          </span>
                        </div>
                      </div>

                      {/* Non-SFI Section */}
                      <div className="space-y-4">
                        <div className="flex items-center gap-3">
                          <div className="h-[2px] flex-1 bg-amber-100"></div>
                          <h5 className="text-[11px] font-black text-amber-700 uppercase tracking-[0.15em] flex items-center gap-2">
                            <FileText size={14} /> নন এসএফআই (Non-SFI)
                          </h5>
                          <div className="h-[2px] flex-1 bg-amber-100"></div>
                        </div>

                        <div className="grid grid-cols-2 gap-2.5">
                          <div className="bg-amber-50/40 border border-amber-100/50 rounded-xl p-2.5 hover:bg-amber-50 transition-colors">
                            <p className="text-[9.5px] font-bold text-amber-600/70 uppercase mb-0.5">
                              বিএসআর
                            </p>
                            <p className="text-sm font-black text-slate-800">
                              {toBengaliDigits(stats.nonSfi.bsr)} টি
                            </p>
                          </div>
                          <div className="bg-amber-50/40 border border-amber-100/50 rounded-xl p-2.5 hover:bg-amber-50 transition-colors">
                            <p className="text-[9.5px] font-bold text-amber-600/70 uppercase mb-0.5">
                              মিলিকরণ
                            </p>
                            <p className="text-sm font-black text-slate-800">
                              {toBengaliDigits(stats.nonSfi.reconciliation)} টি
                            </p>
                          </div>
                          <div className="bg-amber-50/40 border border-amber-100/50 rounded-xl p-2.5 hover:bg-amber-50 transition-colors">
                            <p className="text-[9.5px] font-bold text-amber-600/70 uppercase mb-0.5">
                              দ্বিপক্ষীয় (কার্যপত্র)
                            </p>
                            <p className="text-sm font-black text-slate-800">
                              {toBengaliDigits(stats.nonSfi.biWork)} টি
                            </p>
                          </div>
                          <div className="bg-amber-50/40 border border-amber-100/50 rounded-xl p-2.5 hover:bg-amber-50 transition-colors">
                            <p className="text-[9.5px] font-bold text-amber-600/70 uppercase mb-0.5">
                              দ্বিপক্ষীয় (বিবরণী)
                            </p>
                            <p className="text-sm font-black text-slate-800">
                              {toBengaliDigits(stats.nonSfi.biMin)} টি
                            </p>
                          </div>
                          {stats.nonSfi.triWork > 0 && (
                            <div className="bg-amber-50/40 border border-amber-100/50 rounded-xl p-2.5 hover:bg-amber-50 transition-colors">
                              <p className="text-[9.5px] font-bold text-amber-600/70 uppercase mb-0.5">
                                ত্রিপক্ষীয় (কার্যপত্র)
                              </p>
                              <p className="text-sm font-black text-slate-800">
                                {toBengaliDigits(stats.nonSfi.triWork)} টি
                              </p>
                            </div>
                          )}
                          {stats.nonSfi.triMin > 0 && (
                            <div className="bg-amber-50/40 border border-amber-100/50 rounded-xl p-2.5 hover:bg-amber-50 transition-colors">
                              <p className="text-[9.5px] font-bold text-amber-600/70 uppercase mb-0.5">
                                ত্রিপক্ষীয় (বিবরণী)
                              </p>
                              <p className="text-sm font-black text-slate-800">
                                {toBengaliDigits(stats.nonSfi.triMin)} টি
                              </p>
                            </div>
                          )}
                          <div className="bg-amber-50/40 border border-amber-100/50 rounded-xl p-2.5 hover:bg-amber-50 transition-colors">
                            <p className="text-[9.5px] font-bold text-amber-600/70 uppercase mb-0.5">
                              অন্যান্য
                            </p>
                            <p className="text-sm font-black text-slate-800">
                              {toBengaliDigits(stats.nonSfi.others)} টি
                            </p>
                          </div>
                        </div>
                        <div className="bg-amber-600 text-white px-4 py-2 rounded-xl text-center">
                          <span className="text-xs font-black">
                            মোট নন এসএফআই: {toBengaliDigits(stats.nonSfi.total)} টি
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-slate-900 p-4 text-center">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.3em]">
                        Ledger Management System
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {hasChanges && (
              <button
                onClick={saveAllChanges}
                disabled={isUpdating}
                className="px-6 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-xl font-black text-[11px] flex items-center gap-2 hover:shadow-xl hover:scale-105 active:scale-95 transition-all animate-in zoom-in-95 duration-300 border border-emerald-400 shadow-lg shadow-emerald-200/50"
              >
                {isUpdating ? (
                  <Clock size={16} className="animate-spin" />
                ) : (
                  <Save size={16} />
                )}
                আপডেট করুন {toBengaliDigits(Object.keys(pendingChanges).length)}{" "}
                টি এন্ট্রি
              </button>
            )}
          </div>
        </div>
      </div>

      {cycleDetailModal.isOpen ? (
        <div className="bg-white flex flex-col h-[calc(100vh-210px)] min-h-[580px] rounded-2xl border border-slate-300 shadow-xl overflow-hidden animate-in fade-in zoom-in-[0.99] duration-200 mb-6">
          <LetterDetailsModal
            isOpen={true}
            isEmbedded={true}
            onClose={() =>
              setCycleDetailModal({
                isOpen: false,
                title: "",
                letters: [],
              })
            }
            title={cycleDetailModal.title}
            letters={cycleDetailModal.letters}
          />
        </div>
      ) : (
        <>
          {/* Filter UI for Correspondence */}
          <div
            id="correspondence-filters"
            className="!bg-white p-4 md:p-6 rounded-2xl border border-slate-200 shadow-xl space-y-4 no-print mb-6 animate-in slide-in-from-top-4 duration-300 relative z-[1000] isolate"
          >
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {/* Cycle & Date Selection */}
          <div className="space-y-1.5" ref={cycleDropdownRef}>
            <label className="text-[11px] font-bold text-slate-500 uppercase tracking-widest ml-1">
              সময়কাল / সাইকেল
            </label>
            <div
              onClick={() => setIsCycleDropdownOpen(!isCycleDropdownOpen)}
              className={customDropdownCls(isCycleDropdownOpen)}
            >
              <CalendarDays className="text-blue-600" size={16} />
              <span className="font-bold text-[13px] text-slate-900 truncate">
                {isCustomDateActive && (filterStartDate || filterEndDate)
                  ? `${filterStartDate ? toBengaliDigits(format(new Date(filterStartDate), 'dd/MM/yyyy')) : ''} হতে ${filterEndDate ? toBengaliDigits(format(new Date(filterEndDate), 'dd/MM/yyyy')) : ''}`
                  : selectedCycleDate
                  ? toBengaliDigits(activeCycle?.label || "")
                  : "সকল সময়কাল"}
              </span>
              <ChevronDown
                size={14}
                className={`text-slate-400 ml-auto transition-transform duration-300 ${isCycleDropdownOpen ? "rotate-180 text-blue-600" : ""}`}
              />

              {isCycleDropdownOpen && (
                <div className="absolute top-[calc(100%+12px)] left-0 w-[280px] sm:w-[310px] !bg-white border-2 border-slate-200 rounded-2xl shadow-[0_30px_60px_rgba(0,0,0,0.4)] z-[2000] overflow-hidden animate-in fade-in zoom-in-95 slide-in-from-top-4 duration-300 ease-out select-none">
                  <div className="p-2 border-b border-slate-100 flex items-center gap-1 bg-slate-50">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setDateTab('custom');
                      }}
                      className={`flex-1 py-1 text-[11px] font-black rounded-lg transition-all cursor-pointer ${
                        dateTab === 'custom'
                          ? 'bg-white text-blue-700 shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      হতে - থেকে ডেট
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setDateTab('cycle');
                      }}
                      className={`flex-1 py-1 text-[11px] font-black rounded-lg transition-all cursor-pointer ${
                        dateTab === 'cycle'
                          ? 'bg-white text-blue-700 shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      মাসিক সাইকেল
                    </button>
                  </div>

                  {dateTab === 'custom' && (
                    <div className="p-3 space-y-3 bg-white" onClick={(e) => e.stopPropagation()}>
                      <div className="text-[11px] font-black text-slate-800 flex items-center gap-1.5">
                        <CalendarDays size={13} className="text-blue-600" />
                        <span>কাংখিত সময়কাল নির্ধারণ (হতে - থেকে)</span>
                      </div>

                      <div className="space-y-2">
                        <div>
                          <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                            শুরুর তারিখ (হতে):
                          </label>
                          <div className="relative flex items-center border border-slate-300 rounded-lg px-2 py-1 bg-white focus-within:border-blue-500">
                            <input
                              type="text"
                              value={manualStartDate}
                              onChange={(e) => {
                                const val = e.target.value;
                                setManualStartDate(val);
                                const parsed = parseManualDate(val);
                                if (parsed) {
                                  setFilterStartDate(format(parsed, 'yyyy-MM-dd'));
                                  setIsCustomDateActive(true);
                                } else if (!val.trim()) {
                                  setFilterStartDate('');
                                }
                              }}
                              onBlur={() => {
                                const parsed = parseManualDate(manualStartDate);
                                if (parsed) {
                                  setFilterStartDate(format(parsed, 'yyyy-MM-dd'));
                                  setManualStartDate(toBengaliDigits(format(parsed, 'dd/MM/yyyy')));
                                } else if (!manualStartDate.trim()) {
                                  setFilterStartDate('');
                                  setManualStartDate('');
                                } else if (filterStartDate) {
                                  setManualStartDate(toBengaliDigits(format(new Date(filterStartDate), 'dd/MM/yyyy')));
                                }
                              }}
                              placeholder="০১/০১/২০২৬"
                              className="w-full bg-transparent font-bold text-xs text-slate-800 outline-none p-0 border-none focus:ring-0 cursor-text"
                              title="ক্যালেন্ডার বা ম্যানুয়ালি তারিখ লিখুন (যেমন: ০১/০১/২০২৬ বা 01/01/2026)"
                            />
                            <div className="relative shrink-0 ml-1">
                              <input
                                type="date"
                                value={filterStartDate}
                                onChange={(e) => {
                                  setFilterStartDate(e.target.value);
                                  setIsCustomDateActive(true);
                                }}
                                className="opacity-0 absolute inset-0 w-full h-full cursor-pointer z-10"
                                title="ক্যালেন্ডার থেকে নির্বাচন করুন"
                              />
                              <Calendar size={14} className="text-blue-600 cursor-pointer" />
                            </div>
                          </div>
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                            শেষের তারিখ (পর্যন্ত):
                          </label>
                          <div className="relative flex items-center border border-slate-300 rounded-lg px-2 py-1 bg-white focus-within:border-blue-500">
                            <input
                              type="text"
                              value={manualEndDate}
                              onChange={(e) => {
                                const val = e.target.value;
                                setManualEndDate(val);
                                const parsed = parseManualDate(val);
                                if (parsed) {
                                  setFilterEndDate(format(parsed, 'yyyy-MM-dd'));
                                  setIsCustomDateActive(true);
                                } else if (!val.trim()) {
                                  setFilterEndDate('');
                                }
                              }}
                              onBlur={() => {
                                const parsed = parseManualDate(manualEndDate);
                                if (parsed) {
                                  setFilterEndDate(format(parsed, 'yyyy-MM-dd'));
                                  setManualEndDate(toBengaliDigits(format(parsed, 'dd/MM/yyyy')));
                                } else if (!manualEndDate.trim()) {
                                  setFilterEndDate('');
                                  setManualEndDate('');
                                } else if (filterEndDate) {
                                  setManualEndDate(toBengaliDigits(format(new Date(filterEndDate), 'dd/MM/yyyy')));
                                }
                              }}
                              placeholder="৩১/০১/২০২৬"
                              className="w-full bg-transparent font-bold text-xs text-slate-800 outline-none p-0 border-none focus:ring-0 cursor-text"
                              title="ক্যালেন্ডার বা ম্যানুয়ালি তারিখ লিখুন (যেমন: ৩১/০১/২০২৬ বা 31/01/2026)"
                            />
                            <div className="relative shrink-0 ml-1">
                              <input
                                type="date"
                                value={filterEndDate}
                                onChange={(e) => {
                                  setFilterEndDate(e.target.value);
                                  setIsCustomDateActive(true);
                                }}
                                className="opacity-0 absolute inset-0 w-full h-full cursor-pointer z-10"
                                title="ক্যালেন্ডার থেকে নির্বাচন করুন"
                              />
                              <Calendar size={14} className="text-blue-600 cursor-pointer" />
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Quick Presets: [ < ] [বিগত মাস] [চলতি মাস] [ > ] [গত ৩০ দিন] */}
                      <div className="flex flex-wrap items-center gap-1 pt-1 border-t border-slate-100">
                        {/* পূর্ববর্তী মাস নেভিগেশন বোতাম */}
                        <button
                          type="button"
                          onClick={() => {
                            const base = filterStartDate ? new Date(filterStartDate) : new Date();
                            const prevM = subMonths(base, 1);
                            const s = format(startOfMonth(prevM), 'yyyy-MM-dd');
                            const e = format(endOfMonth(prevM), 'yyyy-MM-dd');
                            setFilterStartDate(s);
                            setFilterEndDate(e);
                            setIsCustomDateActive(true);
                          }}
                          className="p-1 px-1.5 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-300 border border-slate-200 rounded text-slate-700 transition-colors cursor-pointer flex items-center justify-center shrink-0"
                          title="পূর্ববর্তী মাস (পেছনে যান - যতবার চাপবেন এক মাস করে পেছনে যাবে)"
                        >
                          <ChevronLeft size={12} />
                        </button>

                        {/* বিগত মাস */}
                        <button
                          type="button"
                          onClick={() => {
                            const now = new Date();
                            const s = format(startOfMonth(subMonths(now, 1)), 'yyyy-MM-dd');
                            const e = format(endOfMonth(subMonths(now, 1)), 'yyyy-MM-dd');
                            setFilterStartDate(s);
                            setFilterEndDate(e);
                            setIsCustomDateActive(true);
                          }}
                          className="px-2 py-0.5 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 border border-slate-200 rounded text-[10px] font-bold cursor-pointer"
                          title="বিগত মাস"
                        >
                          বিগত মাস
                        </button>

                        {/* চলতি মাস (বিগত মাসের ডান পাশে) */}
                        <button
                          type="button"
                          onClick={() => {
                            const now = new Date();
                            const s = format(startOfMonth(now), 'yyyy-MM-dd');
                            const e = format(endOfMonth(now), 'yyyy-MM-dd');
                            setFilterStartDate(s);
                            setFilterEndDate(e);
                            setIsCustomDateActive(true);
                          }}
                          className="px-2 py-0.5 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 border border-slate-200 rounded text-[10px] font-bold cursor-pointer"
                          title="চলতি মাস"
                        >
                          চলতি মাস
                        </button>

                        {/* পরবর্তী মাস নেভিগেশন বোতাম */}
                        <button
                          type="button"
                          onClick={() => {
                            const base = filterStartDate ? new Date(filterStartDate) : new Date();
                            const nextM = addMonths(base, 1);
                            const s = format(startOfMonth(nextM), 'yyyy-MM-dd');
                            const e = format(endOfMonth(nextM), 'yyyy-MM-dd');
                            setFilterStartDate(s);
                            setFilterEndDate(e);
                            setIsCustomDateActive(true);
                          }}
                          className="p-1 px-1.5 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-300 border border-slate-200 rounded text-slate-700 transition-colors cursor-pointer flex items-center justify-center shrink-0"
                          title="পরবর্তী মাস (সামনে যান)"
                        >
                          <ChevronRight size={12} />
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            const now = new Date();
                            const s = format(new Date(now.getTime() - 29 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd');
                            const e = format(now, 'yyyy-MM-dd');
                            setFilterStartDate(s);
                            setFilterEndDate(e);
                            setIsCustomDateActive(true);
                          }}
                          className="px-2 py-0.5 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 border border-slate-200 rounded text-[10px] font-bold cursor-pointer"
                        >
                          গত ৩০ দিন
                        </button>
                      </div>

                      <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-100">
                        <button
                          type="button"
                          onClick={() => {
                            setFilterStartDate("");
                            setFilterEndDate("");
                            setIsCustomDateActive(false);
                            setSelectedCycleDate(null);
                          }}
                          className="px-2.5 py-1 text-slate-500 hover:text-rose-600 rounded text-xs font-bold cursor-pointer"
                        >
                          মুছুন
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setIsCustomDateActive(true);
                            setIsCycleDropdownOpen(false);
                          }}
                          className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-black shadow-xs cursor-pointer"
                        >
                          প্রয়োগ করুন
                        </button>
                      </div>
                    </div>
                  )}

                  {dateTab === 'cycle' && (
                    <div className="max-h-[320px] overflow-y-auto no-scrollbar !bg-white !bg-opacity-100 flex flex-col">
                      <div className="px-4 py-2.5 border-b border-slate-100 flex items-center justify-between sticky top-0 !bg-white !bg-opacity-100 z-[2010]">
                        <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest flex items-center gap-2">
                          <CalendarSearch size={12} /> সাইকেল নির্বাচন
                        </span>
                      </div>
                      <div className="p-2 space-y-1">
                        <div
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedCycleDate(null);
                            setIsCustomDateActive(false);
                            setIsCycleDropdownOpen(false);
                          }}
                          className={`flex items-center justify-between px-3 py-2 rounded-xl cursor-pointer transition-all !bg-opacity-100 ${!selectedCycleDate && !isCustomDateActive ? "!bg-blue-600 !text-white shadow-lg font-black" : "hover:bg-slate-100 text-slate-700 font-bold bg-white"}`}
                        >
                          <span className="text-[12px]">সকল</span>
                          {!selectedCycleDate && !isCustomDateActive && (
                            <Check size={14} strokeWidth={3} />
                          )}
                        </div>
                        {cycleOptions.map((opt, idx) => {
                          const isSelected = selectedCycleDate && opt.date.getTime() === selectedCycleDate.getTime() && !isCustomDateActive;
                          return (
                            <div
                              key={idx}
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedCycleDate(opt.date);
                                setIsCustomDateActive(false);
                                setIsCycleDropdownOpen(false);
                              }}
                              className={`flex items-center justify-between px-3 py-2 rounded-xl cursor-pointer transition-all !bg-opacity-100 ${isSelected ? "!bg-blue-600 !text-white shadow-lg font-black" : "hover:bg-slate-100 text-slate-700 font-bold bg-white"}`}
                            >
                              <span className="text-[12px] whitespace-nowrap">{opt.label}</span>
                              {isSelected && (
                                <Check size={14} strokeWidth={3} />
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
          {/* Status Selection (চলমান / সকল / নিষ্পন্ন) */}
          <div className="space-y-1.5" ref={statusDropdownRef}>
            <label className="text-[11px] font-bold text-slate-500 uppercase tracking-widest ml-1">
              চিঠি ফিল্টার
            </label>
            <div
              onClick={() => setIsStatusDropdownOpen(!isStatusDropdownOpen)}
              className={customDropdownCls(isStatusDropdownOpen)}
            >
              <Clock size={18} className="text-amber-500" />
              <span className="font-bold text-[13px] text-slate-900 truncate">
                {filterStatus === ""
                  ? `সকল চিঠি (${toBengaliDigits(entries.length)})`
                  : filterStatus === "চলমান"
                  ? `চলমান চিঠি (${toBengaliDigits(ongoingCount)})`
                  : `নিষ্পন্ন চিঠি (${toBengaliDigits(settledCount)})`}
              </span>
              <ChevronDown
                size={14}
                className={`text-slate-400 ml-auto transition-transform duration-300 ${isStatusDropdownOpen ? "rotate-180 text-blue-600" : ""}`}
              />

              {isStatusDropdownOpen && (
                <div className="absolute top-[calc(100%+12px)] left-0 w-full min-w-[220px] !bg-white border-2 border-slate-200 rounded-2xl shadow-[0_30px_60px_rgba(0,0,0,0.4)] z-[2000] overflow-hidden animate-in fade-in zoom-in-95 slide-in-from-top-4 duration-300 ease-out">
                  <div className="max-h-[320px] overflow-y-auto no-scrollbar !bg-white !bg-opacity-100 flex flex-col">
                    <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-center sticky top-0 !bg-white !bg-opacity-100 z-[2010]">
                      <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest flex items-center gap-2">
                        <Filter size={12} /> অবস্থা নির্বাচন
                      </span>
                    </div>
                    <div className="p-2 space-y-1">
                      {[
                        { val: "চলমান", label: `চলমান চিঠি (${toBengaliDigits(ongoingCount)})` },
                        { val: "", label: `সকল চিঠি (${toBengaliDigits(entries.length)})` },
                        { val: "নিষ্পন্ন", label: `নিষ্পন্ন চিঠি (${toBengaliDigits(settledCount)})` },
                      ].map((opt, idx) => (
                        <div
                          key={idx}
                          onClick={(e) => {
                            e.stopPropagation();
                            setFilterStatus(opt.val);
                            setIsStatusDropdownOpen(false);
                          }}
                          className={`flex items-center justify-between gap-2 px-4 py-2.5 rounded-xl cursor-pointer transition-all !bg-opacity-100 ${filterStatus === opt.val ? "!bg-blue-600 !text-white shadow-lg" : "hover:bg-slate-100 text-slate-700 font-bold bg-white"}`}
                        >
                          <span className="text-[13px]">{opt.label}</span>
                          {filterStatus === opt.val && (
                            <Check size={16} strokeWidth={3} />
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Branch Selection */}
          <div className="space-y-1.5" ref={branchDropdownRef}>
            <label className="text-[11px] font-bold text-slate-500 uppercase tracking-widest ml-1">
              শাখা
            </label>
            <div
              onClick={() => setIsBranchDropdownOpen(!isBranchDropdownOpen)}
              className={customDropdownCls(isBranchDropdownOpen)}
            >
              <LayoutGrid className="text-blue-600" size={16} />
              <span className="font-bold text-[13px] text-slate-900 truncate">
                {filterParaType === "" ? "সকল শাখা" : filterParaType}
              </span>
              <ChevronDown
                size={14}
                className={`text-slate-400 ml-auto transition-transform duration-300 ${isBranchDropdownOpen ? "rotate-180 text-blue-600" : ""}`}
              />

              {isBranchDropdownOpen && (
                <div className="absolute top-[calc(100%+12px)] left-0 w-full min-w-[220px] !bg-white border-2 border-slate-200 rounded-2xl shadow-[0_30px_60px_rgba(0,0,0,0.4)] z-[2000] overflow-hidden animate-in fade-in zoom-in-95 slide-in-from-top-4 duration-300 ease-out">
                  <div className="max-h-[320px] overflow-y-auto no-scrollbar !bg-white !bg-opacity-100 flex flex-col">
                    <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-center sticky top-0 !bg-white !bg-opacity-100 z-[2010]">
                      <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest flex items-center gap-2">
                        <LayoutGrid size={12} /> শাখা নির্বাচন
                      </span>
                    </div>
                    <div className="p-2 space-y-1">
                      {[
                        { val: "", label: "সকল শাখা" },
                        { val: "এসএফআই", label: "এসএফআই (SFI)" },
                        { val: "নন এসএফআই", label: "নন এসএফআই (Non-SFI)" },
                        { val: "প্রশাসন", label: "প্রশাসন (Administration)" },
                      ].map((opt, idx) => (
                        <div
                          key={idx}
                          onClick={(e) => {
                            e.stopPropagation();
                            setFilterParaType(opt.val);
                            setIsBranchDropdownOpen(false);
                          }}
                          className={`flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl cursor-pointer transition-all !bg-opacity-100 ${filterParaType === opt.val ? "!bg-blue-600 !text-white shadow-lg" : "hover:bg-slate-100 text-slate-700 font-bold bg-white"}`}
                        >
                          <span className="text-[13px]">{opt.label}</span>
                          {filterParaType === opt.val && (
                            <Check size={16} strokeWidth={3} />
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Letter Type Selection */}
          <div className="space-y-1.5" ref={typeDropdownRef}>
            <label className="text-[11px] font-bold text-slate-500 uppercase tracking-widest ml-1">
              চিঠির ধরণ
            </label>
            <div
              onClick={() => setIsTypeDropdownOpen(!isTypeDropdownOpen)}
              className={customDropdownCls(isTypeDropdownOpen)}
            >
              <FileText className="text-blue-600" size={16} />
              <span className="font-bold text-[13px] text-slate-900 truncate">
                {filterType === "" ? "সকল ধরণ" : getCleanLetterTypeDisplay(filterType)}
              </span>
              <ChevronDown
                size={14}
                className={`text-slate-400 ml-auto transition-transform duration-300 ${isTypeDropdownOpen ? "rotate-180 text-blue-600" : ""}`}
              />

              {isTypeDropdownOpen && (
                <div className="absolute top-[calc(100%+12px)] right-0 w-full min-w-[220px] !bg-white border-2 border-slate-200 rounded-2xl shadow-[0_30px_60px_rgba(0,0,0,0.4)] z-[2000] overflow-hidden animate-in fade-in zoom-in-95 slide-in-from-top-4 duration-300 ease-out">
                  <div className="max-h-[320px] overflow-y-auto no-scrollbar !bg-white !bg-opacity-100 flex flex-col">
                    <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-center sticky top-0 !bg-white !bg-opacity-100 z-[2010]">
                      <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest flex items-center gap-2">
                        <FileText size={12} /> ধরণ নির্বাচন
                      </span>
                    </div>
                    <div className="p-2 space-y-1">
                      {[
                        { val: "", label: "সকল ধরণ" },
                        { val: "বিএসআর", label: "বিএসআর" },
                        { val: "দ্বি-সভা (কার্যবিবরনী)", label: "দ্বি-সভা (কার্যবিবরনী)" },
                        { val: "দ্বি-সভা (কার্যপত্র)", label: "দ্বি-সভা (কার্যপত্র)" },
                        { val: "ত্রিপক্ষীয় সভা", label: "ত্রিপক্ষীয় সভা" },
                        { val: "কার্যপত্র (ত্রি-সভা)", label: "কার্যপত্র (ত্রি-সভা)" },
                        { val: "মিলকরণ", label: "মিলকরণ" },
                        { val: "অন্যান্য", label: "অন্যান্য" },
                      ].map((opt, idx) => (
                        <div
                          key={idx}
                          onClick={(e) => {
                            e.stopPropagation();
                            setFilterType(opt.val);
                            setIsTypeDropdownOpen(false);
                          }}
                          className={`flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl cursor-pointer transition-all !bg-opacity-100 ${filterType === opt.val ? "!bg-blue-600 !text-white shadow-lg" : "hover:bg-slate-100 text-slate-700 font-bold bg-white"}`}
                        >
                          <span className="text-[13px]">{opt.label}</span>
                          {filterType === opt.val && (
                            <Check size={16} strokeWidth={3} />
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

            {/* Receiver Selection */}
            <div className="space-y-1.5" ref={receiverDropdownRef}>
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-widest ml-1">
                প্রাপক/গ্রহীতা
              </label>
              <div
                onClick={() => setIsReceiverDropdownOpen(!isReceiverDropdownOpen)}
                className={customDropdownCls(isReceiverDropdownOpen)}
              >
                <Users className="text-blue-600 font-bold" size={16} />
                <span className="font-bold text-[13px] text-slate-900 truncate">
                  {filterReceiver === "" ? "সকল প্রাপক" : filterReceiver}
                </span>
                <ChevronDown
                  size={14}
                  className={`text-slate-400 ml-auto transition-transform duration-300 ${isReceiverDropdownOpen ? "rotate-180 text-blue-600" : ""}`}
                />

                {isReceiverDropdownOpen && (
                  <div className="absolute top-[calc(100%+12px)] right-0 w-full min-w-[220px] !bg-white border-2 border-slate-200 rounded-2xl shadow-[0_30px_60px_rgba(0,0,0,0.4)] z-[2000] overflow-hidden animate-in fade-in zoom-in-95 slide-in-from-top-4 duration-300 ease-out">
                    <div className="max-h-[320px] overflow-y-auto no-scrollbar !bg-white !bg-opacity-100 flex flex-col">
                      <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-center sticky top-0 !bg-white !bg-opacity-100 z-[2010]">
                        <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest flex items-center gap-2">
                          <Users size={12} /> প্রাপক নির্বাচন
                        </span>
                      </div>
                      <div className="p-2 space-y-1">
                        <div
                          onClick={(e) => {
                            e.stopPropagation();
                            setFilterReceiver("");
                            setIsReceiverDropdownOpen(false);
                          }}
                          className={`flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl cursor-pointer transition-all !bg-opacity-100 ${filterReceiver === "" ? "!bg-blue-600 !text-white shadow-lg" : "hover:bg-slate-100 text-slate-700 font-bold bg-white"}`}
                        >
                          <span className="text-[13px]">সকল প্রাপক</span>
                          {filterReceiver === "" && (
                            <Check size={16} strokeWidth={3} />
                          )}
                        </div>
                        {uniqueReceivers.map((receiver, idx) => (
                          <div
                            key={idx}
                            onClick={(e) => {
                              e.stopPropagation();
                              setFilterReceiver(receiver);
                              setIsReceiverDropdownOpen(false);
                            }}
                            className={`flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl cursor-pointer transition-all !bg-opacity-100 ${filterReceiver === receiver ? "!bg-blue-600 !text-white shadow-lg" : "hover:bg-slate-100 text-slate-700 font-bold bg-white"}`}
                          >
                            <span className="text-[13px]">{receiver}</span>
                            {filterReceiver === receiver && (
                              <Check size={16} strokeWidth={3} />
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Search Input */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-widest ml-1 flex items-center justify-between">
                <span>অনুসন্ধান</span>
              </label>
              <div className="relative">
                <Search
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-600"
                  size={16}
                />
                <input
                  type="text"
                  value={searchTerm === "__UNASSIGNED__" ? "অনির্ধারিত এন্ট্রি" : searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="বিবরণ, জারিপত্র বা নং দিয়ে খুঁজুন..."
                  className={`w-full pl-9 pr-9 h-[48px] bg-white border rounded-xl font-bold text-[13px] outline-none focus:ring-4 transition-all shadow-sm placeholder:text-slate-400 placeholder:font-bold ${
                    searchTerm === "__UNASSIGNED__"
                      ? "border-red-300 text-red-700 focus:border-red-600 focus:ring-red-50"
                      : "border-slate-300 text-slate-900 focus:border-blue-600 focus:ring-blue-50"
                  }`}
                />
                {searchTerm && (
                  <button
                    onClick={() => setSearchTerm("")}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 font-bold text-[15px]"
                    title="অনুসন্ধান মুছুন"
                  >
                    ✕
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>

      {!showCycleHeaders && (
        <div className="flex justify-end mb-4 no-print animate-in fade-in slide-in-from-top-2 duration-300">
          <button
            onClick={() => setShowCycleHeaders(true)}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-50 to-indigo-50 hover:from-blue-100 hover:to-indigo-100 border border-blue-200 hover:border-blue-300 text-blue-700 rounded-xl font-black text-[11px] transition-all shadow-sm cursor-pointer select-none group"
            title="সময়কাল অপশনটি পুনরায় দেখান"
          >
            <Eye size={14} className="animate-pulse text-blue-600 group-hover:scale-110 transition-transform" />
            <span>সময়কাল অপশনটি পুনরায় দেখান</span>
          </button>
        </div>
      )}

          {/* Table Container */}
          <div id="correspondence-register-table-container" className="table-container border border-slate-300 rounded-sm relative z-[1] shadow-xl bg-white">
            <table className="w-full border-separate border-spacing-0 table-fixed min-w-[900px]">
              <colgroup>
                <col className="w-[32px]" />
                <col className="w-[145px]" />
                <col className="w-[145px]" />
                <col className="w-[136px]" />
                <col className="w-[172px]" />
                <col className="w-[172px]" />
                <col className="w-[85px]" />
              </colgroup>
              <thead className="sticky top-0 z-[120] bg-slate-200 shadow-sm" style={{ position: "sticky", top: 0, zIndex: 120 }}>
                <tr className="h-[40px]">
                  <th className={thCls} style={{ position: "sticky", top: 0, zIndex: 120 }}>ক্র: নং</th>
                  <th className={thCls} style={{ position: "sticky", top: 0, zIndex: 120 }}>পত্রের বিবরণ</th>
                  <th className={thCls} style={{ position: "sticky", top: 0, zIndex: 120 }}>পত্রের অন্যান্য তথ্য</th>
                  <th className={thCls} style={{ position: "sticky", top: 0, zIndex: 120 }}>অত্র অফিসের তথ্য</th>
                  <th className={thCls} style={{ position: "sticky", top: 0, zIndex: 120 }}>গ্রহণ ও উপস্থাপন</th>
                  <th className={thCls} style={{ position: "sticky", top: 0, zIndex: 120 }}>জারিপত্র নং ও তারিখ</th>
                  <th className={thCls} style={{ position: "sticky", top: 0, zIndex: 120 }}>মন্তব্য</th>
                </tr>
                <tr className="h-[26px]">
                  <th className={thSubCls} style={{ position: "sticky", top: "40px", zIndex: 120 }}>১</th>
                  <th className={thSubCls} style={{ position: "sticky", top: "40px", zIndex: 120 }}>২</th>
                  <th className={thSubCls} style={{ position: "sticky", top: "40px", zIndex: 120 }}>৩</th>
                  <th className={thSubCls} style={{ position: "sticky", top: "40px", zIndex: 120 }}>৪</th>
                  <th className={thSubCls} style={{ position: "sticky", top: "40px", zIndex: 120 }}>৫</th>
                  <th className={thSubCls} style={{ position: "sticky", top: "40px", zIndex: 120 }}>৬</th>
                  <th className={thSubCls} style={{ position: "sticky", top: "40px", zIndex: 120 }}>৭</th>
                </tr>
              </thead>
          {groupedEntries.length > 0 ? (
            (() => {
              let globalIdx = 0;
              return groupedEntries.map((group) => (
                <tbody key={group.label}>
                  {/* Sticky Cycle Header */}
                  {showCycleHeaders && (
                    <tr className="correspondence-cycle-header no-print">
                      <td
                        colSpan={7}
                        className="sticky top-[66px] z-[115] p-0 border border-slate-400 shadow-sm bg-slate-100"
                        style={{ position: "sticky", top: "66px", zIndex: 115 }}
                      >
                        <div
                          ref={(el) => {
                            cycleRefs.current[group.label] = el;
                          }}
                          onClick={() => {
                            setIsCycleStatsExpanded((prev) => !prev);
                          }}
                          className="bg-slate-100 border-b border-slate-300 px-4 py-2 flex items-center justify-between cursor-pointer hover:bg-blue-50 transition-all group/cycle-header shadow-sm"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-blue-600 text-white rounded-lg flex items-center justify-center shadow-md group-hover/cycle-header:scale-110 transition-transform">
                              <CalendarDays size={18} />
                            </div>
                            <div className="flex flex-col">
                              <span className="font-black text-[13px] text-slate-800 tracking-tight uppercase">
                                সময়কাল:{" "}
                                <span className="text-blue-700 font-black">
                                  {toBengaliDigits(group.label)}
                                </span>
                              </span>
                              <div className="flex items-center gap-2">
                                <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">
                                  Cycle Statistics
                                </span>
                                <div className="h-1 w-1 bg-slate-300 rounded-full"></div>
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setCycleDetailModal({
                                      isOpen: true,
                                      title: `সময়কাল: ${toBengaliDigits(group.label)} — সকল চিঠিপত্র`,
                                      letters: group.entries,
                                    });
                                  }}
                                  className="text-[9px] font-black text-blue-600 hover:text-blue-800 hover:underline active:scale-95 transition-all cursor-pointer"
                                  title="এই সময়কালের সকল চিঠি দেখতে ক্লিক করুন"
                                >
                                  মোট{" "}
                                  {toBengaliDigits(
                                    cycleStats[group.label]?.total || 0,
                                  )}{" "}
                                  টি চিঠি
                                </button>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setShowCycleHeaders(false);
                              }}
                              className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all active:scale-95 border border-transparent hover:border-red-200 flex items-center justify-center"
                              title="সময়কাল অপশনটি লুকান"
                            >
                              <EyeOff size={15} />
                            </button>
                            <div
                              className={`px-3 py-1 rounded-full text-[10px] font-black transition-all flex items-center gap-1.5 ${isCycleStatsExpanded ? "bg-blue-600 text-white shadow-lg shadow-blue-200" : "bg-white text-blue-600 border border-blue-200 hover:border-blue-400"}`}
                            >
                              {isCycleStatsExpanded
                                ? "সংক্ষিপ্ত করুন"
                                : "বিস্তারিত দেখুন"}
                              <ChevronDown
                                size={12}
                                className={`transition-transform duration-300 ${isCycleStatsExpanded ? "rotate-180" : ""}`}
                              />
                            </div>
                          </div>
                        </div>

                        {isCycleStatsExpanded && (
                          <div className="bg-white p-4 border-b border-slate-300 shadow-md animate-in fade-in slide-in-from-top-4 duration-500 ease-out">
                            <div className="relative grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                              {/* Desktop Middle Separator */}
                              <div className="hidden md:block absolute left-1/2 top-1 bottom-1 w-[2px] bg-gradient-to-b from-slate-200 via-slate-300 to-slate-200 -translate-x-1/2 rounded-full pointer-events-none"></div>

                              {/* SFI Stats */}
                              <div className="group/sfi relative bg-emerald-50/60 hover:bg-emerald-50/90 border-2 border-emerald-300/80 hover:border-emerald-500 rounded-2xl p-3.5 space-y-2 transition-all duration-300 hover:shadow-[0_0_20px_rgba(16,185,129,0.22)] hover:-translate-y-0.5">
                                <div className="flex items-center justify-between border-b border-emerald-200 pb-1.5">
                                  <span className="text-[11px] font-black text-emerald-900 flex items-center gap-2">
                                    <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse shadow-sm shadow-emerald-400"></div>
                                    এসএফআই (SFI)
                                  </span>
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      const filtered = group.entries.filter((ent) => isSFI(ent.paraType));
                                      setCycleDetailModal({
                                        isOpen: true,
                                        title: `সময়কাল: ${toBengaliDigits(group.label)} — এসএফআই (SFI) এর সকল চিঠিপত্র`,
                                        letters: filtered,
                                      });
                                    }}
                                    className="bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white px-2.5 py-0.5 rounded-lg text-[10px] font-black shadow-sm transition-all cursor-pointer hover:ring-2 hover:ring-emerald-400 flex items-center gap-1"
                                    title="এসএফআই (SFI) এর সকল চিঠি দেখতে ক্লিক করুন"
                                  >
                                    {toBengaliDigits(
                                      cycleStats[group.label]?.sfi.total || 0,
                                    )}{" "}
                                    টি
                                  </button>
                                </div>
                                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      const filtered = group.entries.filter(
                                        (ent) => isSFI(ent.paraType) && ent.letterType === "বিএসআর"
                                      );
                                      setCycleDetailModal({
                                        isOpen: true,
                                        title: `সময়কাল: ${toBengaliDigits(group.label)} — এসএফআই (বিএসআর)`,
                                        letters: filtered,
                                      });
                                    }}
                                    className="flex flex-col text-left p-1.5 rounded-xl hover:bg-emerald-100/80 active:scale-95 transition-all cursor-pointer group/item border border-transparent hover:border-emerald-300"
                                    title="এসএফআই বিএসআর চিঠিপত্র দেখতে ক্লিক করুন"
                                  >
                                    <span className="text-[9px] font-bold text-emerald-700 group-hover/item:text-emerald-950 uppercase transition-colors">
                                      বিএসআর
                                    </span>
                                    <span className="text-[12px] font-black text-slate-800 group-hover/item:text-emerald-800 transition-colors">
                                      {toBengaliDigits(
                                        cycleStats[group.label]?.sfi.bsr || 0,
                                      )}{" "}
                                      টি
                                    </span>
                                  </button>
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      const filtered = group.entries.filter(
                                        (ent) =>
                                          isSFI(ent.paraType) &&
                                          (ent.letterType === "ত্রিপক্ষীয় সভা (কার্যপত্র)" ||
                                            ent.letterType === "কার্যপত্র (ত্রি-সভা)")
                                      );
                                      setCycleDetailModal({
                                        isOpen: true,
                                        title: `সময়কাল: ${toBengaliDigits(group.label)} — এসএফআই — ত্রিপক্ষীয় (কার্যপত্র)`,
                                        letters: filtered,
                                      });
                                    }}
                                    className="flex flex-col text-left p-1.5 rounded-xl hover:bg-emerald-100/80 active:scale-95 transition-all cursor-pointer group/item border border-transparent hover:border-emerald-300"
                                    title="এসএফআই ত্রিপক্ষীয় (কার্যপত্র) চিঠিপত্র দেখতে ক্লিক করুন"
                                  >
                                    <span className="text-[9px] font-bold text-emerald-700 group-hover/item:text-emerald-950 uppercase transition-colors">
                                      ত্রিপক্ষীয় (কার্যপত্র)
                                    </span>
                                    <span className="text-[12px] font-black text-slate-800 group-hover/item:text-emerald-800 transition-colors">
                                      {toBengaliDigits(
                                        cycleStats[group.label]?.sfi.triWork || 0,
                                      )}{" "}
                                      টি
                                    </span>
                                  </button>
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      const filtered = group.entries.filter(
                                        (ent) =>
                                          isSFI(ent.paraType) &&
                                          (ent.letterType === "ত্রিপক্ষীয় সভা (কার্যবিবরণী)" ||
                                            ent.letterType === "ত্রিপক্ষীয় সভা")
                                      );
                                      setCycleDetailModal({
                                        isOpen: true,
                                        title: `সময়কাল: ${toBengaliDigits(group.label)} — এসএফআই — ত্রিপক্ষীয় (বিবরণী)`,
                                        letters: filtered,
                                      });
                                    }}
                                    className="flex flex-col text-left p-1.5 rounded-xl hover:bg-emerald-100/80 active:scale-95 transition-all cursor-pointer group/item border border-transparent hover:border-emerald-300"
                                    title="এসএফআই ত্রিপক্ষীয় (বিবরণী) চিঠিপত্র দেখতে ক্লিক করুন"
                                  >
                                    <span className="text-[9px] font-bold text-emerald-700 group-hover/item:text-emerald-950 uppercase transition-colors">
                                      ত্রিপক্ষীয় (বিবরণী)
                                    </span>
                                    <span className="text-[12px] font-black text-slate-800 group-hover/item:text-emerald-800 transition-colors">
                                      {toBengaliDigits(
                                        cycleStats[group.label]?.sfi.triMin || 0,
                                      )}{" "}
                                      টি
                                    </span>
                                  </button>
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      const filtered = group.entries.filter(
                                        (ent) =>
                                          isSFI(ent.paraType) &&
                                          (ent.letterType === "মিলিকরণ" ||
                                            ent.letterType === "মিলকরণ" ||
                                            (ent.letterType || "").includes("মিলকরণ") ||
                                            (ent.letterType || "").includes("মিলিকরণ"))
                                      );
                                      setCycleDetailModal({
                                        isOpen: true,
                                        title: `সময়কাল: ${toBengaliDigits(group.label)} — এসএফআই — মিলকরণ`,
                                        letters: filtered,
                                      });
                                    }}
                                    className="flex flex-col text-left p-1.5 rounded-xl hover:bg-emerald-100/80 active:scale-95 transition-all cursor-pointer group/item border border-transparent hover:border-emerald-300"
                                    title="এসএফআই মিলকরণ চিঠিপত্র দেখতে ক্লিক করুন"
                                  >
                                    <span className="text-[9px] font-bold text-emerald-700 group-hover/item:text-emerald-950 uppercase transition-colors">
                                      মিলকরণ
                                    </span>
                                    <span className="text-[12px] font-black text-slate-800 group-hover/item:text-emerald-800 transition-colors">
                                      {toBengaliDigits(
                                        cycleStats[group.label]?.sfi.reconciliation || 0,
                                      )}{" "}
                                      টি
                                    </span>
                                  </button>
                                </div>
                              </div>

                              {/* Non-SFI Stats */}
                              <div className="group/nonsfi relative bg-amber-50/60 hover:bg-amber-50/90 border-2 border-amber-300/80 hover:border-amber-500 rounded-2xl p-3.5 space-y-2 transition-all duration-300 hover:shadow-[0_0_20px_rgba(245,158,11,0.22)] hover:-translate-y-0.5">
                                <div className="flex items-center justify-between border-b border-amber-200 pb-1.5">
                                  <span className="text-[11px] font-black text-amber-900 flex items-center gap-2">
                                    <div className="w-2.5 h-2.5 bg-amber-500 rounded-full animate-pulse shadow-sm shadow-amber-400"></div>
                                    নন এসএফআই (Non-SFI)
                                  </span>
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      const filtered = group.entries.filter((ent) => isNonSFI(ent.paraType));
                                      setCycleDetailModal({
                                        isOpen: true,
                                        title: `সময়কাল: ${toBengaliDigits(group.label)} — নন এসএফআই (Non-SFI) এর সকল চিঠিপত্র`,
                                        letters: filtered,
                                      });
                                    }}
                                    className="bg-amber-600 hover:bg-amber-700 active:scale-95 text-white px-2.5 py-0.5 rounded-lg text-[10px] font-black shadow-sm transition-all cursor-pointer hover:ring-2 hover:ring-amber-400 flex items-center gap-1"
                                    title="নন এসএফআই (Non-SFI) এর সকল চিঠি দেখতে ক্লিক করুন"
                                  >
                                    {toBengaliDigits(
                                      cycleStats[group.label]?.nonSfi.total || 0,
                                    )}{" "}
                                    টি
                                  </button>
                                </div>
                                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      const filtered = group.entries.filter(
                                        (ent) => isNonSFI(ent.paraType) && ent.letterType === "বিএসআর"
                                      );
                                      setCycleDetailModal({
                                        isOpen: true,
                                        title: `সময়কাল: ${toBengaliDigits(group.label)} — নন এসএফআই (বিএসআর)`,
                                        letters: filtered,
                                      });
                                    }}
                                    className="flex flex-col text-left p-1.5 rounded-xl hover:bg-amber-100/80 active:scale-95 transition-all cursor-pointer group/item border border-transparent hover:border-amber-300"
                                    title="নন এসএফআই বিএসআর চিঠিপত্র দেখতে ক্লিক করুন"
                                  >
                                    <span className="text-[9px] font-bold text-amber-700 group-hover/item:text-amber-950 uppercase transition-colors">
                                      বিএসআর
                                    </span>
                                    <span className="text-[12px] font-black text-slate-800 group-hover/item:text-amber-800 transition-colors">
                                      {toBengaliDigits(
                                        cycleStats[group.label]?.nonSfi.bsr || 0,
                                      )}{" "}
                                      টি
                                    </span>
                                  </button>
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      const filtered = group.entries.filter(
                                        (ent) =>
                                          isNonSFI(ent.paraType) &&
                                          (ent.letterType === "দ্বিপক্ষীয় সভা (কার্যপত্র)" ||
                                            ent.letterType === "কার্যপত্র (দ্বি-সভা)" ||
                                            ent.letterType === "দ্বি-সভা (কার্যপত্র)")
                                      );
                                      setCycleDetailModal({
                                        isOpen: true,
                                        title: `সময়কাল: ${toBengaliDigits(group.label)} — নন এসএফআই — দ্বিপক্ষীয় (কার্যপত্র)`,
                                        letters: filtered,
                                      });
                                    }}
                                    className="flex flex-col text-left p-1.5 rounded-xl hover:bg-amber-100/80 active:scale-95 transition-all cursor-pointer group/item border border-transparent hover:border-amber-300"
                                    title="নন এসএফআই দ্বিপক্ষীয় (কার্যপত্র) চিঠিপত্র দেখতে ক্লিক করুন"
                                  >
                                    <span className="text-[9px] font-bold text-amber-700 group-hover/item:text-amber-950 uppercase transition-colors">
                                      দ্বিপক্ষীয় (কার্যপত্র)
                                    </span>
                                    <span className="text-[12px] font-black text-slate-800 group-hover/item:text-amber-800 transition-colors">
                                      {toBengaliDigits(
                                        cycleStats[group.label]?.nonSfi.biWork ||
                                          0,
                                      )}{" "}
                                      টি
                                    </span>
                                  </button>
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      const filtered = group.entries.filter(
                                        (ent) =>
                                          isNonSFI(ent.paraType) &&
                                          (ent.letterType === "দ্বিপক্ষীয় সভা (কার্যবিবরণী)" ||
                                            ent.letterType === "দ্বিপক্ষীয় সভা" ||
                                            ent.letterType === "দ্বি-সভা (কার্যবিবরনী)" ||
                                            ent.letterType === "দ্বি-সভা (কার্যবিবরণী)")
                                      );
                                      setCycleDetailModal({
                                        isOpen: true,
                                        title: `সময়কাল: ${toBengaliDigits(group.label)} — নন এসএফআই — দ্বিপক্ষীয় (বিবরণী)`,
                                        letters: filtered,
                                      });
                                    }}
                                    className="flex flex-col text-left p-1.5 rounded-xl hover:bg-amber-100/80 active:scale-95 transition-all cursor-pointer group/item border border-transparent hover:border-amber-300"
                                    title="নন এসএফআই দ্বিপক্ষীয় (বিবরণী) চিঠিপত্র দেখতে ক্লিক করুন"
                                  >
                                    <span className="text-[9px] font-bold text-amber-700 group-hover/item:text-amber-950 uppercase transition-colors">
                                      দ্বিপক্ষীয় (বিবরণী)
                                    </span>
                                    <span className="text-[12px] font-black text-slate-800 group-hover/item:text-amber-800 transition-colors">
                                      {toBengaliDigits(
                                        cycleStats[group.label]?.nonSfi.biMin ||
                                          0,
                                      )}{" "}
                                      টি
                                    </span>
                                  </button>
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      const filtered = group.entries.filter(
                                        (ent) =>
                                          isNonSFI(ent.paraType) &&
                                          (ent.letterType === "মিলিকরণ" ||
                                            ent.letterType === "মিলকরণ" ||
                                            (ent.letterType || "").includes("মিলকরণ") ||
                                            (ent.letterType || "").includes("মিলিকরণ"))
                                      );
                                      setCycleDetailModal({
                                        isOpen: true,
                                        title: `সময়কাল: ${toBengaliDigits(group.label)} — নন এসএফআই — মিলকরণ`,
                                        letters: filtered,
                                      });
                                    }}
                                    className="flex flex-col text-left p-1.5 rounded-xl hover:bg-amber-100/80 active:scale-95 transition-all cursor-pointer group/item border border-transparent hover:border-amber-300"
                                    title="নন এসএফআই মিলকরণ চিঠিপত্র দেখতে ক্লিক করুন"
                                  >
                                    <span className="text-[9px] font-bold text-amber-700 group-hover/item:text-amber-950 uppercase transition-colors">
                                      মিলকরণ
                                    </span>
                                    <span className="text-[12px] font-black text-slate-800 group-hover/item:text-amber-800 transition-colors">
                                      {toBengaliDigits(
                                        cycleStats[group.label]?.nonSfi.reconciliation ||
                                          0,
                                      )}{" "}
                                      টি
                                    </span>
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </td>
                    </tr>
                  )}
                  {/* Print-only cycle header */}
                  <tr className="hidden print:table-row bg-slate-100 border-y border-slate-300">
                    <td
                      colSpan={7}
                      className="px-4 py-2 border border-slate-300"
                    >
                      <span className="font-black text-[13px] text-slate-800 tracking-tight uppercase">
                        সময়কাল:{" "}
                        <span className="text-blue-700 font-black">
                          {toBengaliDigits(group.label)}
                        </span>
                      </span>
                    </td>
                  </tr>
                  {group.entries.map((entry) => {
                    const idx = globalIdx++;
                    const pending = pendingChanges[entry.id] || {};
                    const currentPresDate =
                      pending.presentationDate !== undefined
                        ? pending.presentationDate
                        : entry.presentationDate || "";
                    const currentPresName =
                      pending.presentedToName !== undefined
                        ? pending.presentedToName
                        : entry.presentedToName || "";
                    const currentSentToDhakaDate =
                      pending.sentToDhakaDate !== undefined
                        ? pending.sentToDhakaDate
                        : entry.sentToDhakaDate || "";
                    const currentReturnedFromDhakaDate =
                      pending.returnedFromDhakaDate !== undefined
                        ? pending.returnedFromDhakaDate
                        : entry.returnedFromDhakaDate || "";
                    const isSfiEntry = isSFI(entry.paraType);
                    const currentIssueNo =
                      pending.issueLetterNo !== undefined
                        ? pending.issueLetterNo
                        : entry.issueLetterNo || "";
                    const currentIssueDate =
                      pending.issueLetterDate !== undefined
                        ? pending.issueLetterDate
                        : entry.issueLetterDate || "";
                    const currentIssueComment =
                      pending.issueLetterComment !== undefined
                        ? pending.issueLetterComment
                        : entry.issueLetterComment || "";
                    const isPendingForApproval =
                      entry.approvalStatus === "pending";

                    const isDeleting = deletingId === entry.id;

                    if (isDeleting) {
                      return (
                        <tr
                          key={entry.id}
                          className="bg-rose-50/60 transition-all duration-500 animate-pulse"
                        >
                          <td
                            colSpan={7}
                            className="p-8 text-center text-rose-600 font-black text-sm border border-rose-200"
                          >
                            <div className="flex items-center justify-center gap-3">
                              <div className="relative flex items-center justify-center">
                                <span className="w-5 h-5 rounded-full border-2 border-rose-600 border-t-transparent animate-spin"></span>
                              </div>
                              <span className="animate-pulse">ডাটাবেজ থেকে তথ্যটি মুছে ফেলা হচ্ছে... অনুগ্রহ করে অপেক্ষা করুন</span>
                            </div>
                          </td>
                        </tr>
                      );
                    }

                    return (
                      <tr
                        key={entry.id}
                        className="group transition-all bg-white hover:bg-blue-50/30"
                      >
                        <td className={tdCls + " text-center font-black"}>
                          {toBengaliDigits(idx + 1)}
                        </td>
                        <td
                          className="border border-slate-300 p-2 sm:p-2.5 align-top transition-colors group-hover:bg-blue-50/50 break-words relative text-justify"
                          style={{ textAlign: "justify", textJustify: "inter-word" }}
                        >
                          <div
                            className="text-slate-950 font-bold text-justify"
                            style={{ textAlign: "justify", textJustify: "inter-word" }}
                          >
                            {entry.description ? (
                              <div
                                className="font-bold text-slate-800 text-[10px] leading-relaxed tracking-normal break-words text-justify"
                                style={{ textAlign: "justify", textJustify: "inter-word" }}
                              >
                                <HighlightText
                                  text={entry.description}
                                  searchTerm={searchTerm}
                                />
                              </div>
                            ) : (
                              <span className="text-slate-400 font-bold text-[10px]">-</span>
                            )}
                          </div>
                        </td>
                        <td className={tdCls}>
                          {(() => {
                            let itemIdx = 1;
                            const matched = findMatchedSettlements(entry, settlementEntries || []);
                            let totalInvolvedAmount = 0;
                            let totalSettledAmount = 0;

                            matched.forEach((se) => {
                              if (se.paragraphs && se.paragraphs.length > 0) {
                                const parasInvolved = se.paragraphs.reduce(
                                  (sum, p) => sum + (Number(p.involvedAmount) || 0),
                                  0
                                );
                                totalInvolvedAmount += parasInvolved > 0 ? parasInvolved : (Number(se.involvedAmount) || 0);

                                se.paragraphs.forEach((p) => {
                                  totalSettledAmount += (Number(p.recoveredAmount) || 0) + (Number(p.adjustedAmount) || 0);
                                });
                              } else {
                                totalInvolvedAmount += Number(se.involvedAmount) || 0;
                                const recAdj = (Number(se.totalRec) || 0) + (Number(se.totalAdj) || 0);
                                const meetingAmt = Number((se as any).meetingSettledAmount) || 0;
                                totalSettledAmount += recAdj > 0 ? recAdj : (meetingAmt > 0 ? meetingAmt : 0);
                              }
                            });

                            const totalRemainingAmount = Math.max(0, totalInvolvedAmount - totalSettledAmount);

                            const pending = pendingChanges[entry.id] || {};
                            const currentIsSettled =
                              pending.isSettled !== undefined
                                ? pending.isSettled
                                : entry.isSettled;

                            return (
                              <div className="space-y-1">
                                <div className="text-[10px] leading-snug">
                                  <span className="font-bold text-emerald-800">{toBengaliDigits(itemIdx++)}. মন্ত্রণালয়: </span>
                                  <span className="font-black text-slate-950">
                                    <HighlightText
                                      text={entry.ministryName || 'প্রযোজ্য নয়'}
                                      searchTerm={searchTerm}
                                    />
                                  </span>
                                </div>
                                {entry.entityName && (
                                  <div className="text-[10px] leading-snug">
                                    <span className="font-bold text-emerald-800">{toBengaliDigits(itemIdx++)}. এনটিটি: </span>
                                    <span className="font-black text-slate-950">
                                      <HighlightText
                                        text={entry.entityName}
                                        searchTerm={searchTerm}
                                      />
                                    </span>
                                  </div>
                                )}
                                {entry.auditYear && (
                                  <div className="text-[10px] leading-snug">
                                    <span className="font-bold text-emerald-800">{toBengaliDigits(itemIdx++)}. নিরীক্ষা সাল: </span>
                                    <span className="font-black text-slate-950">
                                      <HighlightText
                                        text={entry.auditYear}
                                        searchTerm={searchTerm}
                                      />
                                    </span>
                                  </div>
                                )}
                                <div className="text-[10px] leading-snug">
                                  <span className="font-bold text-emerald-800">{toBengaliDigits(itemIdx++)}. শাখার ধরণ: </span>
                                  <span className="font-black text-slate-950">
                                    <HighlightText
                                      text={entry.paraType}
                                      searchTerm={searchTerm}
                                    />
                                  </span>
                                </div>
                                <div className="text-[10px] leading-snug">
                                  <span className="font-bold text-emerald-800">{toBengaliDigits(itemIdx++)}. পত্রের ধরণ: </span>
                                  <span className="font-black text-slate-950">
                                    <HighlightText
                                      text={getCleanLetterTypeDisplay(entry.letterType)}
                                      searchTerm={searchTerm}
                                    />
                                  </span>
                                </div>
                                <div className="text-[10px] leading-snug">
                                  <span className="font-bold text-emerald-800">{toBengaliDigits(itemIdx++)}. পত্র নং ও তারিখ: </span>
                                  <span className="font-black text-slate-950">
                                    <HighlightText
                                      text={`${entry.letterNo}, ${formatDateBN(entry.letterDate)}`}
                                      searchTerm={searchTerm}
                                    />
                                  </span>
                                </div>
                                <div className="text-[10px] leading-snug">
                                  <span className="font-bold text-emerald-800">{toBengaliDigits(itemIdx++)}. প্রেরিত অনু: সংখ্যা: </span>
                                  <span className="font-black text-slate-950">
                                    <HighlightText
                                      text={`${toBengaliDigits(entry.totalParas)} টি`}
                                      searchTerm={searchTerm}
                                    />
                                  </span>
                                </div>

                                {currentIsSettled === "হ্যাঁ" && (
                                  <div className="space-y-0.5 my-1">
                                    <div className="flex items-baseline justify-between text-[10px] leading-snug gap-2">
                                      <span className="font-bold text-emerald-800">{toBengaliDigits(itemIdx++)}. নিষ্পন্ন অনুচ্ছেদে জড়িত টাকা:</span>
                                      <span className="font-black text-slate-950 text-right whitespace-nowrap">
                                        <HighlightText
                                          text={`${toBengaliDigits(Math.round(totalInvolvedAmount))}`}
                                          searchTerm={searchTerm}
                                        />
                                      </span>
                                    </div>
                                    <div className="flex items-baseline justify-between text-[10px] leading-snug gap-2">
                                      <span className="font-bold text-emerald-800">{toBengaliDigits(itemIdx++)}. মোট নিষ্পন্ন টাকা:</span>
                                      <span className="font-black text-slate-950 text-right whitespace-nowrap">
                                        <HighlightText
                                          text={`${toBengaliDigits(Math.round(totalSettledAmount))}`}
                                          searchTerm={searchTerm}
                                        />
                                      </span>
                                    </div>
                                    <div className="border-t-2 border-blue-500/90 my-1" />
                                    <div className="flex items-baseline justify-between text-[10px] leading-snug gap-2">
                                      <span className="font-bold text-emerald-800">{toBengaliDigits(itemIdx++)}. মোট অবশিষ্ট টাকা:</span>
                                      <span className="font-black text-slate-950 text-right whitespace-nowrap">
                                        <HighlightText
                                          text={`${toBengaliDigits(Math.round(totalRemainingAmount))}`}
                                          searchTerm={searchTerm}
                                        />
                                      </span>
                                    </div>
                                  </div>
                                )}

                                {entry.meetingDate && (
                                  <div className="text-[10px] leading-snug">
                                    <span className="font-bold text-emerald-800">{toBengaliDigits(itemIdx++)}. সভার তারিখ: </span>
                                    <span className="font-black text-slate-950">
                                      <HighlightText
                                        text={formatDateBN(entry.meetingDate)}
                                        searchTerm={searchTerm}
                                      />
                                    </span>
                                  </div>
                                )}
                                 {(() => {
                                   const discussed = entry.discussedParaCount || entry.meetingDiscussedParaCount;
                                   if (!discussed) return null;
                                   return (
                                     <div className="text-[10px] leading-snug">
                                       <span className="font-bold text-emerald-800">{toBengaliDigits(itemIdx++)}. আলোচিত অনুচ্ছেদ সংখ্যা: </span>
                                       <span className="font-black text-slate-950">
                                         <HighlightText
                                           text={`${toBengaliDigits(discussed)} টি`}
                                           searchTerm={searchTerm}
                                         />
                                       </span>
                                     </div>
                                   );
                                 })()}
                                 {(() => {
                                   const recommended = entry.recommendedParaCount || entry.meetingRecommendedParaCount;
                                   if (!recommended) return null;
                                   return (
                                     <div className="text-[10px] leading-snug">
                                       <span className="font-bold text-emerald-800">{toBengaliDigits(itemIdx++)}. সুপারিশকৃত অনুচ্ছেদ সংখ্যা: </span>
                                       <span className="font-black text-slate-950">
                                         <HighlightText
                                           text={`${toBengaliDigits(recommended)} টি`}
                                           searchTerm={searchTerm}
                                         />
                                       </span>
                                     </div>
                                   );
                                 })()}
                              </div>
                            );
                          })()}
                        </td>
                        <td className={tdCls}>
                          <div className="space-y-1">
                            <div className="text-[10px] leading-snug">
                              <span className="font-bold text-emerald-800">১. ডায়েরি নং ও তারিখ: </span>
                              <span className="font-black text-slate-950">
                                <HighlightText
                                  text={`${entry.diaryNo}, ${formatDateBN(entry.diaryDate)}`}
                                  searchTerm={searchTerm}
                                />
                              </span>
                            </div>
                            <div className="text-[10px] leading-snug">
                              <span className="font-bold text-emerald-800">২. শাখায় প্রাপ্তির তারিখ: </span>
                              <span className="font-black text-slate-950">
                                <HighlightText
                                  text={formatDateBN(entry.receiptDate)}
                                  searchTerm={searchTerm}
                                />
                              </span>
                            </div>
                            <div className="text-[10px] leading-snug">
                              <span className="font-bold text-emerald-800">৩. ডিজিটাল নথি নং- </span>
                              <span className="font-black text-slate-950">
                                <HighlightText
                                  text={entry.digitalFileNo && entry.digitalFileNo !== '-' ? entry.digitalFileNo : ''}
                                  searchTerm={searchTerm}
                                />
                              </span>
                            </div>
                            <div className="text-[10px] leading-snug">
                              <span className="font-bold text-emerald-800">৪. গ্রহণের তারিখ: </span>
                              <span className="font-black text-slate-950">
                                <HighlightText
                                  text={formatDateBN(entry.receivedDate)}
                                  searchTerm={searchTerm}
                                />
                              </span>
                            </div>
                            <div className="text-[10px] leading-snug">
                              <span className="font-bold text-emerald-800">৫. অনলাইনে প্রাপ্তি: </span>
                              <span className="font-black text-slate-950">
                                <HighlightText
                                  text={entry.isOnline || '-'}
                                  searchTerm={searchTerm}
                                />
                              </span>
                            </div>
                            {entry.archiveNo && (
                              <div className="text-[10px] leading-snug">
                                <span className="font-bold text-emerald-800">৬. আর্কাইভ নং- </span>
                                <span className="font-black text-purple-700">
                                  <HighlightText
                                    text={entry.archiveNo}
                                    searchTerm={searchTerm}
                                  />
                                </span>
                              </div>
                            )}

                            {/* চিঠিটির বর্তমান অবস্থা ও অবস্থান সংক্রান্ত তথ্য (ক্রমিক হিসেবে) */}
                            {(() => {
                              const hasIssueNo = !!(currentIssueNo && currentIssueNo.trim() !== "" && currentIssueNo.trim() !== "-");
                              if (hasIssueNo) return null;

                              const currentCustodian = currentPresName && currentPresName.trim() !== "" && currentPresName.trim() !== "-"
                                ? currentPresName
                                : (entry.receiverName && entry.receiverName.trim() !== "" ? `${entry.receiverName}` : " শাখা");

                              const custodianDate = currentPresName && currentPresName.trim() !== "" && currentPresName.trim() !== "-"
                                ? (currentPresDate || entry.receivedDate || entry.receiptDate || entry.diaryDate)
                                : (entry.receivedDate || entry.receiptDate || entry.diaryDate);

                              const calculateHoldingDays = (dateStr?: string | null): number | null => {
                                if (!dateStr) return null;
                                let d: Date | null = null;
                                const clean = dateStr.trim();
                                if (clean.includes("-")) {
                                  const parts = clean.split("T")[0].split(" ")[0].split("-");
                                  if (parts.length === 3) {
                                    if (parts[0].length === 4) {
                                      d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
                                    } else if (parts[2].length === 4) {
                                      d = new Date(Number(parts[2]), Number(parts[1]) - 1, Number(parts[0]));
                                    }
                                  }
                                } else if (clean.includes("/")) {
                                  const parts = clean.split("/");
                                  if (parts.length === 3) {
                                    if (parts[2].length === 4) {
                                      d = new Date(Number(parts[2]), Number(parts[1]) - 1, Number(parts[0]));
                                    } else if (parts[0].length === 4) {
                                      d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
                                    }
                                  }
                                } else {
                                  const parsed = new Date(clean);
                                  if (!isNaN(parsed.getTime())) d = parsed;
                                }
                                if (!d || isNaN(d.getTime())) return null;

                                const today = new Date();
                                const startOfDayD = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
                                const startOfDayToday = new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime();
                                const diffDays = Math.floor((startOfDayToday - startOfDayD) / (1000 * 60 * 60 * 24));
                                return Math.max(0, diffDays);
                              };

                              const holdingDays = calculateHoldingDays(custodianDate);
                              const serial6 = entry.archiveNo ? "৭" : "৬";
                              const serial7 = entry.archiveNo ? "৮" : "৭";

                              return (
                                <>
                                  <div className="text-[10px] leading-snug">
                                    <span className="font-bold text-emerald-800">{serial6}. বর্তমান অবস্থা: </span>
                                    <span className="font-black text-amber-700">
                                      চলমান
                                    </span>
                                  </div>
                                  <div className="text-[10px] leading-snug">
                                    <span className="font-bold text-emerald-800">{serial7}. নাম: </span>
                                    <span className="font-black text-slate-950">
                                      {currentCustodian}
                                      {holdingDays !== null && ` - ${toBengaliDigits(holdingDays < 10 ? `0${holdingDays}` : holdingDays.toString())} দিন`}
                                    </span>
                                  </div>
                                </>
                              );
                            })()}
                          </div>
                        </td>
                        <td data-inline-col="col4" className={`${tdCls} relative group/col5`}>
                          {(() => {
                            const isRowInlineActive = inlineEditingRowId === entry.id || activeInlineEditingCell?.id === entry.id;
                            const hasCol4Pending = !!(
                              pending.presentationDate !== undefined ||
                              pending.presentedToName !== undefined ||
                              pending.sentToDhakaDate !== undefined ||
                              pending.returnedFromDhakaDate !== undefined ||
                              pending.receiverName !== undefined
                            );
                            const isCol4Editable = isRowInlineActive || hasCol4Pending;
                            const isCol4Locked = !isCol4Editable;

                            return (
                              <div className="flex flex-col justify-between h-full min-h-[175px] space-y-2">
                                <div className={`space-y-2 flex-1 ${isCol4Locked ? 'pointer-events-none' : ''}`}>
                            {/* ৫ নং কলামের একটি সমন্বিত একক ব্লক (Single Card) */}
                            <div className={`p-2 border rounded-xl space-y-2 transition-all duration-200 bg-gradient-to-br from-white via-slate-50 to-blue-50/40 border-slate-300 shadow-xs ${
                              pending.presentationDate || pending.presentedToName ? "ring-1 ring-blue-300/80 border-blue-400" : ""
                            }`}>
                              {/* গ্রহণকারী */}
                              <div className="flex items-center justify-between gap-1.5 pb-1 border-b border-slate-200/80 min-w-0 h-[24px]">
                                <div className="text-[9px] font-bold text-emerald-700 uppercase tracking-tighter flex items-center gap-1 shrink-0">
                                  <Inbox size={9} /> গ্রহণকারী:
                                </div>
                                <div className="font-bold text-slate-900 text-[9.5px] leading-tight truncate">
                                  <HighlightText
                                    text={entry.receiverName || "-"}
                                    searchTerm={searchTerm}
                                  />
                                </div>
                              </div>

                              {/* উপস্থাপন */}
                              <div className="space-y-1.5">
                                <div className="flex items-center justify-between gap-1 h-5">
                                  <div className="text-[9px] font-bold text-blue-700 uppercase tracking-tighter flex items-center gap-1 shrink-0">
                                    <UserCheck size={9} /> উপস্থাপন
                                  </div>
                                  <div className="flex items-center gap-1 shrink-0 ml-auto">
                                    {formatDateBN(currentPresDate) && (
                                      <span className="text-[8.5px] font-black text-blue-600">
                                        {formatDateBN(currentPresDate)}
                                      </span>
                                    )}
                                    {isCol4Editable && (currentPresDate || currentPresName) && (
                                      <button
                                        type="button"
                                        onClick={() => {
                                          handleInlineChange(
                                            entry.id,
                                            "presentationDate",
                                            "",
                                          );
                                          handleInlineChange(
                                            entry.id,
                                            "presentedToName",
                                            "",
                                          );
                                        }}
                                        className="p-0.5 hover:bg-red-100 text-red-400 hover:text-red-600 rounded transition-all flex items-center justify-center cursor-pointer"
                                        title="তথ্য মুছুন"
                                      >
                                        <XCircle size={10} />
                                      </button>
                                    )}
                                    <div className="relative flex items-center h-3.5 w-3.5 shrink-0">
                                      <Calendar
                                        size={11}
                                        className={`text-blue-500 transition-colors ${isCol4Editable ? "cursor-pointer hover:text-blue-700" : "opacity-50"}`}
                                        onClick={(e) => {
                                          if (!isCol4Editable) return;
                                          const input =
                                            e.currentTarget.parentElement?.querySelector(
                                              "input",
                                            ) as HTMLInputElement;
                                          if (input) {
                                            try {
                                              if (typeof input.showPicker === 'function') input.showPicker();
                                              else input.focus();
                                            } catch {
                                              input.focus();
                                            }
                                          }
                                        }}
                                      />
                                      <input
                                        type="date"
                                        className={`absolute inset-0 opacity-0 w-3.5 h-3.5 ${isCol4Editable ? "cursor-pointer" : "pointer-events-none"}`}
                                        value={currentPresDate}
                                        disabled={!isCol4Editable}
                                        onChange={(e) =>
                                          handleInlineChange(
                                            entry.id,
                                            "presentationDate",
                                            e.target.value,
                                          )
                                        }
                                      />
                                    </div>
                                  </div>
                                </div>
                                <div>
                                  <PremiumInlineSelect
                                    value={currentPresName}
                                    onSelect={(val) =>
                                      handleInlineChange(
                                        entry.id,
                                        "presentedToName",
                                        val,
                                      )
                                    }
                                    disabled={!isCol4Editable}
                                  />
                                </div>
                              </div>
                            </div>

                            {/* 3. ঢাকায় প্রেরণ ও ঢাকা হতে ফেরত (শুধুমাত্র এসএফআই শাখার জন্য) */}
                            {isSfiEntry && (
                              <div
                                className={`p-1.5 border rounded-lg space-y-1.5 transition-colors ${
                                  currentSentToDhakaDate || currentReturnedFromDhakaDate
                                    ? "bg-amber-600/10 border-amber-400 ring-2 ring-amber-50"
                                    : "bg-amber-50/60 border-amber-200/90"
                                }`}
                              >
                                {/* ঢাকায় প্রেরণ */}
                                <div className="flex items-center justify-between">
                                  <div className="text-[9px] font-black text-amber-900 uppercase tracking-tighter flex items-center gap-1">
                                    <Send size={8} className="text-amber-700" /> ঢাকায় প্রেরণ
                                  </div>
                                  <div className="flex items-center gap-1.5 ml-auto">
                                    {formatDateBN(currentSentToDhakaDate) ? (
                                      <span className="text-[8.5px] font-black text-amber-800 bg-white/90 px-1 py-0.5 rounded border border-amber-300 shadow-2xs">
                                        {formatDateBN(currentSentToDhakaDate)}
                                      </span>
                                    ) : (
                                      <span
                                        className={`text-[8px] font-black ${isCol4Editable ? "text-amber-700 hover:text-amber-900 cursor-pointer" : "text-amber-400"}`}
                                        onClick={(e) => {
                                          if (!isCol4Editable) return;
                                          const input = e.currentTarget.parentElement?.querySelector("input") as HTMLInputElement;
                                          if (input) input.showPicker();
                                        }}
                                      >
                                        তারিখ দিন
                                      </span>
                                    )}
                                    {isCol4Editable && currentSentToDhakaDate && (
                                      <button
                                        type="button"
                                        onClick={() => handleInlineChange(entry.id, "sentToDhakaDate", "")}
                                        className="p-0.5 hover:bg-red-100 text-red-400 hover:text-red-600 rounded transition-all ml-0.5"
                                        title="মুছুন"
                                      >
                                        <XCircle size={10} />
                                      </button>
                                    )}
                                    <div className="relative flex items-center h-3 w-3">
                                      <Calendar
                                        size={11}
                                        className={`text-amber-600 transition-colors ${isCol4Editable ? "cursor-pointer hover:text-amber-800" : "opacity-50"}`}
                                        onClick={(e) => {
                                          if (!isCol4Editable) return;
                                          const input = e.currentTarget.parentElement?.querySelector("input") as HTMLInputElement;
                                          if (input) input.showPicker();
                                        }}
                                      />
                                      <input
                                        type="date"
                                        className={`absolute inset-0 opacity-0 w-3 h-3 ${isCol4Editable ? "cursor-pointer" : "pointer-events-none"}`}
                                        value={currentSentToDhakaDate}
                                        max={currentReturnedFromDhakaDate || undefined}
                                        disabled={!isCol4Editable}
                                        onChange={(e) => {
                                          const val = e.target.value;
                                          if (val && currentReturnedFromDhakaDate && val > currentReturnedFromDhakaDate) {
                                            setValidationErrorMap((prev) => ({
                                              ...prev,
                                              [entry.id]: "ঢাকায় প্রেরণের তারিখ ঢাকা হতে ফেরত তারিখের পরের হতে পারবে না।",
                                            }));
                                            return;
                                          }
                                          handleInlineChange(entry.id, "sentToDhakaDate", val);
                                        }}
                                      />
                                    </div>
                                  </div>
                                </div>

                                {/* ঢাকা হতে ফেরত */}
                                <div className="flex items-center justify-between pt-1 border-t border-amber-200/80">
                                  <div className="text-[9px] font-black text-amber-900 uppercase tracking-tighter flex items-center gap-1">
                                    <RotateCcw size={8} className="text-amber-700" /> ঢাকা হতে ফেরত
                                  </div>
                                  <div className="flex items-center gap-1.5 ml-auto">
                                    {formatDateBN(currentReturnedFromDhakaDate) ? (
                                      <span className="text-[8.5px] font-black text-amber-800 bg-white/90 px-1 py-0.5 rounded border border-amber-300 shadow-2xs">
                                        {formatDateBN(currentReturnedFromDhakaDate)}
                                      </span>
                                    ) : (
                                      <span
                                        className={`text-[8px] font-black ${isCol4Editable ? "text-amber-700 hover:text-amber-900 cursor-pointer" : "text-amber-400"}`}
                                        onClick={(e) => {
                                          if (!isCol4Editable) return;
                                          const input = e.currentTarget.parentElement?.querySelector("input") as HTMLInputElement;
                                          if (input) input.showPicker();
                                        }}
                                      >
                                        তারিখ দিন
                                      </span>
                                    )}
                                    {isCol4Editable && currentReturnedFromDhakaDate && (
                                      <button
                                        type="button"
                                        onClick={() => handleInlineChange(entry.id, "returnedFromDhakaDate", "")}
                                        className="p-0.5 hover:bg-red-100 text-red-400 hover:text-red-600 rounded transition-all ml-0.5"
                                        title="মুছুন"
                                      >
                                        <XCircle size={10} />
                                      </button>
                                    )}
                                    <div className="relative flex items-center h-3 w-3">
                                      <Calendar
                                        size={11}
                                        className={`text-amber-600 transition-colors ${isCol4Editable ? "cursor-pointer hover:text-amber-800" : "opacity-50"}`}
                                        onClick={(e) => {
                                          if (!isCol4Editable) return;
                                          const input = e.currentTarget.parentElement?.querySelector("input") as HTMLInputElement;
                                          if (input) input.showPicker();
                                        }}
                                      />
                                      <input
                                        type="date"
                                        className={`absolute inset-0 opacity-0 w-3 h-3 ${isCol4Editable ? "cursor-pointer" : "pointer-events-none"}`}
                                        value={currentReturnedFromDhakaDate}
                                        min={currentSentToDhakaDate || undefined}
                                        disabled={!isCol4Editable}
                                        onChange={(e) => {
                                          const val = e.target.value;
                                          if (val && currentSentToDhakaDate && val < currentSentToDhakaDate) {
                                            setValidationErrorMap((prev) => ({
                                              ...prev,
                                              [entry.id]: "ঢাকা হতে ফেরত তারিখ ঢাকায় প্রেরণের তারিখের আগের হতে পারবে না।",
                                            }));
                                            return;
                                          }
                                          handleInlineChange(entry.id, "returnedFromDhakaDate", val);
                                        }}
                                      />
                                    </div>
                                  </div>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })()}
                    </td>
                    <td data-inline-col="col5" className={`${tdCls} relative group/col6`}>
                      {(() => {
                        const isRowInlineActive = inlineEditingRowId === entry.id || activeInlineEditingCell?.id === entry.id;
                        const hasCol5Pending = !!(
                          pending.isSettled !== undefined ||
                          pending.issueLetterNo !== undefined ||
                          pending.issueLetterDate !== undefined ||
                          pending.dummyIssueLetterNo !== undefined
                        );
                        const isCol5Editable = isRowInlineActive || hasCol5Pending;
                        const isCol5Locked = !isCol5Editable;

                        return (
                          <div className="flex flex-col justify-between h-full min-h-[175px] space-y-2">
                            <div className={`space-y-2 flex-1 ${isCol5Locked ? 'pointer-events-none' : ''}`}>
                            {(() => {
                              const currentIsSettled =
                                pending.isSettled !== undefined
                                  ? pending.isSettled
                                  : entry.isSettled;

                              // Unlocked when either 'হ্যাঁ' or 'না' is selected
                              const canFillIssue =
                                currentIsSettled === "হ্যাঁ" || currentIsSettled === "না";

                              const isIssueComplete =
                                canFillIssue && !!currentIssueNo && !!currentIssueDate;
                              const issueColorCls = !canFillIssue
                                ? "bg-slate-50 border-slate-200 opacity-80"
                                : isIssueComplete
                                  ? "bg-emerald-600/10 border-emerald-400 ring-2 ring-emerald-50"
                                  : pending.issueLetterNo ||
                                      pending.issueLetterDate
                                    ? "bg-amber-600/10 border-amber-400 ring-2 ring-amber-50"
                                    : "bg-amber-50/50 border-amber-100";

                              const labelColorCls = !canFillIssue
                                ? "text-slate-500"
                                : isIssueComplete
                                  ? "text-emerald-700"
                                  : "text-amber-700";
                              const iconColorCls = !canFillIssue
                                ? "text-slate-400"
                                : isIssueComplete
                                  ? "text-emerald-500"
                                  : "text-amber-500";

                              return (
                                <>
{/* ৬ নং কলামের একটি সমন্বিত একক ব্লক (Single Card) */}
                                  <div className={`p-2 border rounded-xl space-y-2 transition-all duration-200 bg-gradient-to-br from-white via-slate-50 to-slate-100/80 border-slate-300 shadow-xs ${
                                    isIssueComplete ? "ring-1 ring-emerald-300/80 border-emerald-400" : ""
                                  }`}>
                                    {/* ১. নিষ্পত্তি আছে কিনা: হ্যাঁ অথবা না */}
                                    <div className="flex items-center justify-between gap-1 w-full pb-1 border-b border-slate-200/80 min-h-[22px]">
                                      <span className="text-[7.5px] sm:text-[8px] font-black text-slate-800 tracking-tighter flex items-center gap-0.5 shrink-0 whitespace-nowrap">
                                        <CheckCircle2 size={10} className={currentIsSettled === 'হ্যাঁ' ? "text-emerald-600 animate-pulse" : currentIsSettled === 'না' ? "text-rose-500" : "text-amber-500"} />
                                        নিষ্পত্তি:
                                      </span>
                                      <div className="flex items-center gap-0.5 p-0.5 bg-slate-100/90 rounded-md border border-slate-200/80 shrink-0">
                                        <button
                                          type="button"
                                          disabled={!isCol5Editable}
                                          onClick={() => {
                                            const nextVal = currentIsSettled === 'হ্যাঁ' ? '' : 'হ্যাঁ';
                                            handleInlineChange(entry.id, 'isSettled', nextVal);
                                          }}
                                          className={`py-0.5 px-1 sm:px-1.5 rounded text-[7.5px] sm:text-[8px] font-black transition-all flex items-center justify-center gap-0.5 shrink-0 whitespace-nowrap ${
                                            currentIsSettled === 'হ্যাঁ'
                                              ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-xs ring-1 ring-emerald-400/60'
                                              : 'bg-white text-slate-700 hover:bg-emerald-50 hover:text-emerald-700 border border-slate-200/60'
                                          } ${!isCol5Editable ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer active:scale-95'}`}
                                        >
                                          <Check size={8} strokeWidth={3} className="shrink-0" /> হ্যাঁ
                                        </button>
                                        <button
                                          type="button"
                                          disabled={!isCol5Editable}
                                          onClick={() => {
                                            const nextVal = currentIsSettled === 'না' ? '' : 'না';
                                            handleInlineChange(entry.id, 'isSettled', nextVal);
                                          }}
                                          className={`py-0.5 px-1 sm:px-1.5 rounded text-[7.5px] sm:text-[8px] font-black transition-all flex items-center justify-center gap-0.5 shrink-0 whitespace-nowrap ${
                                            currentIsSettled === 'না'
                                              ? 'bg-gradient-to-r from-rose-600 to-red-600 text-white shadow-xs ring-1 ring-rose-400/60'
                                              : 'bg-white text-slate-700 hover:bg-rose-50 hover:text-rose-700 border border-slate-200/60'
                                          } ${!isCol5Editable ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer active:scale-95'}`}
                                        >
                                          <X size={8} strokeWidth={3} className="shrink-0" /> না
                                        </button>
                                      </div>
                                    </div>

                                    {/* View Settled Data Premium Button */}
                                    {currentIsSettled === 'হ্যাঁ' && (
                                      <div className="pt-0.5">
                                        <button
                                          type="button"
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            setViewingSettlementLetter(entry);
                                          }}
                                          className="w-full py-1.5 px-2 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 hover:from-emerald-700 hover:to-teal-800 text-white rounded-lg text-[9.5px] font-black shadow-sm shadow-emerald-600/20 hover:shadow-md transition-all flex items-center justify-center gap-1.5 active:scale-95 border border-emerald-400/40 group cursor-pointer"
                                          title="সংশ্লিষ্ট চিঠির বিস্তারিত নিষ্পন্ন ও অনুচ্ছেদ তথ্য দেখুন"
                                        >
                                          <Sparkles size={11} className="text-amber-300 animate-pulse shrink-0" />
                                          <span className="truncate">মীমাংসিত ডাটা দেখুন</span>
                                          {(() => {
                                            const matched = findMatchedSettlements(entry, settlementEntries || []);
                                            const count = matched.reduce((acc, s) => acc + (s.paragraphs?.length || 1), 0);
                                            return count > 0 ? (
                                              <span className="bg-white/25 text-white text-[8px] px-1 py-0.2 rounded font-extrabold border border-white/30 shrink-0">
                                                {toBengaliDigits(count)}টি
                                              </span>
                                            ) : null;
                                          })()}
                                        </button>
                                      </div>
                                    )}

                                    {/* Notifications */}
                                    {(() => {
                                      if (validationErrorMap[entry.id]) {
                                        return (
                                          <div className="text-[8.5px] font-black text-rose-950 bg-gradient-to-r from-rose-100 via-rose-50 to-red-50 border border-rose-400 rounded-lg p-1.5 flex items-center justify-between leading-tight animate-in zoom-in-95 duration-300 shadow-xs ring-1 ring-rose-300">
                                            <div className="flex items-center gap-1">
                                              <AlertCircle size={12} className="text-rose-600 shrink-0 animate-bounce" />
                                              <span className="text-rose-950 font-extrabold">
                                                {validationErrorMap[entry.id]}
                                              </span>
                                            </div>
                                            <span className="text-[7.5px] font-black text-white bg-rose-600 px-1 py-0.5 rounded-md shadow-2xs shrink-0">
                                              ব্যর্থ
                                            </span>
                                          </div>
                                        );
                                      }

                                      if (recentlyUpdatedMap[entry.id]) {
                                        return (
                                          <div className="text-[8.5px] font-black text-emerald-950 bg-gradient-to-r from-emerald-100 via-teal-100 to-emerald-50 border border-emerald-400 rounded-lg p-1.5 flex items-center justify-between leading-tight animate-in zoom-in-95 duration-300 shadow-xs ring-1 ring-emerald-300/80">
                                            <div className="flex items-center gap-1">
                                              <CheckCircle2 size={12} className="text-emerald-600 shrink-0 animate-bounce" />
                                              <span className="text-emerald-900 font-extrabold">
                                                আপডেট সম্পন্ন হয়েছে! ({currentIsSettled})
                                              </span>
                                            </div>
                                            <span className="text-[7.5px] font-black text-emerald-800 bg-emerald-200/90 px-1 py-0.5 rounded-md shadow-2xs border border-emerald-300 shrink-0">
                                              সফল
                                            </span>
                                          </div>
                                        );
                                      }

                                      if (unsettledClickNoticeMap[entry.id]) {
                                        return (
                                          <div className="text-[8px] font-black text-amber-900 bg-amber-100/90 border border-amber-300 rounded-lg p-1.5 flex items-center gap-1.5 leading-tight animate-in zoom-in-95 duration-200 shadow-xs ring-1 ring-amber-300">
                                            <AlertTriangle size={12} className="text-amber-600 shrink-0 animate-bounce" />
                                            <span>নিষ্পত্তি 'হ্যাঁ' বা 'না' সিলেক্ট না করা পর্যন্ত জারিপত্র নং ও তারিখ ফিলাপ হবে না।</span>
                                          </div>
                                        );
                                      }

                                      if (
                                        isSfiEntry &&
                                        (!currentSentToDhakaDate || !currentReturnedFromDhakaDate) &&
                                        (dhakaNoticeMap[entry.id] || ((currentIssueNo || currentIssueDate) && canFillIssue))
                                      ) {
                                        return (
                                          <div className="text-[8px] font-black text-amber-950 bg-gradient-to-r from-amber-100 via-amber-50 to-orange-50 border border-amber-400 rounded-lg p-1.5 flex items-center gap-1.5 leading-tight animate-in zoom-in-95 duration-200 shadow-xs ring-1 ring-amber-300">
                                            <AlertTriangle size={12} className="text-amber-600 shrink-0 animate-bounce" />
                                            <span>চিঠিটি এখনো ঢাকায় প্রেরণ বা ঢাকা হতে ফেরত আসেনি।</span>
                                          </div>
                                        );
                                      }

                                      return null;
                                    })()}

                                    {/* ২. জারিপত্র নং ও তারিখ */}
                                    {(() => {
                                      const rawIssueDigits = toEnglishDigits(currentIssueNo || '').replace(/[^\d]/g, '');
                                      const is100Entered = rawIssueDigits === '100';
                                      const hasDummyTag = (currentIssueNo || '').includes('ডামি') || (currentIssueNo || '').includes('dummy');
                                      const showDummyPrompt = isCol5Editable && canFillIssue && is100Entered && !hasDummyTag && !dummyDeclinedMap[entry.id];

                                      return (
                                        <div
                                          onClick={() => {
                                            if (!canFillIssue) triggerUnsettledNotice(entry.id);
                                            if (isSfiEntry && (!currentSentToDhakaDate || !currentReturnedFromDhakaDate)) {
                                              triggerDhakaNotice(entry.id);
                                            }
                                          }}
                                          className="space-y-1.5 pt-0.5"
                                        >
                                          {/* জারিপত্র নং সারি */}
                                          <div className="flex items-center gap-1">
                                            <div
                                              className={`text-[7.5px] sm:text-[8.5px] font-bold uppercase tracking-tight flex items-center gap-0.5 shrink-0 ${labelColorCls}`}
                                            >
                                              <Hash size={8} /> জারিপত্র নং:
                                            </div>
                                            <div className="flex-1 flex items-center gap-0.5 min-w-0">
                                              <input
                                                type="text"
                                                placeholder={canFillIssue ? "নং লিখুন" : "নিষ্পত্তি বাছুন"}
                                                className={`w-full h-4.5 sm:h-5 px-1 border border-slate-200 rounded text-[8px] sm:text-[9px] font-bold outline-none ${
                                                  !canFillIssue || !isCol5Editable
                                                    ? "bg-slate-100/80 text-slate-400 cursor-pointer opacity-75"
                                                    : "bg-white focus:border-emerald-400"
                                                }`}
                                                value={canFillIssue ? currentIssueNo : ""}
                                                disabled={!isCol5Editable || !canFillIssue}
                                                onClick={() => {
                                                  if (!canFillIssue) triggerUnsettledNotice(entry.id);
                                                  if (isSfiEntry && (!currentSentToDhakaDate || !currentReturnedFromDhakaDate)) {
                                                    triggerDhakaNotice(entry.id);
                                                  }
                                                }}
                                                onFocus={() => {
                                                  if (isSfiEntry && (!currentSentToDhakaDate || !currentReturnedFromDhakaDate)) {
                                                    triggerDhakaNotice(entry.id);
                                                  }
                                                }}
                                                title={!canFillIssue ? "নিষ্পত্তি 'হ্যাঁ' বা 'না' সিলেক্ট না করা পর্যন্ত জারিপত্র নং ও তারিখ ফিলাপ হবে না।" : ""}
                                                onChange={(e) => {
                                                  if (isSfiEntry && (!currentSentToDhakaDate || !currentReturnedFromDhakaDate)) {
                                                    triggerDhakaNotice(entry.id);
                                                  }
                                                  if (dummyDeclinedMap[entry.id]) {
                                                    setDummyDeclinedMap((prev) => {
                                                      const next = { ...prev };
                                                      delete next[entry.id];
                                                      return next;
                                                    });
                                                  }
                                                  handleInlineChange(
                                                    entry.id,
                                                    "issueLetterNo",
                                                    toBengaliDigits(e.target.value),
                                                  );
                                                }}
                                              />
                                              {hasDummyTag && (
                                                <span
                                                  className="px-1 py-0.2 bg-amber-100 text-amber-900 border border-amber-300 rounded text-[7px] font-black tracking-tight shrink-0 shadow-2xs animate-in zoom-in-95 duration-150"
                                                  title="ডামি জারিপত্র নম্বর"
                                                >
                                                  (ডামি)
                                                </span>
                                              )}
                                              {currentIssueComment && (
                                                <button
                                                  type="button"
                                                  onClick={(e) => {
                                                    e.stopPropagation();
                                                    setSelectedCommentText(currentIssueComment);
                                                  }}
                                                  className="text-amber-500 hover:text-amber-600 active:scale-95 p-0.5 rounded transition-all animate-pulse shrink-0 cursor-pointer"
                                                  title="মন্তব্য দেখুন"
                                                >
                                                  <MessageSquare size={10} fill="currentColor" className="text-amber-500" />
                                                </button>
                                              )}
                                              {isCol5Editable && (
                                                <button
                                                  type="button"
                                                  onClick={(e) => {
                                                    e.stopPropagation();
                                                    setEditingCommentId(editingCommentId === entry.id ? null : entry.id);
                                                  }}
                                                  className={`${editingCommentId === entry.id ? 'text-blue-600' : 'text-slate-400 hover:text-blue-500'} p-0.5 rounded transition-colors shrink-0 cursor-pointer`}
                                                  title="মন্তব্য লিখুন/সম্পাদনা করুন"
                                                >
                                                  <Edit3 size={10} />
                                                </button>
                                              )}
                                              {/* ডামি ট্যাগ বাটন */}
                                              {canFillIssue && is100Entered && !hasDummyTag && !dummyDeclinedMap[entry.id] && (
                                                <button
                                                  type="button"
                                                  onClick={(e) => {
                                                    e.stopPropagation();
                                                    const newNo = `${currentIssueNo || ''} (ডামি)`;
                                                    handleInlineChange(entry.id, "issueLetterNo", newNo);
                                                  }}
                                                  className="px-1.5 py-0.5 bg-amber-500 hover:bg-amber-600 text-white rounded text-[8px] font-black animate-bounce shadow-xs flex items-center gap-0.5 shrink-0 whitespace-nowrap cursor-pointer z-10"
                                                  title="জারিপত্র নম্বরের সাথে '(ডামি)' যুক্ত করুন"
                                                >
                                                  ডামি?
                                                </button>
                                              )}
                                            </div>
                                          </div>

                                          {/* ডামি জারিপত্র নং প্রম্পট মেসেজ (১০০ এন্ট্রি দিলে) */}
                                          {showDummyPrompt && (
                                            <div className="p-1.5 bg-gradient-to-r from-amber-50 via-orange-50 to-amber-100/90 border border-amber-300 rounded-lg flex items-center justify-between gap-1 shadow-xs animate-in zoom-in-95 duration-150 ring-1 ring-amber-200">
                                              <div className="flex items-center gap-1 text-[8px] font-black text-amber-950 leading-tight">
                                                <HelpCircle size={10} className="text-amber-600 shrink-0 animate-bounce" />
                                                <span>এটি কি ডামি জারিপত্র নং?</span>
                                              </div>
                                              <div className="flex items-center gap-1 shrink-0">
                                                <button
                                                  type="button"
                                                  onClick={(e) => {
                                                    e.stopPropagation();
                                                    handleInlineChange(entry.id, "issueLetterNo", "১০০ (ডামি)");
                                                  }}
                                                  className="px-1.5 py-0.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded text-[7.5px] font-black flex items-center gap-0.5 shadow-2xs transition-all cursor-pointer"
                                                  title="হ্যাঁ, এটি ডামি জারিপত্র নং"
                                                >
                                                  <Check size={8} strokeWidth={3} /> হ্যাঁ
                                                </button>
                                                <button
                                                  type="button"
                                                  onClick={(e) => {
                                                    e.stopPropagation();
                                                    setDummyDeclinedMap((prev) => ({ ...prev, [entry.id]: true }));
                                                  }}
                                                  className="px-1.5 py-0.5 bg-rose-500 hover:bg-rose-600 active:scale-95 text-white rounded text-[7.5px] font-black flex items-center gap-0.5 shadow-2xs transition-all cursor-pointer"
                                                  title="না, এটি সাধারণ জারিপত্র নং"
                                                >
                                                  <X size={8} strokeWidth={3} /> না
                                                </button>
                                              </div>
                                            </div>
                                          )}

                                          {isCol5Editable && editingCommentId === entry.id && (
                                            <div className="pt-1 border-t border-dashed border-slate-200 space-y-1">
                                              <div className="text-[7.5px] font-bold text-slate-400">মন্তব্য লিখুন:</div>
                                              <input
                                                type="text"
                                                placeholder="ডামি জারিপত্র নং-এর কারণ"
                                                className="w-full h-4.5 sm:h-5 px-1 border border-slate-200 rounded text-[8px] sm:text-[9px] font-bold outline-none bg-slate-50 focus:bg-white focus:border-blue-400"
                                                value={currentIssueComment}
                                                onChange={(e) =>
                                                  handleInlineChange(
                                                    entry.id,
                                                    "issueLetterComment",
                                                    e.target.value,
                                                  )
                                                }
                                              />
                                            </div>
                                          )}

                                          {/* জারিপত্র তারিখ সারি */}
                                          <div className="pt-1 border-t border-slate-200/70 flex items-center gap-1">
                                            <div
                                              className={`text-[7.5px] sm:text-[8.5px] font-bold uppercase tracking-tight flex items-center gap-0.5 shrink-0 ${labelColorCls}`}
                                            >
                                              <Calendar size={8} /> জারিপত্র তারিখ:
                                            </div>
                                            <div
                                              onClick={(e) => {
                                                if (!isCol5Editable || !canFillIssue) {
                                                  triggerUnsettledNotice(entry.id);
                                                  return;
                                                }
                                                if (isSfiEntry && (!currentSentToDhakaDate || !currentReturnedFromDhakaDate)) {
                                                  triggerDhakaNotice(entry.id);
                                                }
                                                const input = e.currentTarget.querySelector("input") as HTMLInputElement;
                                                if (input) {
                                                  try {
                                                    if (typeof input.showPicker === 'function') input.showPicker();
                                                    else input.focus();
                                                  } catch {
                                                    input.focus();
                                                  }
                                                }
                                              }}
                                              className={`relative flex-1 h-4.5 sm:h-5 px-1 border border-slate-200 rounded flex items-center justify-between text-[8px] sm:text-[9px] font-bold transition-all min-w-0 ${
                                                !canFillIssue || !isCol5Editable
                                                  ? "bg-slate-100/80 text-slate-400 cursor-pointer opacity-75"
                                                  : "bg-white hover:border-emerald-400 cursor-pointer shadow-2xs"
                                              }`}
                                            >
                                              <span
                                                className={`truncate ${
                                                  canFillIssue && formatDateBN(currentIssueDate)
                                                    ? isIssueComplete
                                                      ? "text-emerald-700 font-bold"
                                                      : "text-amber-700 font-bold"
                                                    : "text-slate-400"
                                                }`}
                                              >
                                                {canFillIssue && formatDateBN(currentIssueDate) ? formatDateBN(currentIssueDate) : "বাছুন..."}
                                              </span>
                                              <div className="flex items-center gap-0.5 shrink-0 ml-0.5">
                                                {isCol5Editable && canFillIssue && currentIssueDate && (
                                                  <button
                                                    type="button"
                                                    onClick={(e) => {
                                                      e.stopPropagation();
                                                      handleInlineChange(entry.id, "issueLetterDate", "");
                                                    }}
                                                    className="p-0.5 hover:bg-red-100 text-red-400 hover:text-red-600 rounded transition-all z-20 cursor-pointer"
                                                    title="তারিখ মুছুন"
                                                  >
                                                    <XCircle size={9} />
                                                  </button>
                                                )}
                                                <Calendar
                                                  size={9}
                                                  className={`${iconColorCls} shrink-0 transition-colors ${
                                                    isCol5Editable && canFillIssue ? "hover:opacity-80" : "opacity-40"
                                                  }`}
                                                />
                                              </div>
                                              <input
                                                type="date"
                                                className={`absolute inset-0 opacity-0 w-full h-full ${isCol5Editable && canFillIssue ? 'cursor-pointer z-10' : 'pointer-events-none'}`}
                                                value={canFillIssue ? currentIssueDate : ""}
                                                disabled={!isCol5Editable || !canFillIssue}
                                                onChange={(e) => {
                                                  if (isSfiEntry && (!currentSentToDhakaDate || !currentReturnedFromDhakaDate)) {
                                                    triggerDhakaNotice(entry.id);
                                                  }
                                                  handleInlineChange(
                                                    entry.id,
                                                    "issueLetterDate",
                                                    e.target.value,
                                                  );
                                                }}
                                              />
                                            </div>
                                          </div>
                                        </div>
                                      );
                                    })()}
                                  </div>
                                  </>
                                );
                              })()}
                            </div>
                          </div>
                        );
                      })()}
                    </td>
                        <td
                          className={
                            tdCls + " relative group/action text-center"
                          }
                        >
                          <span className="text-[9px] opacity-70 font-bold">
                            {entry.remarks || "-"}
                          </span>
                          {isAdmin && (
                            <div className={`flex flex-col items-center gap-1 no-print mt-2 transition-opacity duration-300 ${inlineEditingRowId === entry.id || pendingChanges[entry.id] ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
                              {pendingChanges[entry.id] && (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    saveRowChanges(entry.id);
                                  }}
                                  className="p-1.5 bg-emerald-600 text-white rounded-md shadow-md hover:bg-emerald-700 transition-all animate-bounce cursor-pointer"
                                  title="আপডেট করুন"
                                >
                                  <Save size={12} />
                                </button>
                              )}
                              {isPendingForApproval && (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onApprove?.(entry.id);
                                  }}
                                  className="p-1.5 bg-emerald-500 text-white rounded-md shadow-md hover:bg-emerald-600 transition-colors cursor-pointer"
                                  title="অনুমোদন দিন"
                                >
                                  <Check size={12} strokeWidth={3} />
                                </button>
                              )}
                              {isPendingForApproval && (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onReject?.(entry.id);
                                  }}
                                  className="p-1.5 bg-red-500 text-white rounded-md shadow-md hover:bg-red-600 transition-colors cursor-pointer"
                                  title="বাতিল করুন"
                                >
                                  <XCircle size={12} />
                                </button>
                              )}
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onEdit?.(entry);
                                }}
                                className="p-1.5 bg-blue-600 text-white rounded-md shadow-md hover:bg-blue-700 transition-colors cursor-pointer"
                                title="সম্পূর্ণ তথ্য এডিট করুন"
                              >
                                <Pencil size={12} />
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  const rect = e.currentTarget.getBoundingClientRect();
                                  setDeleteConfirm({
                                    id: entry.id,
                                    x: rect.right,
                                    y: rect.top
                                  });
                                }}
                                className="p-1.5 rounded-md shadow-md bg-rose-600 text-white hover:bg-rose-700 transition-all duration-300 cursor-pointer"
                                title="মুছে ফেলুন"
                              >
                                <Trash2 size={12} />
                              </button>
                              <div className="relative">
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    const hasPending = !!pendingChanges[entry.id];
                                    if (inlineEditingRowId === entry.id) {
                                      if (hasPending) {
                                        // Show warning that changes have not been updated yet
                                        setUncommittedWarningId(entry.id);
                                        setTimeout(() => {
                                          setUncommittedWarningId((prev) => (prev === entry.id ? null : prev));
                                        }, 4000);
                                        return;
                                      }
                                      setInlineEditingRowId(null);
                                    } else {
                                      setInlineEditingRowId(entry.id);
                                      setUncommittedWarningId(null);
                                    }
                                  }}
                                  className={`p-1.5 rounded-md shadow-md transition-all duration-300 cursor-pointer ${
                                    inlineEditingRowId === entry.id
                                      ? "bg-amber-600 ring-2 ring-amber-300 text-white scale-105"
                                      : "bg-amber-500 hover:bg-amber-600 text-white"
                                  }`}
                                  title={inlineEditingRowId === entry.id ? "লক করুন (সম্পাদনা বন্ধ)" : "এই সারির তথ্য এন্ট্রি/এডিট করুন (কলাম ৫ ও ৬)"}
                                >
                                  <Edit3 size={12} />
                                </button>

                                {/* আপডেট না করে লক করতে চাইলে ডিজাইনকৃত ইনলাইন মেসেজ */}
                                {uncommittedWarningId === entry.id && (
                                  <div className="absolute right-full top-1/2 -translate-y-1/2 mr-2 z-50 w-48 p-2 bg-gradient-to-r from-amber-500 to-rose-600 text-white rounded-lg shadow-xl border border-white/40 text-left animate-in fade-in zoom-in duration-200">
                                    <div className="flex items-start gap-1.5">
                                      <AlertCircle size={14} className="shrink-0 mt-0.5 text-amber-200 animate-pulse" />
                                      <div>
                                        <div className="text-[10px] font-black leading-tight">আপনি এখনো আপডেট করেননি!</div>
                                        <div className="text-[8.5px] opacity-90 leading-tight mt-0.5">সবুজ সেভ (Save) বাটনে ক্লিক করে আপডেট সম্পন্ন করুন।</div>
                                      </div>
                                    </div>
                                    <div className="absolute -right-1 top-1/2 -translate-y-1/2 w-2 h-2 bg-rose-600 rotate-45 border-r border-t border-white/40"></div>
                                  </div>
                                )}
                              </div>
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                  {/* Cycle Total Row */}
                  <tr className="bg-slate-50/80 font-black border-t-2 border-slate-400 h-[38px] no-print">
                    <td
                      colSpan={2}
                      className="px-4 text-left italic text-[11px] text-blue-900 border border-slate-300"
                    >
                      মোট:{" "}
                      <span className="text-emerald-700">
                        {toBengaliDigits(group.entries.length)} টি চিঠি
                      </span>
                    </td>
                    <td className="px-2 text-center border border-slate-300 text-blue-700 text-[11px]">
                      {toBengaliDigits(group.entries.length)} টি
                    </td>
                    <td
                      colSpan={4}
                      className="border border-slate-300 bg-slate-50/30"
                    ></td>
                  </tr>
                </tbody>
              ));
            })()
          ) : (
            <tbody>
              {/* Invisible baseline row to secure table-layout fixed column widths when empty */}
              <tr className="h-0 p-0 border-0 pointer-events-none select-none invisible">
                <td className="p-0 border-0 h-0"></td>
                <td className="p-0 border-0 h-0"></td>
                <td className="p-0 border-0 h-0"></td>
                <td className="p-0 border-0 h-0"></td>
                <td className="p-0 border-0 h-0"></td>
                <td className="p-0 border-0 h-0"></td>
                <td className="p-0 border-0 h-0"></td>
              </tr>
              <tr>
                <td colSpan={7} className="py-20 text-center bg-white">
                  <div className="flex flex-col items-center gap-3 opacity-30">
                    <Mail size={40} />
                    <p className="text-sm font-black text-slate-900 tracking-widest">
                      রেজিস্টার খালি
                    </p>
                  </div>
                </td>
              </tr>
            </tbody>
          )}
          <tfoot className="sticky bottom-0 z-[110]">
            <tr className="bg-slate-200 text-slate-900 font-black text-[12px] h-10 shadow-[0_-4px_10px_rgba(0,0,0,0.05)] border-t border-slate-300">
              <td
                colSpan={2}
                className="px-4 text-left border-t border-slate-300 bg-slate-200 text-slate-900 shadow-[inset_0_1px_0_rgba(255,255,255,0.5)]"
              >
                সর্বমোট (ফিল্টার ডাটা):
              </td>
              <td
                colSpan={1}
                className="px-2 text-center border-t border-slate-300 bg-slate-200 text-blue-700 shadow-[inset_0_1px_0_rgba(255,255,255,0.5)] font-black"
              >
                {toBengaliDigits(filteredEntries.length)} টি
              </td>
              <td
                colSpan={4}
                className="border-t border-slate-300 bg-slate-200 shadow-[inset_0_1px_0_rgba(255,255,255,0.5)]"
              ></td>
            </tr>
          </tfoot>
        </table>
      </div>
        </>
      )}

      {deleteConfirm && createPortal(
        <>
          {/* Backdrop Click Catcher */}
          <div 
            className="fixed inset-0 z-[29999] bg-transparent cursor-default"
            onClick={() => setDeleteConfirm(null)}
          />
          
          {/* Popover */}
          <div 
            onClick={(e) => e.stopPropagation()}
            className="fixed z-[30000] w-72 p-4 bg-white border-2 border-rose-200 rounded-2xl shadow-[0_15px_40px_rgba(244,63,94,0.18)] text-left animate-in zoom-in-95 fade-in duration-200"
            style={{ 
              left: `${deleteConfirm.x}px`,
              top: `${deleteConfirm.y - 12}px`,
              transform: 'translateX(-100%) translateY(-100%)',
              transformOrigin: "bottom right"
            }}
          >
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-rose-50 flex items-center justify-center shrink-0 border border-rose-100 animate-bounce">
                <AlertTriangle size={16} className="text-rose-600" />
              </div>
              <div className="space-y-1">
                <p className="text-[12px] font-black text-slate-800 leading-tight">
                  তথ্য মুছে ফেলার অবগতি
                </p>
                <p className="text-[10px] font-medium text-slate-500 leading-relaxed">
                  আপনি কি নিশ্চিতভাবে এই তথ্যটি মুছে ফেলতে চান? এটি আর ফিরিয়ে আনা যাবে না।
                </p>
              </div>
            </div>
            
            <div className="flex items-center justify-end gap-2 mt-4 pt-3 border-t border-slate-100">
              <button
                onClick={() => setDeleteConfirm(null)}
                className="px-3 py-1.5 text-[10px] text-slate-500 font-extrabold hover:text-slate-800 bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-200/60 transition-all cursor-pointer"
              >
                না, বাতিল
              </button>
              <button
                onClick={() => {
                  const idToDelete = deleteConfirm.id;
                  setDeleteConfirm(null);
                  setDeletingId(idToDelete);
                  setTimeout(() => {
                    onDelete?.(idToDelete);
                    setDeletingId(null);
                  }, 1000);
                }}
                className="px-3.5 py-1.5 text-[10px] text-white font-extrabold bg-rose-600 hover:bg-rose-700 active:scale-95 rounded-lg shadow-sm shadow-rose-500/10 transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 size={10} />
                <span>হ্যাঁ, নিশ্চিত</span>
              </button>
            </div>
            
            {/* Small arrow down to the clicked button */}
            <div className="absolute top-full right-4 -translate-y-1 w-2.5 h-2.5 bg-white border-r-2 border-b-2 border-rose-200 rotate-45"></div>
          </div>
        </>,
        document.body
      )}

      {selectedCommentText !== null && createPortal(
        <div className="fixed inset-0 z-[40000] flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm cursor-default"
            onClick={() => setSelectedCommentText(null)}
          />
          
          <div 
            className="relative z-10 w-full max-w-md p-6 bg-white border border-slate-100 rounded-2xl shadow-2xl animate-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center shrink-0">
                  <MessageSquare size={18} className="text-amber-600 fill-amber-100" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-800 tracking-tight leading-none">
                    জারিপত্র সংক্রান্ত মন্তব্য
                  </h3>
                  <p className="text-[10px] font-bold text-slate-400 mt-1 uppercase tracking-wider">
                    জারিপত্র তথ্য অবগতি
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedCommentText(null)}
                className="text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg p-1 transition-colors"
              >
                <X size={16} />
              </button>
            </div>
            
            <div className="mt-4 p-4 bg-amber-50/40 border border-amber-100/70 rounded-xl">
              <p className="text-xs font-bold text-slate-700 leading-relaxed whitespace-pre-wrap">
                {selectedCommentText}
              </p>
            </div>
            
            <div className="flex justify-end mt-5 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setSelectedCommentText(null)}
                className="px-5 py-2 text-xs font-black text-white bg-slate-800 hover:bg-slate-900 active:scale-95 rounded-xl shadow-md transition-all cursor-pointer"
              >
                ঠিক আছে
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}

      {/* Settled Data Viewer Modal */}
      {viewingSettlementLetter !== null && (
        <SettledDataModal
          entry={viewingSettlementLetter}
          settlementEntries={settlementEntries}
          onClose={() => setViewingSettlementLetter(null)}
        />
      )}
    </div>
  );
};

export default CorrespondenceTable;
