export type ParaType = 'এসএফআই' | 'নন এসএফআই';
export type SettlementStatus = 'পূর্ণাঙ্গ' | 'আংশিক';
export type FinancialCategory = 'ভ্যাট' | 'আয়কর' | 'অন্যান্য';
export type EntryMode = 'আদায়' | 'সমন্বয়';
export type DesignMode = 'modern' | 'classic';

export interface ArchiveDoc {
  id: string;
  title: string;
  category: 'সার্কুলার' | 'অফিস আদেশ' | 'গেজেট' | 'অন্যান্য';
  archiveId: string; // Archive.org identifier
  docDate: string;
  description: string;
  createdAt: string;
}

export interface MinistryPrevStats {
  unsettledCount: number;
  unsettledAmount: number;
  unsettledQuarterlyAmount?: number;
  recoveryAdjustmentQuarterlyCount?: number;
  recoveryAdjustmentQuarterlyAmount?: number;
  settledCount: number;
  settledAmount: number;
  // Half-Yearly Opening Balance Fields
  halfYearlyPrevUnsettledCount?: number;
  halfYearlyPrevUnsettledAmount?: number | string;
  halfYearlyRaisedCount?: number;
  halfYearlyRaisedAmount?: number | string;
  halfYearlySettledCount?: number;
  halfYearlySettledAmount?: number | string;
  // Yearly Opening Balance Fields
  yearlyPrevUnsettledCount?: number;
  yearlyPrevUnsettledAmount?: number | string;
  yearlySettledCount?: number;
  yearlySettledAmount?: number | string;
}

export interface CumulativeStats {
  inv: number;
  vRec: number; vAdj: number;
  iRec: number; iAdj: number;
  oRec: number; oAdj: number;
  entitiesSFI: Record<string, MinistryPrevStats>;
  entitiesNonSFI: Record<string, MinistryPrevStats>;
}

export interface ParagraphDetail {
  id: string;
  paraNo: string;
  status: SettlementStatus;
  involvedAmount: number;   
  recoveredAmount: number;  
  adjustedAmount: number;   
  category: FinancialCategory; 
  isAdvanced: boolean;
  vatRec: number;
  vatAdj: number;
  itRec: number;
  itAdj: number;
  othersRec: number;
  othersAdj: number;
}

export interface SettlementEntry {
  id: string;
  sl: number;
  ministryName: string;
  entityName: string;
  branchName: string;
  auditYear: string;
  letterNoDate: string;
  workpaperNoDate: string;
  minutesNoDate: string;
  paraType: ParaType;
  paragraphs: ParagraphDetail[];
  involvedAmount: number;
  vatRec: number;
  vatAdj: number;
  itRec: number;
  itAdj: number;
  othersRec: number;
  othersAdj: number;
  totalRec: number;
  totalAdj: number;
  issueLetterNoDate: string;
  issueDateISO?: string; 
  cycleLabel?: string;   
  actualEntryDate?: string; 
  isLate?: boolean; 
  createdAt: string; 
  manualRaisedCount?: string | null;
  manualRaisedAmount?: number | null;
  isMeeting?: boolean;
  meetingType?: string;
  meetingResponseDate?: string;
  meetingDate?: string;
  meetingSentParaCount?: string;
  sentParaInvolvedAmount?: number;
  meetingDiscussedParaCount?: string;
  meetingRecommendedParaCount?: string; 
  meetingSettledParaCount?: string;
  meetingFullSettledParaCount?: string;
  meetingPartialSettledParaCount?: string;
  meetingUnsettledParas?: string;
  meetingUnsettledAmount?: number;
  archiveNo?: string;
  digitalFileNo?: string;
  meetingWorkpaper?: string;
  meetingMinutes?: string;
  branchReceiptDate?: string;      
  receiverName?: string;           
  isSentOnline?: 'হ্যাঁ' | 'না';    
  presentationDate?: string;       
  presentedToName?: string; // New field for the person to whom it's presented
  remarks?: string;
  approvalStatus?: 'approved' | 'pending';
  userEmail?: string | null;
  correspondenceId?: string;
  letterId?: string;
}

export interface CorrespondenceEntry {
  id: string;
  description: string;
  paraType: string;
  letterType: string;
  letterNo: string;
  letterDate: string;
  totalParas: string;
  totalAmount: string;
  diaryNo: string;
  diaryDate: string;
  receiptDate: string;
  digitalFileNo: string;
  presentationDate: string;
  presentedToName?: string;
  sentParaCount: string;
  receiverName: string;
  receivedDate: string;
  isOnline: string;
  issueLetterNo: string;
  issueLetterDate: string;
  isSettled?: 'হ্যাঁ' | 'না';
  issueLetterComment?: string;
  archiveNo?: string;
  remarks?: string;
  createdAt: string;
  approvalStatus?: 'approved' | 'pending';
  type?: string;
  ministryName?: string;
  entityName?: string;
  auditYear?: string;
  meetingDate?: string;
  meetingDiscussedParaCount?: string;
  meetingRecommendedParaCount?: string;
  sentToDhakaDate?: string;
  returnedFromDhakaDate?: string;
}

export interface GroupOption {
  label: string;
  options: string[];
}

export interface BallotVote {
  id?: string;
  voter_hash: string;
  p1: string; p2: string; p3: string;
  p4: string; p5: string; p6: string;
  p7: string;
  created_at?: string;
}

export interface CandidateResult {
  name: string;
  votes: number;
}

export interface PositionResult {
  title: string;
  id: string;
  results: CandidateResult[];
}

export interface VoterToken {
  id: number;
  token: string;
  is_used: boolean;
  created_at: string;
}

export interface ModuleVisibility {
  entry: boolean;
  register: boolean;
  return: boolean;
  archive: boolean;
  voting: boolean;
  setup_receivers: boolean;
  initial_balance: boolean;
  change_pass: boolean;
  admin_analytics: boolean;
  audit_details: boolean;
  navbar?: boolean;
  links?: boolean;
  cycle_wheel?: boolean;
}
